# Fontes, Consultas e Contexto Jurídico Brasileiro

Leia esta referência ao montar a coleta (etapa COLETA DE DADOS) ou quando precisar fundamentar pedidos ao provedor. Todas as consultas listadas são **passivas** (registro, roteamento, DNS e bases públicas). Registre sempre: fonte, URL, data/hora UTC da consulta e resultado (§71–72 da especificação).

> **Data da consulta ≠ data do evento.** Quase todas as fontes abaixo devolvem o estado **atual**. Para eventos passados, use as fontes históricas marcadas com 🕒 e declare a limitação quando não houver histórico.

---

## 1. Como consultar neste ambiente

1. **Script** — `scripts/ipanalise.py consultar` faz RIPEstat + RDAP + PTR + lista Tor e guarda as respostas brutas com SHA-256. Funciona se o ambiente de execução tiver acesso à internet.
2. **Ferramenta de busca/leitura web do Claude** — se o shell não tiver rede, abra as URLs abaixo com a ferramenta de leitura de páginas e transcreva os campos para um JSON no mesmo formato do `consultar` (campos `ip`, `asn`, `as_nome`, `prefixo`, `organizacao`, `pais`, `ptr`, `hospedagem`, `certificados`, `dominios`, `fontes`), para então rodar `correlacionar`.
3. **Fontes com chave/API paga** — só com chave fornecida pelo usuário; nunca contornar limites ou termos de uso.
4. **Nunca** contornar bloqueio de rede, robots.txt ou paywall.

---

## 2. Registro (RDAP / WHOIS) — confiabilidade NÍVEL 1

| Fonte | Consulta | Observações |
|---|---|---|
| RDAP bootstrap | `https://rdap.org/ip/<IP>` | Redireciona ao RIR/NIR responsável. Preferir RDAP a WHOIS (§4) |
| LACNIC RDAP | `https://rdap.lacnic.net/rdap/ip/<IP>` | América Latina e Caribe |
| **Registro.br (NIC.br)** | `https://rdap.registro.br/ip/<IP>` · `https://registro.br/tecnologia/ferramentas/whois/` | **NIR do Brasil** (sob a LACNIC): blocos alocados a provedores brasileiros, com titular, documento (CNPJ do provedor), contato de abuso e responsável técnico. Pode bloquear leitores automáticos — usar o script ou o navegador |
| ARIN / RIPE NCC / APNIC / AFRINIC | via `rdap.org` | Demais regiões |
| RIPEstat whois | `https://stat.ripe.net/data/whois/data.json?resource=<IP>` | Agrega registros do RIR + IRR |

Lembrete obrigatório: *"O registrante do bloco não necessariamente corresponde ao usuário final do IP."*

---

## 3. Roteamento / ASN / BGP — NÍVEL 2

| Fonte | Consulta | Uso |
|---|---|---|
| RIPEstat prefix-overview | `https://stat.ripe.net/data/prefix-overview/data.json?resource=<IP>` | Prefixo anunciado, ASN de origem, titular do ASN, bloco IANA; múltiplos ASNs → MOAS |
| 🕒 RIPEstat routing-history | `https://stat.ripe.net/data/routing-history/data.json?resource=<IP ou prefixo>` | **Histórico de origens** (ASN × período) — essencial para ANALISE_TEMPORAL e para a data do evento |
| RIPEstat as-overview | `https://stat.ripe.net/data/as-overview/data.json?resource=AS<N>` | Nome e titular do ASN |
| RIPEstat announced-prefixes | `https://stat.ripe.net/data/announced-prefixes/data.json?resource=AS<N>` | Prefixos anunciados pelo ASN (pivô ASN → prefixos) |
| RIPEstat asn-neighbours | `https://stat.ripe.net/data/asn-neighbours/data.json?resource=AS<N>` | Vizinhos (upstreams/peers) — contexto de rede, **não** vínculo entre usuários (§87) |
| Hurricane Electric BGP Toolkit | `https://bgp.he.net/ip/<IP>` · `https://bgp.he.net/AS<N>` | Visão rápida de prefixo, ASN, peers, IX |
| Team Cymru IP→ASN | DNS TXT `<IP invertido>.origin.asn.cymru.com` · whois `whois.cymru.com` | Mapeamento rápido em lote |

---

## 4. DNS / PTR / Domínios — NÍVEL 2

| Fonte | Consulta | Observações |
|---|---|---|
| PTR | `dig -x <IP>` · script `consultar` · `https://stat.ripe.net/data/reverse-dns-ip/data.json?resource=<IP>` | Padrões `dynamic`, `static`, `pool`, `dsl`, `cable`, `mobile`, nomes de cidade/POP → **indícios**, não fatos |
| 🕒 Passive DNS | SecurityTrails, VirusTotal, Validin, CIRCL (acesso autorizado) | Normalmente exige chave; separar domínios **atuais** × **históricos** (§9) |
| Certificate Transparency | `https://crt.sh/?q=<domínio>` | Pivô domínio ↔ certificado (busca por IP é limitada) |

---

## 5. Serviços expostos e certificados (dados de varredura de terceiros) — NÍVEL 3

| Fonte | Consulta | Observações |
|---|---|---|
| Shodan InternetDB | `https://internetdb.shodan.io/<IP>` | Gratuito, sem chave: portas, CPEs, hostnames, tags (ex.: `vpn`, `proxy`, `cloud`), CVEs. Dado **observado por terceiro** em data incerta |
| Shodan / Censys / FOFA / ZoomEye | API com chave | Banners, certificados TLS, histórico de serviços |

A skill **não** faz varredura própria (§14, §112).

---

## 6. Cloud, CDN e hospedagem — NÍVEL 1 (lista publicada pelo próprio provedor)

| Provedor | Lista oficial de faixas |
|---|---|
| AWS | `https://ip-ranges.amazonaws.com/ip-ranges.json` (com região e serviço) |
| Google Cloud | `https://www.gstatic.com/ipranges/cloud.json` (com região) |
| Microsoft Azure | "Azure IP Ranges and Service Tags" (download JSON semanal no Microsoft Download Center) |
| Oracle Cloud | `https://docs.oracle.com/en-us/iaas/tools/public_ip_ranges.json` |
| Cloudflare | `https://www.cloudflare.com/ips-v4` · `https://www.cloudflare.com/ips-v6` |

Para os demais (DigitalOcean, Vultr, Hetzner, OVH, Akamai/Linode, Alibaba, M247, etc.), use ASN + RDAP + PTR. IP em CDN/cloud → aplicar §51 e §101 (multi-tenant; baixo poder de atribuição).

---

## 7. Anonimização (VPN / proxy / Tor) — NÍVEL 2 a 3

| Fonte | Consulta | Observações |
|---|---|---|
| Tor — lista atual | `https://check.torproject.org/torbulkexitlist` | Saídas Tor **neste momento** |
| 🕒 **ExoneraTor** | `https://metrics.torproject.org/exonerator.html?ip=<IP>&timestamp=<AAAA-MM-DD>` | **Havia relay Tor nesse IP nessa data?** — a consulta correta para eventos passados |
| Onionoo | `https://onionoo.torproject.org/details?search=<IP>` | Detalhes de relays atuais/recentes |
| VPN / proxy comerciais | ipinfo (privacy), IPQualityScore, proxycheck.io, Spur (chaves) | Bases privadas e heurísticas → no máximo "Provável" sem confirmação do operador |
| Indícios técnicos | ASN de hospedagem, PTR genérico de datacenter, tags do InternetDB, portas típicas (OpenVPN 1194, WireGuard 51820, IPsec 500/4500) | Indícios — classificar como Possível/Provável (§11, §60) |

---

## 8. Reputação e abuso — NÍVEL 4 (comunitário/agregador)

| Fonte | Observações |
|---|---|
| AbuseIPDB | Relatos comunitários com categoria e data (chave para API) |
| GreyNoise | Distingue varredura em massa/benigna de atividade dirigida |
| Spamhaus (ZEN/DROP) | DNSBL; consultas via resolvedores públicos podem ser recusadas |
| abuse.ch (ThreatFox, URLhaus, Feodo Tracker) | IOCs de malware/C2 |
| VirusTotal, AlienVault OTX | Agregadores (chave) |

Regra §13: *"Nunca afirmar que o proprietário do IP praticou determinado crime apenas porque o IP aparece em uma blacklist."*

---

## 9. Geolocalização — NÍVEL 3 (confiança BAIXA por definição)

RIPEstat `maxmind-geo-lite` (no script), ipinfo, ip-api, IP2Location, DB-IP. Compare ≥ 2 bases e registre divergências (§10, §66). Geolocalização de IP **nunca** é endereço físico; em redes móveis e CGNAT, costuma apontar o POP/cidade do provedor.

---

## 10. Contexto jurídico brasileiro (para os "próximos passos" e "requisitos para atribuição")

> Referência orientativa — verificar vigência e o inteiro teor antes de uso em peça.

| Norma / precedente | Relevância |
|---|---|
| **Marco Civil da Internet (Lei 12.965/2014), Art. 13** | Provedor de **conexão** guarda registros de conexão por **1 ano** |
| **Art. 14** | Provedor de conexão **não pode** guardar registros de acesso a aplicações — o ISP, em regra, não sabe qual site foi acessado |
| **Art. 15** | Provedor de **aplicação** (constituído como pessoa jurídica, com fins econômicos) guarda registros de acesso por **6 meses** |
| **Art. 13 §2º e Art. 15 §2º** | Autoridade policial/administrativa ou MP pode **requerer cautelarmente** a guarda por prazo superior, com pedido judicial em até 60 dias |
| **Art. 22** | Fornecimento de registros mediante **ordem judicial** (indícios, justificativa, período) |
| **Art. 10 §3º + Decreto 8.771/2016, Art. 11** | **Dados cadastrais** (qualificação pessoal, filiação, endereço) podem ser requisitados por autoridades administrativas competentes |
| **Lei 12.850/2013, Art. 15** | Delegado e MP têm acesso a dados cadastrais independentemente de autorização judicial (investigação de organização criminosa) |
| **STJ, REsp 1.784.156/SP (3ª Turma, 2019)** | Provedor de **aplicação** deve fornecer também a **porta lógica de origem** — essencial com CGNAT/IPv4 compartilhado |
| **STJ, REsp 2.170.872 (3ª Turma, 2025)** | Provedor de **conexão** deve identificar o usuário a partir do IP e do horário aproximado, sem exigir prévia indicação da porta lógica; cabe a ele guardar IP e porta |

**Dados normalmente necessários para individualizar uma conexão (§97–98):** IP público, data, hora com segundos, **fuso horário**, **porta de origem** (obrigatória quando há CGNAT), protocolo e, idealmente, o IP/porta de destino. Sem a porta, a resposta do provedor pode listar vários assinantes.

**Canais:** contato de abuso do RDAP/Registro.br (incidente técnico), CERT.br (`cert@cert.br`) para notificação de incidentes, e ofício/representação judicial para dados de assinante.
