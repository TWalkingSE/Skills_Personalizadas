# ESPECIFICAÇÃO — IMPLEMENTAÇÃO DA PLATAFORMA (§122–173)

> Texto integral do autor, continuação da `especificacao_completa.md` (§1–121). Use quando o usuário pedir para construir a aplicação/plataforma ou quando precisar dos detalhes do modelo de dados, interface, cache, auditoria, segredos e política de envio a modelos de IA. O resumo operacional está no SKILL.md (§8).

---

# 122. IMPLEMENTAÇÃO DA PLATAFORMA

A skill deve ser projetada para poder ser implementada como uma aplicação de análise de infraestrutura de rede, preferencialmente utilizando:

* Python;
* Streamlit para interface;
* banco SQLite inicialmente;
* possibilidade de evolução para PostgreSQL;
* NetworkX para análise de grafos;
* PyVis, Cytoscape.js ou biblioteca equivalente para visualização;
* Pandas para análise tabular;
* Plotly para gráficos e timeline;
* Pydantic para validação dos objetos;
* JSON para intercâmbio e exportação.

A arquitetura deve separar:

```text
INTERFACE
     ↓
ORQUESTRADOR
     ↓
MÓDULOS DE COLETA
     ↓
NORMALIZAÇÃO
     ↓
MODELO DE DADOS
     ↓
CORRELAÇÃO
     ↓
GRAFO
     ↓
ANÁLISE
     ↓
RELATÓRIO / EXPORTAÇÃO
```

---

# 123. PRINCÍPIO DE ARQUITETURA

Não implementar toda a lógica em um único arquivo.

Utilizar módulos independentes.

Estrutura sugerida:

```text
ip_intelligence/
│
├── app.py
│
├── config/
│   └── settings.py
│
├── models/
│   ├── case.py
│   ├── entity.py
│   ├── relationship.py
│   ├── observation.py
│   ├── event.py
│   └── evidence.py
│
├── collectors/
│   ├── rdap.py
│   ├── whois.py
│   ├── bgp.py
│   ├── dns.py
│   ├── reputation.py
│   ├── geolocation.py
│   ├── certificates.py
│   └── passive_dns.py
│
├── analysis/
│   ├── correlation.py
│   ├── clustering.py
│   ├── scoring.py
│   ├── temporal.py
│   ├── outliers.py
│   ├── attribution.py
│   └── pivots.py
│
├── graph/
│   ├── builder.py
│   ├── metrics.py
│   └── export.py
│
├── reports/
│   ├── report.py
│   ├── markdown.py
│   ├── html.py
│   └── pdf.py
│
├── database/
│   ├── repository.py
│   └── sqlite.py
│
└── utils/
    ├── normalization.py
    ├── validation.py
    └── timestamps.py
```

---

# 124. MODELO DE DADOS

O modelo central deve possuir quatro objetos principais:

```text
CASE
ENTITY
RELATIONSHIP
OBSERVATION
```

Não armazenar simplesmente:

```text
IP → ASN
```

Armazenar:

```text
IP
 ↓
RELATIONSHIP
 ↓
ASN
 ↓
OBSERVATION
 ↓
fonte + data + validade + confiança
```

Isso permite reconstruir o estado da infraestrutura em determinado momento.

---

# 125. ENTITY

Toda entidade deve possuir identificador único.

Exemplo:

```json
{
  "id": "ip:200.100.10.20",
  "type": "ip",
  "value": "200.100.10.20",
  "label": "200.100.10.20"
}
```

Tipos possíveis:

```text
ip
ipv4
ipv6
asn
prefix
organization
isp
domain
subdomain
hostname
certificate
nameserver
url
email
phone
event
provider
datacenter
vpn
proxy
tor
user_agent
fingerprint
```

Não criar entidades duplicadas para o mesmo identificador normalizado.

---

# 126. RELATIONSHIP

Relacionamentos devem ser objetos independentes.

Exemplo:

```json
{
  "id": "rel:001",
  "source": "ip:200.100.10.20",
  "target": "asn:12345",
  "type": "originated_by"
}
```

Tipos:

```text
originated_by
belongs_to
announced_by
operated_by
owned_by
resolves_to
reverse_resolves_to
associated_with
hosted_on
uses_certificate
shares_certificate
shares_prefix
shares_asn
shares_organization
related_to
observed_with
appears_in
```

---

# 127. OBSERVATION

Toda relação importante deve possuir observações.

Exemplo:

```json
{
  "id": "obs:001",
  "relationship_id": "rel:001",
  "value": "AS12345",
  "source": "BGP",
  "source_url": "",
  "observed_at": "2026-10-07T12:30:00Z",
  "valid_from": null,
  "valid_until": null,
  "confidence": 0.98
}
```

Separar:

### observed_at

Quando a informação foi consultada/observada.

### valid_from

Quando a relação passou a ser válida, se conhecido.

### valid_until

Quando deixou de ser válida, se conhecido.

Isso é essencial para análise histórica.

---

# 128. EVIDENCE

Criar um objeto específico para evidência.

```json
{
  "id": "evidence:001",
  "type": "web_source",
  "title": "BGP observation",
  "source": "Fonte",
  "url": "",
  "collected_at": "2026-10-07T12:30:00Z",
  "content_hash": "",
  "reliability": "high",
  "notes": ""
}
```

Quando possível, preservar hash do conteúdo ou artefato coletado.

---

# 129. EVENT

Eventos devem ser entidades próprias.

Exemplo:

```json
{
  "id": "event:001",
  "type": "connection",
  "timestamp": "2026-08-12T17:32:15Z",
  "timezone": "America/Sao_Paulo",
  "source": "application_log"
}
```

Relacionamentos:

```text
EVENT
 ↓
origin_ip
 ↓
destination_ip
 ↓
domain
 ↓
account
```

---

# 130. CASE

O objeto Case deve funcionar como contêiner da investigação.

```json
{
  "id": "CASE-2026-001",
  "name": "Investigação X",
  "description": "",
  "created_at": "",
  "updated_at": "",
  "entities": [],
  "relationships": [],
  "observations": [],
  "events": [],
  "evidence": [],
  "hypotheses": [],
  "snapshots": []
}
```

---

# 131. BANCO DE DADOS

Começar com SQLite.

Tabelas sugeridas:

```text
cases
entities
relationships
observations
evidence
events
hypotheses
sources
snapshots
tags
entity_tags
case_entities
```

Projetar a camada de persistência de forma que seja possível migrar posteriormente para PostgreSQL.

---

# 132. INTERFACE PRINCIPAL

A interface Streamlit deve possuir navegação:

```text
┌─────────────────────────────────────┐
│ IP INTELLIGENCE                     │
├─────────────────────────────────────┤
│ 📁 Casos                            │
│ 🔎 Nova análise                     │
│ 🌐 IPs                              │
│ 🕸 Grafo                            │
│ 🕒 Timeline                         │
│ 📊 Correlações                      │
│ 🚨 Alertas                          │
│ 📑 Evidências                       │
│ 📄 Relatórios                       │
│ ⚙ Configurações                    │
└─────────────────────────────────────┘
```

---

# 133. DASHBOARD DO CASO

O dashboard deve mostrar:

```text
Caso: FRAUDE_2026_001

IPs:                 37
ASNs:                 4
Domínios:            19
Certificados:         7
Clusters:             5
Eventos:             142
Evidências:           64
Alertas:               8
```

E indicadores:

```text
🔴 Alta prioridade: 4
🟠 Atenção: 7
🟡 Moderado: 12
🟢 Baixo: 14
```

---

# 134. TELA DE ANÁLISE DE IP

Permitir inserir:

```text
IP:
[________________________]

Modo:
[Automático ▼]

Profundidade do pivô:
[2]

☑ RDAP
☑ BGP
☑ DNS
☑ Geolocalização
☑ Reputação
☑ Certificados
☑ Histórico
☑ Passive DNS
```

Botão:

```text
[ ANALISAR ]
```

---

# 135. RESULTADO DO IP

Apresentar abas:

```text
Resumo
Rede
ASN/BGP
DNS
Geolocalização
Reputação
VPN/Proxy/Tor
Certificados
Histórico
Domínios
Relacionamentos
Evidências
```

---

# 136. GRAFO INTERATIVO

O grafo deve ser um dos componentes principais da aplicação.

Exemplo:

```text
                         ┌── Domain A
                         │
IP A ── PTR ── Hostname ┼── Certificate X
│                        │
│                        └── Domain B
│
├── Prefix 200.100.0.0/24
│          │
│          └── AS12345
│                │
│                └── ISP X
│
└── IP B
```

Permitir:

* zoom;
* arrastar nós;
* clicar;
* expandir;
* ocultar;
* filtrar;
* destacar clusters;
* filtrar por tipo;
* filtrar por confiança;
* filtrar por período;
* mostrar apenas relações relevantes.

---

# 137. CORES E FORMAS DO GRAFO

Utilizar diferentes representações visuais para tipos de entidades.

Exemplo conceitual:

```text
IP              → círculo
ASN             → hexágono
Domínio         → retângulo
Organização     → quadrado
Certificado     → losango
Evento          → marcador temporal
Evidência       → ícone documental
```

As cores devem ser configuráveis pela interface.

Não utilizar cores para representar "culpabilidade".

---

# 138. FILTROS DO GRAFO

Permitir:

```text
☑ IP
☑ ASN
☑ Prefixo
☑ ISP
☑ Domínio
☑ Certificado
☑ Datacenter
☑ VPN
☑ Proxy
☑ Tor
☑ Eventos
```

E:

```text
Confiança:
[0.00 ───────── 1.00]

Período:
[01/01/2025] → [07/10/2026]

Profundidade:
[1] [2] [3]
```

---

# 139. EXPANSÃO INTERATIVA

Ao clicar em um nó:

```text
IP: 200.100.10.20

[Ver detalhes]
[Expandir relações]
[Mostrar histórico]
[Adicionar ao caso]
[Adicionar como evidência]
[Pivô neste indicador]
```

O usuário pode expandir o grafo progressivamente.

Não carregar todo o universo de relações de uma vez.

---

# 140. TIMELINE

Criar uma visualização temporal.

Exemplo:

```text
2024 ─────── 2025 ─────── 2026
             │              │
          ASN A          ASN B
             │              │
          PTR A          PTR B
                            │
                         Evento X
```

Permitir filtros:

* IP;
* ASN;
* domínio;
* evento;
* certificado;
* alteração de infraestrutura.

---

# 141. SLIDER TEMPORAL

Adicionar um controle:

```text
[────────────●────────────]
2024                     2026
```

Ao mover o slider, o grafo deve mostrar somente relações válidas/observadas naquele período, quando os dados permitirem.

Isso cria uma espécie de:

> **"máquina do tempo da infraestrutura".**

---

# 142. COMPARAÇÃO TEMPORAL

Permitir:

```text
Comparar:

[01/01/2025]  vs  [01/01/2026]
```

Mostrar:

### Adicionados

Novos relacionamentos.

### Removidos

Relacionamentos que desapareceram.

### Alterados

ASN, ISP, PTR etc.

---

# 143. CLUSTERS VISUAIS

Identificar automaticamente clusters e permitir:

```text
[Mostrar Cluster 1]
[Mostrar Cluster 2]
[Mostrar Cluster 3]
```

Ao selecionar um cluster:

* destacar seus nós;
* mostrar características;
* listar entidades;
* mostrar evidências;
* calcular score;
* mostrar conexões externas.

---

# 144. TELA DE CORRELAÇÃO

Mostrar uma matriz:

```text
             IP A   IP B   IP C   IP D
IP A           —    90%    20%    75%
IP B          90%     —     15%    80%
IP C          20%    15%     —     10%
IP D          75%    80%    10%     —
```

Ao clicar em uma célula:

> Mostrar os fatores responsáveis pela correlação.

---

# 145. TELA DE EVIDÊNCIAS

Exibir:

```text
EVIDÊNCIA #001

Indicador:
200.100.10.20

Relação:
originated_by AS12345

Fonte:
BGP

Coletado:
07/10/2026 09:32

Confiança:
Alta

Validade:
01/08/2026 → atual

[Ver fonte]
[Adicionar ao relatório]
```

---

# 146. TELA "O QUE FALTA?"

Criar uma área especialmente útil:

```text
╔════════════════════════════════════╗
║ O QUE FALTA PARA AVANÇAR?         ║
╠════════════════════════════════════╣
║ 🔴 Timestamp preciso               ║
║ 🔴 Porta de origem                 ║
║ 🟠 Histórico do IP                 ║
║ 🟡 Logs da aplicação               ║
║ 🟡 Informações de CGNAT            ║
╚════════════════════════════════════╝
```

Para cada item, explicar:

> Por que essa informação é importante?

---

# 147. NEXT BEST ACTION

Criar uma seção:

```text
PRÓXIMA MELHOR AÇÃO

1. Obter timestamp + porta de origem
   Motivo: IP possivelmente compartilhado.

2. Consultar histórico BGP
   Motivo: houve mudança de ASN próxima ao evento.

3. Expandir certificado X
   Motivo: conecta cinco IPs do caso.
```

---

# 148. ANÁLISE DE ARQUIVOS

A aplicação deve futuramente aceitar:

* TXT;
* CSV;
* XLSX;
* JSON;
* logs;
* relatórios;
* listas de IP;
* exports de sistemas.

Ao importar:

1. identificar automaticamente IPs;
2. identificar timestamps;
3. identificar domínios;
4. identificar URLs;
5. identificar ASN;
6. identificar indicadores adicionais;
7. normalizar;
8. deduplicar;
9. adicionar ao caso.

---

# 149. EXTRAÇÃO AUTOMÁTICA DE INDICADORES

Um arquivo contendo:

```text
12/08/2026 14:32 - conexão de 200.100.10.20 para exemplo.com
```

deve permitir identificar automaticamente:

```text
IP:
200.100.10.20

Domain:
exemplo.com

Timestamp:
12/08/2026 14:32
```

Esses indicadores devem ser apresentados ao usuário antes da incorporação definitiva ao caso.

---

# 150. APROVAÇÃO HUMANA

Quando novos indicadores forem extraídos de arquivos, permitir:

```text
☑ 200.100.10.20
☑ exemplo.com
☑ 12/08/2026 14:32

[Adicionar ao caso]
```

Não adicionar automaticamente informações potencialmente relevantes sem permitir revisão, quando a operação for destrutiva ou alterar significativamente o caso.

---

# 151. EXPORTAÇÃO

Permitir exportar:

### Relatório

* Markdown;
* HTML;
* PDF.

### Dados

* JSON;
* CSV;
* XLSX.

### Grafo

* JSON;
* GraphML;
* CSV nodes;
* CSV edges.

### Caso completo

```text
case_export.zip
├── case.json
├── entities.csv
├── relationships.csv
├── observations.csv
├── evidence.csv
├── timeline.csv
├── graph.graphml
└── report.pdf
```

---

# 152. AUDITORIA

Registrar ações realizadas na aplicação:

```text
Usuário
Data/hora
Ação
Indicador
Fonte
Resultado
```

Exemplo:

```text
07/10/2026 09:35
Consulta RDAP
IP 200.100.10.20
Resultado obtido
```

Não registrar segredos, tokens ou credenciais.

---

# 153. CACHE

Implementar cache para evitar consultas repetidas.

Chave conceitual:

```text
source + indicator + query_parameters
```

Armazenar:

* resultado;
* timestamp;
* validade do cache;
* fonte.

Permitir atualização manual:

```text
[Atualizar dados]
```

---

# 154. RATE LIMITING

Cada fonte deve possuir controle de:

* quantidade de requisições;
* intervalo;
* erros;
* retry;
* timeout.

Não realizar consultas excessivas.

---

# 155. FALHAS DE FONTES

Se uma fonte estiver indisponível:

```text
⚠ Fonte X indisponível.

A análise continuará utilizando:
✓ RDAP
✓ BGP
✓ DNS
✗ Fonte X
```

Nunca preencher o resultado ausente por inferência.

---

# 156. CONFIABILIDADE OPERACIONAL

Cada resultado deve poder informar:

```text
Fonte consultada: ✓
Fonte indisponível: ✗
Informação antiga: ⚠
Informação conflitante: ⚠
Informação estimada: ⚠
```

---

# 157. SEGREDOS E CREDENCIAIS

As chaves de APIs não devem aparecer:

* no código;
* no relatório;
* no JSON exportado;
* no grafo;
* nos logs.

Utilizar:

```text
.env
environment variables
secret manager
```

quando necessário.

---

# 158. ARQUITETURA DE PLUGINS DE FONTES

As fontes externas devem ser implementadas por adaptadores independentes.

Exemplo:

```text
BaseProvider
    │
    ├── RDAPProvider
    ├── BGPProvider
    ├── DNSProvider
    ├── ReputationProvider
    ├── GeoProvider
    └── CertificateProvider
```

Isso permite substituir uma fonte sem alterar o restante da aplicação.

---

# 159. NORMALIZAÇÃO DE FONTES

Diferentes fontes podem chamar a mesma entidade de formas diferentes.

Exemplo:

```text
Fonte A:
"Example Telecom S.A."

Fonte B:
"EXAMPLE TELECOM"

Fonte C:
"Example Telecom"
```

Criar mecanismo de normalização/canonicalização.

Mas preservar sempre o valor original.

```text
canonical_name
original_name
```

---

# 160. RESOLUÇÃO DE ENTIDADES

Quando houver possibilidade de duas entidades serem a mesma:

```text
Entity A
Entity B
```

não fundir automaticamente quando a confiança não for suficiente.

Usar:

```text
Possível mesma entidade
Confiança: 72%
```

Permitir decisão humana:

```text
[Confirmar]
[Manter separadas]
```

---

# 161. CONTROLE DE VERSÃO DO CASO

Cada alteração importante no caso pode gerar uma versão:

```text
Case v1
Case v2
Case v3
```

Permitir reconstruir o estado anterior.

---

# 162. SNAPSHOT MANUAL

Botão:

```text
[Salvar Snapshot]
```

Salvar:

* entidades;
* relações;
* observações;
* scores;
* clusters;
* hipóteses;
* conclusões.

Isso permite comparar a evolução da investigação.

---

# 163. IA COMO CAMADA DE RACIOCÍNIO

A IA deve atuar **sobre os dados estruturados**, e não substituir a coleta.

Fluxo:

```text
Fontes
 ↓
Dados estruturados
 ↓
Validação
 ↓
Correlação determinística
 ↓
Grafo
 ↓
IA
 ↓
Explicação
 ↓
Hipóteses
```

A IA nunca deve inventar dados ausentes.

---

# 164. EXPLICAÇÃO GERADA PELA IA

Para cada conclusão, a IA deve conseguir responder:

> "Por que você concluiu isso?"

Formato:

```text
Conclusão:
IP A e IP B possuem forte relação de infraestrutura.

Motivos:
1. Mesmo ASN.
2. Mesmo prefixo.
3. Mesmo certificado.
4. Observação temporal próxima.

Limitação:
A infraestrutura pode ser compartilhada.
```

---

# 165. IA NÃO DEVE SER A FONTE PRIMÁRIA

A IA não deve ser considerada fonte.

A fonte é:

* RDAP;
* BGP;
* DNS;
* certificado;
* registro;
* log;
* banco consultado;
* evidência preservada.

A IA apenas interpreta e correlaciona os dados.

---

# 166. MODO OFFLINE / LOCAL

A aplicação deve ser projetada para funcionar parcialmente ou totalmente em ambiente local.

Quando possível:

* processamento local;
* armazenamento local;
* modelos locais;
* banco local;
* nenhuma informação sensível enviada para terceiros sem autorização.

Quando uma fonte externa for necessária, indicar:

> "Esta etapa requer consulta externa."

---

# 167. CLASSIFICAÇÃO DE SENSIBILIDADE

Cada dado pode receber:

```text
PUBLIC
INTERNAL
SENSITIVE
RESTRICTED
```

O nível deve controlar:

* exportação;
* logs;
* envio para APIs;
* uso por modelos externos.

---

# 168. POLÍTICA DE ENVIO PARA MODELOS DE IA

Antes de enviar dados para qualquer modelo externo:

1. verificar classificação de sensibilidade;
2. verificar configuração do usuário;
3. remover informações desnecessárias;
4. anonimizar quando possível;
5. impedir envio automático de dados sensíveis.

Por padrão:

> **Dados de investigação não devem ser enviados a modelos externos sem autorização explícita.**

---

# 169. RELATÓRIO INVESTIGATIVO FINAL

O relatório deve possuir:

```text
1. Identificação do caso
2. Objetivo
3. Metodologia
4. Indicadores analisados
5. Infraestrutura identificada
6. ASN/BGP
7. DNS
8. Geolocalização
9. VPN/Proxy/Tor
10. Reputação
11. Correlações
12. Grafo
13. Linha do tempo
14. Evidências
15. Hipóteses
16. Evidências favoráveis
17. Evidências contrárias
18. Limitações
19. O que falta
20. Próximos passos
21. Conclusão
22. Fontes
```

---

# 170. CONCLUSÃO VISUAL

O dashboard final deve permitir que o investigador veja em poucos segundos:

```text
┌──────────────────────────────────────────────┐
│             RESUMO DO CASO                  │
├──────────────────────────────────────────────┤
│ 37 IPs       4 ASN        5 Clusters        │
│ 19 Domínios  7 Cert.      142 Eventos       │
├──────────────────────────────────────────────┤
│ 🔴 4 Alta prioridade                         │
│ 🟠 7 Atenção                                 │
│ 🟡 12 Moderados                              │
├──────────────────────────────────────────────┤
│                                              │
│              GRAFO DA INVESTIGAÇÃO           │
│                                              │
│          IP ─ ASN ─ ISP ─ Prefix             │
│          │       │                         │
│       Domain ─ Certificate ─ IP             │
│                                              │
├──────────────────────────────────────────────┤
│ PRÓXIMO MELHOR PASSO                         │
│                                              │
│ Obter timestamp + porta de origem            │
│ Motivo: possível CGNAT                       │
└──────────────────────────────────────────────┘
```

---

# 171. PRINCÍPIO DE IMPLEMENTAÇÃO

A aplicação deve separar rigorosamente:

```text
COLETA
   ↓
DADO
   ↓
OBSERVAÇÃO
   ↓
RELACIONAMENTO
   ↓
CORRELAÇÃO
   ↓
ANÁLISE
   ↓
HIPÓTESE
   ↓
CONCLUSÃO
```

A IA nunca deve pular diretamente de:

```text
IP
 ↓
Pessoa
```

ou:

```text
IP
 ↓
Crime
```

---

# 172. OBJETIVO FINAL

O produto deve evoluir de:

> **"Ferramenta para consultar IPs"**

para:

> **"Plataforma de inteligência de infraestrutura de rede capaz de reconstruir relações técnicas, temporais e contextuais entre indicadores, preservando as fontes e distinguindo claramente fatos, correlações e hipóteses."**

A arquitetura deve permitir posteriormente incorporar outros indicadores além de IPs, tornando o mesmo mecanismo aplicável a:

```text
IP
ASN
Domínio
URL
Hostname
Certificado
Hash
E-mail
Telefone
Conta
Evento
Timestamp
```

Todos esses indicadores devem poder coexistir no mesmo grafo investigativo.

---

# 173. VISÃO FUTURA

A arquitetura deve permitir evoluir para:

```text
                    CASO
                     │
       ┌─────────────┼─────────────┐
       ▼             ▼             ▼
      IPs         Domínios       Eventos
       │             │             │
       └─────────────┼─────────────┘
                     ▼
                  GRAFO
                     │
          ┌──────────┼──────────┐
          ▼          ▼          ▼
       CLUSTERS    TIMELINE   EVIDÊNCIAS
          │          │          │
          └──────────┼──────────┘
                     ▼
                INTELIGÊNCIA
                     │
          ┌──────────┼──────────┐
          ▼          ▼          ▼
       HIPÓTESES   ALERTAS   PIVÔS
                     │
                     ▼
              PRÓXIMO PASSO
                     │
                     ▼
                 RELATÓRIO
```

O sistema deve ser construído desde o início para suportar essa evolução sem necessidade de reescrever o núcleo da aplicação.
