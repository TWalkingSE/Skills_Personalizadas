#!/usr/bin/env python3
"""
Análise de Endereços IP — ferramenta de apoio da skill (Python 3.9+, somente stdlib).

Subcomandos:
  normalizar    Extrai IPs de texto/log (aceita defang, porta, colchetes IPv6), valida,
                deduplica com contagem/ocorrências, classifica faixas especiais (IANA),
                agrupa por /24, /48 e /64 e extrai timestamp/porta quando presentes na linha.
  consultar     Consulta PASSIVA de fontes públicas para IPs públicos: RIPEstat (prefixo/ASN,
                geolocalização, histórico de roteamento), RDAP (rdap.org → RIR/NIR), PTR (DNS)
                e lista atual de saídas Tor. Guarda cada resposta bruta com URL, data/hora UTC e SHA-256.
  correlacionar Agrupa por ASN/prefixo/organização/domínio do PTR, calcula similaridade técnica
                explicável (pesos ajustáveis), clusters, hubs, outliers e exporta o grafo
                (JSON, CSV de nós/arestas, GraphML).

Modelo de dados exportado (§124–130): CASE · ENTITY · RELATIONSHIP · OBSERVATION · EVIDENCE,
com observed_at separado de valid_from/valid_until. Cache, retry e trilha de auditoria (§152–155).

Nada aqui é intrusivo: não há varredura de portas, autenticação ou contato com o alvo além de
consultas DNS reversas (PTR) e APIs públicas de registro/roteamento.
"""
import argparse, csv, datetime as dt, hashlib, ipaddress, json, os, re, socket, sys, time
import urllib.request, urllib.error
from collections import Counter, defaultdict
from xml.sax.saxutils import escape

UA = "analise-ip-skill/1.0 (investigacao; consulta passiva)"

# ----------------------------------------------------------------------------- faixas especiais
ESPECIAIS = [
    ("0.0.0.0/8", "Esta rede (RFC 791)"), ("10.0.0.0/8", "Privado (RFC 1918)"),
    ("100.64.0.0/10", "CGNAT — espaço compartilhado (RFC 6598)"), ("127.0.0.0/8", "Loopback"),
    ("169.254.0.0/16", "Link-local"), ("172.16.0.0/12", "Privado (RFC 1918)"),
    ("192.0.0.0/24", "Atribuições de protocolo IETF"), ("192.0.2.0/24", "Documentação (TEST-NET-1)"),
    ("192.88.99.0/24", "6to4 relay anycast (obsoleto)"), ("192.168.0.0/16", "Privado (RFC 1918)"),
    ("198.18.0.0/15", "Benchmarking (RFC 2544)"), ("198.51.100.0/24", "Documentação (TEST-NET-2)"),
    ("203.0.113.0/24", "Documentação (TEST-NET-3)"), ("224.0.0.0/4", "Multicast"),
    ("240.0.0.0/4", "Reservado (uso futuro)"), ("255.255.255.255/32", "Broadcast limitado"),
    ("::/128", "Não especificado"), ("::1/128", "Loopback"), ("::ffff:0:0/96", "IPv4 mapeado em IPv6"),
    ("64:ff9b::/96", "Tradução IPv4/IPv6 (NAT64)"), ("100::/64", "Descarte (discard-only)"),
    ("2001::/32", "Teredo"), ("2001:db8::/32", "Documentação"), ("2002::/16", "6to4"),
    ("fc00::/7", "Unique Local (ULA — privado)"), ("fe80::/10", "Link-local"), ("ff00::/8", "Multicast"),
]
ESPECIAIS = [(ipaddress.ip_network(n), d) for n, d in ESPECIAIS]

RE_V4 = r"(?<![\d.])(?:\d{1,3}(?:\[\.\]|\(\.\)|\{\.\}|\.)){3}\d{1,3}(?![\d])"
RE_V6 = r"(?<![0-9A-Fa-f:])(?:[0-9A-Fa-f]{0,4}:){2,7}[0-9A-Fa-f]{0,4}(?:%\w+)?(?![0-9A-Fa-f:])"
RE_TS = [
    (re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?: ?(?:Z|UTC|[+-]\d{2}:?\d{2}))?"), "iso"),
    (re.compile(r"\d{2}/[A-Za-z]{3}/\d{4}:\d{2}:\d{2}:\d{2} [+-]\d{4}"), "clf"),
    (re.compile(r"\d{2}/\d{2}/\d{4}[ ,]+\d{2}:\d{2}(?::\d{2})?"), "br"),
]


def agora():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def classificar(ip):
    for rede, desc in ESPECIAIS:
        if ip.version == rede.version and ip in rede:
            return desc, False
    if ip.version == 6 and ip.ipv4_mapped:
        return "IPv4 mapeado em IPv6", False
    return ("Público (global)" if ip.is_global else "Não global (verificar registro IANA)"), ip.is_global


def precisao_ts(ts):
    if not ts:
        return None
    if re.search(r"\d{2}:\d{2}:\d{2}\.\d+", ts):
        return "ALTA (frações de segundo)"
    if re.search(r"\d{2}:\d{2}:\d{2}", ts):
        return "ALTA (segundos)"
    if re.search(r"\d{2}:\d{2}", ts):
        return "MÉDIA (minutos)"
    return "BAIXA (somente data)"


def extrair_linha(linha):
    achados = []
    for m in re.finditer(RE_V4, linha):
        bruto = m.group(0)
        limpo = re.sub(r"\[\.\]|\(\.\)|\{\.\}", ".", bruto)
        porta = None
        resto = linha[m.end():m.end() + 7]
        mp = re.match(r":(\d{1,5})\b", resto)
        if mp:
            porta = int(mp.group(1))
        achados.append((bruto, limpo, porta))
    for m in re.finditer(RE_V6, linha):
        bruto = m.group(0)
        if bruto.count(":") < 2:
            continue
        if re.fullmatch(r"[\d:]+", bruto) and "::" not in bruto and bruto.count(":") < 7:
            continue  # evita horários/datas como "14:32:15" ou "2026:14:33:01"
        porta = None
        if linha[max(0, m.start() - 1):m.start()] == "[":
            mp = re.match(r"\]:(\d{1,5})\b", linha[m.end():m.end() + 7])
            if mp:
                porta = int(mp.group(1))
        achados.append((bruto, bruto.split("%")[0], porta))
    return achados


RE_URL = re.compile(r"\b(?:https?|hxxps?|ftp)(?:://|\[://\])[^\s\"'<>]+", re.I)
RE_EMAIL = re.compile(r"\b[A-Za-z0-9._%+-]+(?:@|\[@\])[A-Za-z0-9.-]+(?:\.|\[\.\])[A-Za-z]{2,24}\b")
RE_DOM = re.compile(r"\b(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.|\[\.\]))+[A-Za-z]{2,24}\b")
NAO_TLD = {"php", "html", "htm", "js", "json", "txt", "log", "csv", "exe", "py", "jpg", "jpeg", "png", "gif",
           "xml", "asp", "aspx", "jsp", "cgi", "css", "pdf", "doc", "docx", "xls", "xlsx", "dll", "sh", "bak"}


def desfang(v):
    return re.sub(r"\[\.\]|\(\.\)|\{\.\}", ".", v).replace("[@]", "@").replace("[://]", "://").replace("hxxp", "http")


def extrair_outros(linha, n, acc):
    for tipo, rx in (("url", RE_URL), ("email", RE_EMAIL), ("dominio", RE_DOM)):
        for m in rx.finditer(linha):
            v = desfang(m.group(0)).rstrip(".,;)")
            if tipo == "dominio":
                v = v.lower()
                if v.rsplit(".", 1)[-1] in NAO_TLD or re.fullmatch(r"[\d.]+", v):
                    continue
            item = acc[tipo].setdefault(v, {"valor": v, "ocorrencias": 0, "linhas": []})
            item["ocorrencias"] += 1
            if len(item["linhas"]) < 20:
                item["linhas"].append(n)


def cmd_normalizar(a):
    texto = open(a.entrada, encoding="utf-8", errors="replace").read() if a.entrada != "-" else sys.stdin.read()
    registros, invalidos = {}, Counter()
    outros = {"url": {}, "email": {}, "dominio": {}}
    for n, linha in enumerate(texto.splitlines(), 1):
        extrair_outros(linha, n, outros)
        ts, fmt = None, None
        for rx, f in RE_TS:
            mt = rx.search(linha)
            if mt:
                ts, fmt = mt.group(0), f
                break
        for bruto, limpo, porta in extrair_linha(linha):
            try:
                ip = ipaddress.ip_address(limpo)
            except ValueError:
                invalidos[bruto] += 1
                continue
            chave = ip.compressed
            r = registros.setdefault(chave, {"ip": chave, "versao": f"IPv{ip.version}", "ocorrencias": 0,
                                             "formas_originais": [], "linhas": [], "portas": [], "timestamps": []})
            r["ocorrencias"] += 1
            if bruto not in r["formas_originais"]:
                r["formas_originais"].append(bruto)
            if len(r["linhas"]) < 50:
                r["linhas"].append(n)
            if porta is not None and porta not in r["portas"]:
                r["portas"].append(porta)
            if ts:
                r["timestamps"].append({"timestamp_original": ts, "formato": fmt, "linha": n,
                                        "precisao": precisao_ts(ts)})
    for r in registros.values():
        ip = ipaddress.ip_address(r["ip"])
        r["classificacao"], r["publico"] = classificar(ip)
        if ip.version == 4:
            r["bloco_24"] = str(ipaddress.ip_network(f"{ip}/24", strict=False))
        else:
            r["prefixo_48"] = str(ipaddress.ip_network(f"{ip}/48", strict=False))
            r["prefixo_64"] = str(ipaddress.ip_network(f"{ip}/64", strict=False))
        if r["timestamps"]:
            ords = [t["timestamp_original"] for t in r["timestamps"]]
            r["primeira_ocorrencia_texto"], r["ultima_ocorrencia_texto"] = ords[0], ords[-1]
    lista = sorted(registros.values(), key=lambda x: (-x["ocorrencias"], x["ip"]))
    blocos = defaultdict(list)
    for r in lista:
        blocos[r.get("bloco_24") or r.get("prefixo_64")].append(r["ip"])
    saida = {"gerado_em_utc": agora(), "entrada": a.entrada,
             "sha256_entrada": hashlib.sha256(texto.encode("utf-8")).hexdigest(),
             "total_ips_unicos": len(lista), "total_ocorrencias": sum(r["ocorrencias"] for r in lista),
             "publicos": sum(1 for r in lista if r["publico"]), "nao_publicos": sum(1 for r in lista if not r["publico"]),
             "invalidos": dict(invalidos),
             "agrupamento_bloco": {k: v for k, v in blocos.items() if len(v) > 1},
             "ips": lista,
             "outros_indicadores": {
                 "status": "PENDENTE DE APROVAÇÃO HUMANA (§150) — apresentar ao usuário antes de incorporar ao caso",
                 **{k: sorted(v.values(), key=lambda x: -x["ocorrencias"]) for k, v in outros.items()}}}
    escrever(a.saida, saida)
    print(f"| IP | Versão | Ocorrências | Classificação | Portas | 1ª/última (texto) |")
    print("|---|---|---:|---|---|---|")
    for r in lista[: a.limite]:
        print(f"| {r['ip']} | {r['versao']} | {r['ocorrencias']} | {r['classificacao']} | "
              f"{', '.join(map(str, r['portas'])) or '—'} | "
              f"{r.get('primeira_ocorrencia_texto', '—')} / {r.get('ultima_ocorrencia_texto', '—')} |")
    if len(lista) > a.limite:
        print(f"\n… {len(lista) - a.limite} IPs adicionais no JSON.")
    if invalidos:
        print(f"\nEntradas inválidas descartadas: {dict(invalidos)}")
    for k, rot in (("dominio", "Domínios"), ("url", "URLs"), ("email", "E-mails")):
        if outros[k]:
            vals = sorted(outros[k].values(), key=lambda x: -x["ocorrencias"])
            print(f"\n{rot} extraídos (pendentes de aprovação): " + ", ".join(
                f"{x['valor']} ({x['ocorrencias']})" for x in vals[:20]) + (" …" if len(vals) > 20 else ""))


# ----------------------------------------------------------------------------- consultas passivas
CFG = {"cache": None, "ttl_h": 24.0, "atualizar": False, "auditoria": None, "tentativas": 3, "timeout": 20}


def auditar(acao, indicador, fonte, resultado, extra=None):
    """Trilha de auditoria JSONL (§152). Nunca registra segredos, tokens ou chaves (§157)."""
    if not CFG["auditoria"]:
        return
    linha = {"data_hora_utc": agora(), "acao": acao, "indicador": indicador, "fonte": fonte, "resultado": resultado}
    if extra:
        linha.update(extra)
    with open(CFG["auditoria"], "a", encoding="utf-8") as f:
        f.write(json.dumps(linha, ensure_ascii=False) + "\n")


def baixar(url, pasta, indicador=None, fonte=None):
    chave = hashlib.sha256(url.encode()).hexdigest()
    cpath = os.path.join(CFG["cache"], chave + ".json") if CFG["cache"] else None
    if cpath and os.path.exists(cpath) and not CFG["atualizar"]:
        if time.time() - os.path.getmtime(cpath) < CFG["ttl_h"] * 3600:
            c = json.load(open(cpath, encoding="utf-8"))
            corpo = bytes.fromhex(c["corpo_hex"]) if c.get("corpo_hex") else None
            reg = dict(c["reg"], cache=True)
            auditar("consulta (cache)", indicador, fonte, "ok" if corpo else "erro", {"url": url})
            return reg, corpo
    reg, corpo = {"url": url, "consultado_em_utc": agora()}, None
    for tentativa in range(1, CFG["tentativas"] + 1):
        reg = {"url": url, "consultado_em_utc": agora(), "tentativas": tentativa}
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json, application/rdap+json, */*"})
            with urllib.request.urlopen(req, timeout=CFG["timeout"]) as resp:
                corpo = resp.read()
                reg.update(status=resp.status, url_final=resp.geturl())
            break
        except urllib.error.HTTPError as e:
            corpo = e.read() if hasattr(e, "read") else b""
            reg.update(status=e.code, erro=f"HTTP {e.code}")
            if e.code not in (429, 500, 502, 503, 504):
                break
        except Exception as e:  # noqa
            corpo = None
            reg.update(status=None, erro=f"{type(e).__name__}: {e}")
            if "Tunnel connection failed" in str(e) or "Name or service not known" in str(e):
                break  # bloqueio de rede/DNS: repetir não adianta
        time.sleep(2 ** tentativa)
    auditar("consulta", indicador, fonte, "erro" if reg.get("erro") else "ok", {"url": url, "status": reg.get("status")})
    if corpo is None:
        return reg, None
    reg["sha256_resposta"] = hashlib.sha256(corpo).hexdigest()
    if cpath:
        with open(cpath, "w", encoding="utf-8") as f:
            json.dump({"reg": reg, "corpo_hex": corpo.hex()}, f)
    if pasta:
        nome = re.sub(r"[^A-Za-z0-9._-]+", "_", url)[:150] + ".raw"
        with open(os.path.join(pasta, nome), "wb") as f:
            f.write(corpo)
        reg["arquivo_bruto"] = nome
    return reg, corpo


def json_ou_none(corpo):
    try:
        return json.loads(corpo) if corpo else None
    except Exception:  # noqa
        return None


def vcard_nome(ent):
    try:
        for item in ent.get("vcardArray", [None, []])[1]:
            if item[0] == "fn":
                return item[3]
    except Exception:  # noqa
        pass
    return None


def emails_abuso(ents, acc=None):
    acc = acc if acc is not None else []
    for e in ents or []:
        if "abuse" in (e.get("roles") or []):
            for item in (e.get("vcardArray") or [None, []])[1]:
                if item[0] == "email" and item[3] not in acc:
                    acc.append(item[3])
        emails_abuso(e.get("entities"), acc)
    return acc


def cmd_consultar(a):
    base = json.load(open(a.entrada, encoding="utf-8"))
    ips = [r["ip"] for r in base.get("ips", []) if r.get("publico")] if "ips" in base else base
    pasta = a.brutos
    if pasta:
        os.makedirs(pasta, exist_ok=True)
    CFG.update(ttl_h=a.ttl_cache, atualizar=a.atualizar, timeout=a.timeout,
               auditoria=a.auditoria or (os.path.join(pasta, "auditoria.jsonl") if pasta else None))
    if a.cache:
        os.makedirs(a.cache, exist_ok=True)
        CFG["cache"] = a.cache
    tor_set, tor_reg = set(), None
    if not a.sem_tor:
        tor_reg, corpo = baixar("https://check.torproject.org/torbulkexitlist", pasta, "*", "Tor bulk exit list")
        if corpo:
            tor_set = {l.strip() for l in corpo.decode(errors="replace").splitlines() if l.strip()}
    resultados = []
    for ip in ips:
        r = {"ip": ip, "fontes": [], "lacunas": []}
        # RIPEstat — prefixo/ASN anunciados
        reg, corpo = baixar(f"https://stat.ripe.net/data/prefix-overview/data.json?resource={ip}", pasta, ip, "RIPEstat prefix-overview")
        r["fontes"].append({"fonte": "RIPEstat prefix-overview", **reg})
        d = (json_ou_none(corpo) or {}).get("data") or {}
        if d:
            r["prefixo"] = d.get("resource")
            r["anunciado"] = d.get("announced")
            asns = d.get("asns") or []
            r["asn"] = [f"AS{x.get('asn')}" for x in asns]
            r["as_nome"] = [x.get("holder") for x in asns]
            if len(asns) > 1:
                r["alerta_moas"] = "Prefixo com múltiplas origens (MOAS) — verificar"
            r["bloco_iana"] = (d.get("block") or {}).get("desc")
        else:
            r["lacunas"].append("prefixo/ASN (RIPEstat indisponível)")
        # RIPEstat — geolocalização (MaxMind GeoLite via RIPEstat) — fonte de BAIXA confiabilidade
        if not a.sem_geo:
            reg, corpo = baixar(f"https://stat.ripe.net/data/maxmind-geo-lite/data.json?resource={ip}", pasta, ip, "RIPEstat maxmind-geo-lite")
            r["fontes"].append({"fonte": "RIPEstat maxmind-geo-lite", **reg})
            locs = ((json_ou_none(corpo) or {}).get("data") or {}).get("located_resources") or []
            geo = []
            for lr in locs:
                for loc in lr.get("locations") or []:
                    geo.append({k: loc.get(k) for k in ("country", "city", "latitude", "longitude", "covered_percentage")})
            r["geolocalizacao"] = geo or None
        # RDAP (bootstrap rdap.org → RIR/NIR responsável)
        reg, corpo = baixar(f"https://rdap.org/ip/{ip}", pasta, ip, "RDAP")
        r["fontes"].append({"fonte": "RDAP (rdap.org bootstrap)", **reg})
        j = json_ou_none(corpo)
        if j and j.get("objectClassName") == "ip network":
            r["rdap"] = {
                "handle": j.get("handle"), "nome": j.get("name"), "tipo": j.get("type"),
                "inicio": j.get("startAddress"), "fim": j.get("endAddress"), "pais": j.get("country"),
                "parent": j.get("parentHandle"), "servidor_rdap": reg.get("url_final"),
                "entidades": [{"handle": e.get("handle"), "papeis": e.get("roles"), "nome": vcard_nome(e)}
                              for e in j.get("entities") or []],
                "eventos": [{"acao": e.get("eventAction"), "data": e.get("eventDate")} for e in j.get("events") or []],
                "abuso": emails_abuso(j.get("entities")),
            }
            r["organizacao"] = next((e["nome"] for e in r["rdap"]["entidades"]
                                     if e.get("nome") and "registrant" in (e.get("papeis") or [])), None) or j.get("name")
        else:
            r["lacunas"].append("RDAP (sem resposta válida)")
        # PTR
        if not a.sem_ptr:
            try:
                ptr = socket.gethostbyaddr(ip)[0]
                r["ptr"] = ptr
            except Exception as e:  # noqa
                r["ptr"] = None
                r["lacunas"].append(f"PTR ({type(e).__name__})")
            r["fontes"].append({"fonte": "DNS reverso (resolvedor local)", "consultado_em_utc": agora(),
                                **({"erro": "sem PTR/erro de resolução"} if not r.get("ptr") else {})})
            auditar("consulta PTR", ip, "DNS reverso", "ok" if r.get("ptr") else "sem resultado")
        # Tor (lista ATUAL — para data do evento use ExoneraTor)
        if tor_reg:
            r["tor_saida_atual"] = (ip in tor_set) if tor_set else None
            r["fontes"].append({"fonte": "Tor bulk exit list (atual)", **tor_reg})
        resultados.append(r)
        time.sleep(a.pausa)
    saida = {"gerado_em_utc": agora(), "aviso": "Dados atuais na data da consulta; para eventos passados, usar fontes históricas.",
             "resultados": resultados}
    escrever(a.saida, saida)
    status = defaultdict(lambda: [0, 0])
    for r in resultados:
        for f in r["fontes"]:
            status[f["fonte"]][0 if not f.get("erro") else 1] += 1
    print("Status das fontes (§155):")
    for fonte, (ok, falha) in status.items():
        print(f"  {'✓' if ok and not falha else ('⚠' if ok else '✗')} {fonte}: {ok} ok, {falha} falha(s)")
    if any(f for _, f in status.values()):
        print("  ⚠ Resultados ausentes NÃO devem ser preenchidos por inferência; complete pela ferramenta web ou registre a lacuna.")
    print(json.dumps({"ips_consultados": len(resultados),
                      "com_lacunas": sum(1 for r in resultados if r["lacunas"]),
                      "saida": a.saida, "auditoria": CFG["auditoria"]}, ensure_ascii=False))


# ----------------------------------------------------------------------------- correlação
PESOS_PADRAO = {"asn": 20, "prefixo": 20, "organizacao": 15, "ptr_dominio": 10,
                "certificado": 15, "dominio": 10, "hospedagem": 5, "temporal": 5}


def dominio_base(host):
    if not host:
        return None
    partes = host.rstrip(".").lower().split(".")
    if len(partes) >= 3 and len(partes[-1]) == 2 and partes[-2] in {"com", "net", "org", "gov", "edu", "co", "ind", "srv", "jus", "mp", "leg"}:
        return ".".join(partes[-3:])
    return ".".join(partes[-2:]) if len(partes) >= 2 else host


SUFIXOS_ORG = r"\b(S\.?\s?A\.?|LTDA\.?|LTD\.?|INC\.?|LLC|EIRELI|ME|EPP|CORP\.?|CORPORATION|GMBH|B\.?V\.?|PLC|LIMITED|CO\.?)\b"


def canonico(nome):
    """Nome canônico para comparação; o valor original é sempre preservado."""
    if not nome:
        return None
    v = re.sub(SUFIXOS_ORG, " ", str(nome).upper())
    v = re.sub(r"[^A-Z0-9À-Ü ]+", " ", v)
    return re.sub(r"\s+", " ", v).strip() or str(nome).upper()


def conj(v):
    if v is None:
        return set()
    return set(v) if isinstance(v, (list, tuple, set)) else {v}


def cmd_correlacionar(a):
    dados = json.load(open(a.entrada, encoding="utf-8"))
    regs = dados.get("resultados", dados)
    pesos = dict(PESOS_PADRAO)
    if a.pesos:
        pesos.update(json.loads(a.pesos))
    total = sum(pesos.values())
    for r in regs:
        r["_f"] = {
            "asn": conj(r.get("asn")), "prefixo": conj(r.get("prefixo")), "organizacao": conj(canonico(r.get("organizacao"))),
            "ptr_dominio": conj(dominio_base(r.get("ptr"))), "certificado": conj(r.get("certificados")),
            "dominio": conj(r.get("dominios")), "hospedagem": conj(r.get("hospedagem")),
            "temporal": conj(r.get("janela_temporal")),
        }
    n = len(regs)
    matriz, pares = [[None] * n for _ in range(n)], []
    for i in range(n):
        for j in range(i + 1, n):
            fatores = [(k, pesos[k]) for k in pesos if regs[i]["_f"][k] & regs[j]["_f"][k]]
            score = round(100 * sum(p for _, p in fatores) / total) if total else 0
            matriz[i][j] = matriz[j][i] = score
            pares.append({"a": regs[i]["ip"], "b": regs[j]["ip"], "similaridade": score,
                          "fatores": [f"+{p} {k}" for k, p in fatores]})
    # clusters: componentes conexos com score >= limiar
    pai = list(range(n))
    def raiz(x):
        while pai[x] != x:
            pai[x] = pai[pai[x]]
            x = pai[x]
        return x
    for i in range(n):
        for j in range(i + 1, n):
            if matriz[i][j] is not None and matriz[i][j] >= a.limiar:
                pai[raiz(i)] = raiz(j)
    grupos = defaultdict(list)
    for i in range(n):
        grupos[raiz(i)].append(regs[i]["ip"])
    clusters = sorted(grupos.values(), key=len, reverse=True)
    # hubs e outliers
    entidade_ips = defaultdict(set)
    for r in regs:
        for k in ("asn", "prefixo", "organizacao", "ptr_dominio", "certificado", "dominio"):
            for v in r["_f"][k]:
                entidade_ips[(k, v)].add(r["ip"])
    hubs = sorted(((k, v, len(s)) for (k, v), s in entidade_ips.items() if len(s) >= 2), key=lambda x: -x[2])
    outliers = []
    for campo in ("pais", "asn"):
        cont = Counter()
        for r in regs:
            for v in conj(r.get(campo)) or {"(não identificado)"}:
                cont[v] += 1
        if n >= 5:
            for v, c in cont.items():
                if c / n <= 0.1:
                    outliers.append({"campo": campo, "valor": v, "ips": c})
    # modelo de dados do caso (§124–130) e grafo (§107)
    caso = construir_caso(regs, a)
    for r in regs:
        r.pop("_f", None)
    os.makedirs(a.saida_dir, exist_ok=True)
    exportar_caso(caso, a.saida_dir)
    rel = {"gerado_em_utc": agora(), "pesos": pesos, "limiar_cluster": a.limiar,
           "aviso": "Similaridade técnica ≠ probabilidade de autoria, identidade ou participação em crime.",
           "pares": sorted(pares, key=lambda p: -p["similaridade"]), "clusters": clusters,
           "hubs": [{"tipo": k, "valor": v, "ips_conectados": c} for k, v, c in hubs], "outliers": outliers}
    escrever(os.path.join(a.saida_dir, "correlacao.json"), rel)
    # saída legível
    ips = [r["ip"] for r in regs]
    if n <= 25:
        print("| | " + " | ".join(ips) + " |")
        print("|---|" + "---:|" * n)
        for i in range(n):
            print(f"| {ips[i]} | " + " | ".join("—" if i == j else str(matriz[i][j]) for j in range(n)) + " |")
    print("\nPares mais similares:")
    for p in rel["pares"][:10]:
        print(f"- {p['a']} ↔ {p['b']}: {p['similaridade']}/100 ({', '.join(p['fatores']) or 'sem fatores comuns'})")
    print("\nClusters (limiar ≥ %d):" % a.limiar)
    for k, c in enumerate(clusters, 1):
        print(f"- Cluster {k}: {len(c)} IP(s) — {', '.join(c[:15])}{' …' if len(c) > 15 else ''}")
    if hubs:
        print("\nHubs:")
        for k, v, c in hubs[:10]:
            print(f"- {k} {v}: conecta {c} de {n} IPs")
    if outliers:
        print("\nOutliers:", json.dumps(outliers, ensure_ascii=False))
    print(f"\nArquivos em {a.saida_dir}/: correlacao.json, case.json, graph.json, graph.graphml, "
          "entities.csv, relationships.csv, observations.csv, evidence.csv")


CONF_FONTE = {"RDAP": 1.0, "RIPEstat prefix-overview": 0.95, "DNS reverso": 0.9,
              "RIPEstat maxmind-geo-lite": 0.3, "Tor bulk exit list": 0.95}


def conf_de(fonte):
    for k, v in CONF_FONTE.items():
        if fonte and fonte.startswith(k):
            return v
    return None


def construir_caso(regs, a):
    ents, rels, obs, evid = {}, [], [], []
    def ent(tipo, valor, label=None, **extra):
        eid = f"{tipo}:{valor}"
        if eid not in ents:  # nunca duplicar o mesmo identificador normalizado (§125)
            ents[eid] = {"id": eid, "type": tipo, "value": valor, "label": label or str(valor), **extra}
        return eid
    def relacionar(src, dst, tipo, valor, fonte, url=None, observed_at=None, extra=None):
        rid = f"rel:{len(rels) + 1:04d}"
        rels.append({"id": rid, "source": src, "target": dst, "type": tipo, **(extra or {})})
        obs.append({"id": f"obs:{len(obs) + 1:04d}", "relationship_id": rid, "value": valor, "source": fonte,
                    "source_url": url, "observed_at": observed_at, "valid_from": None, "valid_until": None,
                    "confidence": conf_de(fonte)})
        return rid
    for r in regs:
        fontes = {f.get("fonte"): f for f in r.get("fontes", [])}
        def ref(nome):
            for k, f in fontes.items():
                if k and k.startswith(nome):
                    return k, f.get("url_final") or f.get("url"), f.get("consultado_em_utc")
            return "informado/importado", None, None
        ip = ent("ipv6" if ":" in r["ip"] else "ipv4", r["ip"])
        for asn, nome in zip(r.get("asn") or [], (r.get("as_nome") or []) + [None] * 10):
            a_id = ent("asn", asn, f"{asn} {nome or ''}".strip())
            relacionar(ip, a_id, "originated_by", asn, *ref("RIPEstat prefix-overview"))
            if r.get("prefixo"):
                relacionar(ent("prefix", r["prefixo"]), a_id, "announced_by", asn, *ref("RIPEstat prefix-overview"))
            nome_org = re.sub(r"^AS\d+\s*-?\s*", "", nome) if nome else None
            if nome_org:
                relacionar(a_id, ent("organization", canonico(nome_org), canonical_name=canonico(nome_org), original_name=nome),
                           "operated_by", nome, *ref("RIPEstat prefix-overview"))
        if r.get("prefixo"):
            relacionar(ip, ent("prefix", r["prefixo"]), "belongs_to", r["prefixo"], *ref("RIPEstat prefix-overview"))
        if r.get("organizacao"):
            o = ent("organization", canonico(r["organizacao"]), canonical_name=canonico(r["organizacao"]),
                    original_name=r["organizacao"])
            relacionar(ip, o, "owned_by", r["organizacao"], *ref("RDAP"),
                       extra={"nota": "registrante do bloco ≠ usuário final"})
        if r.get("ptr"):
            h = ent("hostname", r["ptr"].rstrip(".").lower())
            relacionar(ip, h, "reverse_resolves_to", r["ptr"], *ref("DNS reverso"))
            d = dominio_base(r["ptr"])
            if d:
                relacionar(h, ent("domain", d), "belongs_to", d, "derivado do PTR")
        for c in conj(r.get("certificados")):
            relacionar(ip, ent("certificate", c), "uses_certificate", c, *ref("certificados"))
        for d in conj(r.get("dominios")):
            relacionar(ent("domain", str(d).lower()), ip, "resolves_to", d, *ref("dominios"))
        for h in conj(r.get("hospedagem")):
            relacionar(ip, ent("datacenter", h), "hosted_on", h, *ref("hospedagem"))
        if r.get("tor_saida_atual"):
            relacionar(ip, ent("tor", "tor-exit"), "associated_with", "saída Tor (lista atual)", *ref("Tor bulk exit list"))
        for f in r.get("fontes", []):
            evid.append({"id": f"evidence:{len(evid) + 1:04d}", "type": "web_source", "title": f.get("fonte"),
                         "indicator": r["ip"], "source": f.get("fonte"), "url": f.get("url_final") or f.get("url"),
                         "collected_at": f.get("consultado_em_utc"), "content_hash": f.get("sha256_resposta"),
                         "raw_file": f.get("arquivo_bruto"), "status": "erro" if f.get("erro") else "ok",
                         "reliability": {1.0: "high", 0.95: "high", 0.9: "high", 0.3: "low"}.get(conf_de(f.get("fonte")), "unknown"),
                         "notes": f.get("erro") or ("cache" if f.get("cache") else "")})
    return {"id": a.caso, "name": a.caso, "description": "", "created_at": agora(), "updated_at": agora(),
            "sensitivity": a.sensibilidade,
            "entities": list(ents.values()), "relationships": rels, "observations": obs, "events": [],
            "evidence": evid, "hypotheses": [], "snapshots": []}


def exportar_caso(caso, pasta):
    escrever(os.path.join(pasta, "case.json"), caso)
    grafo = {"nodes": [{"id": e["id"], "type": e["type"], "label": e["label"]} for e in caso["entities"]],
             "edges": [{"source": r["source"], "target": r["target"], "relationship": r["type"],
                        "confidence": next((o["confidence"] for o in caso["observations"] if o["relationship_id"] == r["id"]), None),
                        "source_reference": next((o["source"] for o in caso["observations"] if o["relationship_id"] == r["id"]), None)}
                       for r in caso["relationships"]]}
    escrever(os.path.join(pasta, "graph.json"), grafo)
    for nome, linhas in (("entities", caso["entities"]), ("relationships", caso["relationships"]),
                         ("observations", caso["observations"]), ("evidence", caso["evidence"])):
        campos = sorted({k for l in linhas for k in l}) or ["id"]
        with open(os.path.join(pasta, f"{nome}.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=campos); w.writeheader(); w.writerows(linhas)
    with open(os.path.join(pasta, "graph.graphml"), "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<graphml xmlns="http://graphml.graphdrawing.org/xmlns">\n'
                '<key id="type" for="node" attr.name="type" attr.type="string"/>\n'
                '<key id="label" for="node" attr.name="label" attr.type="string"/>\n'
                '<key id="rel" for="edge" attr.name="relationship" attr.type="string"/>\n'
                '<key id="conf" for="edge" attr.name="confidence" attr.type="double"/>\n<graph edgedefault="directed">\n')
        for nd in grafo["nodes"]:
            f.write(f'<node id="{escape(nd["id"])}"><data key="type">{escape(nd["type"])}</data>'
                    f'<data key="label">{escape(nd["label"])}</data></node>\n')
        for k, e in enumerate(grafo["edges"]):
            conf = f'<data key="conf">{e["confidence"]}</data>' if e["confidence"] is not None else ""
            f.write(f'<edge id="e{k}" source="{escape(e["source"])}" target="{escape(e["target"])}">'
                    f'<data key="rel">{e["relationship"]}</data>{conf}</edge>\n')
        f.write("</graph>\n</graphml>\n")


def escrever(caminho, obj):
    if not caminho:
        return
    os.makedirs(os.path.dirname(os.path.abspath(caminho)), exist_ok=True)
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def main():
    ap = argparse.ArgumentParser(description="Análise de Endereços IP — apoio à skill")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("normalizar"); p.add_argument("entrada", help="arquivo de texto/log ou '-' (stdin)")
    p.add_argument("--saida", default="normalizado.json"); p.add_argument("--limite", type=int, default=100)
    p.set_defaults(f=cmd_normalizar)
    p = sub.add_parser("consultar"); p.add_argument("entrada", help="saída do 'normalizar' ou lista JSON de IPs")
    p.add_argument("--saida", default="consulta.json"); p.add_argument("--brutos", default="respostas_brutas")
    p.add_argument("--pausa", type=float, default=1.0); p.add_argument("--sem-geo", action="store_true")
    p.add_argument("--sem-ptr", action="store_true"); p.add_argument("--sem-tor", action="store_true")
    p.add_argument("--cache", default=".cache_ip", help="pasta de cache (§153); '' desativa")
    p.add_argument("--ttl-cache", type=float, default=24.0, help="validade do cache em horas")
    p.add_argument("--atualizar", action="store_true", help="ignora o cache e consulta de novo")
    p.add_argument("--timeout", type=float, default=20.0)
    p.add_argument("--auditoria", help="arquivo JSONL da trilha de auditoria (padrão: <brutos>/auditoria.jsonl)")
    p.set_defaults(f=cmd_consultar)
    p = sub.add_parser("correlacionar"); p.add_argument("entrada", help="saída do 'consultar' (ou JSON no mesmo formato)")
    p.add_argument("--saida-dir", default="correlacao"); p.add_argument("--limiar", type=int, default=40)
    p.add_argument("--caso", default="CASO-SEM-ID", help="identificador do caso (§77)")
    p.add_argument("--sensibilidade", default="SENSITIVE", choices=["PUBLIC", "INTERNAL", "SENSITIVE", "RESTRICTED"],
                   help="classificação de sensibilidade do caso (§167)")
    p.add_argument("--pesos", help='JSON para ajustar pesos, ex.: \'{"asn":10,"certificado":25}\'')
    p.set_defaults(f=cmd_correlacionar)
    a = ap.parse_args()
    a.f(a)


if __name__ == "__main__":
    main()
