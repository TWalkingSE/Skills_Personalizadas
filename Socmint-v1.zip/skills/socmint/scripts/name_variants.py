#!/usr/bin/env python3
"""Gera candidatos de username e e-mail a partir de um nome (convenções pt-BR; offline).

Só GERA candidatos: não consulta nada e não confirma existência. A verificação é manual
(WhatsMyName, Sherlock, Blackbird…) e cada confirmação passa pela regra de corroboração
(references/06). Para pessoa privada, aplique o gate antes (references/00).

Exemplos:
    python3 scripts/name_variants.py --name "Maria da Silva Souza" --max 60
    python3 scripts/name_variants.py --name "João Pedro Alves" --nick jp --year 1990 --domains gmail.com,uol.com.br
"""
from __future__ import annotations

import argparse
import json
import re
import sys

from _common import ensure_utf8_stdout, strip_accents

PARTICLES = {"da", "de", "do", "das", "dos", "e", "di", "du", "del", "la", "le", "van", "von", "bin", "al", "el"}
# Agnomes (Júnior, Filho, Neto…): no fim de um nome com 3+ partes, não são o sobrenome principal
AGNOMES = {"junior", "jr", "filho", "neto", "sobrinho", "bisneto", "segundo", "terceiro"}
DEFAULT_DOMAINS = ["gmail.com", "hotmail.com", "outlook.com", "yahoo.com.br", "uol.com.br", "icloud.com"]
SEPS = ["", ".", "_", "-"]
# Gmail aceita só letras, números e pontos, de 6 a 30 caracteres, e ignora os pontos (maria.souza = mariasouza)
GMAIL_DOMAINS = {"gmail.com", "googlemail.com"}


def tokenize(name: str) -> list[str]:
    s = strip_accents(name).lower()
    s = re.sub(r"[^a-z0-9]+", " ", s)
    return [t for t in s.split() if t]


def core_tokens(tokens: list[str]) -> list[str]:
    core = [t for t in tokens if t not in PARTICLES]
    return core or tokens


def gen_usernames(name: str, nick: str | None, year: int | None, suffixes: bool) -> list[str]:
    toks = tokenize(name)
    if len(toks) < 1:
        raise SystemExit("Informe um nome válido em --name.")
    core = core_tokens(toks)
    agnome = core[-1] if len(core) > 2 and core[-1] in AGNOMES else ""
    if agnome:
        core = core[:-1]
    first = core[0]
    last = core[-1] if len(core) > 1 else ""
    second_last = core[-2] if len(core) > 2 else ""
    middles = core[1:-1] if len(core) > 2 else []
    out: list[str] = []

    def add(u: str) -> None:
        u = re.sub(r"([._-])\1+", r"\1", u).strip("._-")
        if u and u not in out:
            out.append(u)

    if last:
        for sep in SEPS:
            add(f"{first}{sep}{last}")
        for sep in SEPS:
            if second_last:
                add(f"{first}{sep}{second_last}")
        if len(core) > 2:  # nome composto (José Carlos, Maria Eduarda, João Pedro)
            second = core[1]
            for sep in ["", ".", "_"]:
                add(f"{first}{sep}{second}")
                add(f"{first}{second}{sep}{last}")
            for sep in ["", ".", "_"]:
                add(f"{first[0]}{second[0]}{sep}{last}")
        for sep in ["", ".", "_"]:
            add(f"{first[0]}{sep}{last}")
            add(f"{first}{sep}{last[0]}")
        for sep in SEPS:
            add(f"{last}{sep}{first}")
        if len(core) > 2:
            for sep in SEPS:
                add(sep.join(core))
            for sep in ["", ".", "_"]:
                add(f"{first}{sep}{middles[0][0]}{sep}{last}")
        if any(t in PARTICLES for t in toks):
            for sep in ["", ".", "_"]:
                add(sep.join(toks))
        if agnome:  # variantes com o agnome, depois das principais
            ags = [agnome] + (["jr"] if agnome == "junior" else [])
            for ag in ags:
                for sep in ["", ".", "_"]:
                    add(f"{first}{sep}{last}{sep}{ag}")
                    add(f"{first}{sep}{ag}")
                    add(f"{ag}{sep}{last}")
    add(first)
    if nick:
        n = tokenize(nick)
        n = "".join(n)
        if n:
            add(n)
            if last:
                for sep in ["", ".", "_"]:
                    add(f"{n}{sep}{last}")
                    add(f"{first}{sep}{n}")

    base = list(out)
    nums: list[str] = []
    if year:
        nums += [str(year), f"{year % 100:02d}"]
    if suffixes:
        nums += ["1", "01", "123"]
    for u in base[:40]:
        for n in nums:
            add(f"{u}{n}")
    return out


def valid_local(local: str, domain: str) -> bool:
    if domain in GMAIL_DOMAINS:
        return bool(re.fullmatch(r"[a-z0-9][a-z0-9.]*[a-z0-9]", local)) and ".." not in local and 6 <= len(local.replace(".", "")) <= 30
    return bool(re.fullmatch(r"[a-z0-9._-]+", local)) and local[0] not in ".-_"


def gen_emails(users: list[str], domains: list[str], cap: int) -> list[str]:
    emails: list[str] = []
    seen: set[str] = set()
    for u in users:
        for d in domains:
            if not valid_local(u, d):
                continue
            key = f"{u.replace('.', '')}@{d}" if d in GMAIL_DOMAINS else f"{u}@{d}"  # Gmail ignora pontos
            if key in seen:
                continue
            seen.add(key)
            emails.append(f"{u}@{d}")
            if len(emails) >= cap:
                return emails
    return emails


def main(argv: list[str] | None = None) -> int:
    ensure_utf8_stdout()
    p = argparse.ArgumentParser(description="Candidatos de username e e-mail a partir de um nome (offline).")
    p.add_argument("--name", required=True, help='nome completo, ex.: "Maria da Silva Souza"')
    p.add_argument("--nick", help="apelido conhecido")
    p.add_argument("--year", type=int, help="ano de nascimento (gera sufixos de 2 e 4 dígitos)")
    p.add_argument("--suffixes", action="store_true", help="inclui sufixos comuns (1, 01, 123)")
    p.add_argument("--domains", default=",".join(DEFAULT_DOMAINS), help="domínios de e-mail (vírgula)")
    p.add_argument("--no-emails", action="store_true")
    p.add_argument("--max", type=int, default=100, help="limite de usernames e de e-mails")
    p.add_argument("--format", choices=["txt", "json", "md"], default="txt")
    a = p.parse_args(argv)

    users = gen_usernames(a.name, a.nick, a.year, a.suffixes)[: a.max]
    domains = [d.strip().lower() for d in a.domains.split(",") if d.strip()]
    emails = [] if a.no_emails else gen_emails(users, domains, a.max)
    note = ("Candidatos, não resultados: nada foi consultado. Verifique com WhatsMyName/Sherlock/Blackbird por sua conta; "
            "username igual não prova identidade (references/06); pessoa privada exige o gate (references/00).")
    if a.format == "json":
        print(json.dumps({"usernames": users, "emails": emails, "aviso": note}, ensure_ascii=False, indent=2))
    elif a.format == "md":
        print("## Usernames\n" + "\n".join(f"- `{u}`" for u in users))
        if emails:
            print("\n## E-mails\n" + "\n".join(f"- `{e}`" for e in emails))
        print(f"\n> {note}")
    else:
        print("# usernames")
        print("\n".join(users))
        if emails:
            print("\n# e-mails")
            print("\n".join(emails))
        print(f"\n# {note}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
