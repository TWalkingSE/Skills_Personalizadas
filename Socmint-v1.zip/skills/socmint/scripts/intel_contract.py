"""
intel_contract.py — Contrato de dados comum `intel-bundle/1.0`.

Todas as skills de inteligência (Document, Financial, Link Analysis, Social Media,
Malware/Artifact) entregam um BUNDLE: uma lista de operações compatível com o
`nb.py batch` do Investigative Notebook, acrescida de:
  - op "indicator" (IOC), e
  - `provenance` em cada item (documento, página, trecho, posição, método).

O Notebook importa com `nb.py import-bundle caso.json bundle.json`, aplicando entity
resolution entre skills (mesmo CPF, conta, IP, domínio, hash... => mesma entidade).

Princípios codificados aqui (não contorne):
  * toda afirmação carrega `nature` (fato/declarado/correlacao/inferencia/hipotese/nao_verificado);
  * nada vira "fato" sem fonte ou evidência associada (validate() acusa);
  * proveniência é estruturada (Locator), não texto livre.

Somente biblioteca padrão.
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import re
from typing import Any

try:
    from intel_normalize import normalize, strip_accents
except ImportError:  # uso fora da pasta scripts
    from .intel_normalize import normalize, strip_accents  # type: ignore

CONTRACT = "intel-bundle/1.0"

NATURES = ("fato", "observado", "declarado", "correlacao", "inferencia", "hipotese", "nao_verificado")
# Vocabulário do contrato (inglês) -> chave interna. "fato" = OFFICIAL (fonte oficial: ordem judicial, sistema
# institucional, resposta de ofício); "observado" = OBSERVED (verificação direta do analista/ferramenta: hash
# calculado, string presente no arquivo, perfil público capturado).
NATURE_CONTRACT = {"fato": "OFFICIAL", "observado": "OBSERVED", "declarado": "DECLARED", "correlacao": "CORRELATED",
                   "inferencia": "INFERRED", "hipotese": "HYPOTHESIS", "nao_verificado": "UNVERIFIED"}
NATURE_ALIASES = {**{v.lower(): k for k, v in NATURE_CONTRACT.items()}, **{k: k for k in NATURE_CONTRACT},
                  "oficial": "fato", "fact": "fato", "correlation": "correlacao", "inference": "inferencia",
                  "unverified": "nao_verificado", "naoverificado": "nao_verificado"}
FACTUAL = {"fato", "observado"}
SOURCE_RELIABILITY = {"A": "completamente confiável", "B": "geralmente confiável", "C": "razoavelmente confiável",
                      "D": "geralmente não confiável", "E": "não confiável", "F": "não avaliável"}
INFO_CREDIBILITY = {"1": "confirmada por outras fontes", "2": "provavelmente verdadeira", "3": "possivelmente verdadeira",
                    "4": "duvidosa", "5": "improvável", "6": "não avaliável"}


def canon_nature(v):
    """Aceita a chave interna ou o termo do contrato (OFFICIAL, OBSERVED, …); devolve a chave interna."""
    if v in (None, ""):
        return v
    k = strip_accents(str(v)).lower().strip().replace(" ", "_").replace("-", "_")
    if k not in NATURE_ALIASES:
        raise ValueError(f"natureza inválida {v!r}; use {', '.join(NATURES)} ou {', '.join(NATURE_CONTRACT.values())}")
    return NATURE_ALIASES[k]
CONFIDENCE = ("muito_baixa", "baixa", "media", "alta", "muito_alta")

# Identificadores fortes: igualdade do valor normalizado basta para a entity resolution.
STRONG_IDENTIFIERS = {
    "cpf", "cnpj", "telefone", "email", "ip", "prefixo_ip", "dominio", "url", "placa", "pix", "imei",
    "mac", "asn", "sha256", "sha1", "md5", "sha512", "conta_bancaria", "processo", "perfil",
    "username", "e2e", "chassi", "renavam", "certificado_sha256", "pacote_android", "caso_ref",
}

# Tipo de entidade do Notebook para cada tipo de IOC
IOC_ENTITY_TYPE = {
    "ip": "ip", "ipv4": "ip", "ipv6": "ip", "domain": "dominio", "dominio": "dominio", "url": "url",
    "email": "email", "hash": "hash", "sha256": "hash", "sha1": "hash", "md5": "hash",
    "file": "arquivo", "arquivo": "arquivo", "certificate": "certificado", "certificado": "certificado",
    "mutex": "mutex", "registry": "chave_registro", "chave_registro": "chave_registro",
    "asn": "asn", "user_agent": "outro", "path": "arquivo", "apk": "aplicativo", "pacote_android": "aplicativo",
}
IOC_IDENTIFIER_KIND = {"ip": "ip", "ipv4": "ip", "ipv6": "ip", "domain": "dominio", "dominio": "dominio",
                       "url": "url", "email": "email", "sha256": "sha256", "sha1": "sha1", "md5": "md5",
                       "hash": "hash", "asn": "asn", "pacote_android": "pacote_android"}


def now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ----------------------------------------------------------------------------
# Locator (proveniência)
# ----------------------------------------------------------------------------

def locator(document: str, doc_sha256: str = "", page: int | None = None, snippet: str = "",
            char_start: int | None = None, char_end: int | None = None, line: int | None = None,
            bbox: list | None = None, bbox_unit: str = "", where: str = "", context: str = "",
            method: str = "", confidence: float | None = None, doc_id: str = "", **extra) -> dict:
    """Posição exata de onde a informação foi obtida.

    where: rótulo humano da posição quando não há página ("Planilha1!C12", "§ 14", "linha 230",
           "seção .text", "AndroidManifest.xml").
    bbox:  [x0, y0, x1, y1] na unidade `bbox_unit` ("pt" para PDF, "px" para imagem/OCR).
    """
    loc = {"document": document, "doc_sha256": doc_sha256, "doc_id": doc_id, "page": page, "where": where,
           "line": line, "char_start": char_start, "char_end": char_end, "bbox": bbox, "bbox_unit": bbox_unit,
           "snippet": snippet, "context": context, "method": method, "confidence": confidence}
    loc.update(extra)
    return {k: v for k, v in loc.items() if v not in (None, "", [])}


def cite(loc: dict, what: str = "") -> str:
    """Frase de citação: 'O telefone X foi extraído da página 4 do documento Y (...), linha 12: «...»'."""
    parts = []
    if loc.get("page"):
        parts.append(f"da página {loc['page']}")
    if loc.get("where"):
        parts.append(f"de {loc['where']}" if not parts else f"({loc['where']})")
    doc = loc.get("document", "documento sem nome")
    sha = loc.get("doc_sha256", "")
    s = (f"{what} foi extraído " if what else "Extraído ") + " ".join(parts) + f" do documento {doc}"
    if sha:
        s += f" (SHA-256 {sha[:12]}…)"
    if loc.get("line"):
        s += f", linha {loc['line']}"
    if loc.get("bbox"):
        b = loc["bbox"]
        s += f", posição [{', '.join(str(round(x)) for x in b)}] {loc.get('bbox_unit', '')}".rstrip()
    if loc.get("snippet"):
        snip = re.sub(r"\s+", " ", loc["snippet"]).strip()
        s += f": «{snip[:160]}{'…' if len(snip) > 160 else ''}»"
    if loc.get("method"):
        s += f" [método: {loc['method']}]"
    return s.replace("  ", " ").strip() + ("" if s.endswith(".") else ".")


# ----------------------------------------------------------------------------
# Bundle
# ----------------------------------------------------------------------------

_STOP = {"DA", "DE", "DO", "DAS", "DOS", "E"}


def names_compatible(a: str, b: str) -> bool:
    """Contenção de tokens (João Silva ⊂ João da Silva Ferreira); abreviações de 1 letra aceitas."""
    def toks(s):
        return [t for t in re.sub(r"[^A-Z0-9 ]", " ", strip_accents(s or "").upper()).split() if t not in _STOP]
    ta, tb = toks(a), toks(b)
    if not ta or not tb:
        return True
    short, long_ = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
    hit = sum(any(y == x or (len(x) == 1 and y.startswith(x)) or (len(y) == 1 and x.startswith(y)) for y in long_) for x in short)
    return hit / len(short) >= 0.75 and ta[0][0] == tb[0][0]


def _entity_key(etype: str, label: str, identifiers: dict) -> tuple:
    for k, v in sorted((identifiers or {}).items()):
        kk = k.split("__")[0]
        if kk in STRONG_IDENTIFIERS:
            n = normalize(kk, v)["normalized"] if not isinstance(v, dict) else v.get("normalized")
            if n and "?" not in str(n):
                return ("id", kk, n)
    lab = re.sub(r"\s+", " ", strip_accents(label or "").upper()).strip()
    return ("label", etype, lab)


class Bundle:
    """Construtor de bundles. Todos os métodos retornam uma referência local ("@ref")."""

    def __init__(self, producer: str, producer_version: str = "1.0", case_ref: str = "",
                 legal_basis: str = "", analyst: str = "", description: str = ""):
        self.meta = {"contract": CONTRACT, "producer": producer, "producer_version": producer_version,
                     "generated_at": now_iso(), "case_ref": case_ref, "legal_basis": legal_basis,
                     "analyst": analyst or os.environ.get("NB_USER", ""), "description": description}
        self.items: list[dict] = []
        self._n = 0
        self._ents: dict[tuple, dict] = {}
        self._srcs: dict[tuple, str] = {}
        self._evid: dict[str, str] = {}
        self._rels: dict[tuple, dict] = {}

    def _ref(self, prefix: str) -> str:
        self._n += 1
        return f"{prefix}{self._n}"

    # --- fontes e evidências ---
    def source(self, type: str, title: str, reference: str = "", date: str = "", reliability: str = "",
               credibility: str = "", level: str = "", url: str = "", accessed_at: str = "", **kw) -> str:
        """reliability A–F e credibility 1–6 (escala Admiralty); level primaria|secundaria; accessed_at = data da consulta."""
        key = (type, title, reference)
        if key in self._srcs:
            return self._srcs[key]
        ref = self._ref("src")
        extra = {k: v for k, v in (("reliability", str(reliability).upper() if str(reliability).upper() in SOURCE_RELIABILITY else reliability),
                                   ("credibility", str(credibility) if credibility else ""), ("level", level), ("url", url),
                                   ("accessed_at", accessed_at)) if v}
        self.items.append({"op": "source", "ref": ref, "type": type, "title": title, "reference": reference,
                           "date": date, **extra, **kw})
        self._srcs[key] = "@" + ref
        return "@" + ref

    def evidence(self, name: str, type: str = "outro", file_path: str | None = None, sha256: str = "",
                 source_id: str = "", description: str = "", **kw) -> str:
        if file_path and os.path.isfile(file_path) and not sha256:
            sha256 = sha256_file(file_path)
        key = sha256 or f"{name}|{file_path}"
        if key in self._evid:
            return self._evid[key]
        ref = self._ref("ev")
        item = {"op": "evidence", "ref": ref, "name": name, "type": type, "source_id": source_id,
                "description": description, **kw}
        if file_path:
            item["file_path"] = os.path.abspath(file_path)
        if sha256:
            item["sha256"] = sha256
        self.items.append(item)
        self._evid[key] = "@" + ref
        return "@" + ref

    # --- entidades e indicadores ---
    def entity(self, type: str, label: str, identifiers: dict | None = None, attributes: dict | None = None,
               nature: str = "nao_verificado", confidence: Any = "media", source_ids=None, evidence_ids=None,
               provenance: list | dict | None = None, aliases=None, location: dict | None = None,
               tags=None, status: str | None = None, notes: str = "", _op: str = "entity", **kw) -> str:
        identifiers = {k: v for k, v in (identifiers or {}).items() if v not in (None, "")}
        nature = canon_nature(nature)
        prov = [provenance] if isinstance(provenance, dict) else list(provenance or [])
        key = _entity_key(type, label, identifiers)
        if key in self._ents and type in ("pessoa", "empresa") and key[0] == "id" \
                and not names_compatible(self._ents[key]["label"], label):
            # mesmo CPF/CNPJ com nomes incompatíveis: NÃO unifica (contradição a ser registrada pelo produtor)
            key = key + ("nome", re.sub(r"\s+", " ", strip_accents(label).upper()))
        if key in self._ents:  # mesma entidade no mesmo bundle: acumula proveniência
            it = self._ents[key]
            it.setdefault("provenance", []).extend(p for p in prov if p not in it["provenance"])
            for fld, val in (("source_ids", source_ids), ("evidence_ids", evidence_ids), ("aliases", aliases), ("tags", tags)):
                if val:
                    it[fld] = list(dict.fromkeys(it.get(fld, []) + list(val)))
            for k, v in identifiers.items():
                it.setdefault("identifiers", {}).setdefault(k, v)
            for k, v in (attributes or {}).items():
                it.setdefault("attributes", {}).setdefault(k, v)
            if label != it["label"] and label not in it.get("aliases", []):
                it.setdefault("aliases", []).append(label)
            return "@" + it["ref"]
        ref = self._ref("e")
        item = {"op": _op, "ref": ref, "type": type, "label": label, "identifiers": identifiers,
                "attributes": dict(attributes or {}), "nature": nature, "confidence": confidence,
                "source_ids": list(source_ids or []), "evidence_ids": list(evidence_ids or []),
                "provenance": prov, "aliases": list(aliases or []), "tags": list(tags or []), "notes": notes, **kw}
        if location:
            item["location"] = location
        if status:
            item["status"] = status
        self.items.append(item)
        self._ents[key] = item
        return "@" + ref

    def indicator(self, ioc_type: str, value: str, nature: str = "nao_verificado", confidence: Any = "media",
                  context: str = "", tlp: str = "TLP:AMBER", first_seen: str = "", last_seen: str = "",
                  source_ids=None, evidence_ids=None, provenance=None, label: str = "", **kw) -> str:
        etype = IOC_ENTITY_TYPE.get(ioc_type, "indicador")
        kind = IOC_IDENTIFIER_KIND.get(ioc_type)
        idents = {kind: value} if kind else {}
        if ioc_type in ("hash",):
            n = normalize("hash", value)
            if n["valid"]:
                idents = {n["note"]: value}
        attrs = {"ioc_type": ioc_type, "tlp": tlp, "context": context}
        if first_seen:
            attrs["first_seen"] = first_seen
        if last_seen:
            attrs["last_seen"] = last_seen
        return self.entity(etype, label or value, idents, attrs, nature, confidence, source_ids, evidence_ids,
                           provenance, tags=["IOC"], _op="indicator", **kw)

    # --- relações, eventos, observações, hipóteses ---
    def rel(self, source: str, type: str, target: str, nature: str = "nao_verificado", confidence: Any = "media",
            start: str = "", end: str = "", attributes: dict | None = None, source_ids=None, evidence_ids=None,
            provenance=None, notes: str = "", directed: bool | None = None, **kw) -> str:
        prov = [provenance] if isinstance(provenance, dict) else list(provenance or [])
        nature = canon_nature(nature)
        attributes = dict(attributes or {})
        key = (source, type, target, start, str(attributes.get("amount", "")), str(attributes.get("txid", "")),
               json.dumps({k: v for k, v in attributes.items() if k not in ("amount", "txid")}, sort_keys=True, default=str)[:300])
        if key in self._rels:
            it = self._rels[key]
            it["provenance"].extend(p for p in prov if p not in it["provenance"])
            it["source_ids"] = list(dict.fromkeys(it["source_ids"] + list(source_ids or [])))
            it["evidence_ids"] = list(dict.fromkeys(it["evidence_ids"] + list(evidence_ids or [])))
            return "@" + it["ref"]
        ref = self._ref("r")
        item = {"op": "rel", "ref": ref, "source": source, "type": type, "target": target, "nature": nature,
                "confidence": confidence, "start": start, "end": end, "attributes": attributes,
                "source_ids": list(source_ids or []), "evidence_ids": list(evidence_ids or []),
                "provenance": prov, "notes": notes, **kw}
        if directed is not None:
            item["directed"] = directed
        self.items.append(item)
        self._rels[key] = item
        return "@" + ref

    def event(self, title: str, type: str = "personalizado", start: str = "", end: str = "", participants=None,
              nature: str = "nao_verificado", confidence: Any = "media", attributes: dict | None = None,
              location: dict | None = None, source_ids=None, evidence_ids=None, provenance=None,
              description: str = "", **kw) -> str:
        ref = self._ref("evt")
        item = {"op": "event", "ref": ref, "title": title, "type": type, "start": start, "end": end,
                "participants": list(participants or []), "nature": canon_nature(nature), "confidence": confidence,
                "attributes": dict(attributes or {}), "source_ids": list(source_ids or []),
                "evidence_ids": list(evidence_ids or []),
                "provenance": [provenance] if isinstance(provenance, dict) else list(provenance or []),
                "description": description, **kw}
        if location:
            item["location"] = location
        self.items.append(item)
        return "@" + ref

    def observation(self, statement: str, entity_id: str = "", attribute: str = "", value: Any = None,
                    source_id: str = "", evidence_id: str = "", method: str = "", nature: str | None = None,
                    confidence: Any = None, provenance=None, relationship_id: str = "", observed_at: str = "", **kw) -> str:
        ref = self._ref("o")
        item = {"op": "obs", "ref": ref, "statement": statement, "entity_id": entity_id, "attribute": attribute,
                "value": value, "source_id": source_id, "evidence_id": evidence_id, "method": method,
                "relationship_id": relationship_id, "observed_at": observed_at,
                "provenance": [provenance] if isinstance(provenance, dict) else list(provenance or []), **kw}
        if nature:
            item["nature"] = canon_nature(nature)
        if confidence is not None:
            item["confidence"] = confidence
        self.items.append(item)
        return "@" + ref

    def hypothesis(self, title: str, supporting=None, contradicting=None, gaps=None, confidence=None,
                   status: str = "aberta", **kw) -> str:
        ref = self._ref("h")
        self.items.append({"op": "hypothesis", "ref": ref, "title": title, "supporting": list(supporting or []),
                           "contradicting": list(contradicting or []), "gaps": list(gaps or []),
                           "confidence": confidence, "status": status, **kw})
        return "@" + ref

    def analysis(self, type: str, method: str, result, input_entities=None, confidence=None, limitations: str = "",
                 nature: str = "inferencia", tool: str = "", tool_version: str = "", parameters: dict | None = None,
                 source_ids=None, evidence_ids=None, **kw) -> str:
        """Contrato ANALYSIS: registro reproduzível (entrada, método, parâmetros, resultado, confiança, limitações)."""
        ref = self._ref("an")
        self.items.append({"op": "analysis", "ref": ref, "type": type, "method": method, "result": result,
                           "input_entities": list(input_entities or []), "confidence": confidence, "limitations": limitations,
                           "nature": canon_nature(nature), "tool": tool or self.meta["producer"],
                           "tool_version": tool_version or self.meta["producer_version"], "parameters": dict(parameters or {}),
                           "source_ids": list(source_ids or []), "evidence_ids": list(evidence_ids or []), **kw})
        return "@" + ref

    def osint(self, query: str, tool: str, result_summary: str, entity_ids=None, limitations: str = "",
              legal_basis: str = "", evidence_id: str = "", **kw) -> str:
        ref = self._ref("q")
        self.items.append({"op": "osint", "ref": ref, "query": query, "tool": tool, "result_summary": result_summary,
                           "entity_ids": list(entity_ids or []), "limitations": limitations,
                           "legal_basis": legal_basis or self.meta.get("legal_basis", ""), "evidence_id": evidence_id, **kw})
        return "@" + ref

    # --- saída ---
    def summary(self) -> dict:
        from collections import Counter
        c = Counter(i["op"] for i in self.items)
        return dict(c)

    def to_dict(self, findings: list | None = None, extra: dict | None = None) -> dict:
        # fontes e evidências primeiro: um item criado antes pode ter recebido (por unificação) referência a uma fonte posterior
        order = {"source": 0, "evidence": 1}
        items = sorted(self.items, key=lambda it: order.get(it["op"], 2))
        d = {**self.meta, "summary": self.summary(), "items": items}
        if findings is not None:
            d["findings"] = findings
        if extra:
            d.update(extra)
        return d

    def save(self, path: str, findings: list | None = None, extra: dict | None = None) -> str:
        data = self.to_dict(findings, extra)
        problems = validate(data)
        errors = [p for p in problems if p["level"] == "erro"]
        if errors:
            raise ValueError("Bundle inválido: " + "; ".join(p["message"] for p in errors[:10]))
        data["validation"] = problems
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=1, default=str)
        return path


# ----------------------------------------------------------------------------
# Validação
# ----------------------------------------------------------------------------

def validate(data: dict) -> list[dict]:
    out = []
    def add(level, msg, ref=None):
        out.append({"level": level, "message": msg, "ref": ref})
    if data.get("contract") != CONTRACT:
        add("erro", f"contrato inesperado: {data.get('contract')!r} (esperado {CONTRACT})")
    refs = set()
    for i, it in enumerate(data.get("items", []), start=1):
        op = it.get("op")
        if op not in ("source", "evidence", "entity", "indicator", "rel", "relationship", "event", "obs",
                      "observation", "hypothesis", "osint", "analysis"):
            add("erro", f"item {i}: op desconhecida {op!r}")
            continue
        if it.get("ref"):
            if it["ref"] in refs:
                add("erro", f"ref duplicada {it['ref']}", it["ref"])
            refs.add(it["ref"])
        def check_ref(v):
            if isinstance(v, str) and v.startswith("@") and v[1:] not in refs:
                add("erro", f"item {i} ({op}): referência {v} usada antes de definida", it.get("ref"))
        for fld in ("source", "target", "entity_id", "source_id", "evidence_id", "relationship_id"):
            check_ref(it.get(fld))
        for fld in ("source_ids", "evidence_ids", "participants", "supporting", "contradicting", "entity_ids", "input_entities"):
            for v in it.get(fld, []) or []:
                check_ref(v)
        if op in ("entity", "indicator", "rel", "relationship", "event", "obs", "observation", "analysis"):
            nat = it.get("nature")
            try:
                nat = canon_nature(nat)
            except ValueError:
                add("erro", f"item {i}: natureza inválida {nat!r}", it.get("ref"))
            if nat in FACTUAL and not it.get("source_ids") and not it.get("evidence_ids") and not it.get("source_id") \
                    and not it.get("evidence_id"):
                add("alerta", f"item {i} ({op}) marcado como fato sem fonte/evidência", it.get("ref"))
            if op in ("entity", "indicator", "rel", "event") and not it.get("provenance"):
                add("alerta", f"item {i} ({op}) sem proveniência (documento/página/trecho)", it.get("ref"))
    return out


def load(path: str) -> dict:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)
