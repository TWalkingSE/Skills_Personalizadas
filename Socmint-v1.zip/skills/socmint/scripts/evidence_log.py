#!/usr/bin/env python3
"""Log de evidências com hash encadeado e árvore de pastas ODPAR (offline).

Comandos:
    init    cria a pasta do caso (01_..06_), case.json e evidence_log.jsonl
    add     registra arquivo(s): SHA-256/SHA-512, tamanho, hora da coleta e do registro (UTC), URL, método e ambiente
    event   registra evento de custódia (acondicionamento, transporte, recebimento, processamento, armazenamento,
            descarte, acesso, cópia) sobre uma ou mais evidências (CPP art. 158-B, por analogia)
    custody lista os eventos de custódia (ou exporta em CSV)
    verify  reconfere a cadeia de hashes e os arquivos (SHA-256 e SHA-512)
    export  exporta o log em csv, md, json ou sha256sums (formato do `sha256sum -c`)
    list    lista as evidências
    hash    calcula o hash de arquivos avulsos

Exemplos:
    python3 scripts/evidence_log.py init --case-dir caso-001 --title "Perfil falso" --collector "Ana" --tz America/Sao_Paulo
    python3 scripts/evidence_log.py add --case-dir caso-001 --file perfil.html --url https://... --platform tiktok --type html \
        --captured "2026-05-10 14:22:05" --tool "Firefox" --tool-version "131" --network "VPN X" --account "nenhuma"
    python3 scripts/evidence_log.py event --case-dir caso-001 --stage transporte --evidence all --who "Ana" --to "Cartório Y"
    python3 scripts/evidence_log.py verify --case-dir caso-001
    python3 scripts/evidence_log.py export --case-dir caso-001 --format csv --out caso-001/evidencias.csv

O encadeamento (prev_hash -> entry_hash) torna adulteração EVIDENTE, mas não prova a data da coleta
(o relógio é o do computador) e não detecta a remoção das ÚLTIMAS linhas: guarde o "hash final da cadeia"
fora do arquivo (relatório, ata notarial, carimbo do tempo) e use `verify --expect-last <hash>`.

Horários: `utc` é o momento do REGISTRO no log; `coleta_utc` é o momento da COLETA, informado com --captured
(sem fuso = fuso do caso). Os dois podem diferir (captura feita antes e registrada depois): o relatório usa a hora
da coleta e marca quando só existe a do registro. `arquivo_mtime_utc` guarda a data de modificação do arquivo de
origem, como indício adicional (não prova a hora da coleta).

`init` exige --tz com o fuso IANA da localidade do fato (ex.: America/Maceio para SE/AL): ele vai para o
case.json e define a hora local do relatório. Deslocamento fixo (escreva `--tz=-03:00`, com sinal de igual) é
aceito, mas ignora o horário de verão histórico.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

from _common import (
    DEFAULT_TZ,
    SCRIPTS_VERSION,
    canonical_json,
    die,
    ensure_utf8_stdout,
    file_mtime_utc,
    guard_output,
    parse_tz,
    parse_when_utc,
    sha256_file,
    slugify,
    utc_now_iso,
    write_csv,
)

CUSTODY_STAGES = ["acondicionamento", "transporte", "recebimento", "processamento", "armazenamento", "descarte",
                  "acesso", "copia", "outro"]
EVIDENCE_FIELDS = ["id", "coleta_utc", "utc", "plataforma", "tipo", "url", "metodo", "ferramenta", "versao_ferramenta",
                   "navegador", "rede", "conta", "arquivo", "arquivo_mtime_utc", "tamanho", "sha256", "notas", "coletor"]

ODPAR_DIRS = [
    "01_Identificadores",
    "02_Midia_Original",
    "03_Pivotagem_Social",
    "04_Preservacao_Web",
    "05_Analises",
    "06_Relatorios_e_Mapas",
]
TYPE_DIR = {
    "id": ODPAR_DIRS[0], "identificador": ODPAR_DIRS[0],
    "midia": ODPAR_DIRS[1], "imagem": ODPAR_DIRS[1], "video": ODPAR_DIRS[1], "audio": ODPAR_DIRS[1], "documento": ODPAR_DIRS[1],
    "pivo": ODPAR_DIRS[2],
    "perfil": ODPAR_DIRS[3], "post": ODPAR_DIRS[3], "html": ODPAR_DIRS[3], "json": ODPAR_DIRS[3], "captura": ODPAR_DIRS[3],
    "screenshot": ODPAR_DIRS[3], "warc": ODPAR_DIRS[3], "pagina": ODPAR_DIRS[3], "convite": ODPAR_DIRS[3],
    "export": ODPAR_DIRS[4], "analise": ODPAR_DIRS[4], "planilha": ODPAR_DIRS[4],
    "relatorio": ODPAR_DIRS[5], "grafo": ODPAR_DIRS[5], "mapa": ODPAR_DIRS[5],
}
LOG_NAME = "evidence_log.jsonl"
ZERO = "0" * 64


def entry_hash(entry: dict) -> str:
    body = {k: v for k, v in entry.items() if k != "entry_hash"}
    return hashlib.sha256(canonical_json(body).encode("utf-8")).hexdigest()


def case_paths(case_dir: str) -> tuple[Path, Path, Path]:
    root = Path(case_dir)
    return root, root / "case.json", root / LOG_NAME


def load_log(log_path: Path) -> list[dict]:
    if not log_path.exists():
        return []
    entries = []
    for i, line in enumerate(log_path.read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError as exc:
            die(f"linha {i} de {log_path.name} não é JSON válido: {exc}")
    return entries


def append_entry(log_path: Path, entry: dict) -> dict:
    entries = load_log(log_path)
    entry["prev_hash"] = entries[-1]["entry_hash"] if entries else ZERO
    entry["entry_hash"] = entry_hash(entry)
    with open(log_path, "a", encoding="utf-8", newline="\n") as fh:
        fh.write(json.dumps(entry, ensure_ascii=False, sort_keys=True) + "\n")
    return entry


def load_case(case_json: Path) -> dict:
    if case_json.exists():
        try:
            return json.loads(case_json.read_text(encoding="utf-8-sig"))
        except json.JSONDecodeError:
            die(f"{case_json} não é JSON válido.")
    return {}


def template_case() -> dict:
    tpl = Path(__file__).resolve().parent.parent / "assets" / "case.template.json"
    if tpl.exists():
        return json.loads(tpl.read_text(encoding="utf-8-sig"))
    return {"id_caso": "", "titulo": "", "criado_utc": "", "fuso": DEFAULT_TZ, "coletor": "", "contexto": "", "nivel": 2, "gate": {}, "hipoteses": [], "escopo": {}, "sementes": []}


def cmd_init(a: argparse.Namespace) -> int:
    root, case_json, log_path = case_paths(a.case_dir)
    guard_output(root, "--case-dir")
    _, tz_label = parse_tz(a.tz)  # valida antes de criar qualquer pasta
    if "/" not in a.tz and a.tz.upper() not in ("UTC", "Z"):
        print(f"Aviso: --tz {a.tz!r} não é um nome IANA ({tz_label}); horários anteriores a 2019 podem sair com 1 h de erro "
              "em períodos de horário de verão. Prefira o nome da localidade (ex.: America/Maceio).", file=sys.stderr)
    root.mkdir(parents=True, exist_ok=True)
    for d in ODPAR_DIRS:
        (root / d).mkdir(exist_ok=True)
    case_id = a.case_id or slugify(root.resolve().name, "-").upper()
    if not case_json.exists() or a.force:
        case = template_case()
        case.update({
            "id_caso": case_id, "titulo": a.title or case.get("titulo", ""), "criado_utc": utc_now_iso(),
            "fuso": a.tz, "coletor": a.collector or "", "contexto": a.context or case.get("contexto", ""), "nivel": a.level,
        })
        case_json.write_text(json.dumps(case, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    else:
        case = load_case(case_json)
        case_id = case.get("id_caso", case_id)
        if case.get("fuso") != a.tz:
            print(f"Aviso: case.json já existe com fuso {case.get('fuso')!r}; mantido (use --force para recriar ou edite o campo 'fuso').", file=sys.stderr)
    if not log_path.exists() or log_path.stat().st_size == 0:
        header = {"registro": "cabecalho", "id_caso": case_id, "criado_utc": utc_now_iso(), "versao_log": 1,
                  "fuso": a.tz, "versao_scripts": SCRIPTS_VERSION}
        append_entry(log_path, header)
    print(f"Caso {case_id} pronto em {root}")
    print("Pastas:", ", ".join(ODPAR_DIRS))
    print(f"Arquivos: case.json, {LOG_NAME} (cabeçalho da cadeia gravado)")
    return 0


def next_ev_id(entries: list[dict]) -> str:
    n = sum(1 for e in entries if e.get("registro") == "evidencia")
    return f"EV-{n + 1:04d}"


def cmd_add(a: argparse.Namespace) -> int:
    root, case_json, log_path = case_paths(a.case_dir)
    guard_output(root, "--case-dir")
    if not log_path.exists():
        die(f"caso não inicializado em {root} (rode `init` antes).")
    case = load_case(case_json)
    collector = a.collector or case.get("coletor", "")
    tipo = (a.type or "").lower()
    tz, _ = parse_tz(case.get("fuso") or DEFAULT_TZ)
    captured = parse_when_utc(a.captured, tz) if a.captured else ""
    if not captured:
        print("Aviso: hora da coleta não informada (--captured); fica registrada só a hora do registro no log.", file=sys.stderr)
    for f in a.file:
        src = Path(f)
        if not src.is_file():
            die(f"arquivo não encontrado: {src}")
        src_sha256 = sha256_file(src)  # hash da origem ANTES de copiar
        src_mtime = file_mtime_utc(src)
        entries = load_log(log_path)
        ev_id = next_ev_id(entries)
        now = utc_now_iso()
        if a.no_copy:
            try:
                rel = src.resolve().relative_to(root.resolve()).as_posix()
            except ValueError:
                rel = src.resolve().as_posix()
            stored = src
        else:
            sub = TYPE_DIR.get(tipo, ODPAR_DIRS[3])
            stamp = now.replace("-", "").replace(":", "")
            name = f"{stamp}_{slugify(a.platform or 'fonte', '')}_{slugify(tipo or 'arquivo', '')}_{slugify(src.stem)[:40]}{src.suffix.lower()}"
            dest = root / sub / name
            k = 1
            while dest.exists():
                dest = root / sub / f"{dest.stem}_{k}{dest.suffix}"
                k += 1
            shutil.copy2(src, dest)
            if sha256_file(dest) != src_sha256:
                dest.unlink(missing_ok=True)
                die(f"a cópia de {src} não confere com a origem (SHA-256 diferente); nada foi registrado.")
            stored, rel = dest, dest.relative_to(root).as_posix()
        entry = {
            "registro": "evidencia", "id": ev_id, "utc": now, "coleta_utc": captured, "coletor": collector, "url": a.url or "",
            "plataforma": a.platform or "", "tipo": tipo, "metodo": a.method or "", "arquivo": rel,
            "arquivo_original": src.name, "arquivo_mtime_utc": src_mtime, "tamanho": stored.stat().st_size,
            "sha256": src_sha256, "sha512": sha256_file(stored, "sha512"), "copia_conferida": not a.no_copy,
            "ferramenta": a.tool or "", "versao_ferramenta": a.tool_version or "", "navegador": a.browser or "",
            "rede": a.network or "", "conta": a.account or "", "notas": a.notes or "",
        }
        done = append_entry(log_path, entry)
        print(f"{ev_id}  {rel}  sha256={done['sha256'][:16]}…")
    last = load_log(log_path)[-1]["entry_hash"]
    print(f"Hash final da cadeia: {last}  (guarde fora do arquivo)")
    return 0


def custody_events(entries: list[dict]) -> list[dict]:
    return [e for e in entries if e.get("registro") == "custodia"]


def discarded_ids(entries: list[dict]) -> set[str]:
    return {ev for e in custody_events(entries) if e.get("etapa") == "descarte" for ev in e.get("evidencias", [])}


def cmd_event(a: argparse.Namespace) -> int:
    root, case_json, log_path = case_paths(a.case_dir)
    if not log_path.exists():
        die(f"caso não inicializado em {root} (rode `init` antes).")
    entries = load_log(log_path)
    known = [e["id"] for e in entries if e.get("registro") == "evidencia"]
    wanted = known if [x.lower() for x in a.evidence] == ["all"] else [x.strip() for x in a.evidence]
    missing = [x for x in wanted if x not in known]
    if missing:
        die(f"evidência(s) inexistente(s) no log: {', '.join(missing)}")
    if not wanted:
        die("nenhuma evidência no log para associar ao evento.")
    gone = discarded_ids(entries) & set(wanted)
    if gone and a.stage != "descarte":
        print(f"Aviso: {', '.join(sorted(gone))} já tem descarte registrado.", file=sys.stderr)
    case = load_case(case_json)
    tz, _ = parse_tz(case.get("fuso") or DEFAULT_TZ)
    now = utc_now_iso()
    n = len(custody_events(entries)) + 1
    entry = {"registro": "custodia", "id": f"CU-{n:04d}", "utc": now, "quando_utc": parse_when_utc(a.when, tz) if a.when else now,
             "etapa": a.stage, "evidencias": wanted, "responsavel": a.who, "destino": a.to or "", "notas": a.notes or ""}
    append_entry(log_path, entry)
    print(f"{entry['id']}  {a.stage}  {', '.join(wanted)}")
    if a.stage == "descarte":
        print("Descarte registrado. O script não apaga arquivos: elimine-os pelo procedimento da unidade; `verify` deixa de cobrá-los.")
    print(f"Hash final da cadeia: {load_log(log_path)[-1]['entry_hash']}  (guarde fora do arquivo)")
    return 0


def cmd_custody(a: argparse.Namespace) -> int:
    _, _, log_path = case_paths(a.case_dir)
    rows = [{"id": e["id"], "quando_utc": e.get("quando_utc", ""), "registro_utc": e.get("utc", ""), "etapa": e.get("etapa", ""),
             "evidencias": ";".join(e.get("evidencias", [])), "responsavel": e.get("responsavel", ""), "destino": e.get("destino", ""),
             "notas": e.get("notas", "")} for e in custody_events(load_log(log_path))]
    if a.out:
        write_csv(Path(a.out), rows, ["id", "quando_utc", "registro_utc", "etapa", "evidencias", "responsavel", "destino", "notas"])
        print(f"CSV gravado em {a.out} ({len(rows)} evento(s))")
    elif not rows:
        print("Nenhum evento de custódia registrado.")
    for r in rows if not a.out else []:
        print(f"{r['id']}  {r['quando_utc']}  {r['etapa']:<16} {r['evidencias']}  {r['responsavel']}{' → ' + r['destino'] if r['destino'] else ''}")
    return 0


def check(root: Path, entries: list[dict], expect_last: str | None = None) -> tuple[bool, list[str]]:
    problems: list[str] = []
    prev = ZERO
    gone = discarded_ids(entries)
    for i, e in enumerate(entries, 1):
        if e.get("prev_hash") != prev:
            problems.append(f"linha {i}: prev_hash não confere (cadeia quebrada: linha alterada, removida ou reordenada)")
        if entry_hash(e) != e.get("entry_hash"):
            problems.append(f"linha {i}: entry_hash não confere (conteúdo da linha foi alterado)")
        prev = e.get("entry_hash", "")
        if e.get("registro") == "evidencia":
            path = Path(e["arquivo"])
            full = path if path.is_absolute() else root / path
            if e["id"] in gone:
                continue  # descarte registrado: arquivo não é mais cobrado
            if not full.exists():
                problems.append(f"{e['id']}: arquivo AUSENTE ({e['arquivo']})")
            else:
                if sha256_file(full) != e["sha256"]:
                    problems.append(f"{e['id']}: arquivo ALTERADO (sha256 difere) ({e['arquivo']})")
                elif e.get("sha512") and sha256_file(full, "sha512") != e["sha512"]:
                    problems.append(f"{e['id']}: arquivo ALTERADO (sha512 difere) ({e['arquivo']})")
    if expect_last and entries and entries[-1].get("entry_hash") != expect_last:
        problems.append("hash final da cadeia difere do esperado (linhas finais removidas ou adicionadas depois)")
    return (not problems), problems


def cmd_verify(a: argparse.Namespace) -> int:
    root, _, log_path = case_paths(a.case_dir)
    if not log_path.exists():
        die(f"{log_path} não existe.")
    entries = load_log(log_path)
    ok, problems = check(root, entries, a.expect_last)
    evid = [e for e in entries if e.get("registro") == "evidencia"]
    gone = discarded_ids(entries)
    print(f"Evidências: {len(evid)} | descartadas: {len(gone)} | eventos de custódia: {len(custody_events(entries))} | linhas na cadeia: {len(entries)}")
    for e in evid:
        if e["id"] in gone and (root / e["arquivo"]).exists():
            print(f"Nota: {e['id']} tem descarte registrado, mas o arquivo ainda está na pasta do caso.")
    if entries:
        print(f"Hash final da cadeia: {entries[-1]['entry_hash']}")
    if ok:
        print("RESULTADO: ÍNTEGRO (cadeia e arquivos conferem: SHA-256 e, quando registrado, SHA-512).")
        print("Limite: o encadeamento não prova a data e não detecta remoção das últimas linhas sem --expect-last.")
        return 0
    print("RESULTADO: FALHA")
    for p in problems:
        print(" -", p)
    return 1


def evidence_rows(entries: list[dict]) -> list[dict]:
    return [{k: e.get(k, "") for k in EVIDENCE_FIELDS} for e in entries if e.get("registro") == "evidencia"]


def cmd_export(a: argparse.Namespace) -> int:
    root, _, log_path = case_paths(a.case_dir)
    entries = load_log(log_path)
    rows = evidence_rows(entries)
    fields = EVIDENCE_FIELDS
    final = entries[-1]["entry_hash"] if entries else ZERO
    if a.format == "sha256sums":
        gone = discarded_ids(entries)
        lines = [f"{r['sha256']}  {r['arquivo']}" for r in rows if r["id"] not in gone]
        out = Path(a.out) if a.out else root / "SHA256SUMS"
        out.write_text("\n".join(lines) + "\n", encoding="utf-8")
        print(f"{out} gravado ({len(lines)} arquivo(s); confira com `sha256sum -c {out.name}` dentro da pasta do caso). "
              f"SHA-256 do próprio arquivo: {sha256_file(out)}. Hash final da cadeia: {final}")
        return 0
    if a.format == "csv":
        out = Path(a.out) if a.out else root / "evidence_log.csv"
        write_csv(out, rows, fields)
        print(f"CSV gravado em {out} ({len(rows)} evidências). Hash final da cadeia: {final}")
    elif a.format == "json":
        text = json.dumps({"evidencias": rows, "hash_final": final}, ensure_ascii=False, indent=2)
        if a.out:
            Path(a.out).write_text(text + "\n", encoding="utf-8")
            print(f"JSON gravado em {a.out}")
        else:
            print(text)
    else:
        lines = ["| ID | Coleta (UTC) | Registro (UTC) | Plataforma | Tipo | URL | Arquivo | SHA-256 |", "|---|---|---|---|---|---|---|---|"]
        for r in rows:
            lines.append(f"| {r['id']} | {r['coleta_utc'] or '—'} | {r['utc']} | {r['plataforma']} | {r['tipo']} | {r['url']} | {r['arquivo']} | `{r['sha256']}` |")
        lines.append("")
        lines.append(f"Hash final da cadeia: `{final}`")
        text = "\n".join(lines)
        if a.out:
            Path(a.out).write_text(text + "\n", encoding="utf-8")
            print(f"Markdown gravado em {a.out}")
        else:
            print(text)
    return 0


def cmd_list(a: argparse.Namespace) -> int:
    _, _, log_path = case_paths(a.case_dir)
    entries = load_log(log_path)
    gone = discarded_ids(entries)
    for r in evidence_rows(entries):
        quando = r["coleta_utc"] or f"{r['utc']} (registro)"
        print(f"{r['id']}  {quando}  {r['plataforma']:<10} {r['tipo']:<10} {r['arquivo']}  {r['sha256'][:12]}…{'  [descartada]' if r['id'] in gone else ''}")
    return 0


def cmd_hash(a: argparse.Namespace) -> int:
    for f in a.file:
        p = Path(f)
        if not p.is_file():
            die(f"arquivo não encontrado: {p}")
        print(f"sha256  {sha256_file(p)}  {p}")
        if a.sha512:
            print(f"sha512  {sha256_file(p, 'sha512')}  {p}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Log de evidências com hash encadeado (offline).")
    sub = p.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("init", help="cria a pasta do caso")
    s.add_argument("--case-dir", required=True)
    s.add_argument("--case-id")
    s.add_argument("--title")
    s.add_argument("--collector")
    s.add_argument("--context", help="estudo | pericia | jornalismo | cti | policial")
    s.add_argument("--level", type=int, default=2, choices=[1, 2, 3])
    s.add_argument("--tz", required=True, help="fuso IANA da localidade do fato (ex.: America/Sao_Paulo, America/Maceio para SE/AL)")
    s.add_argument("--force", action="store_true", help="sobrescreve case.json")
    s.set_defaults(fn=cmd_init)

    s = sub.add_parser("add", help="registra arquivo(s) como evidência")
    s.add_argument("--case-dir", required=True)
    s.add_argument("--file", required=True, nargs="+")
    s.add_argument("--url")
    s.add_argument("--platform")
    s.add_argument("--type", help="captura, html, json, pagina, warc, midia, ata, export, ... (define a camada de preservação no relatório)")
    s.add_argument("--method", help="como foi coletado (ex.: Ctrl+U, captura de tela, SingleFile)")
    s.add_argument("--captured", help="data/hora da COLETA em ISO 8601 (sem fuso = fuso do caso), ex.: \"2026-05-10 14:22:05\"")
    s.add_argument("--tool", help="ferramenta usada na coleta")
    s.add_argument("--tool-version", help="versão da ferramenta")
    s.add_argument("--browser", help="navegador e perfil usados (ex.: Firefox, perfil dedicado)")
    s.add_argument("--network", help="rede/saída usada (ex.: VPN X, rede institucional)")
    s.add_argument("--account", help="conta usada na coleta (conta de investigação ou 'nenhuma')")
    s.add_argument("--notes")
    s.add_argument("--collector")
    s.add_argument("--no-copy", action="store_true", help="não copia o arquivo para a árvore do caso (registra o caminho)")
    s.set_defaults(fn=cmd_add)

    s = sub.add_parser("event", help="registra evento de custódia sobre evidências")
    s.add_argument("--case-dir", required=True)
    s.add_argument("--stage", required=True, choices=CUSTODY_STAGES, help="etapa (CPP art. 158-B por analogia) ou acesso/cópia")
    s.add_argument("--evidence", required=True, nargs="+", help="IDs (EV-0001 …) ou 'all'")
    s.add_argument("--who", required=True, help="responsável pelo ato")
    s.add_argument("--to", help="destino/recebedor (transporte, recebimento, cópia)")
    s.add_argument("--when", help="data/hora do ato em ISO 8601 (padrão: agora; sem fuso = fuso do caso)")
    s.add_argument("--notes")
    s.set_defaults(fn=cmd_event)

    s = sub.add_parser("custody", help="lista os eventos de custódia")
    s.add_argument("--case-dir", required=True)
    s.add_argument("--out", help="exporta em CSV")
    s.set_defaults(fn=cmd_custody)

    s = sub.add_parser("verify", help="reconfere cadeia e arquivos")
    s.add_argument("--case-dir", required=True)
    s.add_argument("--expect-last", help="hash final da cadeia guardado externamente")
    s.set_defaults(fn=cmd_verify)

    s = sub.add_parser("export", help="exporta o log")
    s.add_argument("--case-dir", required=True)
    s.add_argument("--format", choices=["csv", "md", "json", "sha256sums"], default="csv")
    s.add_argument("--out")
    s.set_defaults(fn=cmd_export)

    s = sub.add_parser("list", help="lista evidências")
    s.add_argument("--case-dir", required=True)
    s.set_defaults(fn=cmd_list)

    s = sub.add_parser("hash", help="hash de arquivos avulsos")
    s.add_argument("--file", required=True, nargs="+")
    s.add_argument("--sha512", action="store_true")
    s.set_defaults(fn=cmd_hash)
    return p


def main(argv: list[str] | None = None) -> int:
    ensure_utf8_stdout()
    a = build_parser().parse_args(argv)
    return a.fn(a)


if __name__ == "__main__":
    sys.exit(main())
