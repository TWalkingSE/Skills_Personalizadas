#!/usr/bin/env python3
"""Gera o grafo de vínculos de um caso a partir de nós e arestas (offline).

Entradas: --nodes nos.csv (id,label,type,platform,notes) e --edges arestas.csv
(source,target,relation,evidence_id,confidence[,tipo]), ou --json grafo.json ({"nodes":[...],"edges":[...]}).
Saídas em --out: grafo.mmd (Mermaid), grafo.graphml, grafo.dot, nos_gephi.csv, arestas_gephi.csv
e grafo.png (se networkx e matplotlib estiverem instalados).

Exemplo:
    python3 scripts/build_graph.py --nodes assets/exemplos/nos_exemplo.csv --edges assets/exemplos/arestas_exemplo.csv --out grafo/

Regras: toda aresta deve apontar para uma evidência (evidence_id) e ter confiança (fraca, moderada, forte).
Aresta sem evidência é sinalizada. O grafo mostra VÍNCULOS HIPOTÉTICOS corroborados por evidências; não prova identidade.

Coluna opcional `tipo` (natureza do vínculo; vazio = associacao):
    identidade  candidato a "mesma pessoa/operador"; só este tipo entra na regra de corroboração (references/06)
    associacao  aponta para, usa, publica, cadastrado com (ex.: link da bio → domínio)
    imitacao    usa marca, logotipo ou identidade de terceiro (ex.: perfil falso → empresa imitada); desenhada em
                vermelho tracejado e NUNCA deve ser lida como vínculo entre o imitador e a vítima
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from xml.sax.saxutils import escape as xml_escape

from _common import die, ensure_utf8_stdout, guard_output, input_manifest, read_csv_dicts, script_tag, utc_now_iso, write_csv

SHAPES = {  # tipo -> (abre, fecha)
    "conta": ("([", "])"), "pessoa": ("[", "]"), "organizacao": ("[", "]"), "email": ("{{", "}}"), "telefone": ("{{", "}}"),
    "dominio": ("[(", ")]"), "imagem": ("[/", "/]"), "grupo": ("[[", "]]"), "servidor": ("[[", "]]"), "canal": ("[[", "]]"),
    "bot": ("(", ")"), "evento": (">", "]"), "desconhecido": ("[", "]"),
}
COLORS = {"conta": "#cfe8ff", "pessoa": "#ffd9d9", "organizacao": "#ffe9b3", "email": "#e4d9ff", "telefone": "#e4d9ff", "dominio": "#d9f5d9",
          "imagem": "#f5e6d9", "grupo": "#d9f0f5", "servidor": "#d9f0f5", "canal": "#d9f0f5", "bot": "#eeeeee", "evento": "#fff3b0", "desconhecido": "#f0f0f0"}
CONF_STYLE = {"forte": "==>", "moderada": "-->", "fraca": "-.->"}
CONF_ORDER = {"forte": 3, "moderada": 2, "fraca": 1}
KINDS = {"identidade": "identidade", "associacao": "associacao", "associação": "associacao", "imitacao": "imitacao", "imitação": "imitacao", "": "associacao"}
IMITACAO_COLOR = "#c0392b"


def load_graph(a: argparse.Namespace) -> tuple[list[dict], list[dict]]:
    if a.json:
        data = json.loads(Path(a.json).read_text(encoding="utf-8-sig"))
        return list(data.get("nodes", [])), list(data.get("edges", []))
    if not (a.nodes and a.edges):
        die("informe --nodes e --edges, ou --json.")
    return read_csv_dicts(Path(a.nodes)), read_csv_dicts(Path(a.edges))


def clean(nodes: list[dict], edges: list[dict], strict: bool) -> tuple[list[dict], list[dict], list[str]]:
    warns: list[str] = []
    by_id: dict[str, dict] = {}
    for n in nodes:
        nid = str(n.get("id", "")).strip()
        if not nid:
            warns.append("nó sem id ignorado")
            continue
        if nid in by_id:
            warns.append(f"id de nó duplicado: {nid} (mantido o primeiro)")
            continue
        n = dict(n)
        n["id"] = nid
        n["type"] = (n.get("type") or "desconhecido").strip().lower()
        n["label"] = (n.get("label") or nid).strip()
        by_id[nid] = n
    ok_edges = []
    for e in edges:
        s, t = str(e.get("source", "")).strip(), str(e.get("target", "")).strip()
        if not s or not t:
            warns.append("aresta sem origem ou destino ignorada")
            continue
        for end in (s, t):
            if end not in by_id:
                if strict:
                    die(f"aresta aponta para nó inexistente: {end}")
                by_id[end] = {"id": end, "label": end, "type": "desconhecido", "platform": "", "notes": "criado automaticamente (nó ausente)"}
                warns.append(f"nó ausente criado como 'desconhecido': {end}")
        e = dict(e)
        e["source"], e["target"] = s, t
        e["confidence"] = (e.get("confidence") or "").strip().lower()
        if not (e.get("evidence_id") or "").strip():
            warns.append(f"aresta {s}→{t} ({e.get('relation', '')}) sem evidence_id: vínculo sem evidência ligada")
        if e["confidence"] not in CONF_ORDER:
            warns.append(f"aresta {s}→{t}: confiança {e['confidence']!r} inválida (use fraca, moderada ou forte); tratada como fraca")
            e["confidence"] = "fraca"
        raw_kind = (e.get("tipo") or "").strip().lower()
        if raw_kind not in KINDS:
            warns.append(f"aresta {s}→{t}: tipo {raw_kind!r} inválido (use identidade, associacao ou imitacao); tratado como associacao")
        e["tipo"] = KINDS.get(raw_kind, "associacao")
        ok_edges.append(e)
    return list(by_id.values()), ok_edges, warns


def mm_label(text: str) -> str:
    text = re.sub(r"[\"\[\](){}<>|#;`]", " ", text)
    return re.sub(r"\s+", " ", text).strip()[:60] or "?"


def render_mermaid(nodes: list[dict], edges: list[dict], max_nodes: int) -> tuple[str, list[str]]:
    notes: list[str] = []
    deg = Counter()
    for e in edges:
        deg[e["source"]] += 1
        deg[e["target"]] += 1
    keep = nodes
    if len(nodes) > max_nodes:
        keep = sorted(nodes, key=lambda n: (-deg[n["id"]], n["id"]))[:max_nodes]
        notes.append(f"Mermaid truncado aos {max_nodes} nós de maior grau (de {len(nodes)}); GraphML e DOT mantêm todos.")
    keep_ids = {n["id"] for n in keep}
    idx = {n["id"]: f"n{i}" for i, n in enumerate(keep, 1)}
    lines = ["graph LR"]
    for n in keep:
        o, c = SHAPES.get(n["type"], SHAPES["desconhecido"])
        plat = f"<br/>{mm_label(n['platform'])}" if n.get("platform") else ""
        lines.append(f'  {idx[n["id"]]}{o}"{mm_label(n["label"])}{plat}"{c}')
    link_no, imit_links = 0, []
    for e in edges:
        if e["source"] not in keep_ids or e["target"] not in keep_ids:
            continue
        prefix = "imitação: " if e["tipo"] == "imitacao" else ""
        label = mm_label(prefix + " · ".join(x for x in (e.get("relation", ""), e.get("evidence_id", ""), e["confidence"]) if x))
        arrow = CONF_STYLE.get(e["confidence"], "-->")
        lines.append(f'  {idx[e["source"]]} {arrow}|"{label}"| {idx[e["target"]]}')
        if e["tipo"] == "imitacao":
            imit_links.append(link_no)
        link_no += 1
    for i in imit_links:
        lines.append(f"  linkStyle {i} stroke:{IMITACAO_COLOR},stroke-width:2px,stroke-dasharray:6 3")
    for t in sorted({n["type"] for n in keep}):
        lines.append(f"  classDef {t} fill:{COLORS.get(t, '#f0f0f0')},stroke:#555")
    for n in keep:
        lines.append(f"  class {idx[n['id']]} {n['type']}")
    return "\n".join(lines) + "\n", notes


def render_graphml(nodes: list[dict], edges: list[dict]) -> str:
    out = ['<?xml version="1.0" encoding="UTF-8"?>',
           '<graphml xmlns="http://graphml.graphdrawing.org/xmlns">']
    for key, scope, name in (("d0", "node", "label"), ("d1", "node", "type"), ("d2", "node", "platform"), ("d3", "node", "notes"),
                             ("e0", "edge", "relation"), ("e1", "edge", "evidence_id"), ("e2", "edge", "confidence"), ("e3", "edge", "tipo")):
        out.append(f'  <key id="{key}" for="{scope}" attr.name="{name}" attr.type="string"/>')
    out.append('  <graph id="G" edgedefault="directed">')
    for n in nodes:
        out.append(f'    <node id="{xml_escape(n["id"])}">')
        for key, field in (("d0", "label"), ("d1", "type"), ("d2", "platform"), ("d3", "notes")):
            out.append(f'      <data key="{key}">{xml_escape(str(n.get(field, "") or ""))}</data>')
        out.append("    </node>")
    for i, e in enumerate(edges, 1):
        out.append(f'    <edge id="e{i}" source="{xml_escape(e["source"])}" target="{xml_escape(e["target"])}">')
        for key, field in (("e0", "relation"), ("e1", "evidence_id"), ("e2", "confidence"), ("e3", "tipo")):
            out.append(f'      <data key="{key}">{xml_escape(str(e.get(field, "") or ""))}</data>')
        out.append("    </edge>")
    out += ["  </graph>", "</graphml>"]
    return "\n".join(out) + "\n"


def dot_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"')


def render_dot(nodes: list[dict], edges: list[dict]) -> str:
    lines = ["digraph G {", "  rankdir=LR;", '  node [style=filled, fontname="Helvetica"];']
    for n in nodes:
        lines.append(f'  "{dot_escape(n["id"])}" [label="{dot_escape(n["label"])}", fillcolor="{COLORS.get(n["type"], "#f0f0f0")}", tooltip="{dot_escape(n["type"])}"];')
    for e in edges:
        label = ("imitação: " if e["tipo"] == "imitacao" else "") + " · ".join(x for x in (e.get("relation", ""), e.get("evidence_id", ""), e["confidence"]) if x)
        style = {"forte": "bold", "moderada": "solid", "fraca": "dashed"}.get(e["confidence"], "solid")
        extra = f', color="{IMITACAO_COLOR}", fontcolor="{IMITACAO_COLOR}", style="dashed,bold"' if e["tipo"] == "imitacao" else f", style={style}"
        lines.append(f'  "{dot_escape(e["source"])}" -> "{dot_escape(e["target"])}" [label="{dot_escape(label)}"{extra}];')
    lines.append("}")
    return "\n".join(lines) + "\n"


def try_png(nodes: list[dict], edges: list[dict], path: Path) -> str:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import networkx as nx
    except ImportError:
        return "PNG não gerado (instale networkx e matplotlib para habilitar)."
    g = nx.DiGraph()
    for n in nodes:
        g.add_node(n["id"], label=n["label"], type=n["type"])
    for e in edges:
        g.add_edge(e["source"], e["target"], label=e.get("relation", ""), conf=e["confidence"], tipo=e["tipo"])
    pos = nx.spring_layout(g, seed=7, k=1.2 / max(1, len(g) ** 0.5))
    fig, ax = plt.subplots(figsize=(11, 8))
    nx.draw_networkx_nodes(g, pos, node_color=[COLORS.get(g.nodes[n]["type"], "#f0f0f0") for n in g], node_size=1400, edgecolors="#555", ax=ax)
    nx.draw_networkx_labels(g, pos, {n: g.nodes[n]["label"][:22] for n in g}, font_size=7, ax=ax)
    styles = {"forte": "solid", "moderada": "solid", "fraca": "dashed"}
    for conf in ("forte", "moderada", "fraca"):
        sel = [(u, v) for u, v, d in g.edges(data=True) if d["conf"] == conf and d["tipo"] != "imitacao"]
        nx.draw_networkx_edges(g, pos, edgelist=sel, style=styles[conf], width=2.5 if conf == "forte" else 1.2, arrows=True, ax=ax, node_size=1400)
    imit = [(u, v) for u, v, d in g.edges(data=True) if d["tipo"] == "imitacao"]
    if imit:
        nx.draw_networkx_edges(g, pos, edgelist=imit, style="dashed", edge_color=IMITACAO_COLOR, width=2.0, arrows=True, ax=ax, node_size=1400)
    nx.draw_networkx_edge_labels(g, pos, {(u, v): (("imitação: " + d["label"])[:30] if d["tipo"] == "imitacao" else d["label"][:20]) for u, v, d in g.edges(data=True)}, font_size=6, ax=ax)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return f"PNG gravado em {path}"


def main(argv: list[str] | None = None) -> int:
    ensure_utf8_stdout()
    p = argparse.ArgumentParser(description="Gera grafo de vínculos (Mermaid, GraphML, DOT, CSV Gephi).")
    p.add_argument("--nodes")
    p.add_argument("--edges")
    p.add_argument("--json")
    p.add_argument("--out", required=True)
    p.add_argument("--max-nodes", type=int, default=150, help="limite de nós no Mermaid (padrão 150)")
    p.add_argument("--strict", action="store_true", help="falha se uma aresta apontar para nó inexistente")
    p.add_argument("--no-png", action="store_true")
    a = p.parse_args(argv)

    guard_output(a.out, "--out")
    nodes, edges = load_graph(a)
    nodes, edges, warns = clean(nodes, edges, a.strict)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    mmd, notes = render_mermaid(nodes, edges, a.max_nodes)
    manifest = {"script": script_tag("build_graph.py"), "executado_utc": utc_now_iso(),
                "entradas": input_manifest({"nos": a.nodes, "arestas": a.edges, "json": a.json}),
                "nos": len(nodes), "arestas": len(edges), "avisos": notes + warns}
    (out / "grafo_manifesto.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    origem = "; ".join(f"{m['entrada']} {Path(m['arquivo']).name} sha256 {m['sha256'][:16]}…" for m in manifest["entradas"])
    mmd = mmd.replace("graph LR\n", f"graph LR\n  %% {manifest['script']} — {origem}\n", 1)
    (out / "grafo.mmd").write_text(mmd, encoding="utf-8")
    (out / "grafo.graphml").write_text(render_graphml(nodes, edges), encoding="utf-8")
    (out / "grafo.dot").write_text(render_dot(nodes, edges), encoding="utf-8")
    write_csv(out / "nos_gephi.csv", [{"Id": n["id"], "Label": n["label"], "Type": n["type"], "Platform": n.get("platform", ""), "Notes": n.get("notes", "")} for n in nodes],
              ["Id", "Label", "Type", "Platform", "Notes"])
    write_csv(out / "arestas_gephi.csv", [{"Source": e["source"], "Target": e["target"], "Type": "Directed", "Label": e.get("relation", ""),
                                            "Evidence": e.get("evidence_id", ""), "Confidence": e["confidence"], "Weight": CONF_ORDER[e["confidence"]], "Kind": e["tipo"]} for e in edges],
              ["Source", "Target", "Type", "Label", "Evidence", "Confidence", "Weight", "Kind"])
    png_msg = "PNG desativado (--no-png)." if a.no_png else try_png(nodes, edges, out / "grafo.png")
    print(f"Grafo: {len(nodes)} nós, {len(edges)} arestas em {out}/ (grafo.mmd, grafo.graphml, grafo.dot, nos_gephi.csv, arestas_gephi.csv, grafo_manifesto.json)")
    print(png_msg)
    for w in notes + warns:
        print("AVISO:", w)
    return 0


if __name__ == "__main__":
    sys.exit(main())
