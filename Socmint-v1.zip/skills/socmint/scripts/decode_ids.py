#!/usr/bin/env python3
"""Decodifica datas embutidas em IDs e timestamps (offline, sem rede).

Exemplos:
    python3 scripts/decode_ids.py discord 175928847299117063
    python3 scripts/decode_ids.py tiktok-video 7598746068280495381 --tz America/Sao_Paulo
    python3 scripts/decode_ids.py instagram-media 2384288897814875714
    python3 scripts/decode_ids.py instagram-media CuE2WNQs6vH
    python3 scripts/decode_ids.py x 1585841080431321088
    python3 scripts/decode_ids.py unix 1340433637
    python3 scripts/decode_ids.py fb-range 100035049878735
    python3 scripts/decode_ids.py bluesky-tid 3jzfcijpj2z2a
    python3 scripts/decode_ids.py snowflake 123456789012345678 --epoch 1420070400000 --shift 22

A data decodificada de um ID é INFERÊNCIA sobre o instante de criação do objeto
(conta, mensagem, post). Confirme com o campo de data da própria fonte quando existir.
"""
from __future__ import annotations

import argparse
import bisect
import json
import re
import sys
from datetime import datetime, timedelta, timezone

from _common import (
    DEFAULT_TZ,
    dst_note,
    ensure_utf8_stdout,
    from_unix_ms,
    from_unix_us,
    iso_ms,
    parse_tz,
)

DISCORD_EPOCH_MS = 1420070400000
TWITTER_EPOCH_MS = 1288834974657
INSTAGRAM_EPOCH_MS = 1314220021721
IG_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
B32_SORT = "234567abcdefghijklmnopqrstuvwxyz"

# Âncoras da tabela 07 do livro (L p.297-298, compilada por T1t0), em ordem crescente de ID.
# A âncora de 2017 (100043987846036) fica acima das de 2018/2019 (outlier) e foi descartada.
FB_ANCHORS = [
    (4, 2004), (6, 2004), (10, 2004),
    (2_507_882, 2004), (7_949_314, 2005), (500_011_749, 2006), (700_945_295, 2007),
    (1_418_256_308, 2008), (1_431_556_570, 2009),
    (100_000_126_463_756, 2010), (100_002_284_156_384, 2011), (100_004_947_573_889, 2012),
    (100_004_993_928_607, 2013), (100_007_787_700_161, 2014), (100_009_506_123_654, 2015),
    (100_012_716_439_159, 2016), (100_028_690_792_552, 2018), (100_035_049_878_735, 2019),
    (100_058_283_354_527, 2020), (100_076_066_428_423, 2021), (100_083_688_981_403, 2022),
    (100_095_176_847_562, 2023),
]
FB_OUTLIER = 100_043_987_846_036
FB_NEW_RANGE_MIN = 61_000_000_000_000
FB_NEW_RANGE_ANCHOR = (61_556_281_671_164, 2024)


def parse_int(value: str, what: str) -> int:
    v = value.strip().replace("_", "").replace(".", "").replace(",", "")
    if not re.fullmatch(r"\d+", v):
        raise SystemExit(f"{what} deve ser um inteiro positivo (recebido: {value!r}).")
    return int(v)


def local_block(dt_utc: datetime, tz_arg: str) -> dict:
    tz, tz_label = parse_tz(tz_arg)
    local = dt_utc.astimezone(tz)
    return {"local": iso_ms(local), "fuso": tz_label}


def base_result(tipo: str, entrada: str, dt_utc: datetime | None, tz_arg: str) -> dict:
    res: dict = {"tipo": tipo, "entrada": entrada}
    if dt_utc is not None:
        res["utc"] = iso_ms(dt_utc)
        res.update(local_block(dt_utc, tz_arg))
        res["unix_ms"] = int((dt_utc - datetime(1970, 1, 1, tzinfo=timezone.utc)) / timedelta(milliseconds=1))
    res["avisos"] = []
    if dt_utc is not None:
        nota = dst_note(dt_utc, *parse_tz(tz_arg))
        if nota:
            res["avisos"].append(nota)
    return res


def plausibility(res: dict, dt_utc: datetime, lo: datetime, hi: datetime | None = None, nome: str = "") -> None:
    hi = hi or (datetime.now(timezone.utc) + timedelta(days=1))
    if dt_utc < lo:
        res["avisos"].append(f"Data anterior ao início esperado para {nome or res['tipo']} ({lo.date()}): ID provavelmente não é deste tipo.")
    if dt_utc > hi:
        res["avisos"].append("Data no futuro: ID provavelmente não é deste tipo ou foi digitado errado.")


def decode_snowflake(value: str, epoch_ms: int, shift: int, tipo: str, tz: str, lo: datetime | None = None, metodo: str = "") -> dict:
    n = parse_int(value, "ID")
    ms = (n >> shift) + epoch_ms
    dt = from_unix_ms(ms)
    res = base_result(tipo, str(n), dt, tz)
    res["rotulo"] = "INFERÊNCIA: instante de criação do objeto identificado pelo ID"
    res["metodo"] = metodo or f"(ID >> {shift}) + {epoch_ms} ms"
    res["componentes"] = {"timestamp_ms": ms}
    if n < (1 << shift):
        res["avisos"].append(f"ID menor que 2^{shift}: a parte de timestamp é zero; provavelmente não é um snowflake.")
    if lo:
        plausibility(res, dt, lo, nome=tipo)
    return res


def decode_discord(value: str, tz: str) -> dict:
    res = decode_snowflake(value, DISCORD_EPOCH_MS, 22, "Discord (snowflake)", tz, lo=datetime(2015, 1, 1, tzinfo=timezone.utc),
                           metodo="timestamp_ms = (ID >> 22) + 1420070400000 (época 01/01/2015 UTC)")
    n = int(res["entrada"])
    res["componentes"].update({"worker_id": (n >> 17) & 0x1F, "process_id": (n >> 12) & 0x1F, "incremento": n & 0xFFF})
    res["limitacoes"] = ["Vale para usuário, servidor, canal, cargo e mensagem.", "Contas muito recentes podem ser alts ou bots de spam (indicador, não prova)."]
    return res


def decode_x(value: str, tz: str) -> dict:
    res = decode_snowflake(value, TWITTER_EPOCH_MS, 22, "X/Twitter (snowflake de post)", tz, lo=datetime(2010, 11, 4, tzinfo=timezone.utc),
                           metodo="timestamp_ms = (ID >> 22) + 1288834974657 (época 04/11/2010 UTC)")
    res["limitacoes"] = ["Vale para IDs de post pós-nov/2010; IDs de usuário antigos não são snowflake."]
    return res


def decode_tiktok_video(value: str, tz: str) -> dict:
    n = parse_int(value, "ID do vídeo")
    secs = n >> 32
    dt = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(seconds=secs)
    res = base_result("TikTok (ID de vídeo)", str(n), dt, tz)
    res["rotulo"] = "INFERÊNCIA: instante de criação do ID do vídeo"
    res["metodo"] = "segundos Unix = ID >> 32 (mesma lógica da ferramenta TikTok Timestamp da Bellingcat)"
    res["componentes"] = {"unix_s": secs}
    plausibility(res, dt, datetime(2016, 9, 1, tzinfo=timezone.utc), nome="TikTok")
    res["limitacoes"] = ["Confirme com o campo createTime do código-fonte do post.", "Não vale para ID de usuário."]
    return res


def ig_shortcode_to_id(code: str) -> int:
    n = 0
    for ch in code:
        n = n * 64 + IG_ALPHABET.index(ch)
    return n


def ig_id_to_shortcode(n: int) -> str:
    if n == 0:
        return IG_ALPHABET[0]
    out = []
    while n:
        n, r = divmod(n, 64)
        out.append(IG_ALPHABET[r])
    return "".join(reversed(out))


def decode_instagram_media(value: str, tz: str) -> dict:
    v = value.strip()
    v = re.sub(r"^https?://[^/]+/(?:p|reel|reels|tv)/", "", v).split("/")[0].split("?")[0]
    if re.fullmatch(r"\d+(_\d+)?", v):
        n = int(v.split("_")[0])
        code = ig_id_to_shortcode(n)
    elif re.fullmatch(r"[A-Za-z0-9_-]{1,12}", v):
        n = ig_shortcode_to_id(v)
        code = v
    else:
        raise SystemExit("Entrada deve ser um ID de mídia numérico ou um shortcode de até 12 caracteres (A-Z a-z 0-9 - _).")
    ms = (n >> 23) + INSTAGRAM_EPOCH_MS
    dt = from_unix_ms(ms)
    res = base_result("Instagram (ID de mídia)", str(n), dt, tz)
    res["rotulo"] = "INFERÊNCIA: instante de criação do ID de mídia"
    res["metodo"] = "timestamp_ms = (ID >> 23) + 1314220021721; shortcode = ID em base64 de URL (A-Z a-z 0-9 - _)"
    res["componentes"] = {"timestamp_ms": ms, "shard": (n >> 10) & 0x1FFF, "sequencia": n & 0x3FF, "shortcode": code}
    plausibility(res, dt, datetime(2011, 8, 24, tzinfo=timezone.utc), nome="Instagram")
    res["limitacoes"] = [
        "Fórmula do ID documentada pelo Instagram Engineering (2012); conversão shortcode↔ID é prática da comunidade.",
        "Shortcodes longos (posts privados) não decodificam; IDs de usuário pequenos são sequenciais e não trazem data.",
        "Confirme com taken_at do código-fonte do post.",
    ]
    return res


def decode_unix(value: str, tz: str) -> dict:
    raw = value.strip().replace(",", ".")
    if not re.fullmatch(r"-?\d+(\.\d+)?", raw):
        raise SystemExit(f"Timestamp inválido: {value!r}")
    num = float(raw)
    digits = len(raw.split(".")[0].lstrip("-"))
    mag = abs(num)
    if mag < 1e11:
        escala, dt = "segundos", datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(seconds=num)
    elif mag < 1e14:
        escala, dt = "milissegundos", from_unix_ms(int(num))
    elif mag < 1e17:
        escala, dt = "microssegundos", from_unix_us(int(num))
    else:
        escala, dt = "nanossegundos", from_unix_us(int(num) // 1000)
    res = base_result("Unix timestamp", raw, dt, tz)
    res["rotulo"] = "DADO: conversão direta (a fonte do horário deve ser registrada)"
    res["metodo"] = f"escala detectada: {escala} ({digits} dígitos); referência 01/01/1970 00:00 UTC"
    res["limitacoes"] = ["Timestamps do código-fonte de redes sociais vêm em UTC.", "Se a escala detectada parecer errada, converta manualmente."]
    return res


def decode_fb_range(value: str, tz: str) -> dict:
    n = parse_int(value, "ID do Facebook")
    res = {"tipo": "Facebook (faixa de ID)", "entrada": str(n), "avisos": []}
    anchors = FB_ANCHORS
    keys = [a[0] for a in anchors]
    if n < 100_000:
        faixa, anos = "primeiros usuários e fundadores", "2004"
    elif n <= 899_999:
        faixa, anos = "faixa reservada a universidades (Columbia, Stanford, Yale, Cornell, Dartmouth, NYU)", "2004–2006"
    elif n >= FB_NEW_RANGE_MIN and n < 100_000_000_000_000:
        faixa, anos = "nova faixa iniciada em `61…` (âncora do livro: 2024)", "2024 ou posterior"
    elif n in keys:
        ano = anchors[keys.index(n)][1]
        faixa, anos = f"coincide com uma âncora da tabela do livro ({ano})", str(ano)
    elif n > keys[-1]:
        faixa, anos = "acima da última âncora do livro (2023)", "2023 ou posterior"
    else:
        i = bisect.bisect_right(keys, n)
        lo, hi = anchors[i - 1], anchors[i]
        anos = str(lo[1]) if lo[1] == hi[1] else f"{lo[1]}–{hi[1]}"
        faixa = f"entre as âncoras {lo[0]:,} ({lo[1]}) e {hi[0]:,} ({hi[1]})".replace(",", ".")
    res["faixa"] = faixa
    res["ano_provavel"] = anos
    res["rotulo"] = "ESTIMATIVA GROSSEIRA (±1–2 anos); o ID do Facebook não traz timestamp"
    res["metodo"] = "interpolação entre âncoras da tabela 07 do livro (L p.297–298); âncora de 2017 descartada por inconsistência"
    res["limitacoes"] = [
        "Melhores fontes: campo 'Entrou no Facebook' quando visível e perfil do Marketplace (L p.310).",
        "Nunca apresentar como data de criação.",
    ]
    if n == FB_OUTLIER:
        res["avisos"].append("Este ID é a âncora de 2017 do livro, considerada outlier: a estimativa pode estar errada.")
    return res


def decode_bluesky_tid(value: str, tz: str) -> dict:
    v = value.strip().lower()
    if len(v) != 13 or any(c not in B32_SORT for c in v):
        raise SystemExit("TID do Bluesky deve ter 13 caracteres do alfabeto base32-sort (2-7 a-z).")
    n = 0
    for ch in v:
        n = n * 32 + B32_SORT.index(ch)
    micros = n >> 10
    clock = n & 0x3FF
    dt = from_unix_us(micros)
    res = base_result("Bluesky (TID)", v, dt, tz)
    res["rotulo"] = "DADO/INFERÊNCIA: o TID embute o instante de criação do registro, mas é declarado pelo cliente"
    res["metodo"] = "base32-sort de 13 caracteres → 64 bits: 53 bits de microssegundos Unix + 10 bits de identificador de relógio"
    res["componentes"] = {"unix_us": micros, "clock_id": clock}
    plausibility(res, dt, datetime(2022, 1, 1, tzinfo=timezone.utc), nome="Bluesky")
    res["limitacoes"] = ["O relógio vem do cliente; compare com indexedAt/createdAt do registro."]
    return res


def decode_generic(value: str, epoch: int, shift: int, tz: str) -> dict:
    return decode_snowflake(value, epoch, shift, f"Snowflake genérico (época {epoch} ms, deslocamento {shift})", tz)


def render(res: dict) -> str:
    lines = [f"Tipo:      {res['tipo']}", f"Entrada:   {res['entrada']}"]
    if "utc" in res:
        lines += [f"UTC:       {res['utc']}", f"Local:     {res['local']}  ({res['fuso']})"]
    if "faixa" in res:
        lines += [f"Ano provável: {res['ano_provavel']}", f"Faixa:     {res['faixa']}"]
    lines.append(f"Rótulo:    {res['rotulo']}")
    lines.append(f"Método:    {res['metodo']}")
    if res.get("componentes"):
        lines.append("Componentes: " + ", ".join(f"{k}={v}" for k, v in res["componentes"].items()))
    for lim in res.get("limitacoes", []):
        lines.append(f"Limite:    {lim}")
    for av in res.get("avisos", []):
        lines.append(f"AVISO:     {av}")
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="Decodifica datas embutidas em IDs e timestamps (offline).")
    p.add_argument("--tz", default=DEFAULT_TZ, help=f"fuso local de exibição: o IANA da localidade do fato, ex.: America/Maceio para SE/AL (padrão {DEFAULT_TZ}; deslocamento fixo como --tz=-03:00)")
    p.add_argument("--json", action="store_true", help="saída em JSON")
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--tz", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    common.add_argument("--json", action="store_true", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    sub = p.add_subparsers(dest="cmd", required=True)
    for name, helptxt in [
        ("discord", "ID snowflake do Discord"),
        ("x", "ID de post do X/Twitter"),
        ("tiktok-video", "ID de vídeo do TikTok"),
        ("instagram-media", "ID de mídia ou shortcode/URL do Instagram"),
        ("unix", "Unix timestamp em s, ms, µs ou ns"),
        ("fb-range", "ID de perfil do Facebook (estimativa por faixa)"),
        ("bluesky-tid", "TID do Bluesky (13 caracteres)"),
    ]:
        sp = sub.add_parser(name, help=helptxt, parents=[common])
        sp.add_argument("valor")
    sg = sub.add_parser("snowflake", help="snowflake genérico com época e deslocamento", parents=[common])
    sg.add_argument("valor")
    sg.add_argument("--epoch", type=int, required=True, help="época em ms Unix")
    sg.add_argument("--shift", type=int, default=22, help="deslocamento de bits (padrão 22)")
    return p


def main(argv: list[str] | None = None) -> int:
    ensure_utf8_stdout()
    a = build_parser().parse_args(argv)
    funcs = {
        "discord": decode_discord,
        "x": decode_x,
        "tiktok-video": decode_tiktok_video,
        "instagram-media": decode_instagram_media,
        "unix": decode_unix,
        "fb-range": decode_fb_range,
        "bluesky-tid": decode_bluesky_tid,
    }
    if a.cmd == "snowflake":
        res = decode_generic(a.valor, a.epoch, a.shift, a.tz)
    else:
        res = funcs[a.cmd](a.valor, a.tz)
    print(json.dumps(res, ensure_ascii=False, indent=2) if a.json else render(res))
    return 0


if __name__ == "__main__":
    sys.exit(main())
