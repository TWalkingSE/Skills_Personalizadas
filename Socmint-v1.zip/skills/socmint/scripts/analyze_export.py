#!/usr/bin/env python3
"""Analisa exports CSV/XLSX de seguidores, comentários ou posts e gera INDICADORES (nunca veredito).

Exemplos:
    python3 scripts/analyze_export.py comentarios.csv --platform tiktok --out analise/
    python3 scripts/analyze_export.py comentarios.csv --map text=comment,time=create_time,user=unique_id
    python3 scripts/analyze_export.py seguidores_a.csv --compare seguidores_b.csv --out analise/
    python3 scripts/analyze_export.py contas.csv --decode-ids discord --tz America/Sao_Paulo

Colunas reconhecidas automaticamente (use --map para forçar): user, display, id, text, time,
acct_created, followers, following, avatar, likes. XLSX exige openpyxl; sem ele, exporte para CSV.
Toda saída vem com explicações alternativas: indicador não é prova de bot nem de coordenação.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import re
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from pathlib import Path

from _common import (DEFAULT_TZ, die, ensure_utf8_stdout, from_unix_ms, from_unix_us, guard_output, input_manifest, iso_ms, parse_tz,
                     read_csv_dicts, script_tag, strip_accents, utc_now_iso, write_csv)

SYN = {
    "user": ["username", "user_name", "uniqueid", "unique_id", "handle", "author", "autor", "usuario", "screen_name", "login", "user", "profile", "perfil"],
    "display": ["nickname", "display_name", "displayname", "full_name", "name", "nome"],
    "id": ["user_id", "userid", "uid", "author_id", "id_usuario", "account_id", "id"],
    "text": ["text", "comment", "comentario", "texto", "content", "message", "mensagem", "body", "caption", "legenda", "description"],
    "time": ["create_time", "createtime", "created_at", "timestamp", "time", "date", "data", "datetime", "data_hora", "posted_at", "publish_time"],
    "acct_created": ["account_created", "account_created_at", "user_create_time", "joined", "joined_at", "data_criacao", "signup", "registered", "user_created_at"],
    "followers": ["followers", "follower_count", "followers_count", "seguidores"],
    "following": ["following", "following_count", "seguindo"],
    "avatar": ["avatar", "avatar_url", "profile_pic", "profile_pic_url", "foto", "image", "picture"],
    "likes": ["likes", "like_count", "digg_count", "curtidas", "reactions"],
}
DEFAULT_AVATAR_HINTS = ("default", "placeholder", "no_image", "noimage", "blank", "generic", "silhouette")
EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF\u2B50\u2B06\u2194-\u21AA\u2764\uFE0F]")
URL_RE = re.compile(r"https?://[^\s]+", re.I)
EXPLICACOES = {
    "rajada": "Viralização orgânica, evento ao vivo, mobilização real de fãs ou notícia podem gerar picos legítimos.",
    "texto_repetido": "Frases curtas e comuns ('parabéns', 'kkkk') se repetem naturalmente; roteiros compartilhados também podem ser mutirão de fãs.",
    "texto_quase_repetido": "Variações de uma mesma frase podem ser trote, meme ou campanha legítima.",
    "texto_repetido_concentrado": "Mesmo texto, em poucas contas e em poucos minutos: pode ser roteiro compartilhado, mas também mutirão de fãs ou resposta a um pedido do próprio perfil.",
    "texto_quase_repetido_concentrado": "Variações de uma frase concentradas no tempo: roteiro ou campanha; ainda assim podem ser fãs respondendo a um mesmo chamado.",
    "username_padrao": "Muitos usuários reais usam nome + números; contas geradas em massa também. Isolado, é indício fraco.",
    "conta_nova": "Pessoas reais também criam conta para participar de um assunto específico.",
    "criacao_em_lote": "Campanhas legítimas de cadastro e eventos podem concentrar criações em um dia.",
    "avatar_padrao": "Privacidade e usuários novos geram avatares padrão.",
    "avatar_repetido": "Avatares de banco de imagens e memes se repetem entre pessoas diferentes.",
    "seguindo_muito_seguidores_poucos": "Perfis novos ou de consumo passivo têm esse formato.",
    "ids_proximos": "IDs próximos indicam criação em sequência, que pode ser legítima em ondas de cadastro.",
    "muitos_comentarios": "Fãs e moderadores comentam muito.",
}


# ----------------------------------------------------------------------------- leitura

def norm_header(h: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", strip_accents(h).lower()).strip("_")


def read_rows(path: Path, sheet: str | None) -> list[dict[str, str]]:
    if path.suffix.lower() in (".xlsx", ".xlsm"):
        try:
            import openpyxl  # type: ignore
        except ImportError:
            die("XLSX exige o pacote openpyxl. Exporte a planilha para CSV ou instale openpyxl.")
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb[sheet] if sheet else wb.worksheets[0]
        it = ws.iter_rows(values_only=True)
        headers = [str(c).strip() if c is not None else "" for c in next(it, [])]
        rows = []
        for r in it:
            rows.append({headers[i]: ("" if v is None else str(v)) for i, v in enumerate(r) if i < len(headers) and headers[i]})
        return rows
    return read_csv_dicts(path)


def resolve_columns(headers: list[str], overrides: dict[str, str]) -> dict[str, str]:
    by_norm = {norm_header(h): h for h in headers}
    cols: dict[str, str] = {}
    for key, syns in SYN.items():
        for s in syns:
            if s in by_norm:
                cols[key] = by_norm[s]
                break
    for key, name in overrides.items():
        if name in headers:
            cols[key] = name
        elif norm_header(name) in by_norm:
            cols[key] = by_norm[norm_header(name)]
        else:
            die(f"coluna {name!r} (para {key}) não existe. Colunas: {', '.join(headers)}")
    return cols


def parse_time(value: str, input_tz) -> datetime | None:
    v = (value or "").strip()
    if not v:
        return None
    if re.fullmatch(r"-?\d+(\.\d+)?", v):
        num = float(v)
        mag = abs(num)
        try:
            if mag < 1e11:
                return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(seconds=num)
            if mag < 1e14:
                return from_unix_ms(int(num))
            if mag < 1e17:
                return from_unix_us(int(num))
        except (OverflowError, ValueError):
            return None
        return None
    s = v.replace("Z", "+00:00").replace("z", "+00:00")
    m = re.match(r"^(.*?\d{2}:\d{2}:\d{2})\.(\d+)(.*)$", s)
    if m:
        s = f"{m.group(1)}.{(m.group(2) + '000000')[:6]}{m.group(3)}"
    for attempt in (s, s.replace(" ", "T", 1)):
        try:
            dt = datetime.fromisoformat(attempt)
            return dt if dt.tzinfo else dt.replace(tzinfo=input_tz)
        except ValueError:
            pass
    for fmt in ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%d/%m/%Y", "%d-%m-%Y %H:%M:%S", "%m/%d/%Y %H:%M:%S", "%Y/%m/%d %H:%M:%S"):
        try:
            return datetime.strptime(v, fmt).replace(tzinfo=input_tz)
        except ValueError:
            continue
    return None


# ----------------------------------------------------------------------------- análise

def norm_text(t: str) -> str:
    t = URL_RE.sub(" ", t.lower())
    t = strip_accents(t)
    t = re.sub(r"[^a-z0-9@# ]+", " ", t)
    return re.sub(r"\s+", " ", t).strip()


def entropy(s: str) -> float:
    if not s:
        return 0.0
    c = Counter(s)
    n = len(s)
    return -sum(v / n * math.log2(v / n) for v in c.values())


def username_flags(u: str) -> list[str]:
    s = u.lower().lstrip("@")
    flags = []
    if re.fullmatch(r"[a-z._]+\d{4,}", s):
        flags.append("letras+4 ou mais dígitos finais")
    if re.fullmatch(r"(user|usuario|usr|account|conta)[._-]?\d+", s):
        flags.append("prefixo genérico + número")
    digits = sum(ch.isdigit() for ch in s)
    if len(s) >= 9 and digits / len(s) >= 0.5:
        flags.append("maioria de dígitos")
    # "aleatória": poucas vogais nas letras ou sequência longa de consoantes. O critério antigo (sem duas vogais
    # seguidas) marcava nomes comuns em português, como marcelo_silva4846.
    letters = re.sub(r"[^a-z]", "", s)
    vowel_ratio = sum(ch in "aeiouy" for ch in letters) / len(letters) if letters else 0.0
    if (len(s) >= 12 and entropy(s) >= 3.5 and digits >= 2 and len(letters) >= 6
            and (vowel_ratio < 0.25 or re.search(r"[bcdfghjklmnpqrstvwxz]{5,}", letters))):
        flags.append("sequência de aparência aleatória")
    return flags


def hour_hist(times: list[datetime], tz) -> list[int]:
    h = [0] * 24
    for t in times:
        h[t.astimezone(tz).hour] += 1
    return h


def estimate_offset(hist_utc: list[int]) -> tuple[int, str] | None:
    total = sum(hist_utc)
    if total < 100:
        return None
    best, start = None, 0
    for s in range(24):
        w = sum(hist_utc[(s + k) % 24] for k in range(6))
        if best is None or w < best:
            best, start = w, s
    mid = (start + 3) % 24
    off = (4 - mid) % 24
    if off > 12:
        off -= 24
    return off, f"vale de menor atividade em {start:02d}h–{(start + 6) % 24:02d}h UTC (centro {mid:02d}h)"


def find_bursts(times: list[datetime], window_min: int = 5) -> list[dict]:
    if len(times) < 10:
        return []
    secs = sorted(int(t.timestamp()) for t in times)
    w = window_min * 60
    t0, t1 = secs[0], secs[-1]
    n_win = (t1 - t0) // w + 1
    if n_win > 200_000:
        w = max(w, (t1 - t0) // 200_000 + 1)
        n_win = (t1 - t0) // w + 1
    counts = [0] * n_win
    for s in secs:
        counts[(s - t0) // w] += 1
    mu = sum(counts) / n_win
    sd = max(1.0, math.sqrt(sum((c - mu) ** 2 for c in counts) / n_win))
    thr = max(5, mu + 3 * sd)
    flagged = [i for i, c in enumerate(counts) if c >= thr]
    bursts: list[dict] = []
    for i in flagged:
        start = t0 + i * w
        if bursts and start - bursts[-1]["_end"] <= w:
            bursts[-1]["_end"] = start + w
            bursts[-1]["comentarios"] += counts[i]
        else:
            bursts.append({"_start": start, "_end": start + w, "comentarios": counts[i]})
    out = []
    for b in bursts:
        out.append({
            "inicio_utc": iso_ms(datetime.fromtimestamp(b["_start"], tz=timezone.utc)),
            "fim_utc": iso_ms(datetime.fromtimestamp(b["_end"], tz=timezone.utc)),
            "comentarios": b["comentarios"],
            "z_aprox": round((b["comentarios"] / max(1, (b["_end"] - b["_start"]) // w) - mu) / sd, 1),
        })
    return out


def concentration(idx: list[int], rtimes: list[datetime | None], window_min: int = 30) -> tuple[float | None, float | None]:
    """Devolve (fração dos comentários do grupo na melhor janela de window_min, extensão total em minutos)."""
    ts = sorted(rtimes[i] for i in idx if rtimes[i])
    if len(ts) < 2:
        return None, None
    span = (ts[-1] - ts[0]).total_seconds() / 60
    best, j = 0, 0
    for i in range(len(ts)):
        while (ts[i] - ts[j]).total_seconds() > window_min * 60:
            j += 1
        best = max(best, i - j + 1)
    return round(best / len(ts), 2), round(span, 1)


def duplicates(rows: list[dict], cols: dict[str, str], rtimes: list[datetime | None]) -> tuple[list[dict], list[dict]]:
    tcol, ucol = cols.get("text"), cols.get("user") or cols.get("id")
    if not tcol:
        return [], []
    groups: dict[str, list[int]] = defaultdict(list)
    for i, r in enumerate(rows):
        t = norm_text(r.get(tcol, ""))
        if len(t) >= 8:
            groups[t].append(i)

    def users_of(idx: list[int]) -> set[str]:
        return {rows[i].get(ucol, "") if ucol else str(i) for i in idx}

    exact = []
    for t, idx in groups.items():
        u = users_of(idx)
        if len(idx) >= 3 and len(u) >= 2:
            frac, span = concentration(idx, rtimes)
            exact.append({"texto": rows[idx[0]].get(tcol, "")[:140], "comentarios": len(idx), "contas": len(u), "idx": idx,
                          "fracao_em_30min": frac, "extensao_min": span, "concentrado": None if frac is None else frac >= 0.6})
    exact.sort(key=lambda d: (d["concentrado"] is not True, -d["comentarios"]))
    # quase-duplicados: agrupa textos únicos com razão >= 0.85
    uniq = [t for t, _ in sorted(groups.items(), key=lambda kv: -len(kv[1]))][:1500]
    clusters: list[list[str]] = []
    for t in uniq:
        placed = False
        for c in clusters:
            rep = c[0]
            if abs(len(rep) - len(t)) / max(len(rep), len(t)) > 0.4:
                continue
            if SequenceMatcher(None, rep, t).ratio() >= 0.85:
                c.append(t)
                placed = True
                break
        if not placed:
            clusters.append([t])
    near = []
    for c in clusters:
        if len(c) < 2:
            continue
        idx = [i for t in c for i in groups[t]]
        u = users_of(idx)
        if len(idx) >= 3 and len(u) >= 2:
            frac, span = concentration(idx, rtimes)
            near.append({"exemplos": [rows[groups[t][0]].get(tcol, "")[:100] for t in c[:4]], "variantes": len(c), "comentarios": len(idx), "contas": len(u), "idx": idx,
                         "fracao_em_30min": frac, "extensao_min": span, "concentrado": None if frac is None else frac >= 0.6})
    near.sort(key=lambda d: (d["concentrado"] is not True, -d["comentarios"]))
    return exact, near


def top_entities(rows: list[dict], tcol: str | None) -> dict:
    if not tcol:
        return {}
    ht, mn, urls, dom, em = Counter(), Counter(), Counter(), Counter(), Counter()
    for r in rows:
        t = r.get(tcol, "")
        ht.update(x.lower() for x in re.findall(r"#\w+", t))
        mn.update(x.lower() for x in re.findall(r"@\w+", t))
        for u in URL_RE.findall(t):
            urls[u] += 1
            m = re.match(r"https?://([^/\s]+)", u, re.I)
            if m:
                dom[m.group(1).lower()] += 1
        em.update(EMOJI_RE.findall(t))
    return {k: v.most_common(10) for k, v in (("hashtags", ht), ("mencoes", mn), ("links", urls), ("dominios", dom), ("emojis", em)) if v}


def decode_id_time(kind: str, value: str) -> datetime | None:
    if not re.fullmatch(r"\d{5,25}", value or ""):
        return None
    n = int(value)
    try:
        if kind == "discord":
            return from_unix_ms((n >> 22) + 1420070400000)
        if kind == "x":
            return from_unix_ms((n >> 22) + 1288834974657)
        if kind == "instagram-media":
            return from_unix_ms((n >> 23) + 1314220021721)
        if kind == "tiktok-video":
            return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(seconds=n >> 32)
    except (OverflowError, ValueError):
        return None
    return None


def analyze(rows: list[dict], cols: dict[str, str], a: argparse.Namespace) -> dict:
    tz, tz_label = parse_tz(a.tz)
    in_tz, _ = parse_tz(a.input_tz)
    res: dict = {"arquivo": str(a.input), "linhas": len(rows), "colunas_mapeadas": cols, "fuso_local": tz_label, "indicadores_por_conta": {},
                 "proveniencia": {"script": script_tag("analyze_export.py"), "executado_utc": utc_now_iso(),
                                  "parametros": {"platform": a.platform, "map": a.map, "tz": a.tz, "input_tz": a.input_tz, "decode_ids": a.decode_ids},
                                  "entradas": input_manifest({"export": a.input, "comparado": a.compare})}}
    ucol, icol, tcol, timecol = cols.get("user"), cols.get("id"), cols.get("text"), cols.get("time")
    key_of = lambda r: (r.get(ucol, "") if ucol else "") or (r.get(icol, "") if icol else "")  # noqa: E731
    users = {key_of(r) for r in rows if key_of(r)}
    res["contas_distintas"] = len(users)
    flags: dict[str, set[str]] = defaultdict(set)

    # tempo
    times = [t for t in (parse_time(r.get(timecol, ""), in_tz) for r in rows) if t] if timecol else []
    res["com_data"] = len(times)
    if times:
        res["janela_utc"] = {"inicio": iso_ms(min(times)), "fim": iso_ms(max(times))}
        hu, hl = hour_hist(times, timezone.utc), hour_hist(times, tz)
        res["hora_utc"], res["hora_local"] = hu, hl
        res["horarios_em_horario_de_verao"] = sum(1 for t in times if t.astimezone(tz).dst())
        wd = Counter(t.astimezone(tz).weekday() for t in times)
        res["dia_semana_local"] = [wd.get(i, 0) for i in range(7)]
        bursts = find_bursts(times)
        res["rajadas"] = bursts
        spans = [(datetime.fromisoformat(b["inicio_utc"].replace("Z", "+00:00")), datetime.fromisoformat(b["fim_utc"].replace("Z", "+00:00"))) for b in bursts]
        outside = [t for t in times if not any(s <= t < e for s, e in spans)]
        est = estimate_offset(hour_hist(outside, timezone.utc))
        base_note = " (calculado sem as rajadas)" if spans else ""
        res["fuso_provavel"] = ({"deslocamento_horas": est[0], "base": est[1] + base_note, "confianca": "baixa (inferência)"} if est
                                else f"amostra com menos de 100 horários{base_note}: não estimado")
        if spans:
            for r, t in zip(rows, (parse_time(r.get(timecol, ""), in_tz) for r in rows)):
                if t and any(s <= t < e for s, e in spans) and key_of(r):
                    flags[key_of(r)].add("rajada")

    # textos
    rtimes = [parse_time(r.get(timecol, ""), in_tz) if timecol else None for r in rows]
    exact, near = duplicates(rows, cols, rtimes)
    res["textos_repetidos"] = [{k: v for k, v in d.items() if k != "idx"} for d in exact[:15]]
    res["textos_quase_repetidos"] = [{k: v for k, v in d.items() if k != "idx"} for d in near[:15]]
    for group, base in ((exact, "texto_repetido"), (near, "texto_quase_repetido")):
        for d in group:
            if d["concentrado"] is False:
                continue
            label = base + ("_concentrado" if d["concentrado"] else "")
            for i in d["idx"]:
                if key_of(rows[i]):
                    flags[key_of(rows[i])].add(label)
    res["entidades"] = top_entities(rows, tcol)

    # contas
    if ucol or icol:
        names = {key_of(r) for r in rows if key_of(r)}
        pat = {u: username_flags(u) for u in names}
        flagged = {u: f for u, f in pat.items() if f}
        res["username_padrao"] = {"contas": len(flagged), "percentual": round(100 * len(flagged) / max(1, len(names)), 1), "exemplos": [f"{u} ({'; '.join(f)})" for u, f in list(flagged.items())[:15]]}
        for u in flagged:
            flags[u].add("username_padrao")
        cnt = Counter(key_of(r) for r in rows if key_of(r))
        heavy = {u: c for u, c in cnt.items() if c >= max(5, 0.05 * len(rows))}
        res["contas_com_muitos_comentarios"] = sorted(heavy.items(), key=lambda kv: -kv[1])[:10]
        for u in heavy:
            flags[u].add("muitos_comentarios")

    # criação de contas (campo ou decodificado do ID)
    created: dict[str, datetime] = {}
    ccol = cols.get("acct_created")
    kind = a.decode_ids or (a.platform if a.platform in ("discord", "x") else None)
    for r in rows:
        k = key_of(r)
        if not k or k in created:
            continue
        dt = parse_time(r.get(ccol, ""), in_tz) if ccol else None
        if dt is None and kind and icol:
            dt = decode_id_time(kind, r.get(icol, ""))
        if dt:
            created[k] = dt
    if created:
        by_day = Counter(d.astimezone(tz).date().isoformat() for d in created.values())
        n_dates = len(created)
        lotes: list[dict] = []
        pending = sorted((d, k) for k, d in created.items())
        while len(pending) >= 5 and len(lotes) < 3:
            best, bi, j = 0, 0, 0
            for i in range(len(pending)):
                while (pending[i][0] - pending[j][0]).total_seconds() > 48 * 3600:
                    j += 1
                if i - j + 1 > best:
                    best, bi = i - j + 1, j
            if best < 5 or best / n_dates < 0.2:
                break
            win = pending[bi:bi + best]
            lotes.append({"inicio_utc": iso_ms(win[0][0]), "fim_utc": iso_ms(win[-1][0]), "contas": best, "percentual": round(100 * best / n_dates, 1)})
            for _, k in win:
                flags[k].add("criacao_em_lote")
            pending = pending[:bi] + pending[bi + best:]
        res["criacao_de_contas"] = {"contas_com_data": n_dates, "por_dia_top": by_day.most_common(8), "lotes_suspeitos": lotes,
                                    "origem": "coluna de criação" if ccol else f"ID decodificado ({kind})", "janela_do_lote": "48 h"}
        if timecol:
            young = 0
            seen = set()
            for r in rows:
                k = key_of(r)
                t = parse_time(r.get(timecol, ""), in_tz)
                if k in created and t and k not in seen:
                    seen.add(k)
                    if (t - created[k]) < timedelta(days=7):
                        young += 1
                        flags[k].add("conta_nova")
            res["contas_com_menos_de_7_dias"] = {"contas": young, "de": len(seen)}

    # seguidores / seguindo / avatar
    fcol, gcol, acol = cols.get("followers"), cols.get("following"), cols.get("avatar")
    if fcol and gcol:
        odd: set[str] = set()
        for r in rows:
            try:
                fo, fg = float(r.get(fcol, "")), float(r.get(gcol, ""))
            except ValueError:
                continue
            if fg >= 20 * max(fo, 1) and fo <= 10 and key_of(r):
                flags[key_of(r)].add("seguindo_muito_seguidores_poucos")
                odd.add(key_of(r))
        res["seguindo_muito_seguidores_poucos"] = len(odd)
    if acol:
        acc_av: dict[str, str] = {}
        for r in rows:
            k = key_of(r)
            if k and r.get(acol, "") and k not in acc_av:
                acc_av[k] = r[acol]
        av = Counter(acc_av.values())
        default = {u for u in av if any(h in u.lower() for h in DEFAULT_AVATAR_HINTS)}
        rep = {u: c for u, c in av.items() if c >= 3 and u not in default}
        res["avatares"] = {"padrao": sum(av[u] for u in default), "repetidos": sorted(rep.items(), key=lambda kv: -kv[1])[:5]}
        for k, u in acc_av.items():
            if u in default:
                flags[k].add("avatar_padrao")
            elif u in rep:
                flags[k].add("avatar_repetido")

    # IDs próximos
    if icol:
        ids = sorted({int(r[icol]) for r in rows if re.fullmatch(r"\d{6,20}", r.get(icol, ""))})
        runs, j = [], 0
        for i in range(len(ids)):
            while ids[i] - ids[j] > 10_000:
                j += 1
            if i - j + 1 >= 5:
                runs.append((ids[j], ids[i], i - j + 1))
        if runs:
            res["ids_proximos"] = {"faixas": runs[:5], "confianca": "baixa"}
            near_ids = {x for lo, hi, _ in runs for x in ids if lo <= x <= hi}
            for r in rows:
                if re.fullmatch(r"\d{6,20}", r.get(icol, "")) and int(r[icol]) in near_ids and key_of(r):
                    flags[key_of(r)].add("ids_proximos")

    # sobreposição
    if a.compare:
        other = read_rows(Path(a.compare), a.sheet)
        ocols = resolve_columns(list(other[0].keys()) if other else [], {})
        okey = lambda r: ((r.get(ocols.get("user", ""), "") or r.get(ocols.get("id", ""), "")) if ocols else "").lower()  # noqa: E731
        A = {key_of(r).lower() for r in rows if key_of(r)}
        B = {okey(r) for r in other if okey(r)}
        inter = A & B
        res["sobreposicao"] = {"outro_arquivo": str(a.compare), "A": len(A), "B": len(B), "em_comum": len(inter), "jaccard": round(len(inter) / max(1, len(A | B)), 3), "exemplos": sorted(inter)[:50]}

    res["indicadores_por_conta"] = {k: sorted(v) for k, v in flags.items()}
    return res


# ----------------------------------------------------------------------------- saída

def bar(n: int, mx: int, width: int = 24) -> str:
    return "█" * (0 if mx == 0 else max(1 if n else 0, round(width * n / mx)))


def render_md(res: dict) -> str:
    L: list[str] = []
    L.append(f"# Análise de export — {res['arquivo']}")
    prov = res.get("proveniencia", {})
    if prov:
        L.append("")
        L.append(f"Gerado por {prov['script']} em {prov['executado_utc']}. Entradas: "
                 + "; ".join(f"{m['entrada']} {Path(m['arquivo']).name} (SHA-256 {m['sha256']})" for m in prov.get("entradas", [])) + ".")
    L.append("")
    L.append("> **Indicadores, não veredito.** Nenhum item abaixo prova que uma conta é bot ou que há coordenação; cada indicador tem explicações legítimas (seção final).")
    L.append("")
    L.append("## Resumo")
    L.append(f"- Linhas: {res['linhas']} | contas distintas: {res['contas_distintas']} | linhas com data válida: {res['com_data']}")
    L.append(f"- Colunas mapeadas: {', '.join(f'{k}→{v}' for k, v in res['colunas_mapeadas'].items()) or 'nenhuma'}")
    if "janela_utc" in res:
        L.append(f"- Janela (UTC): {res['janela_utc']['inicio']} a {res['janela_utc']['fim']}")
    L.append("")
    if "hora_utc" in res:
        L.append("## Atividade no tempo")
        mx = max(res["hora_utc"] + res["hora_local"])
        L.append(f"Histograma por hora (UTC | local {res['fuso_local']}):")
        L.append("```")
        for h in range(24):
            L.append(f"{h:02d}h  UTC {res['hora_utc'][h]:>4} {bar(res['hora_utc'][h], mx):<24}  local {res['hora_local'][h]:>4} {bar(res['hora_local'][h], mx)}")
        L.append("```")
        if res.get("horarios_em_horario_de_verao"):
            L.append(f"- {res['horarios_em_horario_de_verao']} horário(s) caem em período de horário de verão de {res['fuso_local']}: na coluna local eles estão 1 h à frente "
                     "do que estariam em localidades sem horário de verão (ex.: SE/AL — America/Maceio). Confirme o fuso da localidade com --tz.")
        fp = res["fuso_provavel"]
        if isinstance(fp, dict):
            L.append(f"- Fuso provável (**inferência de baixa confiança**): UTC{fp['deslocamento_horas']:+d} — {fp['base']}. Trabalho em turnos, automação e rajadas distorcem a estimativa.")
        else:
            L.append(f"- Fuso provável: {fp}")
        dias = ["seg", "ter", "qua", "qui", "sex", "sáb", "dom"]
        L.append("- Dia da semana (local): " + ", ".join(f"{d} {n}" for d, n in zip(dias, res["dia_semana_local"])))
        L.append("")
        L.append("## Rajadas de comentários")
        if res["rajadas"]:
            for b in res["rajadas"]:
                L.append(f"- {b['inicio_utc']} → {b['fim_utc']}: **{b['comentarios']} comentários** (z≈{b['z_aprox']})")
            L.append("- Rajada = janela de 5 min com pelo menos 5 comentários e acima de média+3 desvios. Explicação alternativa: " + EXPLICACOES["rajada"])
        else:
            L.append("- Nenhuma rajada acima do limiar.")
        L.append("")
    L.append("## Textos repetidos e quase repetidos")
    def conc(d: dict) -> str:
        if d.get("fracao_em_30min") is None:
            return ""
        tag = " — **concentrado no tempo**" if d.get("concentrado") else ""
        return f"; {int(d['fracao_em_30min'] * 100)}% dentro de 30 min, extensão {d['extensao_min']} min{tag}"

    if res["textos_repetidos"]:
        for d in res["textos_repetidos"][:10]:
            L.append(f"- “{d['texto']}” — {d['comentarios']} comentários de {d['contas']} contas{conc(d)}")
    else:
        L.append("- Nenhum texto exato repetido por ≥3 comentários de ≥2 contas (textos com menos de 8 caracteres são ignorados).")
    for d in res["textos_quase_repetidos"][:10]:
        L.append(f"- Variações ({d['variantes']}): {' | '.join('“' + e + '”' for e in d['exemplos'])} — {d['comentarios']} comentários de {d['contas']} contas{conc(d)}")
    L.append("")
    L.append("## Contas")
    if "username_padrao" in res:
        u = res["username_padrao"]
        L.append(f"- Usernames com padrão suspeito: {u['contas']} ({u['percentual']}%). Ex.: {', '.join(u['exemplos'][:8]) or '—'}")
    if "criacao_de_contas" in res:
        c = res["criacao_de_contas"]
        L.append(f"- Datas de criação disponíveis para {c['contas_com_data']} contas (origem: {c['origem']}). Dias mais comuns: {', '.join(f'{d}: {n}' for d, n in c['por_dia_top'][:5])}")
        for lote in c["lotes_suspeitos"]:
            L.append(f"- **Criação em lote** (janela de {c['janela_do_lote']}): {lote['contas']} contas ({lote['percentual']}%) entre {lote['inicio_utc']} e {lote['fim_utc']}")
    if "contas_com_menos_de_7_dias" in res:
        y = res["contas_com_menos_de_7_dias"]
        L.append(f"- Contas com menos de 7 dias na data do comentário: {y['contas']} de {y['de']}")
    if "seguindo_muito_seguidores_poucos" in res:
        L.append(f"- Contas que seguem ≥20× mais do que têm de seguidores (com ≤10 seguidores): {res['seguindo_muito_seguidores_poucos']}")
    if "avatares" in res:
        av = res["avatares"]
        L.append(f"- Avatares padrão: {av['padrao']} | avatares repetidos entre contas: {av['repetidos'] or '—'}")
    if "ids_proximos" in res:
        L.append(f"- IDs numéricos muito próximos (baixa confiança): {res['ids_proximos']['faixas']}")
    if res.get("contas_com_muitos_comentarios"):
        L.append("- Contas com muitos comentários: " + ", ".join(f"{u} ({n})" for u, n in res["contas_com_muitos_comentarios"][:8]))
    L.append("")
    if res.get("entidades"):
        L.append("## Entidades mais frequentes")
        for k, v in res["entidades"].items():
            L.append(f"- {k}: " + ", ".join(f"{x} ({n})" for x, n in v[:8]))
        L.append("")
    if "sobreposicao" in res:
        s = res["sobreposicao"]
        L.append("## Sobreposição entre exports")
        L.append(f"- A={s['A']} | B={s['B']} | em comum={s['em_comum']} | Jaccard={s['jaccard']}")
        L.append("- Em comum (até 50): " + (", ".join(s["exemplos"]) or "—"))
        L.append("")
    flagged = {k: v for k, v in res["indicadores_por_conta"].items() if len(v) >= 2}
    L.append("## Contas com 2 ou mais indicadores")
    if flagged:
        groups: dict[tuple, list[str]] = defaultdict(list)
        for k, v in flagged.items():
            groups[tuple(v)].append(k)
        L.append("| Contas | Conjunto de indicadores | Exemplos |")
        L.append("|---|---|---|")
        for ind, accs in sorted(groups.items(), key=lambda kv: (-len(kv[0]) * len(kv[1]), -len(kv[1])))[:12]:
            L.append(f"| {len(accs)} | {', '.join(ind)} | {', '.join(sorted(accs)[:4])} |")
        L.append("")
        L.append("A lista completa por conta está em `sinalizados.csv`. Agrupar contas por conjunto de indicadores mostra **padrões**; não identifica pessoas.")
    else:
        L.append("Nenhuma conta com 2 ou mais indicadores.")
    L.append("")
    L.append("## Explicações alternativas e limitações")
    for k, v in EXPLICACOES.items():
        L.append(f"- **{k}**: {v}")
    L.append("- Exports parciais (limites gratuitos de 100 a 500 itens), ordenação por relevância, conteúdo apagado e viés de amostra afetam qualquer conclusão.")
    L.append("- Use estes indicadores para **orientar a coleta e a verificação**; afirmações no relatório exigem corroboração (references/06 e 07).")
    return "\n".join(L)


def main(argv: list[str] | None = None) -> int:
    ensure_utf8_stdout()
    p = argparse.ArgumentParser(description="Analisa exports de seguidores/comentários e gera indicadores (nunca veredito).")
    p.add_argument("input", help="arquivo CSV ou XLSX")
    p.add_argument("--platform", help="plataforma de origem (informativo; discord/x ativam decodificação de ID)")
    p.add_argument("--map", default="", help="mapeamento chave=coluna, separado por vírgula (ex.: text=comment,time=create_time)")
    p.add_argument("--tz", default=DEFAULT_TZ, help=f"fuso local: o IANA da localidade do fato, ex.: America/Maceio para SE/AL (padrão {DEFAULT_TZ})")
    p.add_argument("--input-tz", default="UTC", help="fuso dos horários sem fuso explícito (padrão UTC)")
    p.add_argument("--decode-ids", choices=["discord", "x", "instagram-media", "tiktok-video"], help="decodifica a coluna id em data de criação")
    p.add_argument("--compare", help="outro CSV/XLSX para sobreposição de contas")
    p.add_argument("--sheet", help="nome da aba (XLSX)")
    p.add_argument("--out", help="pasta de saída (relatorio.md, resumo.json, sinalizados.csv)")
    a = p.parse_args(argv)

    path = Path(a.input)
    if not path.is_file():
        die(f"arquivo não encontrado: {path}")
    if a.out:
        guard_output(a.out, "--out")
    rows = read_rows(path, a.sheet)
    if not rows:
        die("nenhuma linha de dados encontrada.")
    overrides = dict(kv.split("=", 1) for kv in a.map.split(",") if "=" in kv)
    cols = resolve_columns(list(rows[0].keys()), {k.strip(): v.strip() for k, v in overrides.items()})
    res = analyze(rows, cols, a)
    md = render_md(res)
    if a.out:
        out = Path(a.out)
        out.mkdir(parents=True, exist_ok=True)
        (out / "relatorio.md").write_text(md + "\n", encoding="utf-8")
        (out / "resumo.json").write_text(json.dumps(res, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
        write_csv(out / "sinalizados.csv", [{"conta": k, "n_indicadores": len(v), "indicadores": ";".join(v)} for k, v in sorted(res["indicadores_por_conta"].items(), key=lambda kv: -len(kv[1]))], ["conta", "n_indicadores", "indicadores"])
        print(f"Relatório gravado em {out}/relatorio.md (+ resumo.json, sinalizados.csv)")
    print(md)
    return 0


if __name__ == "__main__":
    sys.exit(main())
