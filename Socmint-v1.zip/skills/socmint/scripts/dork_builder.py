#!/usr/bin/env python3
"""Gera dorks e URLs de busca por plataforma e intenção (offline; só monta texto).

Exemplos:
    python3 scripts/dork_builder.py --platform telegram --intent keyword --q "termo"
    python3 scripts/dork_builder.py --platform instagram --intent username --q alias
    python3 scripts/dork_builder.py --platform facebook --intent name --q "Nome Sobrenome" --exclude-site facebook.com/perfil.achado
    python3 scripts/dork_builder.py --platform whatsapp --intent invite --q "vagas"
    python3 scripts/dork_builder.py --platform kwai --intent keyword --q "renda extra" --after 2026-01-01
    python3 scripts/dork_builder.py --list

Intenções: name, username, keyword, hashtag, bio, email, contact, invite, group, location, domain, company.
--after/--before (AAAA-MM-DD) acrescentam after:/before: às consultas web (só o Google respeita, [VOL]) e
since:/until: aos operadores nativos do X. Motores padrão: Google, Bing e DuckDuckGo; Yandex só com --engines,
porque o termo do caso vai ao provedor.
O script NÃO consulta nada: devolve consultas e links para você abrir. Respeite o gate (references/00).
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from urllib.parse import quote_plus

from _common import ensure_utf8_stdout

ENGINES = {
    "google": "https://www.google.com/search?q={q}",
    "bing": "https://www.bing.com/search?q={q}",
    "duckduckgo": "https://duckduckgo.com/?q={q}",
    "yandex": "https://yandex.com/search/?text={q}",
}

# placeholders: {q} termo principal; {x} site/perfil a excluir; {g} ID ou vanity de grupo
# cada item: (modelo, observação, origem)
T = {
    "instagram": {
        "name": [('site:instagram.com "{q}"', "perfil por nome", "L p.532")],
        "bio": [('site:instagram.com "{q}"', "texto de bio (a busca interna não indexa bio)", "L p.533")],
        "username": [
            ('@{q} inurl:instagram.com -site:instagram.com/{q}', "citações ao alias, sem o perfil", "L p.533"),
            ('site:instagram.com "{q}"', "alias em qualquer página", "L p.532"),
        ],
        "keyword": [('inurl:instagram.com/p/ "{q}"', "legenda de publicação", "L p.534"), ('site:instagram.com "{q}"', "hashtags relacionadas", "L p.528")],
        "hashtag": [('site:instagram.com/p/ {q}', "publicações com uma ou mais hashtags (passe #tag1 #tag2)", "L p.527, 534")],
        "location": [('site:instagram.com/explore/locations/ "{q}"', "ID de local pelo nome", "L p.534")],
    },
    "facebook": {
        "name": [
            ('intext:"{q}" inurl:facebook.com OR site:facebook.com', "perfil por nome", "L p.441"),
            ('"{q}" site:facebook.com inurl:ref=page_internal', "variação", "L p.441"),
            ('intext:"{q}" inurl:facebook.com -site:{x}', "outros perfis/menções sem o perfil já achado (requer --exclude-site)", "L p.441"),
        ],
        "keyword": [('"{q}" site:facebook.com inurl:ref=page_internal', "palavra-chave em páginas", "L p.371, 441"),
                    ('"text that says {q}" site:facebook.com', "texto automático de descrição de imagem", "L p.329"),
                    ('"May be an image of {q}" site:facebook.com', "descrição automática de imagem", "L p.330")],
        "email": [('site:facebook.com inurl:/about_contact_and_basic_info "{q}"', "e-mail exato em perfil/página (pessoa privada: gate)", "L p.315, 441")],
        "bio": [('"{q}" site:facebook.com', "texto de bio ou detalhes", "L p.441")],
        "group": [('site:facebook.com/groups/{g}/posts "{q}"', "posts do alvo em grupo (requer --group)", "L p.417")],
    },
    "threads": {
        "username": [('site:threads.com/@ "{q}"', "perfil/bio", "L p.608 (domínio atualizado)"), ('site:threads.net/@ "{q}"', "índice antigo", "L p.608")],
        "bio": [('site:threads.com/@ "{q}"', "texto de bio", "L p.608"), ('site:threads.net/@ "{q}"', "índice antigo", "L p.608")],
        "keyword": [('site:threads.com/t/ "{q}"', "publicações", "L p.608"), ('site:threads.net/t/ "{q}"', "índice antigo", "L p.608")],
        "name": [('site:threads.com/@ "{q}"', "nome", "L p.608"), ('site:threads.net/@ "{q}"', "índice antigo", "L p.608")],
    },
    "tiktok": {
        "name": [('"{q}" site:tiktok.com', "por nome", "K c.9.1")],
        "username": [('"@{q}" site:tiktok.com', "por uniqueId", "K c.9.1")],
        "hashtag": [('site:tiktok.com #{q}', "por hashtag", "K c.9.1")],
        "keyword": [('site:tiktok.com "{q}"', "por texto de descrição", "K c.9.1")],
        "bio": [('site:tiktok.com "{q}"', "texto de bio/descrição", "K c.9.1")],
    },
    "telegram": {
        "keyword": [
            ('{q} site:t.me', "canais/grupos/usuários", "T s.84"),
            ('{q} site:telegram.me', "domínio alternativo", "T s.84"),
            ('{q} t.me/joinchat/', "convites", "T s.84"),
            ('site:t.me/joinchat inurl:{q}', "convites com o termo na URL", "T s.84"),
        ],
        "username": [
            ('inurl:{q} site:t.me', "nome de usuário/grupo/canal/bot na URL", "T s.84"),
            ('"Telegram @{q}" site:linkedin.com', "usuário citado no LinkedIn", "T s.84"),
            ('"Contact me on Telegram" "{q}" site:github.com', "usuário citado no GitHub", "T s.84"),
        ],
        "invite": [('{q} t.me/joinchat/', "convites", "T s.84"), ('site:t.me/joinchat inurl:{q}', "convites", "T s.84")],
        "contact": [('"contact us" "{q}" site:t.me', "contatos divulgados em canais", "T s.84"), ('"phone number" "{q}" site:t.me', "telefones divulgados em canais", "T s.84")],
        "name": [('"{q}" site:t.me', "nome em canais/perfis", "T s.84")],
    },
    "whatsapp": {
        "invite": [('site:chat.whatsapp.com "{q}"', "convites abertos indexados", "D s.86"), ('intext:chat.whatsapp.com/invite/ intitle:{q}', "páginas que compilam convites", "L p.613")],
        "keyword": [('intext:chat.whatsapp.com/invite/ intitle:{q}', "páginas que compilam convites", "L p.613")],
    },
    "discord": {
        "invite": [('site:discord.gg "{q}"', "convites", "[ADD]"), ('site:discord.com/invite "{q}"', "convites", "[ADD]")],
        "keyword": [('site:discord.gg "{q}"', "convites e menções", "[ADD]")],
        "username": [('"{q}" site:discord.com/invite', "citações", "[ADD]")],
    },
    "reddit": {
        "username": [('site:reddit.com/user/{q}', "perfil", "[ADD]"), ('site:reddit.com/u/{q}', "perfil (forma curta)", "[ADD]"), ('author:{q}', "operador da busca interna do Reddit", "Reddit Help")],
        "keyword": [('site:reddit.com "{q}"', "posts e comentários", "[ADD]"), ('title:"{q}"', "operador da busca interna", "Reddit Help")],
        "bio": [('inurl:reddit.com/user "{q}"', "texto que a pessoa costuma escrever", "[ADD]")],
    },
    "x": {
        "keyword": [('site:x.com "{q}"', "posts indexados", "[ADD]"), ('site:twitter.com "{q}"', "índice antigo", "[ADD]"), ('"{q}" lang:pt', "operador nativo (conta logada)", "[ADD]")],
        "username": [('site:x.com/{q}', "perfil", "[ADD]"), ('from:{q}', "operador nativo: posts da conta", "[ADD]"), ('to:{q}', "operador nativo: respostas à conta", "[ADD]")],
        "hashtag": [('#{q}', "operador nativo", "[ADD]"), ('site:x.com #{q}', "indexado", "[ADD]")],
    },
    "linkedin": {
        "name": [('site:linkedin.com/in "{q}"', "perfil por nome", "L p.232"), ('intext:"{q}" site:linkedin.com', "nome em qualquer página", "L p.232")],
        "company": [('site:linkedin.com/company "{q}"', "página de empresa", "[ADD]"), ('site:linkedin.com/jobs "{q}"', "vagas (golpes de emprego)", "[ADD]")],
        "keyword": [('site:linkedin.com "{q}"', "texto", "[ADD]")],
    },
    "youtube": {
        "keyword": [('site:youtube.com "{q}"', "vídeos e canais", "[ADD]")],
        "username": [('site:youtube.com/@{q}', "canal pelo handle", "[ADD]")],
        "name": [('site:youtube.com/channel "{q}"', "canal pelo nome", "[ADD]")],
    },
    "kwai": {
        "keyword": [('site:kwai.com "{q}"', "vídeos e perfis indexados", "[ADD]"), ('site:kwai.com inurl:video "{q}"', "páginas de vídeo", "[ADD]")],
        "username": [('site:kwai.com/@{q}', "perfil pelo Kwai ID", "[ADD]"), ('"kwai.com/@{q}"', "onde o perfil é divulgado", "[ADD]")],
        "hashtag": [('site:kwai.com #{q}', "por hashtag", "[ADD]")],
        "name": [('site:kwai.com "{q}"', "nome exibido", "[ADD]")],
    },
    "bluesky": {
        "username": [('site:bsky.app/profile "{q}"', "perfil", "[ADD]")],
        "keyword": [('site:bsky.app "{q}"', "posts indexados", "[ADD]")],
    },
    "generic": {
        "name": [('intext:"{q}"', "nome no texto", "L p.103"), ('intext:"CV {q}" filetype:pdf', "currículo em PDF", "L p.111")],
        "keyword": [('intext:"{q}"', "texto", "L p.103"), ('intitle:"{q}"', "título", "L p.106")],
        "email": [('"{q}"', "e-mail exato (pessoa privada: gate)", "L p.237")],
        "username": [('"{q}"', "alias exato", "L p.246")],
        "domain": [('site:{q}', "conteúdo de um domínio", "L p.109")],
    },
}
ALIASES = {"twitter": "x", "insta": "instagram", "fb": "facebook", "tt": "tiktok", "tg": "telegram", "wa": "whatsapp", "kw": "kwai"}
# nomes antigos de intenção que geravam outra coisa (mantidos por compatibilidade)
LEGACY_INTENTS = {("facebook", "invite"): "group", ("telegram", "email"): "contact"}
SENSITIVE = {"email": "E-mail/telefone exatos podem identificar pessoa física: aplique o gate (references/00) antes de usar.",
             "contact": "Contatos divulgados podem identificar pessoa física: aplique o gate (references/00) antes de usar."}
DEFAULT_ENGINES = "google,bing,duckduckgo"  # Yandex só com --engines: o termo do caso vai a provedor de outra jurisdição


def date_filter(dork: str, note: str, platform: str, after: str | None, before: str | None) -> str:
    """Acrescenta janela de datas: since:/until: nos operadores nativos do X; after:/before: nas consultas web."""
    if not (after or before):
        return dork
    if "operador" in note:  # operador nativo da plataforma, não do buscador
        if platform != "x":
            return dork
        return " ".join([dork] + ([f"since:{after}"] if after else []) + ([f"until:{before}"] if before else []))
    return " ".join([dork] + ([f"after:{after}"] if after else []) + ([f"before:{before}"] if before else []))


def build(platform: str, intent: str | None, q: str, exclude: str | None, group: str | None, engines: list[str],
          after: str | None = None, before: str | None = None) -> list[dict]:
    plat = T.get(platform)
    if plat is None:
        raise SystemExit(f"Plataforma desconhecida: {platform}. Disponíveis: {', '.join(sorted(T))}")
    if intent and (platform, intent) in LEGACY_INTENTS:
        novo = LEGACY_INTENTS[(platform, intent)]
        print(f"Nota: a intenção {intent!r} de {platform} agora se chama {novo!r}.", file=sys.stderr)
        intent = novo
    intents = [intent] if intent else sorted(plat)
    out: list[dict] = []
    seen: set[str] = set()
    for it in intents:
        if it not in plat:
            if intent:
                raise SystemExit(f"Intenção {it!r} não existe para {platform}. Disponíveis: {', '.join(sorted(plat))}")
            continue
        for model, note, src in plat[it]:
            if "{x}" in model and not exclude:
                out.append({"plataforma": platform, "intencao": it, "dork": None, "observacao": f"{note} — pulado: informe --exclude-site", "origem": src, "urls": {}})
                continue
            if "{g}" in model and not group:
                out.append({"plataforma": platform, "intencao": it, "dork": None, "observacao": f"{note} — pulado: informe --group", "origem": src, "urls": {}})
                continue
            tokens = q.split() if it == "hashtag" else None
            qq = " ".join(t if t.startswith("#") else f"#{t}" for t in tokens) if tokens and platform == "instagram" else q
            if it == "hashtag" and platform != "instagram":
                qq = q.lstrip("#")
            dork = date_filter(model.replace("{q}", qq).replace("{x}", exclude or "").replace("{g}", group or ""), note, platform, after, before)
            if dork in seen:
                continue
            seen.add(dork)
            urls = {e: ENGINES[e].format(q=quote_plus(dork)) for e in engines}
            out.append({"plataforma": platform, "intencao": it, "dork": dork, "observacao": note, "origem": src, "urls": urls})
    return out


def render_md(items: list[dict], intent: str | None) -> str:
    lines = []
    if intent in SENSITIVE:
        lines.append(f"> AVISO: {SENSITIVE[intent]}\n")
    for r in items:
        if r["dork"] is None:
            lines.append(f"- ({r['intencao']}) {r['observacao']}")
            continue
        lines.append(f"- **{r['intencao']}** — `{r['dork']}`  \n  {r['observacao']} ({r['origem']})")
        for eng, url in r["urls"].items():
            lines.append(f"  - {eng}: {url}")
    return "\n".join(lines)


def render_txt(items: list[dict]) -> str:
    return "\n".join(r["dork"] for r in items if r["dork"])


def main(argv: list[str] | None = None) -> int:
    ensure_utf8_stdout()
    p = argparse.ArgumentParser(description="Gera dorks por plataforma e intenção (offline).")
    p.add_argument("--platform", help="instagram, facebook, threads, tiktok, kwai, telegram, whatsapp, discord, reddit, x, linkedin, youtube, bluesky, generic")
    p.add_argument("--intent", help="name, username, keyword, hashtag, bio, email, contact, invite, group, location, domain, company (padrão: todas da plataforma)")
    p.add_argument("--q", help="termo principal (nome, alias, palavra-chave, hashtag, local…)")
    p.add_argument("--exclude-site", help="perfil/URL já encontrado a excluir (ex.: facebook.com/perfil)")
    p.add_argument("--group", help="ID ou vanity de grupo do Facebook")
    p.add_argument("--after", help="só resultados a partir de AAAA-MM-DD")
    p.add_argument("--before", help="só resultados até AAAA-MM-DD")
    p.add_argument("--engines", default=DEFAULT_ENGINES, help=f"motores para os links (vírgula; padrão {DEFAULT_ENGINES}; disponíveis: google, bing, duckduckgo, yandex)")
    p.add_argument("--format", choices=["md", "json", "txt"], default="md")
    p.add_argument("--list", action="store_true", help="lista plataformas e intenções")
    a = p.parse_args(argv)
    if a.list:
        for plat in sorted(T):
            print(f"{plat}: {', '.join(sorted(T[plat]))}")
        return 0
    if not a.platform or not a.q:
        p.error("--platform e --q são obrigatórios (ou use --list)")
    platform = ALIASES.get(a.platform.lower(), a.platform.lower())
    engines = [e.strip() for e in a.engines.split(",") if e.strip() in ENGINES]
    for d in (a.after, a.before):
        if d and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", d):
            p.error(f"data inválida: {d!r} (use AAAA-MM-DD)")
    if a.intent and (platform, a.intent.lower()) in LEGACY_INTENTS:
        a.intent = LEGACY_INTENTS[(platform, a.intent.lower())]
        print(f"Nota: intenção renomeada para {a.intent!r}.", file=sys.stderr)
    items = build(platform, a.intent.lower() if a.intent else None, a.q, a.exclude_site, a.group, engines, a.after, a.before)
    if a.format == "json":
        print(json.dumps(items, ensure_ascii=False, indent=2))
    elif a.format == "txt":
        print(render_txt(items))
    else:
        print(render_md(items, a.intent.lower() if a.intent else None))
    return 0


if __name__ == "__main__":
    sys.exit(main())
