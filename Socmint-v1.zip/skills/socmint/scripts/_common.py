"""Utilidades compartilhadas pelos scripts da skill socmint (somente biblioteca padrão)."""
from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
import unicodedata
from datetime import datetime, timedelta, timezone, tzinfo
from pathlib import Path

DEFAULT_TZ = "America/Sao_Paulo"
_FIXED_FALLBACK = {"America/Sao_Paulo": -3, "BRT": -3}
SCRIPTS_VERSION = "1.1.0"  # versão dos scripts da skill; vai para as saídas (reprodutibilidade)
SKILL_DIR = Path(__file__).resolve().parent.parent


def guard_output(path: str | Path, what: str = "saída") -> None:
    """Impede gravar dados de caso dentro da pasta da skill (os dados ficariam junto com a skill e vazariam entre casos)."""
    p = Path(path).resolve()
    try:
        p.relative_to(SKILL_DIR)
    except ValueError:
        return
    die(f"{what} aponta para dentro da pasta da skill ({SKILL_DIR}). Grave os arquivos do caso no diretório de trabalho "
        f"(ex.: rode o script por caminho completo, a partir da pasta do caso).")


def script_tag(name: str) -> str:
    return f"{name} (socmint {SCRIPTS_VERSION})"


def input_manifest(paths: dict[str, str | Path | None]) -> list[dict]:
    """Lista de entradas com SHA-256, para registrar nas saídas o que foi analisado."""
    out = []
    for label, p in paths.items():
        if p and Path(p).is_file():
            out.append({"entrada": label, "arquivo": str(p), "sha256": sha256_file(Path(p)), "bytes": Path(p).stat().st_size})
    return out


def parse_when_utc(value: str, tz: tzinfo) -> str:
    """Converte data/hora informada (ISO 8601 com ou sem fuso; sem fuso = fuso do caso) para ISO UTC (…Z)."""
    v = (value or "").strip().replace("Z", "+00:00").replace("z", "+00:00")
    try:
        dt = datetime.fromisoformat(v.replace(" ", "T", 1) if "T" not in v and " " in v else v)
    except ValueError:
        die(f"data/hora inválida: {value!r} (use ISO 8601, ex.: 2026-05-10T14:22:05-03:00 ou 2026-05-10 14:22:05)")
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=tz)
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def file_mtime_utc(path: Path) -> str:
    return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def ensure_utf8_stdout() -> None:
    """Garante saída UTF-8 (útil no Windows)."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
        except Exception:
            pass


def parse_tz(name: str | None) -> tuple[tzinfo, str]:
    """Aceita nome IANA (America/Sao_Paulo), 'UTC' ou deslocamento fixo (-03:00, +0530)."""
    name = (name or DEFAULT_TZ).strip()
    if name.upper() in ("UTC", "Z"):
        return timezone.utc, "UTC"
    m = re.fullmatch(r"([+-])(\d{1,2}):?(\d{2})?", name)
    if m:
        sign = -1 if m.group(1) == "-" else 1
        delta = timedelta(hours=int(m.group(2)), minutes=int(m.group(3) or 0))
        return timezone(sign * delta), name
    sem_base = True
    try:
        import zoneinfo

        try:
            return zoneinfo.ZoneInfo(name), name
        except Exception:
            sem_base = not zoneinfo.available_timezones()
    except ImportError:
        pass
    if name in _FIXED_FALLBACK:
        if sem_base:
            print(f"Aviso: base de fusos IANA indisponível; usando deslocamento fixo {_FIXED_FALLBACK[name]:+d}h para {name}, "
                  "sem o horário de verão histórico. Instale com `pip install tzdata`.", file=sys.stderr)
        return timezone(timedelta(hours=_FIXED_FALLBACK[name])), f"{name} (deslocamento fixo {_FIXED_FALLBACK[name]:+d}h)"
    if sem_base:
        raise SystemExit(f"Base de fusos IANA indisponível neste Python (comum no Windows): instale com `pip install tzdata` e repita. Fuso pedido: {name!r}.")
    raise SystemExit(f"Fuso desconhecido: {name!r}. Use um nome IANA (ex.: America/Sao_Paulo, America/Maceio) ou um deslocamento como -03:00.")


def dst_note(dt_utc: datetime, tz: tzinfo, tz_label: str) -> str | None:
    """Aviso quando o fuso exibido estava em horário de verão no instante dado (o deslocamento local muda 1 h)."""
    local = dt_utc.astimezone(tz)
    if not local.dst():
        return None
    off = local.utcoffset() or timedelta(0)
    horas = int(off.total_seconds() // 3600)
    return (f"Nesta data o fuso {tz_label} estava em horário de verão (UTC{horas:+d}). Até 2019 a adoção variou por estado e por ano "
            "(ex.: SE/AL — America/Maceio — ficaram fora): confirme o fuso IANA da localidade do fato.")


def iso_ms(dt: datetime) -> str:
    """ISO 8601 com milissegundos; UTC termina em Z."""
    if dt.tzinfo is not None and dt.utcoffset() == timedelta(0):
        return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.") + f"{dt.microsecond // 1000:03d}Z"
    return dt.isoformat(timespec="milliseconds")


def from_unix_ms(ms: int) -> datetime:
    return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(milliseconds=ms)


def from_unix_us(us: int) -> datetime:
    return datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(microseconds=us)


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path: Path, algo: str = "sha256") -> str:
    h = hashlib.new(algo)
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def canonical_json(obj: object) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def strip_accents(text: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", text) if not unicodedata.combining(c))


def slugify(text: str, sep: str = "-") -> str:
    text = strip_accents(text).lower()
    return re.sub(r"[^a-z0-9]+", sep, text).strip(sep) or "item"


def read_text_guess(path: Path) -> str:
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def read_csv_dicts(path: Path) -> list[dict[str, str]]:
    text = read_text_guess(path)
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    reader = csv.DictReader(text.splitlines(), dialect=dialect)
    rows = []
    for row in reader:
        rows.append({(k or "").strip(): (v or "").strip() for k, v in row.items() if k is not None})
    return rows


def write_csv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=fieldnames, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def die(msg: str, code: int = 2) -> None:
    print(f"Erro: {msg}", file=sys.stderr)
    raise SystemExit(code)
