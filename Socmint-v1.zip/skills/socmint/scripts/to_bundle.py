#!/usr/bin/env python3
"""Exporta o caso SOCMINT como bundle `intel-bundle/1.0` para o Investigative Notebook (offline).

Exemplos:
    python3 scripts/to_bundle.py --case-dir caso-001 --nodes nos.csv --edges arestas.csv --out caso-001/socmint.bundle.json
    python3 scripts/to_bundle.py --case case.json --evidence evidence_log.jsonl --findings findings.csv --timeline timeline.csv \
        --pivots pivos.csv --nodes nos.csv --edges arestas.csv --analysis analise/resumo.json --out socmint.bundle.json
Depois, no Investigative Notebook:
    nb.py import-bundle caso.json socmint.bundle.json --dry-run     (revise o que entraria)
    nb.py import-bundle caso.json socmint.bundle.json

O que vai para o bundle:
    evidence_log.jsonl  → op evidence (SHA-256/512, hora da coleta, URL de origem, custódia) + fonte pagina_web por URL
    nos.csv/arestas.csv → entidades e relações; `tipo` da aresta define a natureza:
                          identidade → "possível mesmo titular" (correlacao); associacao → relação observada;
                          imitacao → "imita" (inferencia), nunca vínculo com a vítima da imitação
                          contas com @handle viram perfil_social (identificador perfil = plataforma:username) e
                          um usuario compartilhado ("usado em"): perfis com o mesmo username NÃO são unificados
    findings.csv        → observações (Observação = observado, Inferência = inferencia; Admiralty em reliability/credibility);
                          Desconhecido vai para a lista de achados do bundle como lacuna
    case.json hipóteses → op hypothesis (evidencias_favor/contra como supporting/contradicting)
    timeline.csv        → eventos; pivos.csv → consultas osint; resumo.json do analyze_export → análise reproduzível
Metadados: case_ref = procedimento.numero ou id_caso; legal_basis = gate.base_legal; analyst = coletor.
O script recusa exportar se a cadeia de hashes estiver quebrada ou se um arquivo tiver sido alterado.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

from _common import SCRIPTS_VERSION, die, ensure_utf8_stdout, guard_output, read_csv_dicts, script_tag, sha256_file
from evidence_log import check, custody_events, discarded_ids, load_log
from intel_contract import Bundle, locator

NODE_TYPE = {"conta": "perfil_social", "grupo": "perfil_social", "servidor": "perfil_social", "canal": "perfil_social",
             "bot": "perfil_social", "pessoa": "pessoa", "organizacao": "organizacao", "email": "email",
             "telefone": "telefone", "dominio": "dominio", "imagem": "imagem", "evento": "evento", "desconhecido": "outro"}
IDENT_KIND = {"email": "email", "telefone": "telefone", "dominio": "dominio"}
CONF = {"fraca": "baixa", "moderada": "media", "forte": "alta", "baixa": "baixa", "media": "media", "média": "media", "alta": "alta"}
HYP_STATUS = {"refutada": "rejeitada", "descartada": "rejeitada", "rejeitada": "rejeitada", "aberta": "aberta",
              "em_analise": "em_analise", "em análise": "em_analise", "sustentada": "sustentada", "enfraquecida": "enfraquecida",
              "confirmada": "confirmada"}
IMG_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff"}


def evidence_type(tipo: str, arquivo: str) -> str:
    """Tipo de evidência do Notebook (vocabulário fechado) a partir do tipo e da extensão registrados no log."""
    t, ext = (tipo or "").lower(), Path(arquivo or "").suffix.lower()
    if t in ("captura", "screenshot", "print"):
        return "screenshot"
    if t in ("html", "pagina", "warc", "wacz"):
        return "pagina_web"
    if t in ("json", "har"):
        return "json"
    if t in ("midia", "imagem"):
        return "imagem"
    if t in ("video", "audio", "documento"):
        return t
    if t == "ata":
        return "documento"
    if t in ("export", "planilha"):
        return "csv" if ext == ".csv" else "planilha"
    if ext in (".html", ".htm"):
        return "pagina_web"
    if ext in IMG_EXT:
        return "screenshot"
    if ext == ".json":
        return "json"
    if ext == ".pdf":
        return "pdf"
    return "arquivo_digital" if ext else "outro"


def handle_of(label: str) -> str:
    s = (label or "").strip()
    if s.startswith("@"):
        s = s[1:]
    return s if re.fullmatch(r"[\w.\-]{1,64}", s) else ""


def main(argv: list[str] | None = None) -> int:
    ensure_utf8_stdout()
    p = argparse.ArgumentParser(description="Exporta o caso SOCMINT como intel-bundle/1.0 (Investigative Notebook).")
    p.add_argument("--case-dir", help="pasta do caso (procura case.json, evidence_log.jsonl, findings.csv, timeline.csv, pivos.csv)")
    p.add_argument("--case")
    p.add_argument("--evidence")
    p.add_argument("--findings")
    p.add_argument("--timeline")
    p.add_argument("--pivots")
    p.add_argument("--nodes", help="nós do grafo (mesmo CSV do build_graph.py)")
    p.add_argument("--edges", help="arestas do grafo (mesmo CSV do build_graph.py)")
    p.add_argument("--analysis", help="resumo.json do analyze_export.py (opcional)")
    p.add_argument("--out", required=True)
    a = p.parse_args(argv)

    d = Path(a.case_dir) if a.case_dir else None

    def pick(explicit, *names):
        if explicit:
            return Path(explicit)
        for n in names:
            if d and (d / n).exists():
                return d / n
        return None

    case_p = pick(a.case, "case.json")
    if not case_p or not case_p.exists():
        die("informe --case ou --case-dir com um case.json.")
    guard_output(a.out, "--out")
    case = json.loads(case_p.read_text(encoding="utf-8-sig"))
    ev_p = pick(a.evidence, "evidence_log.jsonl")
    fi_p = pick(a.findings, "findings.csv", "05_Analises/findings.csv", "06_Relatorios_e_Mapas/findings.csv")
    tl_p = pick(a.timeline, "timeline.csv", "05_Analises/timeline.csv", "06_Relatorios_e_Mapas/timeline.csv")
    pv_p = pick(a.pivots, "pivos.csv", "03_Pivotagem_Social/pivos.csv")
    no_p = pick(a.nodes, "nos.csv", "06_Relatorios_e_Mapas/nos.csv")
    ed_p = pick(a.edges, "arestas.csv", "06_Relatorios_e_Mapas/arestas.csv")
    an_p = pick(a.analysis, "05_Analises/resumo.json", "analise/resumo.json")

    gate = case.get("gate", {})
    proc = case.get("procedimento", {}) or {}
    case_ref = proc.get("numero") and f"{proc.get('tipo', '')} {proc['numero']}".strip() or case.get("id_caso", "")
    b = Bundle("socmint", SCRIPTS_VERSION, case_ref=case_ref, legal_basis=gate.get("base_legal", ""),
               analyst=case.get("coletor", ""), description=f"{case.get('titulo', '')} — {gate.get('pergunta', '')}".strip(" —"))
    warns: list[str] = []
    s_case = b.source("consulta_osint", f"SOCMINT — {case.get('titulo') or case.get('id_caso', '')}", reference=gate.get("autorizacao", ""),
                      date=case.get("criado_utc", ""))

    # evidências
    entries = load_log(ev_p) if ev_p and ev_p.exists() else []
    evmap: dict[str, str] = {}
    evloc: dict[str, dict] = {}
    if entries:
        ok, problems = check(ev_p.parent, entries)
        graves = [x for x in problems if x.startswith("linha") or "ALTERADO" in x]
        if graves:
            die("integridade comprometida; corrija antes de exportar:\n - " + "\n - ".join(graves))
        warns += [x for x in problems if "AUSENTE" in x]
        gone = discarded_ids(entries)
        custody = custody_events(entries)
        for e in (x for x in entries if x.get("registro") == "evidencia"):
            src = s_case
            if e.get("url"):
                src = b.source("pagina_web", f"{e.get('plataforma') or 'web'} — {e['url']}", reference=e["url"], url=e["url"],
                               accessed_at=e.get("coleta_utc") or e.get("utc", ""), level="primaria")
            full = ev_p.parent / e["arquivo"]
            evmap[e["id"]] = b.evidence(
                f"{e['id']} — {e.get('tipo') or 'arquivo'} {e.get('plataforma', '')}".strip(), evidence_type(e.get("tipo"), e.get("arquivo")),
                file_path=str(full) if full.exists() else None, sha256=e.get("sha256", ""), source_id=src, description=e.get("notas", ""),
                sha512=e.get("sha512", ""), acquired_at=e.get("coleta_utc") or e.get("utc", ""), origin=e.get("url", ""),
                socmint_id=e["id"], descartada=e["id"] in gone,
                collection={k: e.get(k, "") for k in ("metodo", "ferramenta", "versao_ferramenta", "navegador", "rede", "conta", "coletor")},
                custody=[{k: c.get(k, "") for k in ("id", "quando_utc", "etapa", "responsavel", "destino", "notas")}
                         for c in custody if e["id"] in c.get("evidencias", [])])
            evloc[e["id"]] = locator(Path(e["arquivo"]).name, doc_sha256=e.get("sha256", ""), where=e["id"],
                                     snippet=e.get("url", ""), method=e.get("metodo") or e.get("tipo", ""))
    else:
        warns.append("sem evidence_log.jsonl: entidades e achados irão sem evidência ligada (natureza nao_verificado)")

    def ev_refs(ids) -> list[str]:
        out = []
        for i in ids:
            if i in evmap:
                out.append(evmap[i])
            elif i:
                warns.append(f"{i} citado mas ausente do log de evidências (não ligado no bundle)")
        return list(dict.fromkeys(out))

    def split(v) -> list[str]:
        items = v if isinstance(v, list) else re.split(r"[;,]", str(v or ""))
        return [str(x).strip() for x in items if str(x).strip()]

    # grafo: nós e arestas
    nodes = read_csv_dicts(no_p) if no_p and no_p.exists() else []
    edges = read_csv_dicts(ed_p) if ed_p and ed_p.exists() else []
    if edges and not nodes:
        warns.append("arestas sem arquivo de nós: nós citados viram entidades 'outro'")
    node_sha = sha256_file(no_p) if no_p and no_p.exists() else ""
    edge_sha = sha256_file(ed_p) if ed_p and ed_p.exists() else ""
    incident: dict[str, list[str]] = {}
    for e in edges:
        for end in (e.get("source", "").strip(), e.get("target", "").strip()):
            incident.setdefault(end, []).extend(split(e.get("evidence_id")))
    entref: dict[str, str] = {}
    by_id = {n.get("id", "").strip(): n for n in nodes if n.get("id", "").strip()}
    for nid in list(by_id) + [x for x in incident if x not in by_id]:
        n = by_id.get(nid, {"id": nid, "label": nid, "type": "desconhecido"})
        ntype = (n.get("type") or "desconhecido").strip().lower()
        etype = NODE_TYPE.get(ntype, "outro")
        label = (n.get("label") or nid).strip()
        plat = (n.get("platform") or "").strip().lower()
        evs = ev_refs(dict.fromkeys(incident.get(nid, [])))
        prov = [evloc[i] for i in dict.fromkeys(incident.get(nid, [])) if i in evloc] or [
            locator(no_p.name if no_p else "grafo", doc_sha256=node_sha, where=f"nó {nid}", method="socmint/build_graph")]
        idents = {}
        if etype == "perfil_social" and plat and handle_of(label):
            idents["perfil"] = f"{plat}:{handle_of(label)}"
        elif ntype in IDENT_KIND:
            idents[IDENT_KIND[ntype]] = label
        attrs = {"tipo_socmint": ntype, "plataforma": plat, "no_socmint": nid}
        if n.get("notes"):
            attrs["notas"] = n["notes"]
        entref[nid] = b.entity(etype, label, idents, attrs, nature="observado" if evs else "nao_verificado",
                               confidence="media", source_ids=[s_case], evidence_ids=evs, provenance=prov)
        if etype == "perfil_social" and plat and handle_of(label):
            u = b.entity("usuario", f"@{handle_of(label)}", {"username": handle_of(label)}, nature="observado" if evs else "nao_verificado",
                         source_ids=[s_case], evidence_ids=evs, provenance=prov)
            b.rel(u, "usado em", entref[nid], "observado" if evs else "nao_verificado", "alta", source_ids=[s_case], evidence_ids=evs, provenance=prov)
    for i, e in enumerate(edges, start=2):
        s, t = e.get("source", "").strip(), e.get("target", "").strip()
        if s not in entref or t not in entref:
            continue
        kind = (e.get("tipo") or "associacao").strip().lower().replace("ç", "c").replace("ã", "a")
        ids = split(e.get("evidence_id"))
        evs = ev_refs(ids)
        prov = [evloc[x] for x in ids if x in evloc] + [locator(ed_p.name if ed_p else "arestas", doc_sha256=edge_sha, line=i,
                                                                  where=f"aresta {s}→{t}", snippet=e.get("relation", ""))]
        conf = CONF.get((e.get("confidence") or "").strip().lower(), "baixa")
        attrs = {"tipo_vinculo": kind, "relacao": e.get("relation", ""), "forca": e.get("confidence", "")}
        if kind == "identidade":
            b.rel(entref[s], "possível mesmo titular", entref[t], "correlacao", conf, attributes=attrs, source_ids=[s_case],
                  evidence_ids=evs, provenance=prov, notes="candidato a mesma pessoa/operador; ver regra de corroboração (ref. 06)",
                  directed=False)
        elif kind == "imitacao":
            b.rel(entref[s], "imita", entref[t], "inferencia", conf, attributes=attrs, source_ids=[s_case], evidence_ids=evs,
                  provenance=prov, notes="usa marca ou identidade do destino; não é vínculo entre o imitador e a vítima")
        else:
            b.rel(entref[s], (e.get("relation") or "associado a").strip(), entref[t], "observado" if evs else "nao_verificado", conf,
                  attributes=attrs, source_ids=[s_case], evidence_ids=evs, provenance=prov)

    # achados
    findings_out = []
    fi = read_csv_dicts(fi_p) if fi_p and fi_p.exists() else []
    for f in fi:
        tipo = (f.get("tipo") or "").strip().lower()
        ids = split(f.get("evidencias"))
        evs = ev_refs(ids)
        rec = {k: f.get(k, "") for k in ("id", "tipo", "afirmacao", "evidencias", "admiralty_fonte", "admiralty_info", "confianca", "data_utc", "notas")}
        findings_out.append(rec)
        if tipo.startswith("desconh"):
            continue
        b.observation(f.get("afirmacao", ""), evidence_id=evs[0] if evs else "", source_id=s_case,
                      method="socmint", nature="observado" if tipo.startswith("observ") and evs else "inferencia" if tipo.startswith("infer") else "nao_verificado",
                      confidence=CONF.get((f.get("confianca") or "").strip().lower(), f.get("confianca") or None),
                      provenance=[evloc[x] for x in ids if x in evloc], observed_at=f.get("data_utc", ""), evidence_ids=evs,
                      reliability=(f.get("admiralty_fonte") or "").upper(), credibility=f.get("admiralty_info", ""),
                      finding_id=f.get("id", ""), notes=f.get("notas", ""))

    # hipóteses
    for h in case.get("hipoteses", []):
        if not h.get("texto"):
            continue
        status = HYP_STATUS.get((h.get("status") or "aberta").strip().lower(), "em_analise")
        b.hypothesis(f"{h.get('id', '')}: {h['texto']}".strip(": "), supporting=ev_refs(split(h.get("evidencias_favor"))),
                     contradicting=ev_refs(split(h.get("evidencias_contra"))), status=status,
                     criteria={"confirmaria_se": h.get("confirma", ""), "refutaria_se": h.get("refuta", "")}, hypothesis_id=h.get("id", ""))

    # linha do tempo
    tl = read_csv_dicts(tl_p) if tl_p and tl_p.exists() else []
    for i, r in enumerate(tl, start=2):
        ids = split(r.get("evidencia"))
        evs = ev_refs(ids)
        etype = "criacao_conta" if re.search(r"cria[çc][ãa]o da conta|createTime", r.get("evento", ""), re.I) else "evento_digital"
        b.event(r.get("evento", ""), etype, start=r.get("data_utc", ""), nature="observado" if evs else "nao_verificado",
                source_ids=[s_case], evidence_ids=evs, provenance=[evloc[x] for x in ids if x in evloc] or [
                    locator(tl_p.name, line=i, snippet=r.get("evento", ""), method="timeline")], fonte=r.get("fonte", ""))

    # pivôs como consultas OSINT
    pv = read_csv_dicts(pv_p) if pv_p and pv_p.exists() else []
    for r in pv:
        evs = ev_refs(split(r.get("evidencia")))
        b.osint(f"{r.get('de', '')} → {r.get('para', '')}", r.get("tecnica") or r.get("técnica") or "não informada",
                r.get("resultado", ""), evidence_id=evs[0] if evs else "", date=r.get("data_utc", ""),
                url=r.get("fonte_url") or r.get("fonte", ""), forca=r.get("forca", ""), pivo_id=r.get("id", ""))

    # análise de export (reproduzível)
    if an_p and an_p.exists():
        res = json.loads(an_p.read_text(encoding="utf-8-sig"))
        prov = res.get("proveniencia", {})
        flagged = {k: v for k, v in res.get("indicadores_por_conta", {}).items() if len(v) >= 2}
        b.analysis("indicadores_de_coordenacao", "analyze_export.py: rajadas, textos repetidos, criação em lote, padrões de username, sobreposição",
                   {"linhas": res.get("linhas"), "contas_distintas": res.get("contas_distintas"), "rajadas": len(res.get("rajadas", [])),
                    "textos_repetidos": len(res.get("textos_repetidos", [])), "lotes_de_criacao": len(res.get("criacao_de_contas", {}).get("lotes_suspeitos", [])),
                    "contas_com_2_ou_mais_indicadores": len(flagged)},
                   confidence="baixa", limitations="Indicadores, não veredito: cada um tem explicação legítima (ref. 07 §7); exports parciais e viés de amostra.",
                   nature="inferencia", tool=prov.get("script", "analyze_export.py"), tool_version=SCRIPTS_VERSION,
                   parameters={**prov.get("parametros", {}), "entradas": prov.get("entradas", [])}, source_ids=[s_case])

    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    b.save(str(out), findings=findings_out, extra={"generated_by": script_tag("to_bundle.py")})
    data = json.loads(out.read_text(encoding="utf-8"))
    print(f"Bundle gravado em {out}: " + ", ".join(f"{k} {v}" for k, v in data["summary"].items()))
    for v in data.get("validation", []):
        print(f"VALIDAÇÃO ({v['level']}): {v['message']}")
    for w in dict.fromkeys(warns):
        print("AVISO:", w)
    print("Próximo passo no Investigative Notebook: nb.py import-bundle <caso.json> " + out.name + " --dry-run")
    return 0


if __name__ == "__main__":
    sys.exit(main())
