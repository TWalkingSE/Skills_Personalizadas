#!/usr/bin/env python3
"""Autoteste da skill socmint (offline): roda os scripts com os dados de exemplo e confere os resultados.

Uso:
    python3 scripts/selftest.py            # resumo
    python3 scripts/selftest.py -v         # mostra a saída dos comandos que falharem

Grava só em pasta temporária fora da skill. Rode depois de alterar a skill ou num ambiente novo.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent
EX = SKILL / "assets" / "exemplos"
RESULTS: list[tuple[str, bool, str]] = []


def run(args: list[str], cwd: Path) -> subprocess.CompletedProcess:
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}  # não grava __pycache__ na pasta da skill
    return subprocess.run([sys.executable, str(HERE / args[0]), *args[1:]], cwd=cwd, capture_output=True, text=True, encoding="utf-8", env=env)


def check(name: str, ok: bool, detail: str = "") -> None:
    RESULTS.append((name, bool(ok), detail))


def test_decode(tmp: Path) -> None:
    gabarito = [
        (["discord", "175928847299117063"], "2016-04-30T11:18:25.796Z"),
        (["discord", "80351110224678912"], "2015-08-10T17:26:37.529Z"),
        (["tiktok-video", "7598746068280495381"], "2026-01-24T02:15:38.000Z"),
        (["x", "1585841080431321088"], "2022-10-28T03:49:11.734Z"),
        (["unix", "1340433637"], "2012-06-23T06:40:37.000Z"),
        (["unix", "1700000000"], "2023-11-14T22:13:20.000Z"),
        (["unix", "1700000000000"], "2023-11-14T22:13:20.000Z"),
        (["instagram-media", "2384288897814875714"], "2020-08-26T13:43:27.313Z"),
    ]
    for args, esperado in gabarito:
        r = run(["decode_ids.py", *args, "--json"], tmp)
        utc = json.loads(r.stdout).get("utc") if r.returncode == 0 else None
        check(f"decode_ids {' '.join(args)}", utc == esperado, f"obtido {utc}, esperado {esperado}")
    r = run(["decode_ids.py", "fb-range", "100035049878735", "--json"], tmp)
    check("decode_ids fb-range (ano)", r.returncode == 0 and json.loads(r.stdout).get("ano_provavel") == "2019")
    sp = json.loads(run(["decode_ids.py", "unix", "1516017600", "--json"], tmp).stdout)
    se = json.loads(run(["decode_ids.py", "unix", "1516017600", "--tz", "America/Maceio", "--json"], tmp).stdout)
    check("aviso de horário de verão (SP em jan/2018)", any("horário de verão" in a for a in sp["avisos"]) and not se["avisos"]
          and se["local"].startswith("2018-01-15T09:00"), json.dumps(sp["avisos"], ensure_ascii=False))


def test_evidence(tmp: Path) -> None:
    r = run(["evidence_log.py", "init", "--case-dir", "c0"], tmp)
    check("init sem --tz é recusado", r.returncode != 0)
    r = run(["evidence_log.py", "init", "--case-dir", "c", "--tz", "America/Maceio", "--collector", "Teste"], tmp)
    check("init com --tz", r.returncode == 0, r.stderr)
    (tmp / "a.html").write_text("<html>a</html>", encoding="utf-8")
    (tmp / "b.png").write_bytes(b"png")
    r = run(["evidence_log.py", "add", "--case-dir", "c", "--file", "a.html", "b.png", "--type", "html", "--captured", "2026-05-10 11:00",
             "--tool", "Firefox", "--network", "VPN", "--account", "nenhuma"], tmp)
    log = [json.loads(x) for x in (tmp / "c" / "evidence_log.jsonl").read_text(encoding="utf-8").splitlines() if x.strip()]
    ev = [e for e in log if e.get("registro") == "evidencia"]
    check("add registra hora da coleta convertida para UTC", r.returncode == 0 and ev and ev[0].get("coleta_utc") == "2026-05-10T14:00:00Z", r.stderr)
    check("add registra ambiente e cópia conferida", ev and ev[0].get("ferramenta") == "Firefox" and ev[0].get("copia_conferida") is True)
    check("verify íntegro", run(["evidence_log.py", "verify", "--case-dir", "c"], tmp).returncode == 0)
    alvo = tmp / "c" / ev[1]["arquivo"]
    alvo.write_bytes(b"png alterado")
    check("verify acusa arquivo alterado", run(["evidence_log.py", "verify", "--case-dir", "c"], tmp).returncode == 1)
    r = run(["evidence_log.py", "event", "--case-dir", "c", "--stage", "descarte", "--evidence", "EV-0002", "--who", "Teste"], tmp)
    alvo.unlink()
    check("descarte registrado deixa de cobrar o arquivo", r.returncode == 0 and run(["evidence_log.py", "verify", "--case-dir", "c"], tmp).returncode == 0)
    r = run(["evidence_log.py", "export", "--case-dir", "c", "--format", "sha256sums"], tmp)
    sums = (tmp / "c" / "SHA256SUMS").read_text(encoding="utf-8").strip().splitlines() if r.returncode == 0 else []
    check("export sha256sums (sem a evidência descartada)", len(sums) == 1)
    lines = (tmp / "c" / "evidence_log.jsonl").read_text(encoding="utf-8").splitlines()
    (tmp / "c" / "evidence_log.jsonl").write_text("\n".join(lines[:1] + [lines[1].replace("Firefox", "Chrome")] + lines[2:]) + "\n", encoding="utf-8")
    check("verify acusa linha do log editada", run(["evidence_log.py", "verify", "--case-dir", "c"], tmp).returncode == 1)


def test_graph_and_report(tmp: Path) -> None:
    r = run(["build_graph.py", "--nodes", str(EX / "nos_exemplo.csv"), "--edges", str(EX / "arestas_exemplo.csv"), "--out", "g", "--no-png"], tmp)
    mmd = (tmp / "g" / "grafo.mmd").read_text(encoding="utf-8") if r.returncode == 0 else ""
    check("grafo: aresta de imitação destacada", "imitação:" in mmd and "linkStyle" in mmd)
    check("grafo: manifesto com SHA-256 das entradas", (tmp / "g" / "grafo_manifesto.json").exists())
    common = ["--case", str(EX / "case_exemplo.json"), "--findings", str(EX / "findings_exemplo.csv"), "--graph", str(tmp / "g" / "grafo.mmd")]
    r = run(["make_report.py", *common, "--out", "r", "--format", "md,html", "--redact"], tmp)
    md = (tmp / "r.md").read_text(encoding="utf-8") if r.returncode == 0 else ""
    html = (tmp / "r.html").read_text(encoding="utf-8") if r.returncode == 0 else ""
    check("--redact mascara o grafo", md and "exemplo-mail" not in md and "exemplo-mail" not in html)
    check("hipóteses: critérios separados das evidências", "| Confirmaria se | Refutaria se |" in md)
    check("achados: coluna de notas", "Indicadores, não prova de bots" in md)
    check("metodologia não afirma pivôs sem log", "nenhum log de pivôs" in md)
    check("--strict falha sem log de evidências", run(["make_report.py", *common, "--out", "s", "--strict"], tmp).returncode == 1)
    r = run(["make_report.py", "--case", str(EX / "case_exemplo_policial.json"), "--out", "p"], tmp)
    md = (tmp / "p.md").read_text(encoding="utf-8") if r.returncode == 0 else ""
    check("variante policial (procedimento, quesitos, assinatura)", "| Procedimento |" in md and "Respostas aos quesitos" in md and "Encerramento" in md)


def test_bundle(tmp: Path) -> None:
    d = tmp / "caso"
    run(["evidence_log.py", "init", "--case-dir", "caso", "--tz", "America/Maceio"], tmp)
    (d / "case.json").write_text((EX / "case_exemplo.json").read_text(encoding="utf-8"), encoding="utf-8")
    for i in range(1, 8):
        f = tmp / f"ev{i}.html"
        f.write_text(f"<html>{i}</html>", encoding="utf-8")
        run(["evidence_log.py", "add", "--case-dir", "caso", "--file", str(f), "--type", "html", "--captured", "2026-05-10 12:00"], tmp)
    for src, dst in (("findings_exemplo.csv", "findings.csv"), ("timeline_exemplo.csv", "timeline.csv"), ("pivos_exemplo.csv", "pivos.csv"),
                     ("nos_exemplo.csv", "nos.csv"), ("arestas_exemplo.csv", "arestas.csv")):
        (d / dst).write_text((EX / src).read_text(encoding="utf-8"), encoding="utf-8")
    r = run(["to_bundle.py", "--case-dir", "caso", "--out", "caso/b.bundle.json"], tmp)
    ok = r.returncode == 0
    data = json.loads((d / "b.bundle.json").read_text(encoding="utf-8")) if ok else {}
    erros = [v for v in data.get("validation", []) if v["level"] == "erro"]
    check("to_bundle gera intel-bundle/1.0 válido", ok and data.get("contract") == "intel-bundle/1.0" and not erros, r.stderr or r.stdout)
    ents = [i for i in data.get("items", []) if i["op"] == "entity"]
    perfis = [e for e in ents if e["type"] == "perfil_social" and e.get("identifiers", {}).get("perfil")]
    usuarios = [e for e in ents if e["type"] == "usuario"]
    check("to_bundle não unifica perfis com o mesmo username", len(perfis) == 4 and len(usuarios) == 1)
    rels = [i for i in data.get("items", []) if i["op"] == "rel"]
    check("to_bundle: imitação como inferência", any(x["type"] == "imita" and x["nature"] == "inferencia" for x in rels))
    (d / "04_Preservacao_Web").joinpath(next(p.name for p in (d / "04_Preservacao_Web").iterdir())).write_text("alterado", encoding="utf-8")
    check("to_bundle recusa evidência alterada", run(["to_bundle.py", "--case-dir", "caso", "--out", "caso/c.bundle.json"], tmp).returncode != 0)


def test_misc(tmp: Path) -> None:
    r = run(["name_variants.py", "--name", "José Carlos dos Santos Júnior", "--no-emails", "--max", "40"], tmp)
    users = [x for x in r.stdout.splitlines() if x and not x.startswith("#")]
    check("name_variants: agnome não vira sobrenome", users[:1] == ["josesantos"] and "josecarlos" in users, " ".join(users[:6]))
    r = run(["name_variants.py", "--name", "Maria da Silva Souza", "--domains", "gmail.com", "--max", "200"], tmp)
    mails = [x for x in r.stdout.splitlines() if "@" in x and not x.startswith("#")]
    check("name_variants: só e-mails Gmail válidos e sem duplicata por ponto",
          mails and all("_" not in m and "-" not in m for m in mails) and len({m.replace(".", "", m.count(".") - 1) for m in mails}) == len(mails))
    r = run(["dork_builder.py", "--platform", "facebook", "--intent", "invite", "--q", "Nome", "--group", "1", "--format", "txt"], tmp)
    check("dork_builder: intenção antiga renomeada", "site:facebook.com/groups/1/posts" in r.stdout)
    r = run(["dork_builder.py", "--platform", "x", "--intent", "username", "--q", "a", "--after", "2026-01-01", "--format", "txt"], tmp)
    check("dork_builder: janela de datas", "since:2026-01-01" in r.stdout and "after:2026-01-01" in r.stdout)
    r = run(["dork_builder.py", "--platform", "kwai", "--q", "a"], tmp)
    check("dork_builder: kwai e sem Yandex por padrão", r.returncode == 0 and "kwai.com" in r.stdout and "yandex" not in r.stdout)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(HERE))
    import analyze_export  # noqa: E402
    check("analyze_export: nome comum não é 'aleatório'", not any("aleatória" in f for f in analyze_export.username_flags("marcelo_silva4846"))
          and any("aleatória" in f for f in analyze_export.username_flags("xk7qzpl9mwd2rt")))
    r = run(["analyze_export.py", str(EX / "comentarios_sinteticos.csv"), "--platform", "tiktok", "--out", "a"], tmp)
    res = json.loads((tmp / "a" / "resumo.json").read_text(encoding="utf-8")) if r.returncode == 0 else {}
    check("analyze_export: rajada e proveniência no resumo", res.get("rajadas") and res.get("proveniencia", {}).get("entradas"))
    r = run(["build_graph.py", "--nodes", str(EX / "nos_exemplo.csv"), "--edges", str(EX / "arestas_exemplo.csv"), "--out", str(SKILL / "nao_gravar")], tmp)
    check("scripts recusam gravar dentro da pasta da skill", r.returncode != 0 and not (SKILL / "nao_gravar").exists())


def main() -> int:
    ap = argparse.ArgumentParser(description="Autoteste da skill socmint.")
    ap.add_argument("-v", "--verbose", action="store_true")
    a = ap.parse_args()
    for test in (test_decode, test_evidence, test_graph_and_report, test_bundle, test_misc):
        with tempfile.TemporaryDirectory(prefix="socmint-selftest-") as t:
            try:
                test(Path(t))
            except Exception as exc:  # um teste quebrado não derruba os outros
                check(f"{test.__name__} (exceção)", False, repr(exc))
    fails = [r for r in RESULTS if not r[1]]
    for name, ok, detail in RESULTS:
        print(f"{'OK    ' if ok else 'FALHA '} {name}" + (f"  — {detail}" if (not ok and a.verbose and detail) else ""))
    print(f"\n{len(RESULTS) - len(fails)}/{len(RESULTS)} verificações passaram.")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
