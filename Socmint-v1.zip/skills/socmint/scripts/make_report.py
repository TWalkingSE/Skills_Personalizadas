#!/usr/bin/env python3
"""Monta o relatório ODPAR (Markdown, HTML autocontido e DOCX opcional) a partir dos arquivos do caso.

Exemplos:
    python3 scripts/make_report.py --case-dir caso-001 --out caso-001/06_Relatorios_e_Mapas/relatorio --format md,html
    python3 scripts/make_report.py --case case.json --findings findings.csv --evidence evidence_log.jsonl \
        --timeline timeline.csv --graph grafo.mmd --pivots pivos.csv --out relatorio --format md,html,docx --redact

O texto narrativo (resumo, conclusões, recomendações, limitações) vem do bloco "relatorio" do case.json;
tabelas vêm do evidence_log.jsonl, findings.csv e timeline.csv. O script valida referências (achado → evidência,
hipótese → evidência), verifica a cadeia de hashes e avisa o que falta. A seção de metodologia descreve só o que
os arquivos do caso registram (evidências, camadas de preservação, pivôs, análises); o que faltar fica marcado.
Hipóteses: "confirma"/"refuta" são critérios; as evidências ligadas vêm de "evidencias_favor"/"evidencias_contra".
Com --redact mascara e-mails, telefones e CPF em todo o texto, inclusive no diagrama do grafo; a imagem PNG do
grafo é omitida porque texto dentro de imagem não pode ser mascarado. Com --strict, falha (código 1) se houver
problema de integridade, referência quebrada, Observação sem evidência ou falta do log de evidências quando ele
é exigido (nível 2 ou 3, ou achados que citam evidências).
Variante policial (contexto "policial" no case.json ou --variante policial): título de relatório de investigação,
procedimento/unidade/autoridade na capa, respostas aos quesitos ("quesitos" no case.json) e bloco de assinatura.
"""
from __future__ import annotations

import argparse
import base64
import html
import json
import re
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from _common import DEFAULT_TZ, die, ensure_utf8_stdout, guard_output, input_manifest, iso_ms, parse_tz, read_csv_dicts, script_tag, utc_now_iso
from evidence_log import check, custody_events, discarded_ids, load_log

PENDING = "[A PREENCHER]"
EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")
PHONE_RE = re.compile(
    r"(?<![\w])(?:\+\d{1,3}[\s.-]?\(?\d{2}\)?[\s.-]?\d{4,5}[\s.-]?\d{4}|\(\d{2}\)\s?\d{4,5}[\s.-]?\d{4}|\d{2}\s\d{4,5}[\s.-]\d{4}|\d{4,5}-\d{4})(?![\w])"
)
CPF_RE = re.compile(r"(?<![\w])\d{3}\.\d{3}\.\d{3}-\d{2}(?![\w])")
LONG_ID_RE = re.compile(r"(?<![\w])\d{15,}(?![\w])")


# ----------------------------------------------------------------------------- redação

def make_redactor(enabled: bool, ids: bool):
    if not enabled:
        return lambda s: s

    def mask_email(m: re.Match) -> str:
        local, domain = m.group(0).split("@", 1)
        name, _, tld = domain.rpartition(".")
        return f"{local[:1]}***@{name[:1]}***.{tld}"

    def mask_keep_last(n: int):
        def f(m: re.Match) -> str:
            s = m.group(0)
            idx = [i for i, c in enumerate(s) if c.isdigit()]
            keep = set(idx[-n:])
            return "".join(("*" if c.isdigit() and i not in keep else c) for i, c in enumerate(s))
        return f

    def red(text: str) -> str:
        text = EMAIL_RE.sub(mask_email, text)
        text = CPF_RE.sub(mask_keep_last(2), text)
        text = PHONE_RE.sub(mask_keep_last(2), text)
        if ids:
            text = LONG_ID_RE.sub(lambda m: m.group(0)[:3] + "…" + m.group(0)[-2:], text)
        return text

    return red


# ----------------------------------------------------------------------------- dados

def load_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        die(f"não foi possível ler {path}: {exc}")
        return {}


def parse_iso(value: str) -> datetime | None:
    v = (value or "").strip()
    if not v:
        return None
    try:
        dt = datetime.fromisoformat(v.replace("Z", "+00:00").replace("z", "+00:00"))
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def fmt_dual(value: str, tz, tz_label: str) -> str:
    dt = parse_iso(value)
    if dt is None:
        return value or ""
    local = dt.astimezone(tz).strftime("%Y-%m-%d %H:%M:%S")
    return f"{iso_ms(dt.astimezone(timezone.utc))[:19]}Z ({local} {tz_label.split(' ')[0]})"


def resolve_inputs(a: argparse.Namespace) -> dict:
    d = Path(a.case_dir) if a.case_dir else None

    def pick(explicit: str | None, *candidates: str) -> Path | None:
        if explicit:
            return Path(explicit)
        if d:
            for c in candidates:
                if (d / c).exists():
                    return d / c
        return None

    case_p = pick(a.case, "case.json")
    if case_p is None or not case_p.exists():
        die("informe --case case.json ou --case-dir com um case.json.")
    return {
        "case": case_p,
        "findings": pick(a.findings, "findings.csv", "05_Analises/findings.csv", "06_Relatorios_e_Mapas/findings.csv"),
        "evidence": pick(a.evidence, "evidence_log.jsonl"),
        "timeline": pick(a.timeline, "timeline.csv", "05_Analises/timeline.csv", "06_Relatorios_e_Mapas/timeline.csv"),
        "graph": pick(a.graph, "grafo.mmd", "grafo/grafo.mmd", "06_Relatorios_e_Mapas/grafo.mmd", "06_Relatorios_e_Mapas/grafo/grafo.mmd"),
        "graph_png": pick(a.graph_png, "grafo.png", "grafo/grafo.png", "06_Relatorios_e_Mapas/grafo.png", "06_Relatorios_e_Mapas/grafo/grafo.png"),
        "pivots": pick(a.pivots, "pivos.csv", "03_Pivotagem_Social/pivos.csv"),
    }


# Camadas de preservação da ref. 08 §2, reconhecidas pelo tipo e pela extensão registrados no log.
LAYERS = {
    1: "1 URL e data/hora UTC",
    2: "2 captura de tela",
    3: "3 HTML/JSON fonte",
    4: "4 página completa (PDF/WARC/SingleFile)",
    5: "5 mídia original",
    6: "6 arquivo público (Wayback e similares)",
    7: "7 ata notarial",
}
IMG_EXT = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff"}


def evidence_layers(e: dict) -> set[int]:
    tipo = (e.get("tipo") or "").lower()
    ext = Path(e.get("arquivo") or "").suffix.lower()
    url = (e.get("url") or "").lower()
    found: set[int] = set()
    if url:
        found.add(1)
    if any(h in url for h in ("web.archive.org", "archive.org/web", "archive.ph", "archive.today", "archive.is")):
        found.add(6)
    # o tipo declarado no log tem precedência; a extensão só decide quando o tipo não diz a camada
    if tipo in ("ata", "ata_notarial", "ata-notarial"):
        found.add(7)
    elif tipo in ("captura", "screenshot", "print"):
        found.add(2)
    elif tipo in ("html", "json", "har"):
        found.add(3)
    elif tipo in ("warc", "wacz", "pagina"):
        found.add(4)
    elif tipo in ("midia", "imagem", "video", "audio", "documento"):
        found.add(5)
    elif ext in (".html", ".htm", ".json", ".har"):
        found.add(3)
    elif ext in (".warc", ".wacz", ".mhtml", ".mht"):
        found.add(4)
    elif tipo in ("perfil", "post") and ext in IMG_EXT:
        found.add(2)
    return found


def split_refs(value) -> list[str]:
    if isinstance(value, list):
        items = [str(x) for x in value]
    else:
        items = re.split(r"[;,]", str(value or ""))
    return [x.strip() for x in items if x.strip()]


# ----------------------------------------------------------------------------- blocos

def build_blocks(a: argparse.Namespace, files: dict) -> tuple[list[tuple], list[str], list[str]]:
    warns: list[str] = []
    serious: list[str] = []  # avisos que fazem --strict falhar

    def flag(msg: str, grave: bool = False) -> None:
        warns.append(msg)
        if grave:
            serious.append(msg)

    case = load_json(files["case"])
    if not case.get("fuso"):
        warns.append(f"case.json sem 'fuso': horários locais exibidos em {DEFAULT_TZ}; informe o fuso IANA da localidade do fato (ex.: America/Maceio para SE/AL)")
    tz, tz_label = parse_tz(case.get("fuso") or DEFAULT_TZ)
    try:
        nivel = int(case.get("nivel") or 0)
    except (TypeError, ValueError):
        nivel = 0
    gate, rel = case.get("gate", {}), case.get("relatorio", {})
    escopo, opsec, ret = case.get("escopo", {}), case.get("opsec", {}), case.get("retencao", {})
    title = a.title or case.get("titulo") or "Relatório de investigação SOCMINT"
    policial = a.variante == "policial" or (a.variante == "auto" and (case.get("contexto") or "").strip().lower() == "policial")
    proc = case.get("procedimento") or {}
    if policial:
        B: list[tuple] = [("h", 1, f"Relatório de Investigação — Análise de Fontes Abertas em Redes Sociais (SOCMINT) — {title}")]
    else:
        B = [("h", 1, f"Relatório de investigação SOCMINT — {title}")]

    # evidências e verificação
    entries = load_log(files["evidence"]) if files["evidence"] and files["evidence"].exists() else []
    evid = [e for e in entries if e.get("registro") == "evidencia"]
    ev_ids = {e["id"] for e in evid}
    chain_msg, final_hash = "log de evidências não fornecido", ""
    custody = custody_events(entries)
    gone = discarded_ids(entries)
    if entries:
        root = files["evidence"].parent
        ok, problems = check(root, entries, a.expect_last)
        final_hash = entries[-1]["entry_hash"]
        chain_bad = [p for p in problems if p.startswith("linha")]
        missing = [p for p in problems if "AUSENTE" in p]
        changed = [p for p in problems if "ALTERADO" in p]
        tail_bad = [p for p in problems if p.startswith("hash final")]
        if ok:
            chain_msg = (f"ÍNTEGRO: cadeia de hashes e {len(evid) - len(gone & ev_ids)} arquivo(s) conferem (verificado em {utc_now_iso()})"
                         + ("; hash final confere com o valor guardado fora do log" if a.expect_last else ""))
        else:
            parts = []
            if chain_bad:
                parts.append("cadeia QUEBRADA")
            if tail_bad:
                parts.append("hash final DIFERENTE do valor guardado fora do log (linhas finais removidas ou acrescentadas)")
            if changed:
                parts.append(f"{len(changed)} arquivo(s) ALTERADO(S)")
            if missing:
                parts.append(f"{len(missing)} arquivo(s) não encontrado(s) neste local")
            chain_msg = "ATENÇÃO: " + "; ".join(parts)
            flag("verificação de evidências: " + chain_msg, grave=bool(chain_bad or changed or tail_bad))
        if nivel >= 3 and not a.expect_last:
            warns.append("nível 3: informe --expect-last com o hash final da cadeia guardado fora do log (ata, despacho, carimbo do tempo)")
        sem_coleta = [e["id"] for e in evid if not e.get("coleta_utc")]
        if sem_coleta:
            warns.append(f"{len(sem_coleta)} evidência(s) sem hora da coleta (--captured do evidence_log): a tabela mostra a hora do registro no log")

    meta = [
        ["ID do caso", case.get("id_caso", PENDING)],
        ["Versão / data (UTC)", f"1.0 / {utc_now_iso()}"],
        ["Fuso do caso", tz_label],
        ["Autor / coletor", case.get("coletor") or PENDING],
        ["Solicitante", case.get("solicitante") or "—"],
        ["Contexto", case.get("contexto") or PENDING],
        ["Classificação", case.get("classificacao") or PENDING],
        ["Nível de profundidade", {1: "1 Triagem", 2: "2 Padrão", 3: "3 Formal"}.get(case.get("nivel"), str(case.get("nivel", "")))],
    ]
    if policial:
        tipo_proc = (proc.get("tipo") or "").strip()
        tipo_proc = "" if "|" in tipo_proc else tipo_proc  # placeholder do modelo
        meta[1:1] = [
            ["Procedimento", f"{tipo_proc} {proc.get('numero')}".strip() if proc.get("numero") else PENDING],
            ["Unidade", proc.get("unidade") or PENDING],
            ["Autoridade", proc.get("autoridade") or PENDING],
            ["Instaurado em", proc.get("instaurado_em") or "—"],
        ]
    B.append(("table", ["Campo", "Valor"], meta, []))
    if a.redact:
        B.append(("note", "Versão com dados pessoais mascarados (e-mails, telefones, CPF). Dados completos ficam no anexo restrito do caso."))

    # 1. resumo
    resumo = rel.get("resumo") or ""
    if not resumo:
        warns.append("relatorio.resumo ausente no case.json")
    B += [("h", 2, "1. Resumo executivo"), ("p", resumo or PENDING)]

    # 2. objetivo
    B += [("h", 2, "2. Objetivo e perguntas de investigação"), ("ul", [gate.get("pergunta") or PENDING] + [f"{h.get('id', '')}: {h.get('texto', '')}" for h in case.get("hipoteses", []) if h.get("texto")])]

    # 3. escopo
    scope_items = [
        f"Contexto e autorização: {gate.get('autorizacao') or PENDING}",
        f"Categoria do alvo: {gate.get('categoria_alvo') or PENDING}; modo: {gate.get('modo') or PENDING}; resultado do gate: {gate.get('resultado') or PENDING}",
        f"Base legal: {gate.get('base_legal') or PENDING}",
        f"Minimização: {gate.get('minimizacao') or PENDING}",
    ]
    if gate.get("restricoes"):
        scope_items.append("Restrições: " + "; ".join(gate["restricoes"]))
    if escopo.get("plataformas") or escopo.get("periodo"):
        scope_items.append(f"Plataformas: {', '.join(escopo.get('plataformas', [])) or '—'}; período: {escopo.get('periodo') or '—'}")
    if escopo.get("fora_de_escopo"):
        scope_items.append("Fora de escopo: " + "; ".join(escopo["fora_de_escopo"]))
    scope_items.append(f"Retenção até: {ret.get('ate') or PENDING}; descarte: {ret.get('descarte') or '—'}")
    B += [("h", 2, "3. Escopo e base legal"), ("ul", scope_items)]

    # arquivos do caso usados nas seções seguintes
    findings = read_csv_dicts(files["findings"]) if files["findings"] and files["findings"].exists() else []
    tl = read_csv_dicts(files["timeline"]) if files["timeline"] and files["timeline"].exists() else []
    pivots = read_csv_dicts(files["pivots"]) if files["pivots"] and files["pivots"].exists() else []
    has_graph = bool(files["graph"] and files["graph"].exists())
    hips = [h for h in case.get("hipoteses", []) if h.get("texto")]

    # 4. metodologia: descreve só o que os arquivos do caso registram
    conta = {True: "sim", False: "não"}.get(opsec.get("conta_investigacao"), "não informado")
    organizar = (f"Organizar: {len(hips)} hipótese(s) registrada(s); resultado do gate: {gate.get('resultado') or PENDING}; "
                 f"OPSEC (ambiente: {opsec.get('ambiente') or '—'}; conta de investigação: {conta}; rede: {opsec.get('rede') or '—'}).")
    if evid:
        sha512 = " e SHA-512" if all(e.get("sha512") for e in evid) else ""
        documentar = f"Documentar: {len(evid)} evidência(s) no log com SHA-256{sha512} e hash encadeado; integridade: {chain_msg}."
        layer_count = Counter(n for e in evid for n in evidence_layers(e))
        camadas = ("Camadas de preservação aplicadas (ref. 08 §2): " + "; ".join(f"{LAYERS[n]} ({layer_count[n]})" for n in sorted(layer_count))
                   if layer_count else "Camadas de preservação: não identificadas pelos tipos registrados no log.")
        metodos = Counter(e.get("metodo") for e in evid if e.get("metodo"))
        coleta = ("Métodos de coleta registrados no log: " + ", ".join(f"{m} ({n})" for m, n in metodos.most_common())
                  if metodos else "Métodos de coleta: não registrados no log (opção --method do evidence_log.py).")
        n_hora = sum(1 for e in evid if e.get("coleta_utc"))
        ambiente = Counter(" ".join(x for x in (e.get("ferramenta", ""), e.get("versao_ferramenta", "")) if x) for e in evid if e.get("ferramenta"))
        redes = Counter(e.get("rede") for e in evid if e.get("rede"))
        contas = Counter(e.get("conta") for e in evid if e.get("conta"))
        amb = [f"hora da coleta informada em {n_hora} de {len(evid)}"]
        if ambiente:
            amb.append("ferramentas: " + ", ".join(f"{t} ({n})" for t, n in ambiente.most_common()))
        if redes:
            amb.append("rede: " + ", ".join(f"{t} ({n})" for t, n in redes.most_common()))
        if contas:
            amb.append("conta usada: " + ", ".join(f"{t} ({n})" for t, n in contas.most_common()))
        if custody:
            amb.append(f"{len(custody)} evento(s) de custódia registrado(s)" + (f", {len(gone)} evidência(s) descartada(s)" if gone else ""))
        doc_items = [documentar, camadas, coleta, "Registro da coleta: " + "; ".join(amb) + "."]
    elif entries:
        doc_items = ["Documentar: o log de evidências não tem nenhuma evidência registrada (só o cabeçalho)."]
    else:
        doc_items = ["Documentar: nenhum log de evidências fornecido; as evidências citadas não têm hash registrado neste relatório."]
    if pivots:
        tecnicas = Counter((p.get("tecnica") or p.get("técnica") or "não informada").strip() for p in pivots)
        pivotar = f"Pivotar: {len(pivots)} pivô(s) registrado(s) em {files['pivots'].name} (técnicas: " + ", ".join(f"{t} ({n})" for t, n in tecnicas.most_common()) + ")."
    else:
        pivotar = "Pivotar: nenhum log de pivôs fornecido (ref. 06 §3)."
        if nivel >= 2:
            warns.append("sem log de pivôs (pivos.csv): o nível 2 ou 3 pede log de pivôs (ref. 01 §4)")
    analises = []
    if findings:
        n_adm = sum(1 for f in findings if (f.get("admiralty_fonte") or "").strip() and (f.get("admiralty_info") or "").strip())
        analises.append(f"{len(findings)} achado(s), {n_adm} com avaliação Admiralty")
    if hips:
        n_eval = sum(1 for h in hips if (h.get("status") or "aberta").strip().lower() != "aberta")
        analises.append(f"{n_eval} de {len(hips)} hipótese(s) avaliada(s)")
    if tl:
        analises.append(f"linha do tempo com {len(tl)} evento(s)")
    if has_graph:
        analises.append("mapa de vínculos (grafo)")
    analisar = "Analisar: " + ("; ".join(analises) + "." if analises else "nenhum artefato de análise fornecido.")
    if case.get("ferramentas"):
        ferramentas = "Ferramentas e versões: " + "; ".join(case["ferramentas"])
    else:
        usadas = (["evidence_log.py (log e hashes)"] if entries else []) + (["grafo.mmd (build_graph.py)"] if has_graph else []) + [script_tag("make_report.py") + " (este relatório)"]
        ferramentas = "Ferramentas e versões: " + "; ".join(usadas) + f"; demais ferramentas de coleta e versões: {PENDING} (campo 'ferramentas' do case.json)"
    B += [("h", 2, "4. Metodologia (ODPAR)"), ("ul", [organizar, *doc_items, pivotar, analisar, "Relatar: este documento.", ferramentas])]

    # 5. evidências
    rows = []
    for e in evid:
        desc = " ".join(x for x in (e.get("tipo", ""), e.get("plataforma", ""), "—" if e.get("notas") else "", e.get("notas", "")) if x)
        if e["id"] in gone:
            desc += " (descartada; ver custódia)"
        quando = fmt_dual(e["coleta_utc"], tz, tz_label) if e.get("coleta_utc") else fmt_dual(e.get("utc", ""), tz, tz_label) + " — registro no log; hora da coleta não informada"
        rows.append([e["id"], desc, e.get("url", ""), quando, e.get("sha256", "")])
    B += [("h", 2, "5. Evidências"), ("table", ["ID", "Descrição", "URL", "Coleta (UTC)", "SHA-256"], rows, [4])]
    B.append(("p", f"Verificação de integridade: {chain_msg}." + (f" Hash final da cadeia: {final_hash}" if final_hash else "")))

    # 6. achados
    if not findings:
        warns.append("sem findings.csv: a seção de achados ficará vazia.")
    frows = []
    cited_any = False
    for f in findings:
        refs = split_refs(f.get("evidencias", ""))
        cited_any = cited_any or bool(refs)
        tipo = (f.get("tipo") or "").strip()
        for r in refs:
            if entries and r not in ev_ids:
                flag(f"achado {f.get('id', '?')} cita {r}, que não existe no log de evidências", grave=True)
        if tipo.lower().startswith("observ") and not refs:
            flag(f"achado {f.get('id', '?')} é Observação mas não cita evidência", grave=True)
        if tipo.lower().startswith("infer") and not f.get("confianca"):
            warns.append(f"achado {f.get('id', '?')} é Inferência sem nível de confiança")
        adm = f"{f.get('admiralty_fonte', '')}{f.get('admiralty_info', '')}"
        frows.append([f.get("id", ""), tipo, f.get("afirmacao", ""), ", ".join(refs), adm, f.get("confianca", ""), f.get("notas", "")])
    B += [("h", 2, "6. Achados"), ("table", ["ID", "Tipo", "Afirmação", "Evidências", "Admiralty", "Confiança", "Notas"], frows, [])]
    quesitos = [q for q in case.get("quesitos", []) if (q.get("pergunta") or "").strip()]
    if policial or quesitos:
        qrows = []
        for q in quesitos:
            refs = split_refs(q.get("evidencias"))
            cited_any = cited_any or bool(refs)
            for r in refs:
                if entries and r not in ev_ids:
                    flag(f"quesito {q.get('id', '?')} cita {r}, que não existe no log de evidências", grave=True)
            if not (q.get("resposta") or "").strip():
                warns.append(f"quesito {q.get('id', '?')} sem resposta")
            qrows.append([q.get("id", ""), q.get("pergunta", ""), q.get("resposta") or PENDING, ", ".join(refs) or "—"])
        B.append(("h", 3, "6.1 Respostas aos quesitos"))
        B.append(("table", ["ID", "Quesito", "Resposta", "Evidências"], qrows, []) if qrows else ("p", "Sem quesitos formulados."))
    cited_any = cited_any or any(split_refs(h.get("evidencias_favor")) or split_refs(h.get("evidencias_contra")) for h in case.get("hipoteses", []))
    if not entries:
        exigido = nivel >= 2 or cited_any
        motivo = "achados citam evidências" if cited_any else f"nível {nivel}"
        flag("sem evidence_log.jsonl: a seção de evidências ficará vazia" + (f" e as citações não podem ser conferidas ({motivo})" if exigido else ""), grave=exigido)

    # 7. análise
    B += [("h", 2, "7. Análise"), ("h", 3, "7.1 Linha do tempo")]
    tl.sort(key=lambda r: parse_iso(r.get("data_utc", "")) or datetime.max.replace(tzinfo=timezone.utc))
    B.append(("table", ["Data (UTC)", "Evento", "Evidência"], [[fmt_dual(r.get("data_utc", ""), tz, tz_label), r.get("evento", ""), r.get("evidencia", "")] for r in tl], []))
    B.append(("h", 3, "7.2 Mapa de vínculos"))
    if has_graph:
        B.append(("code", "mermaid", files["graph"].read_text(encoding="utf-8").strip()))
        if files["graph_png"] and files["graph_png"].exists():
            if a.redact:
                B.append(("p", "Imagem do grafo omitida nesta versão mascarada: texto dentro de imagem não pode ser mascarado. O diagrama acima já está mascarado."))
                warns.append("grafo.png não incluído porque --redact está ativo (texto em imagem não é mascarável)")
            else:
                B.append(("img", str(files["graph_png"]), "Mapa de vínculos (grafo.png)"))
    else:
        B.append(("p", "Sem grafo (gere com build_graph.py)."))
    B.append(("h", 3, "7.3 Hipóteses × evidências"))
    hrows = []
    for h in case.get("hipoteses", []):
        favor, contra = split_refs(h.get("evidencias_favor")), split_refs(h.get("evidencias_contra"))
        for r in favor + contra:
            if entries and r not in ev_ids:
                flag(f"hipótese {h.get('id', '?')} cita {r}, que não existe no log de evidências", grave=True)
        status = (h.get("status") or "").strip()
        if h.get("texto") and status.lower() not in ("", "aberta") and not (favor or contra):
            warns.append(f"hipótese {h.get('id', '?')} está '{status}' sem evidências ligadas (evidencias_favor/evidencias_contra no case.json)")
        hrows.append([f"{h.get('id', '')}: {h.get('texto', '')}", h.get("confirma", ""), h.get("refuta", ""),
                      ", ".join(favor) or "—", ", ".join(contra) or "—", status])
    B.append(("table", ["Hipótese", "Confirmaria se", "Refutaria se", "Evidências a favor", "Evidências contra", "Avaliação"], hrows, []))
    B.append(("p", "\"Confirmaria se\" e \"Refutaria se\" são os critérios definidos no planejamento; as colunas de evidências trazem o que foi efetivamente coletado."))

    # 8. conclusões
    B += [("h", 2, "8. Conclusões e recomendações"),
          ("h", 3, "Conclusões (o que as evidências sustentam)"), ("ul", rel.get("conclusoes") or [PENDING]),
          ("h", 3, "O que não foi possível concluir"), ("ul", rel.get("nao_concluido") or [PENDING]),
          ("h", 3, "Recomendações"), ("ul", rel.get("recomendacoes") or [PENDING])]
    for k in ("conclusoes", "nao_concluido", "recomendacoes", "limitacoes"):
        if not rel.get(k):
            warns.append(f"relatorio.{k} ausente no case.json")

    # 9. limitações
    B += [("h", 2, "9. Limitações"), ("ul", rel.get("limitacoes") or [PENDING])]
    if policial:
        ass = case.get("assinatura") or {}
        hoje = datetime.now(timezone.utc).astimezone(tz).strftime("%d/%m/%Y")
        B += [("h", 2, "Encerramento"),
              ("p", f"{ass.get('local') or PENDING}, {hoje}."),
              ("p", "______________________________________"),
              ("p", " — ".join(x for x in (ass.get("nome") or PENDING, ass.get("cargo") or PENDING, f"matrícula {ass['matricula']}" if ass.get("matricula") else PENDING) if x))]

    # 10. anexos
    B += [("h", 2, "10. Anexos"), ("ul", [
        "Log de evidências (evidence_log.jsonl) e verificação de hashes: " + chain_msg,
        "Planilhas e exports (05_Analises)",
        "Glossário: indicadores não são veredito; datas decodificadas de IDs são inferências",
        "Anexo restrito (dados pessoais de terceiros), se houver",
    ])]
    if custody:
        B.append(("h", 3, "Cadeia de custódia"))
        B.append(("table", ["ID", "Quando (UTC)", "Etapa", "Evidências", "Responsável", "Destino", "Notas"],
                  [[c.get("id", ""), fmt_dual(c.get("quando_utc", ""), tz, tz_label), c.get("etapa", ""), ", ".join(c.get("evidencias", [])),
                    c.get("responsavel", ""), c.get("destino", ""), c.get("notas", "")] for c in custody], []))
    manifest = input_manifest({"case.json": files["case"], "evidence_log.jsonl": files["evidence"], "findings.csv": files["findings"],
                               "timeline.csv": files["timeline"], "pivos.csv": files["pivots"], "grafo.mmd": files["graph"]})
    B.append(("h", 3, "Arquivos de entrada deste relatório"))
    B.append(("table", ["Entrada", "Arquivo", "SHA-256"], [[m["entrada"], Path(m["arquivo"]).name, m["sha256"]] for m in manifest], [2]))
    B.append(("p", f"Gerado por {script_tag('make_report.py')} em {utc_now_iso()}. Regerar com as mesmas entradas reproduz as tabelas; "
                   "a data da verificação de integridade muda a cada execução."))
    return B, warns, serious


# ----------------------------------------------------------------------------- renderizadores

def md_cell(s: str) -> str:
    return str(s).replace("|", "\\|").replace("\n", " ").strip()


def to_md(blocks: list[tuple], red) -> str:
    out: list[str] = []
    for b in blocks:
        kind = b[0]
        if kind == "h":
            out += [f"{'#' * b[1]} {red(b[2])}", ""]
        elif kind == "p":
            out += [red(b[1]), ""]
        elif kind == "note":
            out += [f"> {red(b[1])}", ""]
        elif kind == "ul":
            out += [f"- {red(str(i))}" for i in b[1]] + [""]
        elif kind == "table":
            _, headers, rows, code_cols = b
            out.append("| " + " | ".join(headers) + " |")
            out.append("|" + "|".join("---" for _ in headers) + "|")
            for r in rows:
                out.append("| " + " | ".join((f"`{md_cell(red(str(c)))}`" if i in code_cols and c else md_cell(red(str(c)))) for i, c in enumerate(r)) + " |")
            out.append("")
        elif kind == "code":
            out += [f"```{b[1]}", red(b[2]), "```", ""]
        elif kind == "img":
            out += [f"![{b[2]}]({Path(b[1]).name})", ""]
    return "\n".join(out).rstrip() + "\n"


CSS = """body{font-family:Segoe UI,Arial,sans-serif;max-width:980px;margin:2rem auto;padding:0 1rem;line-height:1.5;color:#222}
h1{border-bottom:3px solid #1f4e79;padding-bottom:.3rem}h2{margin-top:2rem;border-bottom:1px solid #ccc}
table{border-collapse:collapse;width:100%;margin:.8rem 0;font-size:.92rem}th,td{border:1px solid #bbb;padding:.35rem .5rem;vertical-align:top}
th{background:#eef3f8;text-align:left}code,pre{font-family:Consolas,monospace;font-size:.85rem}pre{background:#f6f8fa;padding:.8rem;overflow:auto;border:1px solid #ddd}
.note{background:#fff8e1;border-left:4px solid #f0ad00;padding:.5rem .8rem;margin:.8rem 0}img{max-width:100%}"""


def to_html(blocks: list[tuple], red, title: str) -> str:
    e = html.escape
    out = ["<!doctype html>", '<html lang="pt-BR"><head><meta charset="utf-8">', f"<title>{e(red(title))}</title>", f"<style>{CSS}</style></head><body>"]
    in_list = False
    for b in blocks:
        kind = b[0]
        if kind == "h":
            out.append(f"<h{b[1]}>{e(red(b[2]))}</h{b[1]}>")
        elif kind == "p":
            out.append(f"<p>{e(red(b[1]))}</p>")
        elif kind == "note":
            out.append(f'<div class="note">{e(red(b[1]))}</div>')
        elif kind == "ul":
            out.append("<ul>" + "".join(f"<li>{e(red(str(i)))}</li>" for i in b[1]) + "</ul>")
        elif kind == "table":
            _, headers, rows, code_cols = b
            out.append("<table><thead><tr>" + "".join(f"<th>{e(h)}</th>" for h in headers) + "</tr></thead><tbody>")
            for r in rows:
                out.append("<tr>" + "".join(f"<td>{'<code>' if i in code_cols else ''}{e(red(str(c)))}{'</code>' if i in code_cols else ''}</td>" for i, c in enumerate(r)) + "</tr>")
            out.append("</tbody></table>")
        elif kind == "code":
            note = "<p><em>Diagrama em Mermaid: cole em um visualizador Mermaid ou use o PNG, se disponível.</em></p>" if b[1] == "mermaid" else ""
            out.append(f"{note}<pre>{e(red(b[2]))}</pre>")
        elif kind == "img":
            try:
                data = base64.b64encode(Path(b[1]).read_bytes()).decode()
                out.append(f'<figure><img alt="{e(b[2])}" src="data:image/png;base64,{data}"><figcaption>{e(b[2])}</figcaption></figure>')
            except OSError:
                pass
    out.append("</body></html>")
    return "\n".join(out) + "\n"


def to_docx(blocks: list[tuple], red, path: Path) -> str:
    try:
        from docx import Document  # type: ignore
        from docx.shared import Inches, Pt  # type: ignore
    except ImportError:
        return "DOCX não gerado (instale python-docx para habilitar)."
    doc = Document()
    for b in blocks:
        kind = b[0]
        if kind == "h":
            doc.add_heading(red(b[2]), level=min(b[1], 4))
        elif kind == "p":
            doc.add_paragraph(red(b[1]))
        elif kind == "note":
            p = doc.add_paragraph(red(b[1]))
            p.runs[0].italic = True
        elif kind == "ul":
            for i in b[1]:
                doc.add_paragraph(red(str(i)), style="List Bullet")
        elif kind == "table":
            _, headers, rows, _cc = b
            t = doc.add_table(rows=1, cols=len(headers))
            t.style = "Table Grid"
            for i, h in enumerate(headers):
                t.rows[0].cells[i].text = h
                for r in t.rows[0].cells[i].paragraphs[0].runs:
                    r.bold = True
            for r in rows:
                cells = t.add_row().cells
                for i, c in enumerate(r):
                    cells[i].text = red(str(c))
                    for run in cells[i].paragraphs[0].runs:
                        run.font.size = Pt(8)
            doc.add_paragraph()
        elif kind == "code":
            p = doc.add_paragraph()
            run = p.add_run(red(b[2]))
            run.font.name = "Consolas"
            run.font.size = Pt(8)
        elif kind == "img":
            try:
                doc.add_picture(b[1], width=Inches(6))
            except Exception:
                pass
    doc.save(path)
    return f"DOCX gravado em {path}"


def main(argv: list[str] | None = None) -> int:
    ensure_utf8_stdout()
    p = argparse.ArgumentParser(description="Monta o relatório ODPAR a partir dos arquivos do caso.")
    p.add_argument("--case-dir", help="pasta do caso (usa case.json, evidence_log.jsonl, findings.csv, timeline.csv e grafo se existirem)")
    p.add_argument("--case")
    p.add_argument("--findings")
    p.add_argument("--evidence")
    p.add_argument("--timeline")
    p.add_argument("--graph")
    p.add_argument("--graph-png")
    p.add_argument("--out", default="relatorio", help="caminho base de saída (sem extensão)")
    p.add_argument("--format", default="md", help="md, html, docx (vírgula)")
    p.add_argument("--title")
    p.add_argument("--variante", choices=["auto", "padrao", "policial"], default="auto",
                   help="policial: procedimento, autoridade, quesitos e assinatura (auto = policial quando contexto do case.json é 'policial')")
    p.add_argument("--pivots", help="log de pivôs em CSV (ref. 06 §3); com --case-dir procura pivos.csv")
    p.add_argument("--redact", action="store_true", help="mascara e-mails, telefones e CPF (inclusive no diagrama do grafo; omite o PNG do grafo)")
    p.add_argument("--redact-ids", action="store_true", help="com --redact, mascara também IDs numéricos longos (≥15 dígitos)")
    p.add_argument("--strict", action="store_true", help="falha (código 1) com problema de integridade, referência quebrada, Observação sem evidência ou log de evidências ausente quando exigido")
    p.add_argument("--expect-last", help="hash final da cadeia guardado fora do log (detecta remoção das últimas linhas)")
    a = p.parse_args(argv)

    files = resolve_inputs(a)
    blocks, warns, serious = build_blocks(a, files)
    red = make_redactor(a.redact, a.redact_ids)
    guard_output(a.out, "--out")
    base = Path(a.out)
    base.parent.mkdir(parents=True, exist_ok=True)
    title = blocks[0][2]
    fmts = {f.strip().lower() for f in a.format.split(",") if f.strip()}
    for f in sorted(fmts):
        if f == "md":
            (base.with_suffix(".md")).write_text(to_md(blocks, red), encoding="utf-8")
            print(f"Markdown gravado em {base.with_suffix('.md')}")
        elif f == "html":
            (base.with_suffix(".html")).write_text(to_html(blocks, red, title), encoding="utf-8")
            print(f"HTML gravado em {base.with_suffix('.html')}")
        elif f == "docx":
            print(to_docx(blocks, red, base.with_suffix(".docx")))
        else:
            print(f"Formato desconhecido ignorado: {f}")
    pending = sum(str(c).count(PENDING) for b in blocks for c in ([b[1]] if b[0] in ("p", "note") else b[1] if b[0] == "ul" else [x for r in b[2] for x in r] if b[0] == "table" else []))
    if pending:
        warns.append(f"{pending} campo(s) pendente(s) marcado(s) como {PENDING}: preencha case.json (relatorio, gate, retencao) antes de entregar")
    for w in dict.fromkeys(warns):
        print("AVISO (grave):" if w in serious else "AVISO:", w)
    if a.strict and serious:
        print(f"--strict: {len(dict.fromkeys(serious))} aviso(s) grave(s); relatório não está pronto para entrega.")
    return 1 if (a.strict and serious) else 0


if __name__ == "__main__":
    sys.exit(main())
