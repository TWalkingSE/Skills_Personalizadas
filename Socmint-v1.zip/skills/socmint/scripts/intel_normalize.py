"""
intel_normalize.py — Normalização de identificadores compartilhada pelas skills de inteligência.

GERADO a partir de investigative-notebook/scripts/case_model.py (fonte única): os valores
normalizados são idênticos aos do Notebook, o que permite a entity resolution entre skills.
O valor original é sempre preservado. Somente biblioteca padrão.
"""
from __future__ import annotations

import datetime as _dt
import ipaddress
import re
import unicodedata
from typing import Any


def now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def strip_accents(s: str) -> str:
    return "".join(ch for ch in unicodedata.normalize("NFKD", s) if not unicodedata.combining(ch))



# ----------------------------------------------------------------------------
# Normalização (valor original sempre preservado)
# ----------------------------------------------------------------------------

def _digits(s: str) -> str:
    return re.sub(r"\D", "", str(s))


def cpf_is_valid(d: str) -> bool:
    if len(d) != 11 or d == d[0] * 11:
        return False
    for n in (9, 10):
        s = sum(int(d[i]) * (n + 1 - i) for i in range(n))
        dv = (s * 10) % 11 % 10
        if dv != int(d[n]):
            return False
    return True


def cnpj_is_valid(d: str) -> bool:
    if len(d) != 14 or d == d[0] * 14:
        return False
    w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    w2 = [6] + w1
    for w, n in ((w1, 12), (w2, 13)):
        s = sum(int(d[i]) * w[i] for i in range(n))
        dv = 0 if s % 11 < 2 else 11 - s % 11
        if dv != int(d[n]):
            return False
    return True


def normalize(kind: str, value: Any) -> dict:
    """Retorna {original, normalized, valid, note}. Nunca descarta o original."""
    orig = value
    s = "" if value is None else str(value).strip()
    out: dict[str, Any] = {"original": orig, "normalized": s, "valid": None, "note": ""}
    k = strip_accents(kind).lower()
    try:
        if k == "cpf":
            d = _digits(s)
            out["normalized"] = d
            out["valid"] = cpf_is_valid(d)
        elif k == "cnpj":
            d = _digits(s)
            out["normalized"] = d
            out["valid"] = cnpj_is_valid(d)
        elif k in ("telefone", "phone"):
            d = _digits(s)
            if d.startswith("00"):
                d = d[2:]
            if len(d) in (10, 11):          # DDD + número, sem país
                d = "55" + d
            elif len(d) in (12, 13) and d.startswith("0"):  # 0 + operadora? mantém
                out["note"] = "prefixo de operadora não removido"
            out["normalized"] = "+" + d if d else ""
            out["valid"] = 12 <= len(d) <= 13 if d.startswith("55") else 8 <= len(d) <= 15
        elif k in ("email", "e-mail"):
            n = s.lower()
            out["normalized"] = n
            out["valid"] = bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", n))
        elif k == "ip":
            ip = ipaddress.ip_address(s.strip("[]"))
            out["normalized"] = ip.compressed
            out["valid"] = True
            out["note"] = "privado/reservado" if (ip.is_private or ip.is_reserved) else ""
        elif k in ("prefixo_ip", "cidr"):
            net = ipaddress.ip_network(s, strict=False)
            out["normalized"] = net.compressed
            out["valid"] = True
        elif k in ("dominio", "domain"):
            n = s.lower().rstrip(".")
            n = re.sub(r"^https?://", "", n).split("/")[0]
            n = n.replace("[.]", ".")  # refanging de valores defanged
            try:
                n = n.encode("idna").decode("ascii")
            except UnicodeError:
                pass
            out["normalized"] = n
            out["valid"] = bool(re.fullmatch(r"(?=.{1,253}$)([a-z0-9-]{1,63}\.)+[a-z0-9-]{2,63}", n))
        elif k == "url":
            n = s.replace("hxxp", "http").replace("[.]", ".")
            m = re.match(r"^([a-zA-Z][a-zA-Z0-9+.-]*)://([^/]+)(.*)$", n)
            if m:
                n = f"{m.group(1).lower()}://{m.group(2).lower()}{m.group(3)}"
            out["normalized"] = n
            out["valid"] = bool(m)
        elif k in ("placa", "veiculo"):
            n = re.sub(r"[^A-Z0-9]", "", strip_accents(s).upper())
            out["normalized"] = n
            if re.fullmatch(r"[A-Z]{3}[0-9][A-Z][0-9]{2}", n):
                out["valid"], out["note"] = True, "padrão Mercosul"
            elif re.fullmatch(r"[A-Z]{3}[0-9]{4}", n):
                out["valid"], out["note"] = True, "padrão anterior (pré-Mercosul)"
            else:
                out["valid"] = False
        elif k in ("nome", "name", "pessoa", "empresa"):
            n = strip_accents(s).upper()
            n = re.sub(r"[^A-Z0-9 ]", " ", n)
            out["normalized"] = re.sub(r"\s+", " ", n).strip()
            out["valid"] = bool(out["normalized"])
        elif k in ("endereco", "address"):
            n = strip_accents(s).upper()
            for a, b in [(r"\bR\.?\s", "RUA "), (r"\bAV\.?\s", "AVENIDA "), (r"\bTRAV\.?\s", "TRAVESSA "),
                         (r"\bN[º°O]\.?\s*", "N "), (r"\bAPTO?\.?\s", "APARTAMENTO ")]:
                n = re.sub(a, b, n)
            n = re.sub(r"[^A-Z0-9 ,\-]", " ", n)
            out["normalized"] = re.sub(r"\s+", " ", n).strip()
            out["valid"] = bool(out["normalized"])
        elif k in ("data", "date", "datetime"):
            iso, precision = parse_date(s)
            out["normalized"] = iso
            out["valid"] = iso is not None
            out["note"] = precision
        elif k in ("valor", "money", "moeda"):
            out["normalized"] = parse_money(s)
            out["valid"] = out["normalized"] is not None
        elif k in ("imei",):
            d = _digits(s)
            out["normalized"] = d
            out["valid"] = len(d) in (14, 15, 16) and (len(d) != 15 or _luhn(d))
        elif k in ("mac",):
            h = re.sub(r"[^0-9a-fA-F]", "", s).lower()
            out["normalized"] = ":".join(h[i:i + 2] for i in range(0, len(h), 2))
            out["valid"] = len(h) == 12
        elif k in ("asn",):
            d = _digits(s)
            out["normalized"] = f"AS{d}" if d else ""
            out["valid"] = bool(d)
        elif k in ("sha256", "sha1", "md5", "sha512", "hash"):
            h = re.sub(r"[^0-9a-fA-F]", "", s).lower()
            lens = {"md5": 32, "sha1": 40, "sha256": 64, "sha512": 128}
            out["normalized"] = h
            out["valid"] = len(h) == lens[k] if k in lens else len(h) in lens.values()
            if k == "hash" and out["valid"]:
                out["note"] = {32: "md5", 40: "sha1", 64: "sha256", 128: "sha512"}[len(h)]
        elif k in ("username", "usuario", "perfil_social"):
            n = s.strip().lstrip("@").lower()
            n = re.sub(r"^https?://(www\.)?[^/]+/(@)?", "", n).strip("/")
            out["normalized"] = n
            out["valid"] = bool(re.fullmatch(r"[a-z0-9._\-]{1,64}", n))
        elif k in ("conta_bancaria", "conta"):
            # chave composta banco|agência|conta(+DV); '?' marca parte desconhecida
            t = strip_accents(s).lower()
            def grab(pat):
                m = re.search(pat, t)
                return re.sub(r"\D", "", m.group(1)) if m else ""
            banco = grab(r"(?:banco|bco|compe)\s*[:#n.o]*\s*(\d{3})")
            ag = grab(r"(?:ag(?:encia)?|ag\.)\s*[:#n.o]*\s*(\d{3,5}(?:-?\d)?)")
            cc = grab(r"(?:c/?c|conta(?:\s+corrente|\s+poupanca|\s+pagamento)?|cp)\s*[:#n.o]*\s*(\d[\d.\-]{2,15}[0-9x]?)")
            if not cc:
                cc = re.sub(r"\D", "", t) if re.fullmatch(r"[\d.\- x]+", t) else ""
            out["normalized"] = f"{banco or '?'}|{ag.lstrip('0') or '?'}|{cc.lstrip('0') or '?'}"
            out["valid"] = bool(cc)
            out["note"] = "parcial" if "?" in out["normalized"] else ""
        elif k in ("processo", "cnj"):
            d = _digits(s)
            out["normalized"] = d
            out["valid"] = len(d) == 20 and int(d[:7] + d[9:] + d[7:9]) % 97 == 1
            out["note"] = "numeração única CNJ" if out["valid"] else "fora do padrão CNJ"
        elif k in ("pix",):
            # chave PIX pode ser CPF, CNPJ, telefone, e-mail ou aleatória
            if "@" in s:
                return {**normalize("email", s), "note": "chave PIX tipo e-mail"}
            d = _digits(s)
            if re.fullmatch(r"[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}", s):
                out.update(normalized=s.lower(), valid=True, note="chave PIX aleatória (EVP)")
            elif len(d) == 11 and cpf_is_valid(d):
                out.update(normalized=d, valid=True, note="chave PIX tipo CPF (ou telefone sem DDI)")
            elif len(d) == 14 and cnpj_is_valid(d):
                out.update(normalized=d, valid=True, note="chave PIX tipo CNPJ")
            elif s.startswith("+") or len(d) in (12, 13):
                return {**normalize("telefone", s), "note": "chave PIX tipo telefone"}
            else:
                out["valid"] = False
    except (ValueError, TypeError) as exc:
        out["valid"] = False
        out["note"] = f"falha na normalização: {exc}"
    return out


def _luhn(d: str) -> bool:
    total = 0
    for i, ch in enumerate(reversed(d)):
        n = int(ch)
        if i % 2:
            n *= 2
            n -= 9 if n > 9 else 0
        total += n
    return total % 10 == 0


_DATE_PATTERNS = [
    (r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?", "exata"),
    (r"^(\d{2})/(\d{2})/(\d{4})[ ,]+(\d{2}):(\d{2})(?::(\d{2}))?", "exata"),
    (r"^(\d{4})-(\d{2})-(\d{2})$", "dia"),
    (r"^(\d{2})/(\d{2})/(\d{4})$", "dia"),
    (r"^(\d{2})/(\d{4})$", "mes"),
    (r"^(\d{4})-(\d{2})$", "mes"),
    (r"^(\d{4})$", "ano"),
]


def parse_date(s: str) -> tuple[str | None, str]:
    """Interpreta datas BR/ISO. Retorna (ISO, precisão). Precisão: exata|dia|mes|ano|aproximada|desconhecida.
    Prefixos 'aprox.', 'c.', '~' marcam data aproximada."""
    if s is None:
        return None, "desconhecida"
    raw = str(s).strip()
    if not raw or raw.lower() in ("?", "desconhecida", "n/d", "nd", "null", "none"):
        return None, "desconhecida"
    approx = bool(re.match(r"^(aprox\.?|aproximadamente|c\.|~|circa)\s*", raw, re.I))
    raw = re.sub(r"^(aprox\.?|aproximadamente|c\.|~|circa)\s*", "", raw, flags=re.I)
    for pat, prec in _DATE_PATTERNS:
        m = re.match(pat, raw)
        if not m:
            continue
        g = m.groups()
        try:
            if pat.startswith(r"^(\d{4})-(\d{2})-(\d{2})[T"):
                dt = _dt.datetime(int(g[0]), int(g[1]), int(g[2]), int(g[3]), int(g[4]), int(g[5] or 0))
                iso = dt.isoformat()
                tz = re.search(r"(Z|[+-]\d{2}:?\d{2})$", raw)
                if tz:
                    iso += "Z" if tz.group(1) == "Z" else tz.group(1)
            elif pat.startswith(r"^(\d{2})/(\d{2})/(\d{4})[ ,]"):
                iso = _dt.datetime(int(g[2]), int(g[1]), int(g[0]), int(g[3]), int(g[4]), int(g[5] or 0)).isoformat()
            elif prec == "dia" and "-" in pat:
                iso = _dt.date(int(g[0]), int(g[1]), int(g[2])).isoformat()
            elif prec == "dia":
                iso = _dt.date(int(g[2]), int(g[1]), int(g[0])).isoformat()
            elif prec == "mes" and "/" in pat:
                iso = f"{int(g[1]):04d}-{int(g[0]):02d}"
            elif prec == "mes":
                iso = f"{int(g[0]):04d}-{int(g[1]):02d}"
            else:
                iso = f"{int(g[0]):04d}"
        except ValueError:
            return None, "desconhecida"
        return iso, ("aproximada" if approx else prec)
    return None, "desconhecida"


def to_datetime(iso: str | None) -> _dt.datetime | None:
    """Converte ISO (inclusive parcial: AAAA, AAAA-MM) para datetime ingênuo (início do período)."""
    if not iso:
        return None
    s = str(iso)
    try:
        if re.fullmatch(r"\d{4}", s):
            return _dt.datetime(int(s), 1, 1)
        if re.fullmatch(r"\d{4}-\d{2}", s):
            return _dt.datetime(int(s[:4]), int(s[5:7]), 1)
        dt = _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
        return dt.replace(tzinfo=None) if dt.tzinfo else dt
    except ValueError:
        iso2, _ = parse_date(s)
        return to_datetime(iso2) if iso2 and iso2 != s else None


def fmt_brl(v: float | None) -> str:
    """1234.5 -> '1.234,50' (padrão brasileiro)."""
    if v is None:
        return "—"
    return f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def parse_money(s: Any) -> float | None:
    if isinstance(s, (int, float)):
        return float(s)
    t = re.sub(r"[^\d,.\-]", "", str(s))
    if not t:
        return None
    if "," in t and "." in t:
        t = t.replace(".", "").replace(",", ".") if t.rfind(",") > t.rfind(".") else t.replace(",", "")
    elif "," in t:
        t = t.replace(",", ".")
    elif t.count(".") > 1:
        t = t.replace(".", "")
    try:
        return float(t)
    except ValueError:
        return None




def cnj_is_valid(num: str) -> bool:
    """Número único de processo (Res. CNJ 65/2008): NNNNNNN-DD.AAAA.J.TR.OOOO, módulo 97."""
    d = re.sub(r"\D", "", num)
    return len(d) == 20 and int(d[:7] + d[9:] + d[7:9]) % 97 == 1


def e2e_is_plausible(s: str) -> bool:
    """ID fim a fim do PIX: E + ISPB(8) + AAAAMMDDHHMM(12) + 11 alfanuméricos."""
    m = re.fullmatch(r"E(\d{8})(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})([A-Za-z0-9]{11})", s)
    if not m:
        return False
    _, y, mo, dd, hh, mi, _ = m.groups()
    return 1 <= int(mo) <= 12 and 1 <= int(dd) <= 31 and int(hh) < 24 and int(mi) < 60


def defang(value: str) -> str:
    """Neutraliza IOC para exibição (não para armazenamento): http→hxxp, . → [.]"""
    v = re.sub(r"^http", "hxxp", str(value), flags=re.I)
    v = re.sub(r"\.(?=[^.]*$)", "[.]", v) if "@" not in v and "/" not in v else v.replace(".", "[.]", 1)
    return v
