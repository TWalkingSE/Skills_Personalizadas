# Alterações — skill socmint

## 1.1.0 (outubro de 2026)

Versão dos scripts gravada nas saídas: `socmint 1.1.0`. Mudanças de uso marcadas com **⚠**.

### Fase 1 — correções
- `make_report.py --redact` mascara também o diagrama do grafo (MD, HTML e DOCX) e omite o PNG do grafo, cujo texto não pode ser mascarado.
- Hipóteses: "Confirmaria se / Refutaria se" (critérios) separados de "Evidências a favor / contra" (campos `evidencias_favor` e `evidencias_contra` do `case.json`).
- Metodologia do relatório derivada dos arquivos do caso (evidências, camadas de preservação, pivôs, análises, ferramentas); o que falta aparece como pendente.
- Coluna de notas dos achados no relatório.
- **⚠** `--strict` falha também sem log de evidências quando ele é exigido (nível 2 ou 3, ou citações a `EV-…`).
- **⚠** `evidence_log.py init` exige `--tz` (fuso IANA da localidade do fato); `decode_ids.py` e `analyze_export.py` avisam quando o fuso exibido estava em horário de verão; tabela de fusos do Brasil na ref. 04 §5.
- Grafo: coluna opcional `tipo` nas arestas (`identidade`, `associacao`, `imitacao`); exemplo corrigido para não ligar o perfil falso à empresa imitada.

### Fase 2 — evidência e cadeia de custódia
- `evidence_log.py add`: `--captured` (hora da coleta, distinta da hora do registro), `--tool`, `--tool-version`, `--browser`, `--network`, `--account`; data de modificação do arquivo de origem; hash da origem conferido com a cópia.
- Novo `evidence_log.py event` (acondicionamento, transporte, recebimento, processamento, armazenamento, descarte, acesso, cópia) e `custody`; descarte registrado deixa de ser cobrado pelo `verify`.
- `verify` confere SHA-512; `export --format sha256sums`.
- `make_report.py`: hora da coleta na tabela de evidências, `--expect-last`, anexo de custódia, anexo com SHA-256 das entradas.
- `analyze_export.py` e `build_graph.py` registram versão e SHA-256 das entradas (`resumo.json`, `grafo_manifesto.json`, comentário no `.mmd`).
- **⚠** Os scripts recusam gravar dentro da pasta da skill.
- `SKILL.md`: o que o Claude busca na web é orientação, não evidência; não usar o navegador logado do usuário para abrir perfis-alvo; notas de ambiente sem caminhos fixos.

### Fase 3 — integração com as outras skills
- Novo `to_bundle.py`: exporta o caso como `intel-bundle/1.0` para o Investigative Notebook (perfis com o mesmo username não são unificados; identidade como correlação, imitação como inferência). Inclui cópias de `intel_contract.py` e `intel_normalize.py`, como nas demais skills.
- Tabela "Quando passar para outra skill" no `SKILL.md`.
- Atribuição em quatro classes (Confirmado / Provável / Possível / Não confirmado), alinhadas à `social-media-intelligence` (ref. 06 §4). Três ou mais sinais moderados agora resultam em Provável, não em "mesma pessoa".
- Admiralty: integridade (hash) separada da confiabilidade da fonte (ref. 07 §2).
- Nova descrição da skill.

### Fase 4 — contexto policial
- Ref. 00 seção 10: base legal da polícia judiciária, guarda de registros, Convenção de Budapeste, infiltração virtual (Lei 12.850, art. 10-A; ECA, art. 190-A), com textos conferidos no Planalto.
- `case.json`: contexto `policial`, `procedimento`, `quesitos`, `assinatura`; exemplo em `assets/exemplos/case_exemplo_policial.json`.
- `make_report.py --variante policial` (automática com `contexto: "policial"`).
- Pedido de preservação à plataforma em paralelo à captura (ref. 08 §1).
- Estudos de caso: loja falsa no Instagram com PIX, "troquei de número" no WhatsApp, anúncio falso no Marketplace (ref. 13).

### Fase 5 — conteúdo e scripts
- Novo playbook do Kwai; Kwai no `dork_builder.py`, na matriz do `SKILL.md` e nas refs. 03, 04 e 05.
- Modelos `pivos.template.csv` e `timeline.template.csv`; exemplo `pivos_exemplo.csv`.
- `name_variants.py`: agnomes (Júnior, Filho, Neto…) fora do sobrenome principal, nomes compostos, regras do Gmail.
- **⚠** `dork_builder.py`: intenções renomeadas (Facebook `invite` → `group`; Telegram `email` → `contact`; os nomes antigos continuam aceitos), `--after/--before`, Yandex só com `--engines`.
- `analyze_export.py`: critério de username "aleatório" corrigido para nomes comuns em português.
- Novo `selftest.py` (39 verificações).
- Configuração do Telegram do investigador em fonte única (ref. 02 §6); nota de sincronia dos limites rígidos; correspondência entre modelos e tipos de rede movidos para o modo estudo; comentários sobre o material do curso retirados.
- `last_verified` passou a `last_reviewed` (revisão editorial); itens verificados na plataforma trazem data própria, como `[VOL; verificado 2026-10]`.
- Matriz do `SKILL.md` com Kwai, YouTube, LinkedIn e Bluesky; sumários nos playbooks de X, YouTube e LinkedIn.
