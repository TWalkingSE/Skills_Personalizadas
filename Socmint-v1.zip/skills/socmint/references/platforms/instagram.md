# Instagram — playbook

Quando ler: investigação de perfil, post, hashtag ou local no Instagram, ou interpretação de HTML/JSON colado pelo usuário. Fonte principal: livro cap. 10 (2024). Instagram muda com frequência: tudo marcado `[VOL]` deve ser reconferido. `last_reviewed: 2026-10` (conteúdo do livro **não** revalidado na plataforma)

## Conteúdo
1. Estrutura e unidades
2. Identificadores
3. O que é visível
4. Pivôs de alto valor
5. Coleta passo a passo
6. Dorks
7. Ferramentas
8. Armadilhas
9. Limites e o que não fazer
10. Volatilidade e fontes

## 1. Estrutura e unidades (L p.446–449)

Publicações (foto, carrossel, vídeo até 1 min), Reels, Stories (24 h) e Destaques, Marcadas, DMs. Tipos de conta: **pessoal** (sem métricas nem botões de contato), **criador** e **empresa** (profissionais, públicas por definição; podem exibir e-mail, telefone e endereço em botões). O feed pesa interesses, relacionamento, recência, frequência de uso e Explorar (L p.449).

## 2. Identificadores

| Item | Onde | Observação |
|---|---|---|
| ID da conta | código-fonte (`profilePage_`, `profile_id`) e campo `id` do JSON | Sequencial: a conta nº N criada; ID 4 é do cofundador (L p.450). Preservar primeiro |
| ID → username atual | ferramentas de "ID para username" de terceiros `[VOL]` | Handle muda, ID não (L p.455–457) |
| Post | `instagram.com/p/<shortcode>`; chaves `shortcode`, `container_id`, `media_id` | (L p.490, 497) |
| Data de post e de story | `taken_at` (Unix) no código-fonte | `decode_ids.py unix` (L p.503, 515) |
| Story / destaque | `instagram.com/stories/<user>/<id>`, `instagram.com/stories/highlights/<id>`; chaves `pk`, `video_duration`, `taken_at` | (L p.515–516) |
| Local | ID numérico em `instagram.com/explore/locations/<id>` | Grafias diferentes do mesmo local geram IDs diferentes (L p.538) |
| Página do Facebook ligada | campos `page_id`/`ads_page_id` → Biblioteca de Anúncios da Meta (`facebook.com/ads/library/?view_all_page_id=<id>`) | Pivô Instagram → página do Facebook (L p.480–482) |

Data embutida em ID de mídia: `(id>>23)+1314220021721` ms `[ADD]` (conferida com vetores públicos, `04`); `python3 scripts/decode_ids.py instagram-media <id ou shortcode>`.

## 3. O que é visível

- **Perfil público**: foto, bio, link externo, contadores, destaques. A interface arredonda a partir de 10 mil; o JSON/código-fonte traz o exato (L p.473).
- **Campos úteis quando o usuário cola o JSON do perfil** (L p.470–476): `biography`, `external_url`, `fb_profile_biolink` (URL do Facebook ligado), `full_name`, `username`, `id`, `edge_followed_by.count`, `edge_follow.count`, `edge_owner_to_timeline_media.count`, `highlight_reel_count`, `is_private`, `is_verified` (verificado pela Meta **ou** selo comprado, sem distinção no campo), `is_business_account`, `is_professional_account`, `is_joined_recently` (conta com menos de 30 dias), `category_name`, `business_address_json`, `profile_pic_url_hd`, `edge_mutual_followed_by`.
- **Contato público** de conta profissional (e-mail e telefone do botão Contactar), publicado pelo próprio titular (L p.479).
- **"Sobre esta conta"** (menu "…" do perfil): data de entrada (mês/ano), país, seguidores em comum (quando alto percentual) e **quantidade** de trocas de username, sem os nomes antigos. A própria plataforma justifica o campo como sinal de autenticidade (L p.460–461).
- **Perfil privado**: só foto e bio; use-os como pivô (L p.552). Contas privadas no Instagram podem ter Threads aberto (L p.553, 592).

## 4. Pivôs de alto valor

1. Username em outras redes (reuso) e variações (`06`).
2. Bio e link externo (links para outras redes, e-mail, página pessoal).
3. Foto de perfil (busca reversa; cuidado com falsos positivos, `06`).
4. Contato público em conta profissional.
5. Seguidores em comum e listas de seguidores/seguidos (comparar listas).
6. Marcadas e menções de terceiros (dork da seção 6): mostram quem se relaciona com o alvo (L p.511–514).
7. Legendas e comentários (indexados pelo Google).
8. Locais de posts e hashtags.
9. `page_id` → Biblioteca de Anúncios da Meta.
10. Threads do mesmo titular (L p.592).
11. Número de trocas de username (conta que troca de nome em intervalos curtos é indício, não prova, de conta descartável).

## 5. Coleta passo a passo

1. **Preservar** (`08`): URL, captura com data/hora, HTML (`Ctrl+U`), foto de perfil em tamanho máximo com hash.
2. Anotar **ID** (código-fonte `profile_id`) e handle atual.
3. Registrar bio, link externo, contadores **exatos**, flags de conta e "Sobre esta conta".
4. Posts: salvar URL, `shortcode`, `taken_at` convertido para UTC, legenda e mídia original. Comentários podem ser exportados com extensões (limites gratuitos de 100 a 500). Curtidas: a API limita a extração a cerca de 100 em posts de terceiros desde jan/2024 `[VOL]` (L p.500).
5. Marcadas: `instagram.com/<user>/tagged/` (L p.513). Muitos perfis têm poucos posts e muitas marcações.
6. **Stories e destaques**: ao ver, o nome da **conta que visualiza** aparece na lista de audiência do alvo (L p.514). É interação ativa (`02`). Visualizadores "anônimos" de terceiros existem e duram pouco porque exploram a API sem autorização `[VOL]` (L p.520–523).
7. Hashtags: `instagram.com/explore/tags/<tag>` mostra só cerca de 30 posts relevantes por carga, mesmo com dezenas de milhares de resultados (L p.527). Não busca duas hashtags de uma vez; para isso, dorks.
8. Locais: a busca interna mistura perfis, hashtags e locais; acrescentar a palavra "localização" ao nome ajuda. Posts recentes aparecem abaixo das 12 primeiras células (L p.537–539).

## 6. Dorks (L p.528–534)

```
site:instagram.com "Nome do investigado"
site:instagram.com "possível texto da bio"           # a busca interna não indexa bio; o Google sim
@alias inurl:instagram.com -site:instagram.com/alias
site:instagram.com "usuarioquemenciona" @alias
inurl:instagram.com/p/ "texto da legenda"
site:instagram.com/p/ #tag1 #tag2
site:instagram.com/explore/locations/ "nome do local"
```

`scripts/dork_builder.py --platform instagram` gera as variações e links.

## 7. Ferramentas (função → risco; lista completa em `12`)

| Ferramenta | Função | Risco |
|---|---|---|
| Extensões de ID, Instant Data Scraper, InsFo, IGFET, InsC, Growman, IG Downloader, Exact Time Viewer | ID, exportação de seguidores/comentários/curtidas, download, hora exata | Exigem login; uso em escala dispara anti-bot; limites gratuitos; ToS |
| Compare Friends | Interseção de listas | Local ao navegador |
| Picuki/Picnob e similares | Visualização sem conta, incluindo conteúdo que o perfil apagou e o espelho ainda tem | Vida curta, API sem autorização, o termo buscado é revelado `[VOL]` |
| Lampyre (paga) | Seguidores, seguidos, curtidas e comentários sem conta de investigação | Envia consulta a terceiro |
| Hunterintel (Xhunt) | Locais em área por coordenadas | Conta trial; pago |
| Osintgram (CLI), Regrambot (bot Telegram) | Coleta em massa, monitoramento em tempo real | **Pedem credenciais da conta**, vigilância de pessoa, risco de bloqueio e de ToS: ver seção 9 |

## 8. Armadilhas e falsos positivos

- Intervalos curtos entre extrações parecem bot e derrubam a conta de investigação (L p.530–531).
- Vincular conta a site de terceiros expõe credenciais (L p.499).
- Selo azul não distingue verificação real de selo comprado no campo `is_verified` (L p.562).
- Locais duplicados por grafia, posts "destacados" não são os mais recentes, contadores arredondados.
- Handle igual em outra rede não prova identidade (`06`).

## 9. Limites e o que não fazer

A skill **explica o conceito e o risco**, sem passo a passo, destes itens do livro:
- **JSON de endpoints não documentados com User-Agent móvel** (`web_profile_info`, `users/<id>/info`): instável, contra os termos, e a conta recebe "challenge" (L p.462–469). A skill ajuda a **interpretar** o JSON que o usuário já tenha; prefira o código-fonte e a interface.
- **E-mail/telefone ofuscados via fluxo de recuperação de conta**: a técnica gera aviso ao titular e é pretexto de acesso (L p.288–290, 554–562). Não instruir.
- **Achar perfil por número de telefone sincronizando a agenda** (L p.548–551): expõe a conta do investigador e identifica pessoa pelo telefone. Não instruir.
- **Perfil fechado por engenharia social ou pedido de amizade com identidade falsa** (L p.552): não instruir. Opções lícitas: o que é público (foto, bio, Threads aberto, menções de terceiros) e pedido formal.
- **Monitoramento em tempo real de pessoa com credenciais** (L p.565–576): vigilância; só aceitável para conta de organização com autorização.
- **Recuperar a própria conta hackeada**: fluxo oficial `instagram.com/hacked`, em dispositivo já usado na conta, com vídeo-selfie de verificação `[VOL]` (L p.577–587); ver `10`.

## 10. Volatilidade e fontes

`[VOL]`: endpoints, espelhos, limites de API, campos do JSON, layout do menu "Sobre esta conta". Fonte: livro cap. 10 (L p.445–589), Instagram Engineering (formato de ID de mídia) `[ADD]`. Reconferir com busca web antes de afirmar como atual.
