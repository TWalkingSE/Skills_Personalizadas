# Facebook — playbook

Quando ler: investigação de perfil, página, grupo, Marketplace, evento ou arrecadação no Facebook, ou interpretação de HTML/JSON colado pelo usuário. Fonte principal: livro cap. 9 (2024). A interface e os parâmetros mudam: `[VOL]` = reconferir. `last_reviewed: 2026-10` (conteúdo do livro **não** revalidado na plataforma)

## Conteúdo
1. Estrutura e unidades
2. Identificadores e chaves do código-fonte
3. O que é visível (perfil, página, grupo)
4. Pivôs de alto valor
5. Coleta passo a passo
6. Dorks
7. Ferramentas
8. Armadilhas
9. Limites e o que não fazer
10. Volatilidade e fontes

## 1. Estrutura e unidades (L p.292–296)

Perfil, página, grupo (público, privado ou secreto), Marketplace (desde 2016, só maiores de 18), eventos, arrecadações, Watch e stories. Contexto relevante: a busca por grafo (Graph Search) foi removida em 2019; mudanças de código-fonte no fim de 2022 quebraram muitas ferramentas de analistas `[VOL]`. A busca interna hoje tem filtros (grau de amizade, cidade, formação, trabalho), aceita e-mail e domínio, usa OCR em imagens e aceita emojis (L p.366–371).

## 2. Identificadores e chaves do código-fonte

| Objeto | URL / chave | Observação |
|---|---|---|
| Perfil | `userID`; URL `facebook.com/<vanity>` ou `profile.php?id=` | Único dado imutável do perfil (L p.303). `facebook.com/<ID>` leva ao perfil atual (L p.300) |
| Página | `id` dentro de `profile_owner`; `pageID`, `container_id`, `selectedID`; ID de transparência: `profile_transparency_id`, `delegate_page_id`, `message_box_id` | O ID de transparência também resolve para a página atual (L p.421–422) |
| Grupo | `groupID` (`facebook.com/groups/<ID>`); `idorvanity` | (L p.393) |
| Usuário dentro do grupo | `facebook.com/groups/<ID>/user/<userID>`; `entity_id=` no autor de mensagem de chat | (L p.399, 403) |
| Post / vídeo | `facebook.com/<vanity ou ID>/posts/<id>`; `.../video/<id>` | (L p.338, 352) |
| Marketplace | perfil `facebook.com/Marketplace/profile/<ID>`; item `facebook.com/marketplace/item/<ID>/`, chave `product_id` | (L p.372, 379) |
| Evento / arrecadação | `facebook.com/events/<ID>` (`eventID`, `event_id`); `facebook.com/donate/<ID>` (`campaignID`, `campaign_id`) | (L p.383, 388) |

**Cuidado**: `ACCOUNT_ID`, `USER_ID` e `actorID` no código-fonte são da conta **logada** (a do investigador), não do alvo (L p.298).

**Chaves de tempo**: `creation_time` (posts, fotos, itens do Marketplace), `create_time` (grupo), `publish_time` (evento), `campaign_creation_time` (arrecadação). **Chaves de contagem exata** (a interface arredonda): `reaction_count`, `total_count` em comentários, `share_count`, `video_view_count` (L p.339, 353, 396). Converter com `scripts/decode_ids.py unix`. Faixas de ID e ano provável: `references/04-identificadores-e-tempo.md`.

## 3. O que é visível

**Perfil** (L p.302–351)
- Foto de perfil: se a audiência não for "Só eu", qualquer pessoa pode ampliá-la e ver data, comentários, reações e compartilhamentos. A **capa** nunca pode ser restringida: sempre mostra interações (L p.304–308).
- Detalhes: cidade natal/atual, trabalho, relacionamento, "Entrou no Facebook" quando exibido (útil para comparar clones) (L p.310). Outros nomes e apelidos (L p.317).
- Informação: trabalho e formação **com datas**, locais, contato (e-mail só se exibido), **família e relacionamentos** (visíveis mesmo com amigos ocultos; nome cinza sem link = perfil apagado ou relação não aceita) (L p.312–318).
- Fotos (álbuns de capa e de perfil sempre existem), vídeos, visitas (check-ins com data), esportes, música, filmes, TV, livros, apps e jogos, curtidas, eventos (para amigos, só futuros), **comentários criados** (avaliações em estabelecimentos, mesmo com perfil privado) (L p.325–352). Servem para perfilar idioma, região e interesses.
- Marketplace: data de entrada, cidade e país, histórico de itens vendidos, avaliações com nome do avaliador (L p.372–382). Fotos de produtos podem revelar local e até reflexos.
- Amigos: muitas vezes ocultos; a lista pode exibir só seguidores (L p.319).

**Página** (L p.420–428): contato (telefones, e-mails, endereços), informação legal, **Transparência** (ID, data de criação, histórico de nomes, países/regiões dos administradores), menções, opiniões (as primeiras costumam vir de amigos e familiares do criador), anúncios.

**Grupo** (L p.392–420): em grupo público, feed e busca sem entrar; Sobre (categoria, data de criação via `create_time`, histórico de nomes, administradores, total de membros); Pessoas (administradores, moderadores, membros por data); o criador é o último da lista de membros. Grupo privado: Sobre, histórico e administradores são visíveis; membros e conversas só para membros; "Atividade" mostra números de movimento.

**Biblioteca de Anúncios da Meta** (`facebook.com/ads/library`): anúncios por página e anunciante, filtros por idioma, plataforma, tipo e período; relatório de gastos de temas políticos e sociais (L p.429–433).

## 4. Pivôs de alto valor

1. Vanity/username em outras redes (`06`).
2. Nome completo, apelidos, nome de solteiro (dorks; LinkedIn).
3. Foto de perfil e de capa (busca reversa); comentários de amigos na capa.
4. Família e relacionamentos; sobrenomes iguais (cuidado com homônimos).
5. Listas de amigos exportadas de dois alvos: URLs repetidas = amigos em comum (L p.322–324).
6. Busca por nome do alvo **dentro do próprio perfil** e em grupos públicos: encontra menções e marcações de terceiros (L p.434–436).
7. Marketplace (data de entrada, localização, avaliações), eventos e arrecadações (criador, contatos, doadores públicos).
8. Página: transparência, contatos, informação legal → vínculos societários (por exemplo, consulta a registros de empresas).
9. Biblioteca de Anúncios e Instagram vinculado.

## 5. Coleta passo a passo

1. **Preservar** (`08`): URL, captura, HTML (`Ctrl+U`), foto de perfil ampliada com hash.
2. Anotar `userID` (cuidado com o ID do logado) e o handle atual.
3. Registrar Detalhes, Informação, "Entrou no Facebook", outros nomes.
4. Posts e fotos: URL, `creation_time`→UTC, contagens exatas do código-fonte, legenda, marcados, geotag.
5. Busca no perfil por URL quando a lupa está bloqueada: `facebook.com/profile/<userID>/search/?q=<termos>`. Os resultados variam entre contas e filtros: repetir e registrar `[VOL]` (L p.362–363).
6. Comentários: o popup restringe a busca; extensões "anti-popup" e exportadores permitem pesquisar texto. Reações também são um tipo de comentário para inferir vínculos.
7. Grupos: anotar `groupID`, data de criação, histórico de nomes, administradores, regras fixadas. Exportação de membros é coleta em massa: só em grupo **público**, em pequena escala, com ToS e minimização em mente (seção 9).
8. Página: Transparência e Biblioteca de Anúncios.

## 6. Dorks (L p.441)

```
intext:"Nome Sobrenome" inurl:facebook.com OR site:facebook.com
"Nome Sobrenome" site:facebook.com inurl:ref=page_internal
intext:"Nome Sobrenome" inurl:facebook.com -site:facebook.com/<perfil-ja-achado>
site:facebook.com inurl:/about_contact_and_basic_info "email@exemplo.com"
"text that says <texto>" site:facebook.com            # descrições automáticas de imagem
"May be an image of <n> people" site:facebook.com
site:facebook.com/groups/<ID|vanity>/posts "Nome Sobrenome"
```

`scripts/dork_builder.py --platform facebook` gera as variações.

## 7. Ferramentas (função → risco; lista completa em `12`)

| Ferramenta | Função | Risco |
|---|---|---|
| ID Finder (extensão), lookup-id.com, commentpicker, findidfb | ID ↔ perfil | Terceiros recebem o identificador |
| Instant Data Scraper, extensões ESUIT (posts, comentários, reações, álbuns, vídeos, membros), exportadores | Exportação de tabelas e mídia | Exigem login; "full speed" gera alerta; limites gratuitos (50 a 300 itens) |
| Compare Friends, Highlight This! | Interseção de listas, destaque de palavras | Locais ao navegador |
| Who Posted What, Facebook Search Tools (OSINT Combine) | Consultas de busca estruturadas por ID e nome | Dependem de mudanças da interface `[VOL]` |

## 8. Armadilhas e falsos positivos

- Modo "Full Speed" das extensões parece bot e derruba a conta de investigação (L p.252, 358).
- O número de membros no cabeçalho do grupo quase nunca é igual à lista (contas desativadas, visualização prévia) (L p.401).
- Os primeiros comentários e opiniões costumam ser de pessoas próximas ao dono: não os trate como público geral.
- Sobrenome igual não prova parentesco.
- Resultados de busca diferem por conta e filtro (L p.363).

## 9. Limites e o que não fazer

- **Perfis fechados**: só o que é público e lícito (foto de perfil e capa ampliáveis, menções de terceiros em conteúdo público, grupos públicos, Marketplace, comentários criados). Não instruir: adicionar amigos próximos para a plataforma sugerir a conta ao alvo, nem pedir amizade com identidade falsa (L p.324–325, 369).
- **Consulta de vazamento do Facebook (2019) por ID** (L p.439): não usar para identificar pessoa física (`00`).
- **Pretexto de recuperação de senha** para espiar nome, foto e trechos de e-mail/telefone (L p.288–290): avisa o titular e é acesso por engano; não instruir.
- **Scripts colados no console do navegador** (exportar membros): risco de *self-XSS* e de violação de ToS; a skill não detalha. Preferir extensões auditadas ou captura manual.
- **Chat de grupo visível enquanto o pedido de entrada está pendente** (L p.398): comportamento da plataforma, não um acesso autorizado; entrar em grupo exige o gate (`00`, `03`).
- **Grupos privados**: só como membro legítimo, sem engano e com modo "ativo" justificado.

## 10. Volatilidade e fontes

`[VOL]`: URLs de busca, chaves JSON, extensões e preços, comportamento de popups, Graph Search, disponibilidade de visualizações. Fonte: livro cap. 9 (L p.292–444). Reconferir com busca web antes de afirmar como atual.
