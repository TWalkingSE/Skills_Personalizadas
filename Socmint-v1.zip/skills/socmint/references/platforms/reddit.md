# Reddit — playbook

Quando ler: investigação de usuário, subreddit ou discussão no Reddit; análise de padrão de atividade de conta pseudônima. Fontes: slides do Discord (D s.59, 79–81) e pesquisa complementar `[ADD]`. `last_reviewed: 2026-10`

## Conteúdo
1. Estrutura e unidades
2. Identificadores
3. O que é visível
4. Pivôs de alto valor
5. Coleta passo a passo
6. Dorks e busca interna
7. Ferramentas
8. Armadilhas
9. Limites e o que não fazer
10. Volatilidade e fontes

## 1. Estrutura e unidades

Rede **aberta** (D s.52): **subreddits** são fóruns temáticos com moderação distribuída e sistema de reputação (karma) (D s.58). Unidades: subreddit, post, comentário, perfil `u/<username>`. O Reddit permite várias contas por pessoa (D s.79).

## 2. Identificadores

| Item | Detalhe |
|---|---|
| **Username** | **Permanente**: nunca muda, nem por suporte nem por antiguidade; se a conta é apagada, o nome não volta a ficar disponível (D s.79; confirmado no Reddit Help). A única saída de quem se arrepende é criar outra conta |
| Display name | Separado, livre, não único, aparece só no topo do perfil; em posts, comentários, URLs e menções `u/` aparece o username (D s.80) |
| Karma | Soma de votos positivos menos negativos de posts e comentários; sinal reputacional para triagem rápida (D s.81) |
| Idade da conta | "Cake day" no perfil (data em que a conta foi criada) `[ADD]` |

Consequência para investigação (D s.80): diferente do Discord, o vínculo username ↔ histórico é **estável por definição**; não existe o risco de "o alvo mudou de nome e perdi o rastro". O risco é outro: a pessoa pode ter **várias contas**.

## 3. O que é visível

- Perfil público: posts, comentários, karma, data de criação (cake day), subreddits em que atua.
- Desde jun/2025 o usuário pode **ocultar posts e comentários do próprio perfil por subreddit** ("Curate your profile"): o conteúdo continua nas comunidades de origem e na busca, o username continua aparecendo ao lado, e alguns moderadores veem o histórico público por 28 dias (Reddit/TechCrunch/The Verge) `[ADD][VOL]`. Perfil "vazio" não significa conta inativa.
- Subreddit: regras, moderadores, descrição, data de criação, posts e comentários.

## 4. Pivôs de alto valor

1. **Username** idêntico em outras plataformas (reuso exato é indício, não prova; `06`).
2. **Mix de subreddits**: interesses, profissão, região, hobbies.
3. Texto de comentários: estilo, idioma, assinaturas, links próprios, e-mails e usernames citados.
4. **Horário das atividades**: histograma por hora indica fuso provável (`analyze_export.py`; `07`).
5. Links e domínios compartilhados; imagens (busca reversa).
6. Moderação: quem modera subreddits sobre um tema costuma ter ligação com ele.
7. Referências cruzadas: o username citado em outras redes ou em threads de outras comunidades.

## 5. Coleta passo a passo

1. **Preservar** (`08`): URL do perfil, captura, HTML, lista de posts e comentários com datas; posts são preserváveis por URL permanente.
2. Registrar username, display name, karma, cake day, subreddits, moderações.
3. Coletar posts e comentários relevantes com permalink e data/hora (UTC); exportações do Reddit e ferramentas de terceiros variam muito `[VOL]`.
4. Montar histograma de horário e mapa de assuntos; registrar limitações (conta pode ocultar histórico).
5. Verificar perfis que possam pertencer à mesma pessoa por **corroboração**, não por semelhança (`06`).

## 6. Dorks e busca interna

Dorks:
```
site:reddit.com/user/<username>
site:reddit.com/r/<subreddit> "palavra"
inurl:reddit.com/user "texto que a pessoa costuma escrever"
```
Busca interna do Reddit (ajuda oficial) `[ADD]`: `author:<usuário>`, `subreddit:<nome>`, `title:`, `selftext:`, `self:true`, `site:`, `url:`, `flair:`, com operadores `AND`, `OR`, `NOT` em maiúsculas. Sem espaço depois dos dois-pontos (`author:cats`). `scripts/dork_builder.py --platform reddit` gera as variações.

## 7. Ferramentas

Busca interna e dorks; arquivos da web para conteúdo apagado (`08`); `analyze_export.py` para horário e texto repetido. O acesso por API tem regras e limites que mudaram nos últimos anos: verificar os termos vigentes antes de recomendar coleta em escala `[VOL]`.

## 8. Armadilhas

- Conta nova sem histórico ou com histórico oculto não prova ser descartável.
- Várias contas por pessoa: uma conta não representa o indivíduo.
- Comentários removidos por moderação ou pelo autor: preservar cedo.
- Horário típico depende do fuso do **site** e das sessões; amostra pequena engana.
- "Karma" alto não é credibilidade.

## 9. Limites e o que não fazer

- Reddit é pseudo-anonimato social (D s.90): o perfil pode revelar muito sobre a vida da pessoa. Ao perfilar **pessoa privada**, o gate se aplica (`00`): finalidade, necessidade e minimização.
- **Não** tentar desanonimizar usuário crítico, denunciante ou pessoa em risco.
- **Não** usar scrapers que violem os termos da plataforma ou contornem limites de taxa.

## 10. Volatilidade e fontes

`[VOL]`: acesso por API, ocultação de perfil, operadores de busca, ferramentas de terceiros. Fontes: slides do Discord (D s.52, 58, 79–81, 90); Reddit Help (username permanente, busca, "Curate your profile") e notícias de jun/2025 `[ADD]`.
