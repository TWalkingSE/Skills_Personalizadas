# Bluesky e Mastodon (fediverso) — playbook enxuto `[ADD]`

Quando ler: investigação em redes abertas e descentralizadas, onde a identidade persistente e os dados públicos são acessíveis sem conta. **Fora dos materiais do curso** (o livro cita o Mastodon como microblog descentralizado, L p.64); reconfirmar antes de afirmar. `last_reviewed: 2026-10`

## Conteúdo
1. Bluesky
2. Mastodon e fediverso
3. Pivôs e coleta
4. Armadilhas e limites
5. Volatilidade e fontes

## 1. Bluesky (protocolo AT)

- Rede **aberta** (`03`). Identificadores:
  - **DID** (`did:plc:…`), identidade **persistente** da conta (preservar primeiro);
  - **handle**, um nome de domínio, **mutável** (pode ser domínio próprio: pivô por WHOIS e DNS).
- **API pública sem autenticação**: o AppView em `public.api.bsky.app` responde `GET` de `app.bsky.*` sem token. `app.bsky.actor.getProfile` aceita handle ou DID e devolve perfil público (nome, bio, contagens, avatar, datas indexadas). Também há busca de perfis e do feed de um autor (documentação oficial em `docs.bsky.app`).
- **Histórico do DID**: o diretório PLC mantém um **log transparente de operações** de cada `did:plc`, incluindo mudanças de handle (`alsoKnownAs`), com data do servidor (especificação `did:plc`). Serve para reconstruir handles antigos. Conferir endpoints atuais na especificação.
- Registros e publicações usam **TID** (timestamp embutido) como chave: `python3 scripts/decode_ids.py bluesky-tid <tid>`.
- URL de web: `bsky.app/profile/<handle>` e `.../post/<chave>`.

## 2. Mastodon e fediverso (ActivityPub)

- Cada conta vive em uma **instância**: `@usuario@instancia`. A mesma pessoa pode ter contas em várias instâncias; a migração entre instâncias deixa um aviso na conta antiga.
- **WebFinger**: `https://<instancia>/.well-known/webfinger?resource=acct:usuario@instancia` resolve o endereço da conta (RFC 7033).
- **API pública** do Mastodon (documentação oficial): o objeto de conta inclui `acct`, `url`, `display_name`, `note` (bio), `created_at`, contadores, `last_status_at`, `bot`, `locked`. Cada instância define o que é público; há regras de moderação e de bloqueio entre instâncias.
- IDs de conta e de post são locais à instância: para preservar, guardar o **URL canônico** e o `acct` completo.

## 3. Pivôs e coleta

1. Handle ou domínio próprio → WHOIS, DNS, site pessoal, outras contas.
2. Bio, links verificados (no Mastodon, links `rel=me` indicam posse do site), avatar (busca reversa).
3. Datas de criação (`created_at` no Mastodon; histórico do DID no Bluesky); horário das postagens (`07`).
4. Seguidores e seguindo públicos; menções e respostas.
5. **Preservar** (`08`): JSON da API pública (arquivo + hash), captura com data, URL canônica. Registrar a instância e o horário.

## 4. Armadilhas e limites

- Handle como domínio pode ser **transferido ou vendido**; pivotar por DID.
- No fediverso, conteúdo apagado em uma instância pode persistir em outras cópias; a visibilidade depende da federação.
- São redes de comunidades pequenas, muitas vezes de pessoas em risco ou de grupos vulneráveis: gate rigoroso (`00`); não desanonimizar.
- Respeitar limites de taxa; não raspar em escala. Dados públicos ainda são dados pessoais (LGPD).

## 5. Volatilidade e fontes

`[VOL]`: endpoints, campos, políticas de instâncias, adoção. Fontes: documentação do Bluesky (`docs.bsky.app`, `endpoints.bsky.app`), especificação `did:plc`, documentação do Mastodon (WebFinger e Account) `[ADD]`; livro cap. 4 (L p.64).
