# Discord — playbook

Quando ler: investigação de servidor, convite, usuário, bot ou comunidade que usa Discord; datar contas, servidores e mensagens por ID. Fontes: slides do Discord (D s.51–90) e documentação oficial de convites `[ADD]`. `last_reviewed: 2026-10`

## Conteúdo
1. Estrutura e unidades
2. Identificadores
3. O que é visível
4. O que investigar primeiro em um servidor
5. Pivôs de alto valor
6. Coleta passo a passo
7. Dorks e ferramentas
8. Armadilhas
9. Limites e o que não fazer
10. Volatilidade e fontes

## 1. Estrutura e unidades (D s.66–70)

A unidade central **não é o perfil, é o servidor**: infraestrutura comunitária em tempo real, não um feed. Tipo de rede: híbrida ou fechada, conforme o servidor (D s.52).

| Elemento | Como funciona | Relevância OSINT |
|---|---|---|
| Servidor | Comunidade por tema, com dono e administradores | Núcleo de sociabilidade, hierarquia e coordenação |
| Categoria | Agrupa canais | Revela a arquitetura interna e a organização temática |
| Canal de texto | Conversa assíncrona por tópico | Debates, anúncios, logs |
| Canal de voz | Presença em tempo real (voz, vídeo, tela) | Convivência e coordenação síncrona |
| Canal de fórum | Tópicos estilo fórum | Comunidades grandes, suporte, vazamentos |
| Threads | Conversas derivadas de mensagens ou canais | Podem esconder discussões relevantes |
| Cargos (roles) | Permissões e hierarquia | Admins, moderadores, verificados, compradores, insiders |
| Bots | Moderação, logs, jogos, pagamentos, verificação | Costumam revelar o fluxo operacional real |
| DMs e grupos de DM | Conversas privadas | Fora de escopo para terceiros |

**Convites** (D s.69–70): temporário (30 min a 7 dias), com limite de usos (desativa após N entradas), permanente (o mais comum em comunidades estabelecidas) e *vanity URL* `discord.gg/<nome>` (exige nível de boost do servidor). Há ainda eventos, integrações externas e assinaturas de servidor.

## 2. Identificadores

- **Snowflake** (D s.71–73): todo ID (usuário, servidor, canal, cargo, mensagem) é um inteiro de 64 bits; os 42 bits mais significativos guardam o *timestamp* de criação em ms desde a época do Discord. `timestamp_ms = (ID >> 22) + 1420070400000` (01/01/2015 00:00 UTC). Calcula a data **exata** de criação de conta, servidor, canal ou mensagem, sem API nem bot, e funciona para contas apagadas se o ID aparece em algum log. `python3 scripts/decode_ids.py discord <ID>`.
- **Username** (D s.74–77): até meados de 2023 o identificador visível era `Usuário#1234`; desde então é `@username` global e único (2 a 32 caracteres: minúsculas, números, `_` e `.`), com até **2 trocas por semana** `[VOL; verificado 2026-10 na central de ajuda do Discord]`. O **nome de exibição** é livre, não único e aceita emojis; muda a qualquer momento. Provas e logs anteriores a 2023 usam o formato antigo: reconheça os dois.
- Obter IDs no cliente: ativar o modo desenvolvedor nas configurações avançadas e copiar o ID `[ADD]`.

## 3. O que é visível

- **Página/prévia do convite** (`discord.gg/<código>`): nome e ícone do servidor, contagens aproximadas de membros e online `[VOL]`.
- **API documentada de convites** (`GET /invites/<código>`, com `with_counts=true`): devolve o objeto de convite com servidor (ID, nome, descrição, recursos, nível de verificação, *vanity code*, contagem de boosts), canal, **usuário que criou o convite**, contagens aproximadas e data de expiração (documentação oficial do Discord `[ADD]`). Verifique os requisitos atuais de autenticação e limites de taxa antes de orientar o uso `[VOL]`.
- **Widget do servidor** (`/guilds/<ID>/widget.json`), **apenas se o dono o habilitou**: nome, convite instantâneo e membros online `[ADD][VOL]`.
- Dentro do servidor, para quem é membro **legítimo**: canais, categorias, cargos, mensagens, lista de membros, bots, eventos.

## 4. O que investigar primeiro em um servidor (D s.87)

1. **Roles/cargos**: a hierarquia mostra quem são admins, moderadores e membros de confiança.
2. **Canais e categorias**: mapeiam a organização temática e o propósito real da comunidade.
3. **IDs (snowflake)**: datam com precisão contas, mensagens e o próprio servidor.
4. **Convites residuais**: links antigos, ativos ou expirados, revelam o ecossistema de divulgação.

## 5. Pivôs de alto valor

1. **Convites** encontrados em outras redes (Telegram, Reddit, X, YouTube): quem divulga, quando, para qual público.
2. **@username** reutilizado em outras plataformas (é global e único: reuso exato é um indício, não prova; `06`).
3. **Snowflake do servidor** para ligar convites diferentes ao mesmo servidor e datar sua criação.
4. **Bots** de logs, verificação e pagamento: indicam o funcionamento (venda, cobrança, entrada por aprovação).
5. **Cargos** como "comprador", "insider", "verificado": indicam modelo de negócio e hierarquia.
6. **Datas de criação de contas** dos membros: lote de contas criadas no mesmo dia sugere contas descartáveis ou alts (D s.73), como **indicador** (`07`).
7. **Migração de comunidade** (D s.89): servidor como vitrine, núcleo em Telegram ou WhatsApp, canais de backup (`03`).
8. Avatares e banners (busca reversa).

## 6. Coleta passo a passo

1. **Preservar** (`08`): página/prévia do convite (captura + HTML), código do convite, data e hora UTC e onde o link foi publicado.
2. Registrar o ID do servidor (se obtido) e decodificar a data de criação; registrar as datas de criação dos IDs relevantes (`decode_ids.py discord`).
3. Descrever a estrutura visível: categorias, canais, cargos e bots, **sem** interagir.
4. Mapear o ecossistema (convites residuais, canais de divulgação, links cruzados) com dorks (seção 7).
5. Entrar no servidor é ação **ativa**: exige gate (`00`), conta própria de investigação e justificativa. Em servidores de venda de contas, fraudes e comunidades de risco, a coleta passiva da divulgação costuma bastar para denúncia à plataforma.
6. Dentro do servidor, registrar apenas o necessário; mensagens e IDs de terceiros entram com minimização e `--redact` no relatório.

## 7. Dorks e ferramentas

```
site:discord.gg "palavra"
site:discord.com/invite "palavra"
"discord.gg/<código>"                       # onde um convite específico é divulgado
```
`scripts/dork_builder.py --platform discord --intent invite` gera as variações. Diretórios públicos de servidores (por exemplo, Disboard, top.gg) ajudam a achar comunidades por tema `[ADD][VOL]`. Decodificador local de snowflake: `scripts/decode_ids.py`. Detalhes e riscos de ferramentas de terceiros em `12`.

## 8. Armadilhas

- Prints antigos usam `Nome#1234`; o mesmo nome hoje pode ser outro usuário.
- Nome de exibição pode imitar outra pessoa; comparar sempre pelo ID.
- Ordem de IDs não é ordem de entrada no servidor.
- Contagens de membros em convites são aproximadas.
- Convite expirado hoje pode ter sido válido na época do print: o código ainda serve como pivô.

## 9. Limites e o que não fazer

- **Não** usar token de usuário, *self-bot* ou automação de conta de usuário: viola os termos e expõe a conta.
- **Não** exportar em massa mensagens e membros de servidores onde você entrou como investigador sem base legal e minimização; pessoas ali são, em grande parte, pseudônimos estáveis (D s.90) e muitas são menores.
- **Não** entrar com identidade falsa para obter acesso; ver `00` e `02`.
- Servidores com indício de conteúdo de abuso sexual infantil: não entrar, não baixar; orientar denúncia (`00` seção 4).

## 10. Volatilidade e fontes

`[VOL]`: política de username, limites de troca, regras da API de convites, recursos de widget e descoberta. Fontes: slides do Discord (D s.51–90); documentação de desenvolvedores do Discord (invite e guild widget) `[ADD]`; Help Center do Discord sobre usernames (2 trocas por semana).
