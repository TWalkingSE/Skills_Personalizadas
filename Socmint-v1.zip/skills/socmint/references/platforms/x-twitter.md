# X / Twitter — playbook enxuto `[ADD]`

Quando ler: investigação de conta, post ou campanha no X. **Fora dos materiais do curso**: fatos vêm de guias de terceiros e da experiência pública da plataforma; reconfirmar antes de afirmar. `last_reviewed: 2026-10`

## Conteúdo
1. Estrutura e identificadores
2. O que é visível
3. Pivôs de alto valor
4. Coleta
5. Dorks e busca
6. Armadilhas e limites
7. Volatilidade e fontes

## 1. Estrutura e identificadores

- Rede **híbrida** (`03`): perfil, post, resposta, citação, lista. O X é o microblog de referência do livro (L p.64).
- **ID numérico** de conta (preservar primeiro) e **ID de post** (*snowflake*). `@handle` é mutável.
- Data embutida no ID de post: `(id >> 22) + 1288834974657` ms. `python3 scripts/decode_ids.py x <id>`. IDs de usuário antigos não são snowflake; aplicar só a IDs de post pós-nov/2010.
- URL: `x.com/<handle>` e `x.com/<handle>/status/<id>`; `twitter.com` ainda redireciona `[VOL]`.

## 2. O que é visível

- Desde 2023 a **busca exige login**; visitantes sem conta veem um muro de login `[VOL]`. Posts individuais abertos por link podem aparecer com limitações.
- Perfil: foto, banner, bio, local declarado, link, data de entrada, contadores, selo.
- Posts apagados e contas protegidas não aparecem na busca.
- Operadores de busca na interface web (contas logadas) `[VOL]`: `from:`, `to:`, `@`, `"frase"`, `-termo`, `OR`, `#tag`, `since:AAAA-MM-DD`, `until:AAAA-MM-DD`, `lang:`, `url:`, `list:`, `min_faves:`, `min_retweets:`, `min_replies:`, `filter:media|images|videos|links`. Operadores de local (`near:`, `within:`) deixaram de ser úteis. Nomes de filtros de engajamento diferem entre a web e APIs de terceiros.

## 3. Pivôs de alto valor

1. Handle em outras redes (`06`); foto de perfil (busca reversa); link e bio.
2. Interações: respostas, citações, quem menciona quem; horário dos posts (histograma por hora, `07`).
3. Listas públicas e hashtags; domínios compartilhados (`url:`).
4. Histórico de handles por arquivos da web e por ID.

## 4. Coleta

1. **Preservar** (`08`): URL do post, captura com data, HTML; ID da conta e dos posts.
2. Converter datas pelo ID (`decode_ids.py x`) e confirmar com a data exibida.
3. Registrar métricas **no momento** da coleta (mudam).
4. Exportação em escala exige API paga ou ferramentas de terceiros que mudam com frequência `[VOL]`: só em escala mínima e dentro dos termos.

## 5. Dorks e busca

```
site:x.com "palavra"
site:x.com/<handle>/status "palavra"
site:twitter.com "palavra"              # índice antigo
```
`scripts/dork_builder.py --platform x` gera as variações, incluindo a sintaxe de operadores nativos.

## 6. Armadilhas e limites

- Handle trocado pode ser reutilizado por outra pessoa: pivotar por ID.
- Contagens e selos mudam de significado com as políticas da plataforma.
- Contas protegidas, criadores em risco, ativistas e pessoas privadas: gate (`00`). Não contornar o muro de login com contas falsas ou raspagem.
- Coordenação (muitas contas repetindo o mesmo texto em poucos minutos): usar `analyze_export.py`, como indicador, nunca veredito (`07`).

## 7. Volatilidade e fontes

`[VOL]`: acesso sem login, operadores, API e preços, selos. Fontes: livro cap. 4 (microblogs); guias públicos de operadores de busca do X (2026) `[ADD]`; fórmula de snowflake `[ADD]`.
