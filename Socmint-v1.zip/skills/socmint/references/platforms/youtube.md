# YouTube — playbook enxuto `[ADD]`

Quando ler: investigação de canal, vídeo, comentário ou Shorts no YouTube; conferir data de publicação e reuso de vídeo. **Fora dos materiais do curso**: reconfirmar antes de afirmar. `last_reviewed: 2026-10`

## Conteúdo
1. Estrutura e identificadores
2. O que é visível sem login
3. Pivôs de alto valor
4. Coleta
5. Dorks
6. Armadilhas e limites
7. Volatilidade e fontes

## 1. Estrutura e identificadores

- Plataforma de vídeo (`03`, L p.63): canal, vídeos, Shorts, transmissões ao vivo, comunidade, playlists, comentários. Aberta para leitura.
- **ID do canal** alfanumérico `UC…` (estável; L p.271 cita o ID alfanumérico) e `@handle` mutável. **ID do vídeo** de 11 caracteres na URL `youtube.com/watch?v=<id>`.
- A primeira conta do YouTube de uma pessoa costuma refletir nome (e às vezes e-mail) da conta Google (L p.233): pivô para a identidade, **com gate** (`00`).

## 2. O que é visível sem login

- Aba **Sobre**: descrição, data de entrada, país, links externos (públicos sem login).
- Aba Vídeos, Shorts, Ao vivo e Comunidade, conforme o canal; contagem de inscritos pode estar oculta.
- Vídeo: título, descrição, tags visíveis, **data de publicação**, visualizações, curtidas, comentários, capítulos, legendas/transcrição quando existirem.
- **Data de publicação ≠ data de envio do arquivo**: a API documenta que a data pode diferir do upload (vídeo privado tornado público; agendado). Registrar como "publicado em" e não "enviado em".
- Miniaturas em vários tamanhos: busca reversa (Google Lens, Bing, TinEye, Yandex). A ferramenta YouTube DataViewer da Amnesty **saiu do ar** (verificado em out/2026); existem alternativas de terceiros `[VOL]`.

## 3. Pivôs de alto valor

1. Links na aba Sobre e na descrição (outras redes, loja, domínio → WHOIS).
2. Handle e nome do canal em outras plataformas (`06`).
3. Miniaturas, trechos do vídeo e quadros-chave em busca reversa (reuso de conteúdo, origem anterior).
4. Comentários recorrentes e respostas do dono; horários de publicação.
5. Playlists e canais inscritos quando públicos.
6. Descrição com e-mails e formas de contato comercial.

## 4. Coleta

1. **Preservar** (`08`): URL do canal e do vídeo, captura com data, HTML; baixar o vídeo só se for necessário ao caso e com atenção a direitos autorais.
2. Anotar ID do canal, handle, data de entrada, país, links.
3. Para vídeos: ID, data de publicação (UTC), título, descrição, contadores exatos, transcrição.
4. Para verificação de conteúdo: extrair quadros e fazer busca reversa; comparar primeira aparição pública.

## 5. Dorks

```
site:youtube.com "palavra"
site:youtube.com/@<handle>
site:youtube.com/channel "palavra"
```
`scripts/dork_builder.py --platform youtube` gera as variações.

## 6. Armadilhas e limites

- Contagens arredondadas; inscritos podem estar ocultos.
- Vídeo reenviado por terceiros com mesma imagem: comparar a primeira publicação.
- Menores de idade e conteúdo infantil: não coletar além do necessário; indício de abuso: parar e denunciar (`00`).
- Uso da API oficial exige chave (variável de ambiente) e cota; raspagem fora dos termos não é recomendada.

## 7. Volatilidade e fontes

`[VOL]`: layout das abas, ferramentas de metadados, regras de API. Fontes: livro cap. 4 e 8 (L p.63, 233, 271); documentação pública da API de dados do YouTube e guias de metadados `[ADD]`.
