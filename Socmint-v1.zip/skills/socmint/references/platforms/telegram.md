# Telegram — playbook

Quando ler: investigação de canal, grupo, usuário ou bot no Telegram; mapeamento de ecossistema que migrou para o Telegram; escolha de indexadores e dorks. Fontes: slides do Telegram (T) e slides do Discord (D s.60–65). `last_reviewed: 2026-10`

## Conteúdo
1. Estrutura e unidades
2. Identificadores
3. O que é visível
4. Pivôs de alto valor
5. Coleta passo a passo
6. Dorks, buscadores e indexadores
7. Ferramentas
8. Armadilhas
9. Limites e o que não fazer
10. Volatilidade e fontes

## 1. Estrutura e unidades

| Unidade | Como funciona (D s.64; limites oficiais) | Relevância |
|---|---|---|
| Chat privado | 1:1; pode expor username, foto, bio, status | Contexto de conta |
| Grupo (básico) | Até 200 membros; converte em supergrupo | Dinâmica social |
| Supergrupo | Até 200 mil membros, com histórico e permissões `[VOL]` | Comunidades grandes |
| Canal | Difusão um-para-muitos; seguidores ilimitados; só administradores postam e veem a lista de membros | Divulgação, comunicados, links externos |
| Bot | Conta automatizada com comandos (API) | Busca, pagamento, triagem, venda, moderação |
| Username / ID numérico | Identificador público + ID interno permanente | Pivô entre canais, grupos, usuários e bots |

Classificação (D s.63): o Telegram é **multiestrutura**. Canais públicos: aberta (leitura sem conta em `t.me/s/<canal>`). Grupos públicos: acesso por link ou busca. Grupos privados e chats secretos: fechada. Bots pagos e premium: camada híbrido-comercial.

Por que investigar (T s.5–6): criptografia (MTProto), grupos de grande escala e operações anônimas favorecem coordenação, golpes e conteúdo ilícito. Há também chats secretos com mensagens autodestrutivas e envio silencioso/agendado (T s.8).

## 2. Identificadores

| Item | Detalhe |
|---|---|
| ID numérico | Permanente; acessível por bots, app e Desktop (D s.65; T s.133). **Preservar primeiro**: o username muda livremente |
| Username | Trocável a qualquer momento; administradores costumam reutilizá-lo em outras plataformas (D s.65) |
| URLs (T s.83) | `t.me/<username>` · `t.me/<canal>` · prévia `t.me/s/<canal>` · convite `t.me/joinchat/<hash>` (e `t.me/+<hash>`) · vídeos `telesco.pe/<canal>`; também `telegram.me/...` |
| Telefone | `t.me/+<número>` abre o perfil se o titular não ocultou o número (L p.648). Associar número a pessoa é tratado na seção 9 |
| Data de criação | O ID **não** traz data; estimativas por faixa vêm de bots de terceiros (enviam o ID a terceiros) |

## 3. O que é visível (T s.77–80)

- **Usuário**: nome e sobrenome (alias), username, bio, foto, status de atividade, telefone e data de nascimento só se o titular os expõe.
- **Canal**: username, nome, ID, número de membros, número de postagens, posts com data, visualizações e links.
- **Grupo**: nome, ID, membros, mensagens, username.
- **Exportar chat e info de usuário** (Telegram Desktop, menu do chat → exportar histórico): HTML ou JSON, período e tipos de mídia; limite de tamanho de arquivo. Serve para preservar conversas em que a conta legítima já participa (T s.80).
- Dados úteis a extrair para pivotar: links `t.me`, usernames citados, encaminhamentos entre canais, convites, telefones e e-mails divulgados, padrões de spam e fraude (T s.81).

## 4. Pivôs de alto valor

1. **Cadeia de infraestrutura**: canal publica link para grupo → grupo aponta para bot → bot aponta para canal reserva (D s.65).
2. Username reutilizado em outras redes (`06`), em GitHub e LinkedIn (dorks da seção 6).
3. **Encaminhamentos** (forwards) entre canais: quem repassa quem revela rede de divulgação (Telerecon).
4. Links `t.me/...` e convites dentro de posts e fixados.
5. ID numérico de canal, grupo e usuário (estável).
6. Histórico de nomes e usernames (bots tipo SangMata guardam; resultado depende de quando o ID foi visto pelo bot).
7. Telefones, e-mails, domínios e carteiras divulgados em posts.
8. Fotos, textos repetidos e horários de postagem.

## 5. Coleta passo a passo

1. **Preservar** (`08`): URL, captura e HTML da prévia `t.me/s/<canal>`, foto, descrição, número de membros, data e hora UTC.
2. Anotar o ID e o username atual; guardar os convites que aparecerem.
3. Ler o canal público pela prévia web (sem conta) e salvar posts com data e link. Confirmar o fuso exibido; a exportação JSON do Desktop traz data e hora explícitas.
4. Extrair e classificar links `t.me`, usernames, domínios e telefones; montar o mapa de ecossistema (`03` seção 6).
5. Pesquisar o canal e os convites com dorks e indexadores (seção 6) para achar réplicas, histórico e canais relacionados.
6. Só então decidir se há necessidade de **entrar** (ação ativa): exige gate, conta própria de investigação e justificativa. Em golpes e fraudes, a coleta passiva da divulgação costuma bastar para a denúncia.

## 6. Dorks, buscadores e indexadores

Dorks (T s.84):
```
<palavra> site:t.me
<palavra> site:telegram.me
inurl:<nome-do-usuario-grupo-canal-ou-bot>
<palavra> t.me/joinchat/
site:t.me/joinchat inurl:<palavra>
"contact us" site:t.me
"phone number" site:t.me
"Telegram @username" site:linkedin.com
"Contact me on Telegram" site:github.com
```
`scripts/dork_builder.py --platform telegram` gera as variações e as URLs de busca.

**Google Custom Search Engines** (T s.85–92): Telegago, o de Francesco Poldi, Commentgram, BOSINTblanc, as ferramentas de Telegram do IntelX, o do WeVerify e o OSINTme. Localize-os pelo nome; podem sair do ar `[VOL]`.

**Indexadores e catálogos** (T s.93–101): Lyzem, Telemetr, Telemetrio, TgramSearch, TGViewer, TGStat, Tlgrm.eu, Xtea.io, Teleteg (declara mais de 517 milhões de canais indexados), Telemetry (exige cadastro). Servem para achar canais por tema, ver crescimento e cobrir canais já removidos; cobertura e precisão variam.

## 7. Ferramentas (função → risco; lista completa em `12`)

| Ferramenta | Função | Risco |
|---|---|---|
| Telethon e `python-telegram-bot` (T s.145) | Bibliotecas para scripts próprios | Exigem `api_id`/`api_hash` de `my.telegram.org` e conta logada; credenciais só em variáveis de ambiente |
| TelegramScraper, Telerecon, inTelligram, TEx (Telegram Explorer) | Coleta de membros, mensagens, encaminhamentos, URLs `t.me`, regras de busca (e-mails, etc.), exportação CSV/HTML (T s.105–114) | Usam conta de investigação logada; risco de bloqueio e de ToS; coleta de membros = dados pessoais |
| BotFather (T s.141–144) | Criar o **próprio** bot de alertas sobre canais públicos | Token em variável de ambiente |
| Bots de ID, histórico de nomes, data de criação, busca (T s.129–135) | Consulta rápida | O identificador consultado é enviado ao dono do bot, que pode registrá-lo |
| Navegação e indexadores (seção 6) | Descoberta | Termo buscado fica registrado no serviço |

## 8. Armadilhas

- Contagem de membros e visualizações é manipulável; não use como prova de alcance.
- Canais clonados e "espelhos" repetem conteúdo com ID diferente: comparar IDs.
- Bots de terceiros leem tudo o que você consulta (T s.127).
- Conta de investigação logada pode ser banida ou exposta em listas de membros.

## 9. Limites e o que não fazer

- **Configuração segura da conta do investigador**: lista completa em `02` seção 6 (T s.64–69).
- **Número virtual e compra via itens Steam / Skin Cash** (T s.38–61): a skill explica só que existem números descartáveis e seus riscos (reciclagem, bloqueio, vazamento, violação de ToS); **não** descreve o passo a passo de triangulação de pagamento. Alternativa: número ou eSIM corporativo dedicado.
- **Telefone → conta** (TG Phone Number Checker, TrueCaller Bot, bots de vazamento, bots de "puxada" de CPF, T s.116–117, 129–140): associa número a **pessoa física**; bots de "puxada" e de vazamento vendem dados obtidos ilicitamente, e usá-los é tratamento ilícito de dados e pode ser crime. O gate proíbe (`00`).
- **Pessoas próximas / GEOINT** (T s.118–125): o recurso "People Nearby" foi **removido em set/2024** (o próprio slide 119 traz a notícia); Geogramint e Telegram NearbyMap dependiam dele e não servem para localizar pessoas. GEOINT de conteúdo (imagens e metadados) continua válido (`07`).
- **Envio em massa, adicionar membros e raspagem agressiva** (TG Sender e similares): spam e violação de ToS.
- **Entrar em grupos privados com identidade falsa**: não instruir (`00`; infiltração virtual é de agentes de polícia, Lei 12.850/2013 art. 10-A).

## 10. Volatilidade e fontes

`[VOL]`: limites de grupo, indexadores, CSEs, bots, formato de convites, recursos de localização, política de números virtuais. Fontes: slides do Telegram (T s.1–154), slides do Discord (D s.60–65), limites oficiais em `core.telegram.org/api/channel`, remoção do People Nearby (The Verge/The Guardian, 06/09/2024) `[ADD]`.
