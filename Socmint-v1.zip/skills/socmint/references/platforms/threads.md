# Threads — playbook

Quando ler: investigação de perfil ou publicação no Threads, ou quando o Instagram do alvo é privado e há dúvida se o Threads é aberto. Fonte principal: livro cap. 11 (2024). `last_reviewed: 2026-10` (conteúdo do livro **não** revalidado na plataforma)

## Conteúdo
1. Estrutura e unidades
2. Identificadores
3. O que é visível
4. Pivôs de alto valor
5. Coleta passo a passo
6. Dorks
7. Ferramentas
8. Armadilhas
9. Limites e o que não fazer
10. Volatilidade e fontes

## 1. Estrutura e unidades (L p.590–592)

App independente que usa as credenciais do Instagram: todo usuário do Threads tem conta no Instagram, e o perfil só pode ser apagado apagando a conta do Instagram (política de privacidade citada pelo livro). Username, nome e selo de verificação são importados do Instagram; bio e links podem ser editados à parte. Publicações: Threads, Respostas e Republicações; URL `threads.com/@<username>` (o site migrou de `threads.net` para `threads.com` em abr/2025; `.net` redireciona) `[VOL]`.

Por que investigar: o usuário trata o Threads como extensão do Instagram e escreve ali o que não publica no Instagram. Um perfil **privado** no Instagram pode ter threads públicos (L p.591–592, 553).

## 2. Identificadores

| Item | Onde | Observação |
|---|---|---|
| ID da conta | código-fonte: `user_id`, `userID`, `container_id` | Mesmo universo de contas do Instagram (L p.592–593) |
| Username e nome | `username`, `full_name` | Importados do Instagram |
| Bio e links | `biography`, `bio_links` | Editáveis separadamente |
| Foto | `profile_pic_url`, `hd_profile_pic_versions` | A URL no código-fonte vem com barras invertidas: removê-las para abrir (L p.597) |
| Seguidores | `follower_count` | Número exato no código-fonte (L p.596) |
| Publicação | `threads.com/@<user>/post/<código>`; data em `taken_at` (Unix) | `decode_ids.py unix` (L p.602–603) |

## 3. O que é visível

- Menu "…" → **Sobre este perfil**: data de entrada, **posição de registro** (conta nº N do Threads), localização, data de verificação pela Meta e aviso quando o usuário mudou de nome no Instagram (L p.600–602).
- Seguidores e seguidos do Threads **não coincidem** com os do Instagram: ampliam o mapa de contatos (L p.592).
- Atividades da publicação (curtidas) abrem em lotes de cerca de 20; é preciso rolar a lista (L p.604).
- Dados exatos de perfil também aparecem nas respostas GraphQL que o navegador já carrega (aba Rede/Network, filtro `graphql`): seguidores, seguidos e ID (L p.606–607). A skill ajuda a **interpretar** o trecho que o usuário colar.

## 4. Pivôs de alto valor

1. Perfil do Instagram ↔ Threads (botão na bio; mesmo username e ID).
2. `bio_links` e texto da bio, que podem diferir do Instagram.
3. Seguidores e seguidos do Threads (rede diferente).
4. Posts e respostas (texto, fotos, horário `taken_at`).
5. Posição de registro e data de entrada para estimar a antiguidade da conta.

## 5. Coleta passo a passo

1. **Preservar** (`08`): URL, captura, HTML, foto de perfil (ampliada, em círculo, no clique) com hash.
2. Anotar ID, username, `follower_count` e "Sobre este perfil".
3. Para cada post: URL, `taken_at`→UTC, texto, mídia original, respostas.
4. Listas de atividade (curtidas) e seguidores: coleta em pequena escala, com rolagem e extensão de extração (`12`), respeitando ToS.

## 6. Dorks (L p.608, ajustados)

```
site:threads.com/@ "palavra"           # usuários e texto de bio
site:threads.com/t/ "palavra"          # publicações
site:threads.net/@ "palavra"           # índice antigo
site:threads.net/t/ "palavra"
```

Caminhos `/t/` e `/@` devem ser revalidados no domínio atual `[VOL]`. `scripts/dork_builder.py --platform threads` gera as duas famílias.

## 7. Ferramentas

Instant Data Scraper (tabelas), Simple AutoScroll (rolagem), EpochConverter/`decode_ids.py` (datas). Lista completa e riscos em `12`.

## 8. Armadilhas

- Username igual no Instagram e no Threads **é a mesma conta**, não um indício independente.
- Quem muda de nome no Instagram aparece com aviso no Threads (L p.602).
- Posts e respostas podem ser removidos: preservar antes de pivotar.

## 9. Limites e o que não fazer

- Perfil privado no Instagram com Threads público: o que é público pode ser coletado; **não** usar isso para contornar a privacidade do Instagram (pedido de amizade com identidade falsa, engenharia social).
- Coleta em massa de seguidores só em escala mínima e para entidades de interesse; pessoa privada pede gate (`00`).

## 10. Volatilidade e fontes

`[VOL]`: domínio e caminhos, chaves do código-fonte, GraphQL, limites de listas. Fonte: livro cap. 11 (L p.590–608); migração de domínio (TechCrunch/The Verge, 24/04/2025) `[ADD]`.
