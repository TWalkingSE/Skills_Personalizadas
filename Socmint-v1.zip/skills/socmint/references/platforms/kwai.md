# Kwai — playbook enxuto `[ADD]`

Quando ler: investigação de perfil, vídeo ou campanha no Kwai, rede de vídeos curtos muito usada no Brasil. **Fora dos materiais do curso**: os fatos vêm de guias públicos e de verificação de páginas públicas da plataforma; reconfirmar antes de afirmar. `last_reviewed: 2026-10`

## Conteúdo
1. Estrutura e identificadores
2. O que é visível sem login
3. Pivôs de alto valor
4. Coleta
5. Dorks
6. Armadilhas e limites
7. Volatilidade e fontes

## 1. Estrutura e identificadores

- Versão internacional do app da Kuaishou; feed algorítmico de vídeos curtos, como o TikTok (`03` seção 4). Rede **híbrida**: perfis e vídeos têm página web pública, e o app pede conta para quase tudo.
- **Kwai ID**: identificador da conta. É atribuído automaticamente (letras e números aleatórios) e pode ser personalizado **uma única vez**, com 5 a 20 caracteres, segundo guias públicos `[VOL]`. É o `@` da URL do perfil: `kwai.com/@<kwai_id>` `[VOL; verificado 2026-10]`. Registre que o ID pode ter sido trocado uma vez: o ID atual não prova que era o mesmo na época do fato.
- **Nome de usuário** (nome exibido): troca livre, sem limite `[VOL]`. Não serve para reencontrar a conta.
- **Vídeo**: ID numérico longo nas URLs web (`kwai.com/…/video/<id>`) `[VOL; verificado 2026-10]`. Não há fórmula pública conhecida para extrair data do ID: não decodificar; usar a data mostrada na página ou no código-fonte e dizer de onde veio.
- Não há nesta skill um ID numérico interno do perfil confirmado. Se o código-fonte trouxer um, preserve-o e teste se ele resolve o perfil antes de tratá-lo como estável.

## 2. O que é visível sem login

- **Perfil**: nome exibido, Kwai ID, bio, foto e lista de vídeos. Contadores podem não carregar sem JavaScript `[VOL; verificado 2026-10]`.
- **Vídeo**: legenda, menções (`@`), curtidas e número de comentários. O número exibido na página e o da metadescrição podem divergir: registrar os dois e a hora `[VOL; verificado 2026-10]`.
- A web mostra menos que o app. O app exige conta: só conta de investigação, nunca a pessoal (`02`).

## 3. Pivôs de alto valor

1. Kwai ID em outras plataformas (`06`; `social-media-intelligence`): é comum repetir o handle do TikTok ou do Instagram.
2. Bio: links, WhatsApp e chave PIX, frequentes em golpes de "renda extra", sorteios e vendas → `financial-intelligence`, `domain-intelligence`.
3. Vídeos repostados de TikTok ou YouTube: busca reversa de quadros (`07` seção 8) para achar a origem e o autor original.
4. Comentários: o mesmo texto em vários vídeos, de contas recentes → export pequeno e `analyze_export.py` (indicadores, não veredito).
5. Hashtags e áudios usados em série.

## 4. Coleta

1. **Preservar** (`08`): URL do perfil e de cada vídeo, captura, HTML, Kwai ID, nome exibido, bio e contadores no momento da coleta.
2. Vídeo: baixar só se for necessário ao caso (direitos autorais, fidelidade da mídia), com hash; registrar a data de publicação exibida e a fonte dela.
3. Anotar o nome exibido a cada coleta, porque ele muda sem limite.
4. Conteúdo apagado: procurar a URL em arquivos da web (`08` seção 6) e verificar se há snapshot antes de contar com ele.

## 5. Dorks

```
site:kwai.com "palavra"
site:kwai.com/@<kwai_id>
site:kwai.com inurl:video "palavra"
"kwai.com/@<kwai_id>"                 # onde o perfil é divulgado
```
`scripts/dork_builder.py --platform kwai` gera as variações.

## 6. Armadilhas e limites

- Kwai ID igual em outra rede não prova identidade (`06`).
- O nome exibido nunca é identificador.
- Em janeiro de 2024 o MPF anunciou inquérito civil sobre suspeita de que a própria plataforma, diretamente ou por agências contratadas, criava perfis falsos (inclusive imitando órgãos públicos) e conteúdo falso para gerar engajamento (Poder360, 18/01/2024) `[VOL]`. Um perfil sem histórico pode não ter um operador individual por trás: registre essa hipótese quando couber.
- Muitos usuários são menores: não coletar sobre menor; indício de abuso → parar e orientar denúncia (`00` seção 4).
- Raspagem ou exportação em escala viola os termos: só escala mínima e necessária ao caso.

## 7. Volatilidade e fontes

`[VOL]`: regras do Kwai ID, formato das URLs, o que a web mostra sem login. Fontes `[ADD]`: guias públicos sobre a troca do Kwai ID (Tecnoblog; Olhar Digital, 2021), páginas públicas em kwai.com verificadas em out/2026, notícia do inquérito do MPF (Poder360, 18/01/2024).
