# WhatsApp — playbook

Quando ler: investigação de grupo, canal ou comunidade de WhatsApp, análise de convites públicos, ou pedido que envolva descobrir quem está por trás de um número. Fonte principal: livro cap. 12 (2024) e slides do Discord (D s.84–86). `last_reviewed: 2026-10` (itens `[VOL]` precisam de reconferência)

## Conteúdo
1. Estrutura e unidades
2. Identificadores
3. O que é visível sem entrar
4. Pivôs de alto valor
5. Coleta passo a passo
6. Dorks
7. Ferramentas
8. Armadilhas
9. Limites e o que não fazer
10. Volatilidade e fontes

## 1. Estrutura e unidades (L p.609–612)

- **Grupos**: até 1.024 pessoas `[VOL]`; **os números de telefone dos membros ficam visíveis aos outros membros**; administradores podem apagar mensagens; mensagens temporárias (24 h, 7 d, 90 d).
- **Canais** (desde out/2023): difusão unidirecional por administrador; seguidores só reagem com emojis; nomes de seguidores visíveis só aos administradores; ninguém vê o contato dos seguidores.
- **Comunidades**: coleção de grupos; membros veem o total de participantes dos outros grupos, não os contatos; existe um grupo "Anúncios" que reúne todos, só administradores publicam.
- Por que investigar: o app concentra golpes e crimes em grupos privados e comunidades. Entrar em grupo ou canal exige pedido ao administrador ou link aberto, e o número do investigador fica visível ao menos aos administradores (L p.612).

## 2. Identificadores

| Item | Detalhe |
|---|---|
| Conta | Número de telefone no formato E.164 (+país+DDD+número) (D s.84; L p.241). `wa.me/+<número>` abre conversa e indica se o número tem WhatsApp |
| Username | Reservas abertas em 29/06/2026, rollout gradual por país; 3–35 caracteres; um por conta, único; sem diretório público nem autocompletar; **chave de username opcional** que o contato precisa conhecer; quem inicia conversa com username não vê o telefone `[VOL]`. O slide chama essa identidade de LID e destaca que a ausência de diretório limita a enumeração (D s.84–85) |
| Grupo | Convite `chat.whatsapp.com/<código>` (ou `/invite/<código>`) |

O número do criador do grupo aparece como primeiro administrador; a descrição do grupo exibe, por padrão, o número do criador e a data e hora de criação (L p.622–623).

## 3. O que é visível sem entrar

Pela página do convite: **nome**, **foto** e o próprio **link**. Link sem nome e com imagem genérica indica convite expirado ou grupo inválido (L p.619). Pelo número: `wa.me`, e a foto de perfil se as configurações de privacidade do titular permitirem (L p.633–635).

## 4. Pivôs de alto valor (investigação "de fora", L p.615–619)

1. **Link** do convite: buscar o link exato em buscadores revela anúncios e compilações que o divulgam.
2. **Foto do grupo**: busca reversa (Google Lens) acha publicações idênticas, idioma e país de origem.
3. **Nome do grupo**: outras divulgações e datas; a data do anúncio mais antigo indica desde quando o grupo opera.
4. Origem do link: fórum, Reddit, grupo de Facebook, site agregador; o contexto diz a quem o grupo se destina.
5. Ecossistema: o mesmo grupo costuma ter canal "vitrine" aberto, bot e grupo de backup (`03`).

## 5. Coleta passo a passo

1. **Preservar** (`08`): URL do convite, captura da prévia (nome e foto), foto com hash, data e hora UTC.
2. Registrar onde o convite foi publicado (URL, data) e cada anúncio que o repete.
3. Busca reversa da foto e busca pelo nome; anotar idioma, país e datas.
4. **Parar aqui** se o próximo passo for entrar. Entrar é ação **ativa**: o número fica exposto, vale o gate (`00`), exige conta e número próprios de investigação e justificativa. Em grupos de golpe, a coleta passiva da divulgação costuma bastar para denúncia.

## 6. Dorks

```
intext:chat.whatsapp.com/invite/ intitle:palavra
site:chat.whatsapp.com "palavra"                       # convites abertos indexados (D s.86)
"https://chat.whatsapp.com/<código>"                    # onde o link é divulgado
```

`scripts/dork_builder.py --platform whatsapp --intent invite` gera as variações.

## 7. Ferramentas

| Ferramenta | Função | Risco |
|---|---|---|
| Google Lens / buscas reversas de imagem | Foto do grupo | Imagem enviada a terceiro |
| Repositórios de convites por tema | Descobrir grupos | **Podem divulgar grupos de abuso sexual infantil** (ver seção 9) |
| `web.whatsapp.com` | Cliente web (vincula um telefone) | Exige conta; extensões de terceiros leem as conversas |

## 8. Armadilhas

- Número do criador = primeiro administrador; a lista de "membros anteriores" pode mostrar quem saiu ou foi removido, mas só a quem é membro.
- Convite válido hoje pode expirar: preservar já.
- Um username novo esconde o telefone, mas não a identidade comportamental.

## 9. Limites e o que não fazer

**Alerta crítico (L p.615):** sites de convites podem anunciar grupos de abuso sexual infantil. Estar em um grupo assim é crime na maioria dos países. Se aparecer indício, **interrompa, não entre, não baixe** e oriente a denúncia (SaferNet Brasil, Disque 100, polícia) `[VOL]`.

O livro detalha técnicas que a skill trata **só em nível conceitual**, sem passo a passo:
- **Associar número a pessoa** (L p.639–654): cruzar vazamentos, agendas filtradas de bots tipo Truecaller, simulação de transferência bancária, consultas Skype/Telegram por número, WHOIS histórico. Identifica **pessoa física** pelo telefone, o que o gate proíbe (`00`). Alternativas lícitas: consentimento, dados que o titular publicou, registros públicos de empresas, ofício judicial.
- **Monitorar horário de conexão** de um número e **notificações de "online"** (L p.657): vigilância; não instruir.
- **Recuperar mensagens apagadas, ver status e ouvir áudios sem aviso** com extensões (L p.654–659): quebra a expectativa de privacidade de terceiros; não instruir.
- **Extrair a lista de telefones dos membros** de um grupo (L p.626–633): coleta em massa de dados pessoais; só em contexto autorizado e minimizado.
- **Infiltração com identidade falsa**: o ordenamento brasileiro admite infiltração virtual por **agentes de polícia** com autorização judicial (Lei 12.850/2013, art. 10-A). Particular não.
- **Gerador de prints falsos** (L p.662): não.

Autodefesa: o mesmo livro recomenda revisar as configurações de privacidade (foto, "visto por último", grupos); ver `10`.

## 10. Volatilidade e fontes

`[VOL]`: limites de grupo, canais e comunidades, usernames e chave, visibilidade da foto, estrutura de convites. Fontes: livro cap. 12 (L p.609–662); slides do Discord (D s.84–86); anúncio oficial de usernames do WhatsApp (29/06/2026) `[ADD]`.
