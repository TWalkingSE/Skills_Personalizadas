# TikTok — playbook

Quando ler: investigação de perfil, vídeo, comentário ou campanha no TikTok; extração de IDs e datas do código-fonte; conta apagada. Fonte principal: e-book *TikTok Intelligence* (K, 2026) e slides do Discord (D s.55, 82–83). `last_reviewed: 2026-10` (chaves do código-fonte do e-book não revalidadas)

## Conteúdo
1. Estrutura e unidades
2. Identificadores e chaves do código-fonte
3. O que é visível
4. Pivôs de alto valor
5. Coleta passo a passo
6. Dorks
7. Ferramentas
8. Armadilhas
9. Limites e o que não fazer
10. Volatilidade e fontes

## 1. Estrutura e unidades (K c.2–4)

Rede de vídeos curtos (15 s a 10 min) derivada do Douyin; lançada em 2016 e internacional desde 2017, presente em mais de 250 países. Recomendação por IA e feed algorítmico; produtos à venda; integração com outras redes. O TikTok foi construído sobre um **grafo de interesse** (mostra o que prevê que você vai gostar, não quem você segue) (D s.55). Tipo de rede: híbrida; anonimato baixo a médio; relevância: padrões de áudio e hashtag e rede de interações (D s.52).

Os dados vivem em quatro camadas (K c.2.2): interface (o que se vê), **código-fonte** (HTML/JSON), requisições de API e metadados de vídeos e comentários. A investigação eficaz precisa ir além da interface.

- **Perfil** (K c.4.1): foto (muda a qualquer hora), Unique ID (`@`), selo de verificação, nickname, barra de interação (seguidores, seguindo, curtidas totais), bio, links externos.
- **Vídeos** (K c.4.2): filtro de ordenação, republicações, curtidas, barra temporal, fixados, visualizações por vídeo.
- **Post** (K c.4.3, c.7): URL única, ID, data e hora, descrição, música/áudio, métricas (curtidas, comentários, salvos), comentários com avatar, nickname, texto e horário.

## 2. Identificadores e chaves do código-fonte

| Item | Chave / forma | Observação |
|---|---|---|
| **User ID** | `userInfo`, `id` | **Imutável**; permanece mesmo com mudança de nickname e de `uniqueId`; essencial para rastreio de longo prazo (K c.5.2) |
| `secUid` | idem | Identificador estável usado por APIs e ferramentas (D s.83) |
| `uniqueId` | `uniqueId` | O `@` da URL; muda a cada **30 dias**; o antigo fica retido por um tempo. Guardar handles antigos para buscas retrospectivas (K c.6.2; D s.82) |
| `nickname` | `nickname` | Muda a cada **7 dias**; a busca devolve vários resultados: o correto fica próximo do ID já coletado (K c.6.3) |
| Verificação | `verified` (`true`/`false`) | (K c.6.4) |
| Assinatura | `signature` | Texto da bio (K c.6.5) |
| Link da bio | `bioLink` | Pivô para outra rede ou site (K c.6.6) |
| Criação da conta | `createTime` (Unix s) | Converter para data legível (K c.6.7) |
| Contadores exatos | `videoCount`, `followingCount`, `followerCount`, `heartCount` | A interface arredonda; o código traz o valor absoluto (K c.6.1, c.6.8) |
| Post | `tiktok.com/@<usuário>/video/<id>` (também `/image/`, `/post`) | ID numérico longo (K c.7.1–7.2) |
| Data do post | `createTime` do post no código-fonte; `id >> 32` = Unix s `[ADD]` | Confirmar com `createTime` (K c.8.1); `decode_ids.py tiktok-video <id>` |
| Data do comentário | `create_time` na resposta JSON da aba Rede (arquivo que começa com `list/?Web…`) | **Diferente** do `createTime` de perfil e post (K c.8.3) |

Reverso ID → conta: colocar o ID numérico após `@` na URL do navegador `[VOL]`, ou ferramentas "TikTok User Finder" (K c.6.2). Não é necessário estar logado para ler o código-fonte do perfil (K c.5.3).

**Correção do e-book**: o c.4.1 chama o Unique ID de "imutável" e na mesma frase diz que muda a cada 30 dias. O imutável é o **User ID**.

## 3. O que é visível

Sem login: perfil público e seu código-fonte, posts públicos, comentários na aba do post. Com login: exportações e listas de seguidores por extensões (exigem conta; usar **conta de investigação**, jamais a pessoal, K c.9.2). Espelhos mostram versões antigas sem login (K c.10).

## 4. Pivôs de alto valor (K c.13.3, c.14.1; D s.52)

1. Username em outras plataformas (`06`).
2. **Link da bio** → WHOIS e infraestrutura (domínio registrado há pouco tempo é indício).
3. E-mail encontrado em outra rede → novos cadastros e fóruns.
4. **Foto de perfil** → busca reversa (Yandex Images, Bing Visual Search, Google Lens).
5. Interações recorrentes e contas que repetem comentários; avatares genéricos e contas recentes (`07`).
6. Áudio e hashtags usados, padrões de postagem.
7. Seguidores e seguindo (exportação) e sobreposição entre perfis.

## 5. Coleta passo a passo

1. **Preservar** (`08`): URL, captura, e, se o caso permitir, "Salvar página agora" no Wayback (cria cópia pública, K c.10.4).
2. Abrir o código-fonte: `Ctrl+U` (Windows/Linux), `Cmd+Option+U` (macOS), ou `F12` → Inspecionar. Buscar com `Ctrl+F` (K c.5.1): `userInfo`, `id`, `uniqueId`, `nickname`, `verified`, `signature`, `bioLink`, `createTime`, `videoCount`, `followerCount`, `followingCount`, `heartCount`.
3. Converter timestamps: EpochConverter, ferramenta TikTok Timestamp da Bellingcat, Unfurl, ou `decode_ids.py unix` (K c.8.2).
4. Em cada post: ID, `createTime`, métricas exatas e URL permanente.
5. **Comentários com horário**: ferramentas de desenvolvedor (`F12`) → Rede → Fetch/XHR → atualizar a página → abrir a aba de comentários → copiar um nickname e colar na busca → abrir o arquivo `list/?Web…` em nova aba → buscar `create_time` (K c.8.3).
6. Exportar seguidores e comentários em pequena escala com extensões (TTExporter, TTCommentExporter, Instant Data Scraper; CSV/XLSX) apenas com conta de investigação e dentro dos termos (K c.9.2–9.3).
7. Bookmarklets de investigação mostram em um clique username, display name, TikTok ID, data de criação e URL (K c.9.4).
8. Conta apagada ou banida: espelhos (Tikvib, Tikface, Urlebird) e Wayback (`08` seção 6; K c.10–11).
9. Registrar tudo no log e relatar com Observação/Inferência/Desconhecido (`09`).

## 6. Dorks (K c.9.1)

```
"Anitta" site:tiktok.com                  # por nome
"@anitta" site:tiktok.com                 # por uniqueId
site:tiktok.com #flamengo                 # por hashtag
site:tiktok.com "descrição específica"    # por texto de descrição
```
`scripts/dork_builder.py --platform tiktok` gera as variações.

## 7. Ferramentas (função → risco; lista completa em `12`)

| Ferramenta | Função | Risco |
|---|---|---|
| Commentpicker, TikTok User Finder, Fameswap | ID ↔ conta | O identificador consultado vai a terceiros |
| TikTok Timestamp (Bellingcat), EpochConverter, Unfurl | Datas, URLs | Baixo (prefira local) |
| TikTok Quick Search (OSINT Combine), Mavekite, Timetotok | Busca e análise de perfil | Terceiros; dados desatualizados |
| Downloaders (sem marca d'água) | Baixar vídeos | Direitos autorais; fidelidade da mídia |
| Tikvib, Tikface, Urlebird, Wayback | Espelhos e histórico | Snapshots estáticos e incompletos |
| TTExporter, TTCommentExporter, Instant Data Scraper | Exportar seguidores e comentários | Exigem login, ToS |
| TikSpyder (SerpAPI, Apify, yt-dlp) e Clawk | Coleta por linha de comando, JSON/CSV | Chaves de API em variável de ambiente (K c.12.1); custo; ToS |

## 8. Armadilhas

- `nickname` aparece várias vezes no código-fonte; validar contra o ID (K c.6.3).
- Espelhos atrasados: cruzar fontes (K c.10.2, c.16.2).
- "Código-fonte não carrega": conteúdo dinâmico; aguardar o carregamento completo (K c.16.2). "Acesso negado" por bloqueio de IP: o e-book sugere VPN ou proxy; trate como limite de taxa ou de termos e prefira esperar ou mudar de fonte, sem contornar bloqueio.
- Timestamp de comentário ≠ timestamp de post.
- Contagens exatas só no código-fonte; a interface arredonda.

## 9. Limites e o que não fazer (K c.15)

- Os termos do TikTok proíbem raspagem não autorizada; LGPD e GDPR se aplicam a dados pessoais. Usar só dados públicos, não sobrecarregar servidores, documentar métodos, proteger o que for coletado.
- **Nunca** usar conta pessoal para exportações (K c.9.2).
- Pessoa privada, menor, vítima ou denunciante: gate (`00`). TikTok tem muitos menores: não coletar.
- Baixar vídeos de terceiros em massa envolve direitos autorais e privacidade: só o necessário ao caso.

## 10. Volatilidade e fontes

`[VOL]`: nomes de chaves, regras de troca de handle (30 d / 7 d), ferramentas e espelhos, acesso sem login, limites de exportação. Fontes: e-book *TikTok Intelligence* (K c.1–17; recursos e bibliografia); slides do Discord (D s.52, 55, 82–83); `id >> 32` conforme a ferramenta TikTok Timestamp da Bellingcat `[ADD]`.
