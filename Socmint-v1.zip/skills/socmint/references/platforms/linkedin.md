# LinkedIn — playbook enxuto `[ADD]`

Quando ler: due diligence, verificação de vínculo profissional, recrutador ou empresa falsos, perfis usados em golpes de emprego. **Fora dos materiais do curso**: reconfirmar antes de afirmar. `last_reviewed: 2026-10`

## Conteúdo
1. Estrutura e identificadores
2. O que é visível
3. Pivôs de alto valor
4. Coleta
5. Dorks
6. Armadilhas e limites
7. Volatilidade e fontes

## 1. Estrutura e identificadores

- Rede **híbrida** voltada a currículo e contatos profissionais; usuários **querem ser encontrados** (L p.230). Unidades: perfil, página de empresa, vaga, publicação, grupo.
- IDs alfanuméricos (L p.271). A URL pública traz um *slug* mutável: `linkedin.com/in/<slug>` e `linkedin.com/company/<slug>`. Identificadores internos aparecem no código-fonte `[VOL]`.
- Perfil costuma usar **nome real e foto real do rosto** (L p.291): facilita cruzar dados, e exige cuidado com homônimos.

## 2. O que é visível

- Sem login, o acesso a perfis é limitado e variável; buscadores indexam parte dos perfis públicos `[VOL]`.
- Perfil: nome, cargo, empresa atual e anteriores com datas, formação, localidade, resumo, habilidades, publicações. A plataforma exibe informações como data de entrada e verificação de contato/empresa em um painel "sobre este perfil" `[VOL]`.
- Empresa: descrição, setor, tamanho, sede, funcionários listados, vagas, publicações.
- Documentos em PDF compartilhados pelo usuário (apresentações e currículo) podem conter metadados e dados de contato (L p.51).

## 3. Pivôs de alto valor

1. Nome + cargo + empresa → registros públicos da empresa (por exemplo, consulta a cadastros societários) e site oficial.
2. Foto → busca reversa (golpes de recrutador reutilizam fotos de banco de imagens).
3. E-mail corporativo do domínio da empresa vs. e-mail genérico do "recrutador".
4. Slug e nome em outras redes (`06`); links de portfólio, GitHub, Medium.
5. Vagas: texto repetido em outros sites, domínio, data de publicação.
6. Datas de início e fim de cargos para verificar coerência (linha do tempo, `07`).

## 4. Coleta

1. **Preservar** (`08`): URL, captura com data, PDF da página se o caso exigir.
2. Registrar nome exato, cargo, empresa, datas, localidade, link, conexão em comum visível, data de entrada se exibida.
3. Para golpes de emprego: preservar a vaga, o e-mail do contato, o domínio e o fluxo pedido (pagamento antecipado, dados bancários), e denunciar à plataforma.

## 5. Dorks

```
site:linkedin.com/in "Nome Sobrenome"
site:linkedin.com/company "nome da empresa"
site:linkedin.com/jobs "título da vaga" "empresa"
intext:"Nome Sobrenome" site:linkedin.com -inurl:/in/slug-ja-achado
```
Dica do livro (L p.232): `intext:"Nome Sobrenome" site:linkedin.com` ajuda a associar nome a perfil. `scripts/dork_builder.py --platform linkedin` gera as variações.

## 6. Armadilhas e limites

- Os termos do LinkedIn proíbem raspagem automatizada; coleta em escala via ferramentas de terceiros viola os termos e expõe a conta.
- Perfil profissional não equivale a consentimento para qualquer uso: LGPD, finalidade e necessidade (`00`).
- Perfis falsos de recrutador e de executivo são comuns em golpes: sinais são perfil recente, poucas conexões, foto reutilizada e erro de domínio no e-mail (`07`).
- Pessoa privada fora do contexto profissional: gate.

## 7. Volatilidade e fontes

`[VOL]`: visibilidade sem login, painéis de verificação, limites da busca interna, IDs no código-fonte. Fontes: livro cap. 4 e 8 (L p.51, 230–232, 271, 291) e termos de uso públicos `[ADD]`.
