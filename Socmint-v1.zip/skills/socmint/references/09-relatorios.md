# 09 — Relatórios

Quando ler: ao consolidar achados, redigir resumo executivo, entregar relatório ou revisar um já escrito. Script: `scripts/make_report.py`. Modelo: `assets/relatorio-odpar.md`. `last_reviewed: 2026-10`

## Conteúdo
1. Estrutura
2. Regras de escrita
3. Achados: Observação, Inferência, Desconhecido
4. Visuais
5. Redução de PII
6. Variantes por contexto
7. Exemplo de achado
8. Checklist final
9. Exportar para o Investigative Notebook

## 1. Estrutura (K c.13.5, ampliada)

1. **Capa e metadados**: ID do caso, título, data/hora UTC, fuso, autor, versão, classificação.
2. **Resumo executivo**: conclusão principal, nível de confiança e recomendação em até 10 linhas.
3. **Objetivo e perguntas de investigação** (as do gate, `00`).
4. **Escopo e base legal**: contexto de autorização, categoria do alvo, restrições, retenção.
5. **Metodologia**: ODPAR, plataformas e fontes, período, ferramentas e versões, camadas de preservação, nível de OPSEC. Descrever só o que foi feito: `make_report.py` monta esta seção a partir dos arquivos do caso (log de evidências, `pivos.csv`, achados, linha do tempo, grafo, campo `ferramentas` do `case.json`) e marca o que faltar.
6. **Evidências**: tabela com ID, descrição, URL, data/hora UTC, hash (vem do `evidence_log`).
7. **Achados**: um por linha, com tipo (Observação/Inferência/Desconhecido), evidências ligadas, confiança, Admiralty (`07`).
8. **Análise**: linha do tempo, mapa de vínculos, hipóteses × evidências.
9. **Conclusões e recomendações**: acionáveis (denúncia à plataforma, takedown, bloqueio, preservação adicional, encaminhamento a autoridade).
10. **Limitações**: o que não foi possível saber e por quê.
11. **Anexos**: log de evidências, planilhas, grafo, glossário.

## 2. Regras de escrita

- Claro, técnico, **reprodutível** e baseado em evidências; orientado à decisão (K c.13.5–13.6).
- Datas em UTC com fuso do caso entre parênteses.
- Linguagem de confiança calibrada (`07`): evitar "provavelmente" sem nível; evitar "é o responsável" quando só há correlação.
- Estilo de conclusão do EPUB (K c.14.1): afirmar o que as evidências sustentam e declarar com todas as letras o que **não** foi possível concluir (por exemplo, "não foi possível identificar o responsável com alto grau de confiança apenas com técnicas OSINT e informações públicas").
- Cada afirmação aponta para IDs de evidência (`EV-0007`). Sem evidência ligada, é Inferência ou Desconhecido.
- Nada de adjetivos sobre pessoas; descrever comportamento observável.

## 3. Achados: Observação, Inferência, Desconhecido

| Tipo | Definição | Exemplo |
|---|---|---|
| **Observação** | Fato verificável, com fonte e hora UTC | "O perfil `@x` tem `verified=false` no código-fonte coletado em 2026-10-13T14:22Z (EV-0003)" |
| **Inferência** | Conclusão tirada de observações; informar base e confiança | "A conta foi criada em 2026-01-24 (decodificação do ID do vídeo; confiança moderada: confirmar com `createTime`)" |
| **Desconhecido** | Pergunta sem resposta nas fontes consultadas | "Titular real da conta: não determinado" |

Planilha de achados: `assets/findings.template.csv` (colunas `id, tipo, afirmacao, evidencias, admiralty_fonte, admiralty_info, confianca, data_utc, notas`). A coluna `notas` sai no relatório: use-a para ressalvas como "indicadores, não prova de bots".

Hipóteses no `case.json`: `confirma` e `refuta` são **critérios** definidos no planejamento ("o que confirmaria", "o que refutaria"); as evidências efetivamente ligadas vão em `evidencias_favor` e `evidencias_contra` (IDs `EV-…`). O relatório mostra as duas coisas em colunas separadas e avisa quando uma hipótese avaliada não tem evidência ligada.

## 4. Visuais

- **Linha do tempo** (CSV `data_utc, evento, evidencia`): criação da conta, mudanças de handle, picos de postagem, eventos externos.
- **Mapa de vínculos**: `scripts/build_graph.py` gera Mermaid (`.mmd`), GraphML, DOT e CSV para Gephi; no chat, entregar como artefato Mermaid se disponível, senão como arquivo. A coluna `tipo` das arestas separa `identidade` (candidato a mesma pessoa/operador; só este tipo entra na regra de corroboração de `06`), `associacao` (aponta para, usa, publica) e `imitacao` (usa marca ou identidade de terceiro, desenhada em vermelho). Um perfil falso ligado à empresa imitada por `imitacao` **não** é vínculo entre eles.
- **Tabelas de IDs** por plataforma e capturas anotadas.

## 5. Redução de PII

- Mascarar e-mails, telefones e IDs de terceiros não centrais (`make_report.py --redact`). O mascaramento alcança também o diagrama do grafo; a imagem PNG do grafo é omitida na versão mascarada, porque texto dentro de imagem não pode ser mascarado.
- Pseudonimizar terceiros (P1, P2) e manter a chave em anexo restrito.
- Não incluir imagem de rosto de terceiros sem necessidade; preferir hash e descrição.
- Marcar o anexo restrito e a nota de confidencialidade na capa.

## 6. Variantes por contexto

| Contexto | Ênfase |
|---|---|
| Perícia/compliance | Cadeia de custódia completa, hashes, versões de ferramentas, glossário, assinatura, quesitos respondidos um a um |
| Jornalismo/checagem | Método de verificação, fontes independentes, direito de resposta, proteção de fontes e vítimas |
| CTI/fraude/marca | IOCs (handles, IDs, URLs, domínios, hashes de imagem), indicadores de coordenação, recomendação de takedown, linha do tempo da campanha |
| Estudo/CTF | Diário de aprendizagem: o que funcionou, o que falhou, o que mudou na plataforma |
| Policial (IPL, VPI, BO) | Variante policial do `make_report.py` (`contexto: "policial"` ou `--variante policial`): procedimento, unidade e autoridade na capa; respostas aos quesitos (`quesitos` no `case.json`, cada um com evidências); bloco de assinatura; recomendações de preservação e requisição (`00` seção 10). Exemplo: `assets/exemplos/case_exemplo_policial.json`. Se a unidade tiver modelo próprio, siga-o e anexe o relatório gerado |

## 7. Exemplo de achado (adaptado do caso do EPUB, K c.14.1)

- **Observação (EV-0002)**: a imagem de perfil de `@empresa_oficial2025` corresponde ao logotipo oficial na busca reversa.
- **Observação (EV-0005)**: o domínio do link da bio foi registrado há cerca de três meses (WHOIS).
- **Inferência (confiança moderada)**: tentativa de parecer oficial (palavra "oficial" e ano no handle, ausência de selo, conteúdo copiado).
- **Desconhecido**: quem opera a conta.

## 8. Checklist final

- [ ] A pergunta do gate foi respondida? As hipóteses foram avaliadas, inclusive as refutadas?
- [ ] Toda afirmação aponta evidência preservada, com hash conferido (`verify`)?
- [ ] Observação, Inferência e Desconhecido estão separados?
- [ ] Datas em UTC e fuso do caso?
- [ ] PII minimizada e anexo restrito marcado?
- [ ] Limitações e falsos positivos possíveis declarados?
- [ ] Recomendações acionáveis e dentro da base legal?
- [ ] `make_report.py --strict` terminou sem avisos graves?
- [ ] Revisão por outro analista (obrigatória no nível 3)?

## 9. Exportar para o Investigative Notebook

Quando o caso também vai para o `investigative-notebook` (grafo integrado com documentos, extratos e outras skills), gere o bundle `intel-bundle/1.0`:

```
python3 scripts/to_bundle.py --case-dir caso-001 --nodes nos.csv --edges arestas.csv --analysis caso-001/05_Analises/resumo.json --out caso-001/socmint.bundle.json
nb.py import-bundle caso.json caso-001/socmint.bundle.json --dry-run
```

O bundle leva evidências (hashes, hora da coleta, custódia), entidades e relações do grafo, achados (com Admiralty), hipóteses, linha do tempo, pivôs (como consultas OSINT) e a análise de export. Perfis com o mesmo username **não** são unificados: viram perfis distintos ligados a um `usuario` comum. Arestas `identidade` entram como correlação ("possível mesmo titular") e `imitacao` como inferência ("imita"). O script recusa exportar com a cadeia de hashes quebrada ou arquivo alterado. Revise o `--dry-run` antes de importar.
