# 06 — Pivôs e atribuição de identidade

Quando ler: ao expandir uma investigação a partir de um achado, ao decidir se duas contas são da mesma pessoa, ao responder "estou investigando o perfil certo?" ou ao gerar variações de username. Script: `scripts/name_variants.py`. Fontes: livro cap. 8 (L p.230–266, 288–291), EPUB (K c.3.2, c.13.3), slides do Discord (D s.65, 76, 90). `last_reviewed: 2026-10`

## Conteúdo
1. Conceito de pivô
2. Tipos de pivô
3. Registro de pivôs
4. Regra de corroboração
5. Pontuação de força de evidência
6. Checklist de falso positivo
7. "Estou investigando o perfil certo?"
8. Variações de username e e-mail
9. Limites

## 1. Conceito de pivô

Pivotar é, a partir de um dado encontrado em um perfil, saltar para outras contas, plataformas e fontes (L p.231; K c.13.3). Cada pivô transforma um achado em vários, mas também **multiplica falsos positivos**. Pivote de forma estruturada: registrar a descoberta, avaliar relevância, definir o próximo caminho e documentar o pivô (K c.13.6).

## 2. Tipos de pivô

| Pivô | Como funciona | Cuidado |
|---|---|---|
| **Username/alias** | Muitos usuários reutilizam o mesmo alias; basta pesquisar o alias nas plataformas (L p.246) | Alias genérico ("PrincesaM") não prova nada; alias raro ("LukaGangst3r22") é indício **moderado** e ainda precisa de mais provas (L p.246) |
| **Prefixo de e-mail** | O trecho antes do `@` costuma virar username (L p.246) | Candidato, não prova |
| **Foto de perfil** | Busca reversa; fotos são reutilizadas mais que aliases (L p.251) | Foto de banco de imagens, foto roubada e clones; comparar origem e data |
| **Bio e links** | Contas ligadas, e-mails, sites pessoais (L p.267) | Bios podem ser copiadas por impostores |
| **E-mail e telefone** | Mesmo e-mail ou telefone em duas contas indica ligação (L p.237) | Dado volátil (K c.13.2); enumeração de contas por e-mail é invasiva (`05`) |
| **Nome completo e apelidos** | Dorks em LinkedIn e Facebook; sobrenomes levam a familiares (L p.232–233) | Homônimos; a ordem dos sobrenomes depende do país (L p.233) |
| **Rede social** | Seguidores/seguidos em comum, comentários, menções, marcados | Contas populares são "elos fracos" **para engenharia social** (L p.171): a skill não usa isso |
| **Tempo** | Datas de criação, horários de atividade, mudanças de handle | Fuso e automação distorcem (`07`) |
| **Infraestrutura** | Domínio do link da bio → WHOIS (domínio recente), DNS, certificados | WHOIS é anonimizado desde 2018 em muitos casos (L p.650) |
| **Conteúdo e estilo** | Frases recorrentes, erros típicos, emojis, idioma | Indício de baixa força |
| **Localização** | Geotags, locais citados, fundo das fotos | Alvo pessoa privada: gate; geolocalizar **conteúdo** é diferente de localizar **pessoa** |
| **Ecossistema** | Convite → canal → grupo → bot → backup (D s.65, 89) | Mapear o ecossistema inteiro (`03`) |

## 3. Registro de pivôs

Planilha ou CSV com: `id`, `de` (identificador de origem), `para` (identificador encontrado), `tecnica` (dork, ferramenta, ID, busca reversa…), `fonte_url`, `data_utc`, `resultado`, `forca` (fraca/moderada/forte), `evidencia` (`EV-…`), `proximo_passo`. Modelo em `assets/pivos.template.csv` e exemplo em `assets/exemplos/pivos_exemplo.csv`. Salvar como `pivos.csv` na pasta do caso ou em `03_Pivotagem_Social` (`08`): `make_report.py` lê o arquivo para a metodologia e `to_bundle.py` o exporta como consultas OSINT.

## 4. Regra de corroboração

Classificar cada vínculo de identidade em uma de quatro classes, as mesmas da skill `social-media-intelligence`, para que o resultado das duas skills fale a mesma língua no Investigative Notebook. A força de cada sinal vem da tabela da seção 5; só contam sinais **independentes**.

| Classe | Critério | Como escrever |
|---|---|---|
| **Confirmado** | ≥1 sinal **forte** e ≥1 outro sinal independente | "é a mesma pessoa/operador (vínculo confirmado)", citando os sinais |
| **Provável** | ≥2 sinais **moderados** independentes sem forte, ou 1 forte isolado | "vínculo provável", com o que falta para confirmar |
| **Possível** | 1 sinal moderado, ou ≥2 fracos independentes | "**possível vínculo**", com o que falta |
| **Não confirmado** | só sinais fracos isolados, ou sinais que derivam uns dos outros | não afirmar vínculo; manter o perfil registrado |

Reuso de username isolado **nunca** passa de Possível. A `social-media-intelligence` chega à classe por escore e esta skill pela força dos sinais: se as duas divergirem para o mesmo par, vale a classe mais baixa até nova verificação.

Sinais **independentes** não compartilham a mesma origem: "mesma foto" e "foto no mesmo link da bio" podem ser a mesma informação.

No grafo (`build_graph.py`), só arestas `tipo=identidade` contam para esta regra. Foto ou logotipo copiados de terceiro (marca, celebridade, banco de imagens) são `imitacao` ou `associacao`, nunca sinal de identidade com o dono da imagem.

## 5. Pontuação de força de evidência

| Força | Exemplos |
|---|---|
| **Fraca (1)** | Username genérico igual; nome comum igual; foto de banco de imagens; localização aproximada; horário compatível |
| **Moderada (2)** | Username raro idêntico; foto original (sem outra origem na busca reversa) igual; bio com links próprios iguais; menções cruzadas entre as contas; datas de criação coerentes com a narrativa |
| **Forte (3)** | Link bidirecional (A aponta para B e B aponta para A); ID técnico compartilhado e **não público**; domínio próprio ligado às duas contas por registro; metadados originais coincidentes; confirmação direta e **consentida** do titular |

Resultado: aplicar as classes da seção 4 e registrar a confiança (`07`).

## 6. Checklist de falso positivo

- [ ] Homônimo ou nome muito comum?
- [ ] Clone ou impostor que copia foto, bio e nome (comparar **ID**, data de criação, histórico, seguidores)?
- [ ] Foto de banco de imagens, de celebridade ou de IA?
- [ ] Alias reutilizado por pessoas diferentes (comum em jogos e fandoms)?
- [ ] Conta recém-criada que copia outra?
- [ ] Viés de confirmação: busquei evidências contra a hipótese?
- [ ] A informação veio de ferramenta de terceiros desatualizada?
- [ ] Os sinais são independentes entre si?

## 7. "Estou investigando o perfil certo?" (L p.290–291)

Primeiro, **verificar o perfil**, depois aprofundar. Plataformas que usam nome e rosto reais (como o LinkedIn) facilitam o cruzamento. Quando não houver, verificar localização e redes que o perfil vincula; se faltar, observar publicações e contas seguidas. Perguntas úteis: há posts sobre temas que sabemos relevantes para a pessoa? Segue contas ligadas a lugares específicos (comércio local, órgãos locais)? Para confirmar, listar publicações e contas seguidas com as técnicas de cada playbook. Esse método vale para alvo **já autorizado**; não serve para escolher uma pessoa privada entre homônimos por curiosidade.

## 8. Variações de username e e-mail

`python3 scripts/name_variants.py --name "Maria da Silva Souza" --nick "mari" --year 1990 --max 80`

Gera candidatos com as convenções pt-BR: partículas (`da`, `de`, `dos`), acentos removidos, separadores (`.`, `_`, `-`, nada), primeiro + último nome, inicial + sobrenome, ano e dígitos comuns, e e-mails com domínios frequentes (opção `--domains`). **Só gera candidatos**; a verificação é manual, com as ferramentas de `05`, e cada candidato confirmado ainda passa pela regra de corroboração.

## 9. Limites

- Pessoa privada: gate (`00`); minimizar o que se registra sobre terceiros do círculo (amigos, familiares).
- Não usar pivôs que dependam de enganar a plataforma ou o titular (recuperação de senha, perfis falsos, sincronização de agenda com o número do alvo).
- Não usar bases vazadas para ligar identidades (`00`).
