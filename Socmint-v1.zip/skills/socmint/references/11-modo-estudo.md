# 11 — Modo estudo

Quando ler: o usuário quer estudar, revisar para prova, treinar, montar exercícios ou entender termos do curso. Em estudo, use **alvos fictícios, contas próprias ou laboratórios com regras de escopo**; nunca alvo real sem autorização (`00`). Os gabaritos numéricos abaixo são conferidos por `scripts/decode_ids.py`. `last_reviewed: 2026-10`

## Conteúdo
1. Objetivos de aprendizagem por fonte
2. Como conduzir uma sessão de estudo
3. Exercícios com gabarito
4. Exercícios de método (sem gabarito numérico)
5. Flashcards
6. Glossário PT / ES / EN
7. Correspondência entre modelos (vinda de `01`)
8. Tipos de rede social (vinda de `03`)

## 1. Objetivos de aprendizagem por fonte

- **Discord, Módulo 1/Aula 01** (D s.4): compreender como funcionam as redes sociais; identificar diferenças entre redes abertas, híbridas e fechadas; entender como comunidades se organizam, interagem e migram; reconhecer o papel das plataformas em contexto investigativo e de coleta OSINT.
- **Telegram** (T s.2–3): Parte 1, por que o Telegram e OPSEC (ambiente, privacidade, API); Parte 2, OSINT com Telegram (dorks, CSEs, indexadores, ferramentas, GEOINT, bots).
- **TikTok** (K c.1–17): estrutura de dados, extração do código-fonte (User ID, `uniqueId`, `createTime`), timestamps, ferramentas, espelhos, ODPAR, ética.
- **Livro** (L): processo SOCMINT, autoproteção, dorks, ambiente seguro, investigação por nome/e-mail/alias/foto, e módulos Facebook, Instagram, Threads, WhatsApp.

## 2. Como conduzir uma sessão de estudo

1. Perguntar a fonte e o tema; propor 5 a 10 itens (exercícios + flashcards).
2. Apresentar um item por vez, esperar a resposta e só então corrigir, citando a origem (`D s.71`, `K c.5.2`…).
3. Para exercícios numéricos, **rodar o script** e comparar; explicar o cálculo.
4. Terminar com um mini-resumo de lacunas e sugestão de revisão.
5. Sempre sinalizar o que é `[VOL]` e pode ter mudado.

## 3. Exercícios com gabarito (conferir com `decode_ids.py`)

| # | Enunciado | Gabarito |
|---|---|---|
| 1 | Datar o ID do Discord `175928847299117063` | 2016-04-30 11:18:25.796 UTC (exemplo da documentação do Discord) |
| 2 | Datar o ID do Discord `80351110224678912` | 2015-08-10 17:26:37.529 UTC |
| 3 | Datar o vídeo do TikTok `7598746068280495381` (e dar a hora de Brasília) | 2026-01-24 02:15:38 UTC; 2026-01-23 23:15:38 em America/Sao_Paulo (exemplo do e-book, K c.7) |
| 4 | Datar o tweet `1585841080431321088` | 2022-10-28 03:49:11.734 UTC |
| 5 | Converter o Unix timestamp `1340433637` (campo `creation_time` do exemplo do livro, L p.273) | 2012-06-23 06:40:37 UTC |
| 6 | Estimar o ano do ID do Facebook `100035049878735` | Cerca de 2019 (estimativa por faixa, L p.298) |
| 7 | Estimar o ano do ID do Facebook `4` | 2004 (conta do cofundador) |
| 8 | Qual a época do snowflake do Discord e qual o deslocamento? | 01/01/2015 00:00 UTC (`1420070400000` ms); deslocamento de 22 bits (D s.72) |
| 9 | Em `1700000000` e `1700000000000`, qual é segundos e qual é milissegundos? | O de 10 dígitos é em segundos, o de 13 em milissegundos; ambos são 2023-11-14 22:13:20 UTC |

## 4. Exercícios de método

1. **Classificar** Instagram, TikTok, Telegram (canal público, grupo privado), Discord, WhatsApp e Reddit como aberta, híbrida ou fechada e justificar (D s.52, 63). Esperado: Telegram é multiestrutura.
2. **Gate**: "quero saber onde mora minha ex-colega". Aplicar as 5 perguntas, decidir (recusar e redirecionar) e redigir a resposta curta (`00`).
3. **Estável × mutável**: para uma conta do TikTok que trocou de `@` e de nickname, qual identificador permite reencontrá-la? (User ID; K c.5.2) E que erro tem o cap. 4.1 do e-book? (chama o Unique ID de imutável).
4. **Corroboração**: duas contas têm o mesmo username raro e a mesma foto de perfil, sem outras ligações. É "a mesma pessoa"? (Dois sinais moderados, não independentes se a foto veio do mesmo lugar: "possível vínculo"; `06`.)
5. **Preservação**: ordenar as ações de uma coleta de perfil (preservar → ID → bio/links → posts → pivôs → hash/log). Explicar por que preservar vem antes de pivotar (`08`).
6. **Evidência**: com `evidence_log.py`, criar um caso (`init` com `--tz` da localidade), adicionar dois arquivos informando `--captured`, adulterar um, rodar `verify` e interpretar a falha; depois registrar um evento de custódia (`event`) e ver como ele entra na cadeia (`08`).
7. **Análise**: rodar `analyze_export.py` em `assets/exemplos/comentarios_sinteticos.csv` e listar os indicadores; discutir falsos positivos possíveis (`07`).
8. **Relatório**: transformar três achados em Observação, Inferência e Desconhecido, com evidência ligada e confiança (`09`).
9. **Ecossistema**: desenhar o mapa de uma comunidade que começa em servidor Discord, migra para um grupo de Telegram e mantém um canal-vitrine (D s.89; `03`).
10. **OPSEC**: listar o que um site de terceiros aprende quando você digita um username do alvo (L p.24; `02`).

## 5. Flashcards

- **Fonte aberta é o mesmo que gratuita?** Não; é a que se acessa sem autorização especial (L p.39).
- **Qual o critério operacional que substitui o "iceberg"?** Acesso: aberta, híbrida ou fechada (D s.31).
- **O que é um snowflake do Discord e para que serve?** ID de 64 bits cujos 42 bits mais significativos codificam o instante de criação; datar contas, servidores e mensagens (D s.71–73).
- **Quantas trocas de @username o Discord permite?** Até 2 por semana; o nome de exibição é livre.
- **O username do Reddit pode mudar?** Nunca; o display name muda livremente (D s.79–80).
- **Qual o identificador imutável do TikTok?** User ID numérico (e `secUid` estável) (K c.5.2; D s.83).
- **Com que frequência mudam `uniqueId` e nickname no TikTok?** 30 e 7 dias (K c.4.1, c.6.2).
- **O que é `createTime`?** Unix timestamp no código-fonte; precisa converter (K c.6.7).
- **Quando usar `Ctrl+U`?** Para ver o código-fonte e achar chaves como `userInfo` e `createTime` (K c.5.1).
- **O que é ODPAR?** Organizar, Documentar, Pivotar, Analisar e Relatar, de forma iterativa (K c.13).
- **O que são frações significativas?** Partes da matéria-prima com relevância no contexto (K c.3.2).
- **Para que serve o hash?** Mostrar que o arquivo não mudou desde a coleta (K c.13.4).
- **O que é um pivô?** Salto de um dado para outras contas e fontes (L p.231).
- **Qual a diferença entre perfil ativo e passivo?** Ativo interage; passivo só observa (L p.169–171).
- **O que é fingerprinting?** Identificar o navegador pela combinação de configurações, independente de IP e cookies (L p.150–152).
- **O que são `t.me/s/<canal>` e `t.me/joinchat/<hash>`?** Prévia web de canal público e link de convite (T s.83).
- **Qual a cadeia típica de infraestrutura no Telegram?** Canal → grupo → bot → canal reserva (D s.65).
- **Por que o WhatsApp é "fechado" e de vínculo forte com o número?** A conta é o telefone (E.164); usernames estão em implantação (D s.84).
- **O que o gate pergunta?** Finalidade, autorização, categoria do alvo, minimização e passivo × ativo (`00`).
- **O que a LGPD diz sobre dado público?** Considerar finalidade, boa-fé e interesse público; consentimento dispensado para dado manifestamente público pelo titular, sem afastar princípios (art. 7º §§3º–4º).

## 6. Glossário PT / ES / EN

| PT | ES | EN | Nota |
|---|---|---|---|
| Inteligência de fontes abertas (OSINT) | Inteligencia de fuentes abiertas | Open-source intelligence | |
| SOCMINT | Inteligencia en redes sociales | Social media intelligence | Família INT |
| Pivô / pivotar | Pivotar, punto de salto | Pivot | Saltar de um dado a outros |
| Conta de investigação / AVI / sock puppet | Cuenta ficticia / avatar | Sock puppet | Política em `02` |
| OPSEC | Seguridad operacional | Operational security | |
| Vazamento de DNS | Fuga de DNS | DNS leak | |
| Impressão digital do navegador | Huella digital del navegador | Browser fingerprinting | |
| Dork | Dork | Search operator query / dork | |
| Raspagem | Scrapping | Scraping | |
| Espelho | Página espejo | Mirror site | |
| Captura / instantâneo | Captura | Snapshot | |
| Cadeia de custódia | Cadena de custodia | Chain of custody | |
| Hash | Hash | Hash | SHA-256 |
| Carimbo de tempo Unix | Marca de tiempo UNIX | Unix timestamp / epoch | Segundos desde 1970 UTC |
| Snowflake | Snowflake | Snowflake ID | Discord e X |
| Fração significativa | Fracción significativa | Significant fraction | Termo do e-book |
| Escuta ativa | Escucha activa | Social listening | |
| Vazamento (de dados) | Fuga / leak / brecha | Data breach / leak | |
| Verificação em duas etapas | Verificación en dos pasos | Two-factor authentication | |
| Convite | Invitación | Invite | |
| Cargo | Rol | Role | Discord |
| Supergrupo | Supergrupo | Supergroup | Telegram |
| Comportamento coordenado inautêntico | Comportamiento coordinado inauténtico | Coordinated inauthentic behavior (CIB) | `07` |
| Análise de hipóteses concorrentes | Análisis de hipótesis en competencia | Analysis of competing hypotheses | `07` |

## 7. Correspondência entre modelos

| ODPAR | Etapas SOCMINT do livro (L p.45–46) | Fases do Berkeley Protocol | Ciclo de inteligência |
|---|---|---|---|
| Organizar | Definição de objetivos; identificação de fontes | Preparação (ameaça e risco digital, cenário digital, plano online, resiliência, dados e ferramentas) | Direção e planejamento |
| Documentar | Recopilação de dados | Avaliação preliminar; coleta; preservação | Coleta |
| Pivotar | Recopilação iterativa | Consultas online; coleta | Coleta e processamento |
| Analisar | Análise; validação e verificação | Verificação; análise investigativa | Processamento e análise |
| Relatar | Inteligência (informes e apresentação) | Relato escrito, oral e visual | Disseminação e feedback |

As **quatro etapas de produção** do livro (L p.53–57): escuta ativa (menções; métricas de força, sentimento, paixão e alcance), gestão de dados (contagens, geolocalização, data/hora, tipo de página, sentimento), analítica avançada (descartar o que não agrega, separar quantitativo e qualitativo) e distribuição (relatório ou notificação que sustente a decisão).

## 8. Tipos de rede social (L p.58–65)

Redes sociais (Facebook, LinkedIn) · compartilhar fotos (Instagram, Flickr) · vídeo e transmissão ao vivo (YouTube, Vimeo, Twitch) · vídeos curtos (TikTok, Kwai, BeReal; Reels e Shorts) · blogs (WordPress, Tumblr, Blogger) · microblogs (X, Mastodon, Threads) · fóruns (Reddit, Mediavida, ForoCoches) · marcadores sociais (Pinterest, Start.me) · jogos sociais (Xbox Live) · avaliações (Yelp, Google Reviews). Uma plataforma pode aparecer em mais de uma categoria.
