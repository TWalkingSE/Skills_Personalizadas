# 07 — Verificação e análise

Quando ler: ao avaliar a confiabilidade de fontes e achados, escolher a linguagem de confiança, analisar linha do tempo e padrão de atividade, investigar coordenação ou bots, ou verificar imagem e vídeo. Script: `scripts/analyze_export.py`. Fontes: EPUB (K c.13.4, c.14.1), livro (L p.45–47, 290–291), slides do Discord (D s.73, 90); métodos de avaliação `[ADD]`. `last_reviewed: 2026-10`

## Conteúdo
1. Verificar antes de concluir
2. Avaliação da fonte e da informação (Admiralty)
3. Linguagem de confiança
4. Análise de hipóteses concorrentes (ACH)
5. Linha do tempo
6. Padrão de atividade (pattern-of-life)
7. Indicadores de coordenação e de bots
8. Verificação de imagem e vídeo
9. Geolocalização e cronolocalização de conteúdo
10. O que `analyze_export.py` entrega
11. Limites

## 1. Verificar antes de concluir

"Validação e verificação" é a etapa que descarta falsos positivos e informação pouco fiável, e pode esgotar os dados úteis a ponto de devolver o analista à coleta (L p.46–47). Regras: confirmar em **mais de uma fonte independente** (K c.16.1); revisar para erros; checar integridade (hash SHA-256/512, K c.13.4); separar **Observação**, **Inferência** e **Desconhecido** (`09`).

## 2. Avaliação da fonte e da informação (sistema Admiralty/OTAN) `[ADD]`

Dois eixos independentes. Registrar como `B2`, `C3` etc.

| Letra | Confiabilidade da **fonte** | Número | Credibilidade da **informação** |
|---|---|---|---|
| A | Totalmente confiável | 1 | Confirmada por outras fontes independentes |
| B | Normalmente confiável | 2 | Provavelmente verdadeira |
| C | Razoavelmente confiável | 3 | Possivelmente verdadeira |
| D | Normalmente não confiável | 4 | Duvidosa |
| E | Não confiável | 5 | Improvável |
| F | Não pode ser avaliada | 6 | Não pode ser avaliada |

A letra avalia a **origem** da informação, não a integridade da captura: o hash prova que o arquivo não mudou depois da coleta, mas não torna confiável o que está dentro dele. Exemplos: dado técnico gerado pela plataforma e lido no código-fonte (ID, `createTime`, `verified`) = tipicamente B; o que o próprio perfil declara (bio, localização, "oficial" no nome) = autodeclaração, C a E conforme o histórico; espelho desatualizado = D ou F; comentário de conta recém-criada = D. A mesma captura pode ter campos com letras diferentes, e a mesma fonte pode ter informação 1 em um ponto e 4 em outro.

## 3. Linguagem de confiança `[ADD]`

**Confiança no julgamento** (força da base): *baixa* (fontes escassas, fracas ou conflitantes), *moderada* (fontes críveis, mas sem corroboração suficiente), *alta* (várias fontes independentes e consistentes). Separe isso de **probabilidade**; se usar termos de probabilidade, mantenha a escala: quase impossível (até ~5 %), muito improvável (5–20 %), improvável (20–45 %), chance aproximadamente igual (45–55 %), provável (55–80 %), muito provável (80–95 %), quase certo (acima de ~95 %). Evite "talvez" sem nível.

## 4. Análise de hipóteses concorrentes (ACH) `[ADD]`

1. Listar hipóteses mutuamente excludentes (H1 conta oficial, H2 conta falsa, K c.14.1).
2. Listar evidências e premissas.
3. Matriz: para cada evidência, marcar **consistente / inconsistente / neutra** com cada hipótese.
4. Dar mais peso às evidências que **discriminam** (inconsistentes com alguma hipótese); evidências consistentes com todas pouco ajudam.
5. Rejeitar hipóteses com mais inconsistências; sensibilidade: o que muda se a evidência mais forte estiver errada?
6. Registrar o que **observar a seguir** para separar as hipóteses restantes.

## 5. Linha do tempo (K c.13.4)

CSV `data_utc, evento, evidencia, fonte` (modelo em `assets/timeline.template.csv`). Incluir: criação da conta (decodificada de ID ou campo), mudanças de handle, primeiro e último post, picos, eventos externos (notícias, lançamentos), datas de criação de contas relacionadas. Mostrar lacunas. Converter tudo para UTC antes (`04`). Ordenar e verificar contradições (conta "criada" depois do primeiro post = erro de fonte ou de fuso).

## 6. Padrão de atividade (pattern-of-life)

- Histograma de postagens por **hora do dia em UTC** e por dia da semana. O vale de menor atividade costuma corresponder à madrugada local: a diferença para a hora UTC sugere o fuso provável (**inferência**, nunca fato).
- Cuidados: amostra pequena engana; trabalho em turnos, viagens, horário de verão e automação mudam o padrão; **VPN não altera o horário gravado pela plataforma**, mas pode mudar a localização aparente.
- O cabeçalho do horário vem da plataforma (UTC) ou do cliente (fuso do visualizador): registrar a fonte (`04`).

## 7. Indicadores de coordenação e de bots

**São indicadores, não veredito.** Cada um tem explicação legítima; só a convergência de vários, com contexto, justifica uma inferência.

| Indicador | Interpretação cautelosa |
|---|---|
| Contas criadas no mesmo dia ou em sequência de ID (D s.73) | Lote de criação; pode ser campanha legítima de cadastro |
| Username padrão `nome+dígitos longos` ou cadeia aleatória | Contas geradas em massa; muitos usuários reais também usam |
| Avatar padrão, genérico ou repetido | Baixo esforço; usuários novos e privacidade também |
| Texto idêntico ou quase idêntico em contas diferentes (ex.: "Recebi meu prêmio!", K c.14.1) | Roteiro compartilhado |
| Rajadas de comentários em segundos ou minutos | Automação ou mobilização real |
| Idade da conta muito menor que o volume de atividade | Conta nova e muito ativa |
| Mesmos links, domínios ou mídia | Mesmo operador ou mesma campanha |
| Sobreposição alta de seguidores entre contas | Operação em rede ou comunidade orgânica |

Falsos positivos comuns: **viralização orgânica**, fãs organizados, torcidas, eventos e notícias, usuários novos reais.

## 8. Verificação de imagem e vídeo `[ADD]`

1. **Origem**: busca reversa em vários motores (`05`) para achar a primeira aparição; guardar a captura e a URL.
2. **Metadados**: arquivos baixados de redes geralmente perdem EXIF; arquivos recebidos diretamente podem conservá-lo. Registrar hash do original.
3. **Quadros-chave**: extrair quadros de vídeo para busca reversa; verificar cortes e reutilização.
4. **Contexto**: idioma de placas, clima, vegetação, vestuário, tomadas, veículos, sinalização.
5. **Alterações**: sinais de edição (sombras, bordas, compressão desigual); imagens geradas por IA têm falhas típicas, mas **não** há detector infalível: tratar como indício.
6. **Capturas falsas de mensagens**: existem geradores; conferir contra o dado original (`00`).

## 9. Geolocalização e cronolocalização de conteúdo `[ADD]`

Determinar **onde** e **quando** uma imagem ou vídeo foi feito a partir de pistas visuais (relevo, edificações, placas, sombras e ângulo do sol) e mapas e imagens de satélite. É uma técnica de verificação de **eventos e conteúdo**. **Não** aplicar para localizar a residência ou a rotina de pessoa privada (`00` seção 4).

## 10. O que `analyze_export.py` entrega

Entrada: CSV (ou XLSX com `openpyxl`) de seguidores, comentários ou posts exportados por extensões. Saídas (Markdown, JSON e CSV de sinalizados): volume e janela de tempo; histograma por hora e dia (UTC e fuso local); picos por z-score; duplicados e quase-duplicados; hashtags, menções, links e emojis mais frequentes; padrões de username; contas novas versus data do comentário; agrupamento por data de criação (se houver `--platform` para decodificar IDs); sobreposição entre dois exports (`--compare`, índice de Jaccard). Sempre com **ressalvas** e **explicação de cada indicador**. Nada de rótulo "bot".

## 11. Limites

Poucos dados, exports parciais (limites gratuitos de 100 a 500 itens), conteúdo apagado, ordenação por relevância da plataforma e viés de amostra afetam toda conclusão; declarar no relatório (`09`).
