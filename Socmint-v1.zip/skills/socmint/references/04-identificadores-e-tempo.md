# 04 — Identificadores persistentes e tempo

Quando ler: ao receber um username, ID, URL, timestamp ou print e precisar saber o que é estável, o que preservar primeiro e como converter datas. Decodificação determinística: `scripts/decode_ids.py`. `last_reviewed: 2026-10`

## Conteúdo
1. Princípio
2. Matriz de identificadores por plataforma
3. Datas embutidas em IDs (fórmulas)
4. Faixas de ID do Facebook (estimativa)
5. Tempo: UTC, fuso e Unix
6. O que preservar primeiro
7. Armadilhas

## 1. Princípio

O investigado pode trocar nome, alias, foto e gênero; o **ID numérico não muda** (L p.272; K c.5.2). Por isso o primeiro ato de qualquer coleta é achar e preservar o ID. Mesmo com foto, username e URL personalizada alterados, o perfil ainda é localizável pelo ID, **se ele foi coletado antes**. Em perfis usados para ilícitos é comum desativar e reativar a conta com tudo mudado, mas o ID permanece (K c.5.2).

Handles antigos continuam úteis: servem a buscas retrospectivas em arquivos da web e buscadores (K c.6.2).

## 2. Matriz de identificadores por plataforma

`[VOL]` = pode mudar; conferir antes de afirmar como fato atual.

| Plataforma | ID estável (preservar) | Handle e limites | Onde achar / como resolver |
|---|---|---|---|
| **Discord** | *Snowflake* de 64 bits para usuário, servidor, canal, cargo e mensagem (D s.71) | `@username` único global, 2–32 caracteres (minúsculas, números, `_` e `.`), troca até 2×/semana; *display name* livre e não único (D s.74–77). Até meados de 2023 o formato era `Usuário#1234`: reconhecer os dois em evidências antigas | Modo desenvolvedor do app `[ADD]`; IDs em logs, prints, convites e bots |
| **Telegram** | ID numérico interno e permanente (D s.65) | Username público trocável a qualquer momento (D s.65); admins reaproveitam usernames em outras plataformas | Bots de ID, app e Desktop (T s.133); URLs: `t.me/<user>`, `t.me/s/<canal>` (prévia sem login), `t.me/joinchat/<hash>` (convite), `telesco.pe/<canal>` (vídeos) (T s.83) |
| **TikTok** | **User ID** numérico imutável e `secUid`, usado por APIs e ferramentas para referenciar a conta de forma estável (D s.83; K c.5.2) | `uniqueId` (o `@`): muda a cada 30 dias, antigo fica retido um tempo; `nickname`: a cada 7 dias (K c.4.1, c.6.2–6.3; D s.82) | Código-fonte (Ctrl+U), buscar `userInfo`, `id`, `uniqueId`, `nickname`, `verified`, `signature`, `bioLink`, `createTime`, `videoCount`, `followerCount`, `followingCount`, `heartCount` (K c.5–6). Reverso: colocar o ID numérico após `@` na URL `[VOL]` (K c.6.2). Post: `tiktok.com/@user/video/<id>` (K c.7.1) |
| **Instagram** | ID numérico sequencial (conta nº N criada), código-fonte: `profilePage_`, `profile_id` (L p.450) | `username` mutável | ID→perfil exige técnica específica `[VOL]` (L p.455); post: `instagram.com/p/<shortcode>`, chaves `shortcode`, `container_id` (L p.490). Detalhes em `platforms/instagram.md` |
| **Threads** | Mesmo universo de contas do Instagram; chaves `user_id`, `userID`, `container_id` (L p.592–593) | `username` | Botão na bio do Instagram leva ao perfil do Threads (L p.593) |
| **Facebook** | `userID` (perfil), `profile_owner`/`delegate_page_id` (página), `group_id` (grupo) (L p.298–300) | Vanity URL mutável | `facebook.com/<ID>` e `facebook.com/groups/<ID>` resolvem para o perfil atual (L p.300) |
| **Reddit** | `username` **permanente**: não muda nunca; mesmo apagada a conta, o nome não volta a ficar disponível (D s.79) | *Display name* separado, livre, só aparece no topo do perfil; em posts, URLs e menções `u/` aparece o username (D s.80) | Perfil `u/<user>`; karma como sinal de reputação (D s.81) |
| **WhatsApp** | Número de telefone (E.164: país + DDD + número) (D s.84; L p.241) | `@username` em implantação: reservas desde 29/06/2026, rollout gradual por país, 3–35 caracteres, chave de username opcional; sem diretório público `[VOL]` | `wa.me/<número>`; grupos: convites `chat.whatsapp.com/...` (D s.86) |
| **X/Twitter** `[ADD]` | ID numérico (tweets: *snowflake*) | `@handle` mutável | Código-fonte e ferramentas de ID |
| **YouTube** `[ADD]` | ID de canal alfanumérico (`UC…`) | `@handle` mutável | Código-fonte da página do canal |
| **LinkedIn** `[ADD]` | ID alfanumérico (L p.271) | Slug da URL mutável | Código-fonte `[VOL]` |
| **Kwai** `[ADD]` | Kwai ID, que é o `@` da URL `kwai.com/@<id>` e pode ser personalizado uma vez `[VOL]` | Nome exibido de troca livre | Página do perfil; vídeo: `kwai.com/…/video/<id>`, sem data decodificável conhecida (`platforms/kwai.md`) |

Observação do livro: LinkedIn e YouTube usam ID alfanumérico; as demais redes, numérico (L p.271).

## 3. Datas embutidas em IDs (fórmulas)

Use `python3 scripts/decode_ids.py <tipo> <valor>`; ele imprime UTC e o fuso de `--tz` (padrão America/Sao_Paulo; ver seção 5) e rotula **dado × inferência**.

| Tipo | Fórmula | Observação |
|---|---|---|
| Discord (qualquer ID) | `(id >> 22) + 1420070400000` ms (época 01/01/2015 UTC) (D s.72) | Vale para contas, servidores, canais, cargos, mensagens; funciona sem API; também em contas apagadas, se o ID aparece em algum log (D s.73). Contas muito recentes podem ser alts ou bots de spam |
| X/Twitter (tweet) `[ADD]` | `(id >> 22) + 1288834974657` ms | Só tweets e IDs pós-2010; IDs de usuário antigos não são snowflake |
| TikTok (vídeo) `[ADD]` | `id >> 32` = segundos Unix | Mesma lógica da ferramenta TikTok Timestamp da Bellingcat (K c.8.2). **Confirmar** com `createTime` do código-fonte |
| Instagram (mídia) `[ADD]` | `(id >> 23) + 1314220021721` ms (41 bits de tempo, 13 de shard, 10 de sequência; Instagram Engineering, 2012) | Conferido contra vetores públicos (ex.: `2384288897814875714` → 2020-08-26 13:43:27 UTC). Vale para IDs de mídia, não para IDs de usuário pequenos (sequenciais); shortcode ↔ ID usa alfabeto base64 de URL e é prática da comunidade; shortcodes longos (posts privados) não decodificam. Confirmar com `taken_at` |
| Unix | segundos (10 dígitos), ms (13), µs (16), ns (19) | O script detecta a escala |
| Bluesky TID `[ADD]` | 13 caracteres base32-sort; 53 bits de microssegundos | Chave de registro com tempo |
| Facebook | Sem timestamp no ID | Só estimativa por faixa (seção 4) |
| Telegram | Sem timestamp no ID | Estimativa por faixa depende de tabelas externas; bots de "creation date" enviam o ID a terceiros |

## 4. Faixas de ID do Facebook (estimativa grosseira; tabela do livro L p.297–298, compilada por T1t0)

| ID (aprox.) | Ano provável |
|---|---|
| 4, 6, 10 | 2004 |
| 100.000–899.999 | 2004–2006, reservado a universidades (Columbia, Stanford, Yale, Cornell, Dartmouth, NYU) |
| 2,5 milhões | 2004 |
| 7,9 milhões | 2005 |
| 500 milhões | 2006 |
| 700 milhões | 2007 |
| 1,418 bilhão | 2008 |
| 1,43 bilhão | 2009 |
| 100.000.126.463.756 | 2010 (início do prefixo `1000…`) |
| 100.002.284.156.384 | 2011 |
| 100.004.947.573.889 | 2012 |
| 100.004.993.928.607 | 2013 |
| 100.007.787.700.161 | 2014 |
| 100.009.506.123.654 | 2015 |
| 100.012.716.439.159 | 2016 |
| 100.028.690.792.552 | 2018 |
| 100.035.049.878.735 | 2019 |
| 100.058.283.354.527 | 2020 |
| 100.076.066.428.423 | 2021 |
| 100.083.688.981.403 | 2022 |
| 100.095.176.847.562 | 2023 |
| 61.556.281.671.164 | 2024 (nova faixa iniciada em `61…`) |

**Cautela:** a âncora de 2017 do livro (100.043.987.846.036) fica acima da de 2018 e de 2019, ou seja, a tabela não é monotônica e esse ponto é um *outlier*; o script o ignora. Use como estimativa de ±1–2 anos, nunca como data de criação. Há duas formas melhores de obter o ano de entrada: o campo "Entrou no Facebook" quando o usuário o deixa visível em *Detalhes*, e o perfil do Marketplace (L p.310).

## 5. Tempo: UTC, fuso e Unix

- Redes sociais gravam datas em **Unix timestamp**: segundos desde 01/01/1970 UTC (L p.272–274). O código-fonte devolve UTC.
- Converter para ISO 8601 (CyberChef, EpochConverter ou `decode_ids.py unix`). Registrar **sempre** UTC e, entre parênteses, o fuso do caso: o **nome IANA da localidade do fato**, nunca um deslocamento fixo. Desde 2019 não há horário de verão no Brasil, mas antes a adoção variou por estado e por ano; o banco IANA guarda esse histórico. Exemplo: 15/01/2018 12:00 UTC = 10:00 em `America/Sao_Paulo` (UTC−2, horário de verão) e 09:00 em `America/Maceio` (Sergipe, UTC−3). `evidence_log.py init` exige `--tz`; `decode_ids.py` e `analyze_export.py` avisam quando o fuso exibido estava em horário de verão.

  | Fuso IANA | Localidade (tabela do banco IANA) |
  |---|---|
  | `America/Sao_Paulo` | GO, DF, MG, ES, RJ, SP, PR, SC, RS |
  | `America/Maceio` | AL, SE |
  | `America/Bahia` | BA |
  | `America/Recife` | PE |
  | `America/Fortaleza` | MA, PI, CE, RN, PB |
  | `America/Belem` / `America/Santarem` | PA (leste) e AP / PA (oeste) |
  | `America/Araguaina` | TO |
  | `America/Campo_Grande` · `America/Cuiaba` | MS · MT |
  | `America/Manaus` · `America/Eirunepe` | AM (leste) · AM (oeste) |
  | `America/Porto_Velho` · `America/Boa_Vista` · `America/Rio_Branco` | RO · RR · AC |
  | `America/Noronha` | Fernando de Noronha |

  No Windows o Python não traz o banco de fusos: instale com `pip install tzdata`. Com deslocamento fixo, escreva `--tz=-03:00` (com sinal de igual).
- Chaves de tempo diferentes no TikTok: `createTime` do perfil ou do post (código-fonte) ≠ `create_time` do comentário (resposta JSON da aba Rede/Network das ferramentas de desenvolvedor, arquivo que começa com `list/?Web…`) (K c.8.1–8.3). Facebook: `creation_time` (L p.273).
- A interface mostra números arredondados ("1,2 M") e tempo relativo ("há 2 horas"); o código-fonte traz o valor exato (K c.6.8, c.7.3). Preservar o exato.

## 6. O que preservar primeiro (checklist por perfil)

1. ID(s) estável(is) e `secUid`/equivalentes · 2. handle atual · 3. nome de exibição · 4. URL canônica e URL digitada · 5. bio, links externos e `bioLink` · 6. data de criação, se visível ou decodificável · 7. contadores **exatos** (seguidores, seguindo, curtidas, vídeos) · 8. foto de perfil original (arquivo + hash) · 9. captura de tela com data e hora visíveis · 10. HTML/JSON fonte (`08` e `evidence_log.py add`).

## 7. Armadilhas

- ID da própria conta de investigação aparece no código-fonte (`ACCOUNT_ID`, `USER_ID`, `actorID`): não confundir com o do alvo (L p.298).
- No TikTok, buscar `nickname` no código-fonte devolve vários resultados; o certo costuma estar perto do ID já coletado (K c.6.3).
- Data decodificada de ID é **inferência** sobre criação do objeto, não sobre quando o usuário "começou" a usar a conta.
- Em usernames com `.`, `-` ou `_`, algumas redes não aceitam todos os separadores: pesquisar variações (L p.251).
- Diferença de fuso entre prints, relógio do aparelho e UTC gera erro de horas; registrar a fonte do horário.
