# 01 — Metodologia SOCMINT (ODPAR unificado)

Quando ler: ao planejar, estruturar ou revisar uma investigação, ou ao explicar o método. `last_reviewed: 2026-10`

## Conteúdo
1. Definições rápidas
2. Fluxo operacional ODPAR
3. Correspondência entre modelos
4. Níveis de profundidade
5. Plano de coleta
6. Hipóteses e perguntas
7. Frações significativas e ciclo de pivô
8. Critérios de parada
9. Erros comuns

## 1. Definições rápidas

- **OSINT**: inteligência produzida a partir de informação publicamente disponível, coletada, explorada e disseminada em tempo hábil ao público certo (Bazzell, via K c.1.1).
- **Fonte aberta ≠ gratuita**: aberta é a que se acessa sem autorização especial, mesmo mediante pagamento de assinatura. Fechada é a de acesso restrito por credencial, criptografia ou hierarquia (L p.39–40).
- **SOCMINT**: ferramentas e soluções para analisar conversas, publicações, imagens, vídeos e interações em redes sociais e sintetizar tendências; pode usar meios intrusivos e não intrusivos, em redes abertas e fechadas (L p.45). **Esta skill cobre só o não intrusivo.**
- **Família INT**: HUMINT, SIGINT, IMINT, GEOINT, MASINT, OSINT e SOCMINT (L p.40–44).
- **Usos além do policial** (L p.47–48): busca de desaparecidos, resposta a desastres, saúde pública, análise econômica, proteção de marca, compliance, pesquisa acadêmica.

## 2. Fluxo operacional ODPAR

Fluxo **não linear**: a verificação pode descartar falsos positivos e mandar de volta às fontes e à coleta (L p.47; K c.13).

| Etapa | Objetivo | Entregas | Regra-chave |
|---|---|---|---|
| **O**rganizar | Preparar ambiente e plano | gate, objetivo, hipóteses, plano de coleta, nível de OPSEC, árvore de pastas | Antes de qualquer ferramenta: o que preciso descobrir, quem é o alvo, o que é relevante, quais os limites éticos e legais (K c.13.6) |
| **D**ocumentar | Preservar e registrar | evidência bruta + hash + fonte + data/hora UTC + contexto | **Preservar antes de pivotar.** Separar frações permanentes (identidade, perfil, conexões, conteúdo) das casuais/voláteis (e-mails, telefones, vazamentos) (K c.13.2) |
| **P**ivotar | Expandir a partir de um achado | log de pivôs: de → para, técnica, resultado, confiança | Registrar a descoberta, avaliar relevância, definir novos caminhos, documentar o pivô (K c.13.6) |
| **A**nalisar | Interpretar e verificar | timeline, correlações, grafo, integridade, hipóteses × evidências | O que os dados significam? Qual a conclusão lógica? (K c.13.4) |
| **R**elatar | Entregar decisão | relatório claro, técnico, reprodutível, baseado em evidências | Introdução, objetivo, metodologia, evidências, análise, conclusão, anexos (K c.13.5) |

## 3. Correspondência entre modelos

A tabela ODPAR × etapas do livro × Berkeley Protocol × ciclo de inteligência e as quatro etapas de produção do livro estão em `11` seção 7 (material de estudo). Na operação, siga o ODPAR da seção 2.

## 4. Níveis de profundidade

| Nível | Quando | Mínimo exigido |
|---|---|---|
| 1 — Triagem | Dúvida rápida, pré-qualificação | Gate curto, 1 plataforma, URLs e capturas preservadas, até 3 pivôs, nota curta com Observação/Inferência/Desconhecido |
| 2 — Padrão | Investigação de rotina | Plano completo, preservação com hash, log de pivôs, grafo se houver >5 entidades, relatório ODPAR |
| 3 — Formal | Perícia, compliance, litígio, publicação | Nível 2 + cadeia de custódia, ata notarial ou captura forense, verificação independente, revisão por par |

Se o usuário não disser, propor o nível 2 e explicar a diferença em uma linha.

## 5. Plano de coleta (modelo em `assets/plano-de-coleta.md`)

Campos: ID do caso · pergunta de investigação · hipóteses (H1…Hn, com evidência que confirma e que refuta) · escopo (plataformas, período, idioma, geografia) · categoria do alvo e base legal · passivo/ativo · nível de OPSEC · fontes priorizadas por modelo de acesso (aberta → híbrida → fechada, ver `03`) · identificadores semente · critérios de relevância · retenção e descarte · formatos de saída · responsável e marcos.

## 6. Hipóteses e perguntas

Começar com hipóteses de trabalho (K c.13.6), por exemplo: o domínio pode estar ligado a outras empresas; o perfil usa o mesmo username em outras plataformas; o telefone pode estar vinculado a mensageiros. Para cada uma, anotar o que a confirmaria e o que a refutaria, e revisar após cada ciclo de pivô. No caso do EPUB (c.14.1): H1 conta oficial, H2 conta falsa criada para enganar.

## 7. Frações significativas e ciclo de pivô

**Fração significativa** é qualquer parte da matéria-prima com relevância para o contexto (K c.3.2). Em um perfil: foto, username/ID, selo, apelido, contadores, biografia, links externos.

Ciclo de pivô: identificar a fração → **preservar** → pivotar (técnicas em `06`) → verificar (`07`) → registrar no log (de → para, técnica, resultado, confiança) → decidir o próximo pivô. Um e-mail achado em uma rede pode levar a outros perfis, documentos e registros, exigindo novas buscas e validações (K c.13).

## 8. Critérios de parada

Pergunta respondida com confiança suficiente · fontes abertas esgotadas · retorno marginal · limite de tempo ou orçamento · **risco legal ou ético aumentou** (parar e escalar).

## 9. Erros comuns

- Abrir ferramentas sem objetivo definido (K c.13.6).
- Pivotar antes de preservar.
- Confundir o ID da conta de investigação com o do alvo: no código-fonte, `ACCOUNT_ID`, `USER_ID` e `actorID` carregam o ID de **quem está logado** (L p.298).
- Tratar reuso de username como prova de identidade (`06`).
- Ignorar fuso: timestamps do código-fonte vêm em UTC (L p.273).
- Confiar em espelhos desatualizados (K c.10.2, c.16.2).
- Não registrar fonte, data e contexto de cada achado.
