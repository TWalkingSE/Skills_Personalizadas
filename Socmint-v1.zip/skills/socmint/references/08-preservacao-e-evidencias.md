# 08 — Preservação e evidências

Quando ler: antes de pivotar ou interagir com qualquer fonte, ao montar a trilha de evidências, ao tratar conta apagada/banida, ao preparar material para perícia ou litígio. Script: `scripts/evidence_log.py`. `last_reviewed: 2026-10`

## Conteúdo
1. Regra de ouro
2. Camadas de captura
3. Metadados e hash
4. Cadeia de custódia
5. Estrutura de pastas e nomes
6. Contas apagadas, banidas ou alteradas
7. Armazenamento, retenção e descarte
8. Fluxo mínimo com `evidence_log.py`

## 1. Regra de ouro

**Preservar antes de pivotar e antes de interagir.** Perfis mudam de nome, apagam posts e somem; a primeira cópia é a que vale. Preservar é parte do **D** de ODPAR (K c.13.2) e um dos primeiros passos de qualquer investigação em rede social (K c.10.4). Em procedimento policial, peça também à plataforma a preservação do conteúdo e dos registros, em paralelo à captura (`00` seção 10): a captura do analista não recupera o que for apagado depois.

## 2. Camadas de captura (usar quantas o nível do caso exigir, `01` seção 4)

| # | Camada | Como | Limite |
|---|---|---|---|
| 1 | URL canônica + data/hora UTC | Anotar no log | Não prova o conteúdo |
| 2 | Captura de tela com data/hora visíveis | Janela inteira, com barra de endereço | Pode ser contestada; complementar |
| 3 | HTML/JSON fonte | `Ctrl+U` / `view-source:` / DevTools (aba Rede) e salvar o arquivo (K c.5.1, c.8.3) | Contém o dado exato (IDs, timestamps) |
| 4 | Arquivo da página completa | PDF, SingleFile (HTML único), WARC/WACZ (ArchiveWeb.page, wget com `--warc-file`) `[ADD]` | Páginas dinâmicas podem falhar |
| 5 | Mídia original | Baixar o arquivo e calcular hash | Plataformas recomprimem; guardar o que a plataforma serve |
| 6 | Arquivo público | Wayback Machine "Salvar página agora" preserva o estado atual do perfil (K c.10.4) | **Cria cópia pública**: evitar em investigação sigilosa ou em andamento |
| 7 | Ata notarial | Tabelião atesta a existência e o modo de existir do fato, inclusive dados eletrônicos (CPC art. 384) | Custo e prazo; indicada para prova |

Mostrar quais camadas foram aplicadas no relatório. Ferramentas de captura de caso (por exemplo, Hunchly) existem, mas são pagas e fora dos materiais `[ADD]`.

## 3. Metadados e hash

Registrar para cada item: ID da evidência (`EV-0001`), URL, plataforma, tipo (perfil, post, mídia, HTML, JSON, captura, export), data/hora UTC da coleta, fuso e relógio usados, ferramenta e versão, navegador, rede (VPN/IP de saída), conta usada (investigação), responsável, método e notas. No `evidence_log.py add`: `--captured` (hora da coleta; sem fuso = fuso do caso), `--tool`, `--tool-version`, `--browser`, `--network`, `--account`, `--method`, `--notes`. O log guarda também a hora do **registro** (`utc`) e a data de modificação do arquivo de origem (`arquivo_mtime_utc`), que é só indício.

**Hash**: SHA-256 (e SHA-512 se o caso exigir) de cada arquivo, calculado logo após a coleta (K c.13.4). O hash prova que o arquivo não mudou depois, não que o conteúdo original era autêntico. O `add` calcula o hash da origem **antes** de copiar e confere a cópia; se divergir, nada é registrado.

## 4. Cadeia de custódia

- Conceito do CPP art. 158-A: conjunto de procedimentos para manter e documentar a história cronológica do vestígio, da obtenção ao descarte. As etapas do art. 158-B (reconhecimento, isolamento, fixação, coleta, acondicionamento, transporte, recebimento, processamento, armazenamento, descarte) servem de roteiro por analogia para evidência digital.
- Boas práticas: ABNT NBR ISO/IEC 27037 (identificação, coleta, aquisição e preservação), RFC 3227 (coleta e arquivamento; descrever claramente como a evidência foi localizada e tratada), NIST SP 800-86.
- **Hash encadeado** (`evidence_log.py`): cada linha guarda o hash da anterior; alterar ou apagar uma linha quebra a cadeia e `verify` acusa. Isso torna a adulteração **evidente**, mas não é prova de data. Para data confiável usar carimbo do tempo de autoridade credenciada (RFC 3161; no Brasil, ICP-Brasil) `[VOL]` ou ata notarial.
- Trabalhar sempre em **cópias**; nunca editar o original; guardar anotações em arquivo separado.
- **Eventos de custódia** depois da coleta (acondicionamento, transporte, recebimento, processamento, armazenamento, descarte, acesso, cópia): `evidence_log.py event --stage <etapa> --evidence EV-0001 … --who … [--to …] [--when …]`. Eles entram na mesma cadeia de hashes e saem no anexo do relatório. Com descarte registrado, `verify` deixa de cobrar o arquivo; o script não apaga nada.
- Para conferência externa: `export --format sha256sums` gera o arquivo no formato do `sha256sum -c`.

## 5. Estrutura de pastas e nomes (K c.13.1)

```
01_Identificadores       usernames, IDs, nicknames
02_Midia_Original        imagens, vídeos, áudios, documentos
03_Pivotagem_Social      novos achados e log de pivôs
04_Preservacao_Web       HTML, JSON, capturas, WARC, logs
05_Analises              metadados, planilhas, scripts, saídas
06_Relatorios_e_Mapas    relatórios, diagramas, grafos
```

Nome de arquivo: `AAAAMMDDThhmmssZ_plataforma_tipo_idcurto.ext` (ex.: `20261013T142205Z_tiktok_perfil_7598746068.html`). `evidence_log.py init` cria a árvore e o `case.json`.

## 6. Contas apagadas, banidas ou alteradas (K c.10–11)

- **Espelhos** (Tikvib, Tikface, Urlebird, K c.10.3 `[VOL]`) guardam capturas em momentos diferentes: dão acesso a conteúdo deletado, histórico de mudanças, acesso sem login e snapshots de períodos distintos. Desvantagens: dados desatualizados, perfis não capturados, qualidade variável.
- **Wayback Machine**: colar a URL do perfil, escolher uma data no calendário, abrir o snapshot. Recupera fotos e bios antigas, descrições modificadas, links removidos e histórico de mudanças (K c.10.4). Caso do EPUB (`@itspolokid`, K c.11.1): a conta não abre mais no site, mas há snapshots com avatar, links da bio e postagens.
- **Limites**: o que se recupera é estático (snapshot); depois de apagado, dados novos não existem; a qualidade depende da frequência de captura (K c.11.1).
- Se o handle mudou, buscar também pelos handles antigos anotados e pelo ID (`04`).

## 7. Armazenamento, retenção e descarte

- Guardar em volume criptografado com backup; separar anexo restrito (dados pessoais de terceiros).
- Definir retenção no `case.json` (por exemplo, até o fim do caso + prazo legal) e descartar com registro do descarte (último passo da cadeia).
- Minimizar: não preservar o que não responde à pergunta do caso (`00`).
- Não guardar senhas, tokens ou chaves junto da evidência.

## 8. Fluxo mínimo com `evidence_log.py`

```
python3 scripts/evidence_log.py init   --case-dir caso-001 --title "..." --collector "Fulano" --tz America/Sao_Paulo
python3 scripts/evidence_log.py add    --case-dir caso-001 --file perfil.html --url https://... --platform tiktok --type html --method "Ctrl+U" \
                                       --captured "2026-05-10 14:22" --tool Firefox --tool-version 131 --browser "perfil dedicado" --network "VPN X" --account nenhuma --notes "..."
python3 scripts/evidence_log.py event  --case-dir caso-001 --stage transporte --evidence all --who "Fulano" --to "Setor Y"
python3 scripts/evidence_log.py verify --case-dir caso-001
python3 scripts/evidence_log.py export --case-dir caso-001 --format csv
python3 scripts/evidence_log.py export --case-dir caso-001 --format sha256sums
```

`verify` precisa ser rodado antes de entregar o caso e após qualquer transferência. `--tz` do `init` é o fuso IANA da localidade do fato (`04` seção 5). As camadas aplicadas aparecem na metodologia do relatório a partir do `--type` e da URL de cada evidência: use os tipos `captura`, `html`/`json`, `pagina`/`warc`, `midia` e `ata`.
