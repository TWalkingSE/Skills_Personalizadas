# 13 — Estudos de caso

Quando ler: ao precisar de um modelo de como conduzir e reportar uma investigação, ao treinar ou ao calibrar o nível de detalhe esperado. Todos os casos são **fictícios ou sintéticos**; nenhum alvo real. `last_reviewed: 2026-10`

## Conteúdo
1. Marca falsa no TikTok (K c.14.1)
2. Servidor Discord que migra para o Telegram (D s.89)
3. Canal público do Telegram divulgando golpe
4. Conta apagada ou banida (K c.11.1)
5. Comentários coordenados em um export (sintético)
6. Loja falsa no Instagram com pagamento por PIX (contexto policial)
7. "Troquei de número" no WhatsApp (falso parente)
8. Anúncio falso no Marketplace do Facebook

## 1. Marca falsa no TikTok (adaptado de K c.14.1)

**Contexto.** Empresa nota o perfil `@empresa_oficial2025` publicando com logotipo parecido e promoções não confirmadas. Cenário fictício; coleta em 10/05/2026.

**Gate.** Pergunta: *a conta é oficial, quem a opera e há vínculo com outros ativos?* Contexto: contrato com a empresa (CTI/marca). Alvo: ator de ameaça (impostor); organização afetada. Modo passivo. Não identificar a pessoa fora de contexto legal.

**Plano.** Hipóteses: H1 conta oficial; H2 conta falsa para enganar. Fontes: perfil público, código-fonte, link da bio, outras redes. Nível 2.

**Passos (ODPAR).**
1. **O/D**: criar caso (`evidence_log.py init`); preservar URL, captura, HTML; registrar seguidores 12.400, seguindo 4.200, curtidas 95.000, link da bio, data da coleta.
2. Código-fonte: User ID, `uniqueId`, `nickname`, `verified`, `createTime`, `bioLink` (`platforms/tiktok.md`); converter `createTime` (`decode_ids.py unix`).
3. **P**: foto de perfil em busca reversa → corresponde ao logotipo oficial; username em outras redes → Instagram, Telegram e X com o mesmo nome; link da bio → WHOIS: domínio registrado há três meses, sem relação aparente; e-mail achado em outra rede → fórum e outros perfis.
4. **A**: últimos 20 vídeos reaproveitam conteúdo oficial sem marca d'água e anunciam promoções inexistentes; comentários repetitivos ("Recebi meu prêmio!", "Funciona mesmo!") de contas recentes com fotos genéricas → `analyze_export.py` no export dos comentários; grafo de vínculos (`build_graph.py`).
5. **R**: relatório (`09`) com recomendações: denúncia por violação de marca à plataforma e a cada rede ligada, takedown do domínio, aviso aos clientes.

**Achados modelo.** *Observação*: logotipo igual ao oficial (EV-0002); domínio novo (EV-0005). *Inferência (moderada)*: tentativa de parecer oficial (palavra "oficial", ano no handle, sem selo, conteúdo copiado). *Inferência (moderada)*: uso de contas falsas para gerar credibilidade (comentários repetidos). *Desconhecido*: quem opera a conta. Conclusão do e-book: **não** foi possível identificar o responsável com alto grau de confiança só com OSINT.

## 2. Servidor Discord que migra para o Telegram (D s.89)

**Contexto.** Denúncia de servidor Discord com convite público que vende contas roubadas; o convite foi divulgado em canal aberto do Telegram.

**Gate.** Contexto: CTI/fraude com contrato ou denúncia institucional. Alvo: comunidade/ator de ameaça. Modo **passivo**; entrar no servidor é interação e exige justificativa e autorização.

**Passos.**
1. **Preservar** a página do convite (nome, ícone, contagens), o código e onde foi publicado; hash.
2. Decodificar IDs disponíveis (`decode_ids.py discord`): data de criação do servidor e de contas citadas.
3. Descrever sem interagir: categorias, cargos, bots que aparecem na prévia pública.
4. Mapear o **ecossistema** (`03` seção 6): vitrine (canal aberto do Telegram), núcleo (grupo fechado), backup (canal reserva), automação (bot de pagamento/entrada), pontes (links e usernames repetidos).
5. Dorks (`discord.gg`, `t.me`) para achar convites residuais e réplicas (`05`).
6. Relatório com o mapa (Mermaid), cronologia (criação do servidor → divulgação → migração) e pedido de remoção à plataforma e à autoridade.

**Armadilhas.** Prints antigos com `Nome#1234`; nome de exibição imitando outro usuário; convite expirado ainda serve de pivô.

## 3. Canal público do Telegram divulgando golpe de investimento

**Contexto.** Canal público promete retorno fixo e leva a um grupo privado e a um bot que cobra "taxa de adesão".

**Gate.** Contexto: CTI/jornalismo/denúncia. Alvo: ator de ameaça. **Coleta passiva**; não entrar nem criar contas falsas para infiltrar.

**Passos.**
1. Preservar `t.me/s/<canal>` (captura + HTML), ID do canal, descrição, número de membros, posts fixados.
2. Ler os posts da prévia pública; registrar datas (UTC), links `t.me`, usernames, telefones e carteiras; hash de cada captura.
3. Indexadores e dorks (`platforms/telegram.md`) para achar réplicas, canais irmãos e histórico.
4. Cadeia: canal → grupo → bot → canal reserva; registrar cada elo e os identificadores estáveis.
5. Verificar a promessa (impossibilidade de retorno fixo) e coletar provas de vítimas só **com consentimento**.
6. Relatório: indicadores (usernames, links, IDs), linha do tempo, recomendação de denúncia (plataforma, polícia, SaferNet/CERT.br conforme o caso `[VOL]`).

## 4. Conta apagada ou banida (K c.11.1)

**Contexto.** O perfil `@itspolokid` do TikTok não abre mais.

**Passos.** Tentar a URL do perfil (confirma que não existe) → Wayback Machine: escolher snapshots anteriores ao banimento → recuperar avatar, links da bio, postagens e outras informações → espelhos (Tikvib, Tikface, Urlebird) → registrar **cada** snapshot com data, URL e hash → anotar limites: estático, qualidade depende da frequência de captura, dados novos não existem (`08` seção 6).

**Achados modelo.** *Observação*: snapshot de 2025-xx-xx mostra bio X (EV-0001). *Inferência*: bio mudou entre dois snapshots. *Desconhecido*: motivo do banimento.

## 5. Comentários coordenados em um export (sintético)

**Contexto.** CSV `assets/exemplos/comentarios_sinteticos.csv` (dados fictícios) com comentários exportados de um post.

**Passos.** `python3 scripts/analyze_export.py assets/exemplos/comentarios_sinteticos.csv --platform tiktok --out analise/` → ler o Markdown: volume e janela de tempo; pico de comentários em poucos minutos; textos duplicados ("Recebi meu prêmio!"); usernames `nome+dígitos`; contas criadas no mesmo dia. **Interpretar como indicadores**, listar explicações alternativas (viralização, fãs), registrar limitações e **não** rotular as contas como bots.

## 6. Loja falsa no Instagram com pagamento por PIX (contexto policial)

**Contexto.** Três vítimas registram ocorrência: compraram eletrônicos de `@loja_exemplo_ofertas` muito abaixo do preço, combinaram pelo direct ou pelo WhatsApp informado na bio, pagaram por PIX e foram bloqueadas. Caso fictício; modelo de `case.json` em `assets/exemplos/case_exemplo_policial.json`.

**Gate.** Contexto policial (IPL; `00` seção 10). Alvo: ator de ameaça (perfil comercial). Vítimas: só os dados que elas entregam ao procedimento (prints, comprovantes, conversa exportada), em anexo restrito. Modo passivo.

**Passos.**
1. **Preservar** (`08`; `platforms/instagram.md`): URL, captura, HTML, **ID numérico**, "Sobre esta conta" (data de entrada, país, número de trocas de nome), bio, link externo, posts e comentários públicos de compradores. Em paralelo, pedir à plataforma a preservação do perfil e dos registros (`00` seção 10).
2. Registrar no log, com `--captured`, os comprovantes e conversas entregues pelas vítimas (tipo `documento`/`captura`), indicando na nota quem entregou e quando.
3. **Pivôs**, cada um com a skill própria: chave PIX e conta recebedora → `financial-intelligence` (e requisição pelos canais formais); telefone do WhatsApp da bio → o que for público (`platforms/whatsapp.md`) e requisição; domínio do link da bio → `domain-intelligence`; username em outras plataformas → `social-media-intelligence`; fotos de produtos → busca reversa (`05`), que costuma achar a loja real de onde foram copiadas.
4. **Analisar**: comentários elogiosos de contas novas → `analyze_export.py` (indicadores, não veredito); linha do tempo (entrada da conta, trocas de nome, datas das compras, bloqueios).
5. **Relatar** com a variante policial (`09` seção 6): achados, respostas aos quesitos, recomendações de preservação e requisição.

**Armadilhas.** O perfil troca de username: pivotar pelo ID. O titular da conta recebedora pode ser conta de passagem ou laranja: titularidade não é autoria. Lojas legítimas com nome parecido existem. Print pode ser editado: pedir o arquivo original e o comprovante emitido pelo banco.

**Achados modelo.** *Observação*: entrada na plataforma em abril/2026 e três trocas de nome (EV-0001); mesma chave PIX em três comprovantes (EV-0002, EV-0003). *Inferência (moderada)*: padrão compatível com loja falsa (perfil recente, preço muito abaixo, só PIX para pessoa física, relatos convergentes). *Desconhecido*: quem opera o perfil.

## 7. "Troquei de número" no WhatsApp (falso parente)

**Contexto.** A vítima recebe mensagem de um número desconhecido com a foto de um parente: "troquei de número, me ajuda com um PIX urgente". Paga e depois descobre o golpe. Caso fictício.

**Gate.** Contexto policial. Alvo: o número usado no golpe. A foto é de um terceiro (o parente), que também é vítima: minimizar os dados dele.

**Passos.**
1. **Preservar** o que a vítima entrega: exportação da conversa feita pelo próprio aparelho dela (arquivo `.txt` ou `.zip`, com hash), prints com data e hora, comprovante do PIX. Número em E.164 (`platforms/whatsapp.md`).
2. Registrar a foto do perfil golpista e a origem dela (perfil público do parente). No grafo, a ligação número → parente é `imitacao`, nunca vínculo de identidade (`09` seção 4).
3. **Pivôs**: chave PIX e conta → `financial-intelligence`; número → requisição à operadora e ao WhatsApp pelos canais formais (`osint-investigator-forense`); número e chave em outros registros de ocorrência → `case-correlation`, quando houver base de casos.
4. **Relatar**: linha do tempo das mensagens (UTC e fuso da localidade da vítima), achados, recomendações.

**Armadilhas.** O chip pode estar cadastrado em nome de terceiro. A foto não identifica o golpista. Não adicionar o número com conta pessoal nem responder (ação ativa, `02`).

**Achados modelo.** *Observação*: primeira mensagem às 14:02 UTC do número +55…, com foto idêntica à do perfil público do parente (EV-0001, EV-0002). *Inferência*: personificação do parente. *Desconhecido*: quem usa o número.

## 8. Anúncio falso no Marketplace do Facebook

**Contexto.** Anúncio de veículo bem abaixo do preço; o "vendedor" pede sinal por PIX para "reservar" e some. Caso fictício.

**Gate.** Contexto policial ou de apoio à vítima. Alvo: o perfil anunciante. O dono real do veículo das fotos pode ser outra vítima: minimizar os dados dele.

**Passos.**
1. **Preservar** já, porque anúncios somem rápido (`platforms/facebook.md`): URL `marketplace/item/<ID>`, `product_id`, captura, HTML; perfil do Marketplace (data de entrada, cidade, avaliações); perfil do Facebook pelo `userID` (atenção: `actorID` e `USER_ID` no código-fonte são da conta logada).
2. **Pivôs**: fotos → busca reversa (`05`), que costuma achar o anúncio legítimo de onde foram tiradas; texto do anúncio em dorks, para achar o mesmo texto em outros perfis e cidades; telefone e WhatsApp do anúncio → requisição; chave PIX → `financial-intelligence`; placa visível nas fotos → `sistema-pericial-alpr` para leitura e consulta aos sistemas oficiais.
3. **Analisar**: avaliações do vendedor (podem vir de contas ligadas), datas de criação, repetição do mesmo anúncio.

**Armadilhas.** O proprietário do veículo das fotos não é suspeito por isso. Avaliações positivas não comprovam legitimidade. O anúncio pode ter sido criado por conta invadida de terceiro: a conta anunciante não é necessariamente o autor.

**Achados modelo.** *Observação*: as fotos do anúncio são as mesmas de um anúncio publicado antes em outra cidade (EV-0003). *Inferência (moderada)*: anúncio fraudulento com fotos reaproveitadas. *Desconhecido*: quem controla o perfil anunciante.
