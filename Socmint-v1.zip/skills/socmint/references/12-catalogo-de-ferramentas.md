# 12 — Catálogo de ferramentas

Quando ler: ao escolher ferramenta, antes de recomendar um serviço de terceiros ou ao validar uma ferramenta nova. Nomes e funções vêm dos materiais (`L`, `D`, `T`, `K`) e de pesquisa `[ADD]`; os links curtos `chlink.me/...` do livro foram omitidos (não verificáveis): **localize pela ferramenta**. Lista pode estar desatualizada: `[VOL]`. `last_reviewed: 2026-10`

## Conteúdo
1. Como ler as colunas
2. Conversão de tempo e identificadores
3. Busca, username e nome
4. Busca reversa de imagem
5. Extração e exportação (pequena escala)
6. Preservação e arquivo
7. Espelhos e visualizadores
8. Linha de comando, APIs e plataformas de análise
9. Bots do Telegram e serviços de terceiros
10. OPSEC e ambiente
11. Telefone, e-mail e vazamentos
12. Como validar uma ferramenta nova

## 1. Como ler as colunas

**Risco**: o que acontece com o dado consultado. `T` = o identificador é enviado a terceiro; `L` = login exigido; `$` = pago ou freemium; `ToS` = uso em escala pode violar termos; `P` = envolve dado pessoal sensível ou invasivo. **Conduta**: *Usar*, *Cautela* (decisão consciente e justificativa), *Restrito* (só em contexto autorizado) ou *Não usar*.

## 2. Conversão de tempo e identificadores

| Ferramenta | Função | Risco | Origem | Conduta |
|---|---|---|---|---|
| `scripts/decode_ids.py` | Snowflake, Unix, TikTok, X, Instagram, faixa do Facebook | Local | skill | Usar |
| EpochConverter, CyberChef | Unix → data ISO | T (baixo) | L p.273, K c.8.2 | Usar |
| TikTok Timestamp (Bellingcat), Unfurl | Data de vídeo, análise de URL | T (baixo) | K c.8.2 | Usar |
| Commentpicker, lookup-id.com, findidfb, TikTok User Finder, Fameswap | ID ↔ perfil | T | L p.300, K c.5.3, c.6.2 | Cautela |
| Extensões "ID Finder" (ESUIT) | Mostra o ID sob a foto | L | L p.300, 451 | Cautela |

## 3. Busca, username e nome

| Ferramenta | Função | Risco | Origem | Conduta |
|---|---|---|---|---|
| Google, Bing, DuckDuckGo, Yandex | Dorks e busca | T (termo) | L cap. 6 | Usar em ambiente isolado |
| WhatsMyName, Blackbird, Sherlock, Instant Username | Onde um username existe | T | L p.246–251 | Cautela |
| Webmii, NAMINT | Nome e padrões de nome/login/e-mail | T | L p.233–236 | Cautela |
| CSEs e indexadores do Telegram (Telegago, Lyzem, TGStat, Telemetr, TgramSearch, TGViewer…) | Achar canais e mensagens | T | T s.85–101 | Usar/Cautela |
| OSINT Framework, repositórios de ferramentas | Catálogos | — | K recursos | Usar |

## 4. Busca reversa de imagem

| Ferramenta | Função | Risco | Origem | Conduta |
|---|---|---|---|---|
| Google Lens, Yandex, Bing Visual Search, TinEye, extensão Search by Image | Origem e reuso de imagem | T (imagem) | L p.251–254; K c.13.3 | Usar |
| PimEyes, FaceCheck.ID | Busca por rosto | T, P (biometria) | L p.254–264 | **Restrito**: nunca para identificar pessoa privada |
| Face++, Betaface | Comparar dois rostos | T, P | L p.264–266 | Restrito |

## 5. Extração e exportação (pequena escala, dados públicos, dentro dos termos)

| Ferramenta | Função | Risco | Origem | Conduta |
|---|---|---|---|---|
| Instant Data Scraper (Pokebola) | Exportar tabelas (seguidores, comentários) CSV/XLSX | L, ToS | L p.287; K c.9.2 | Cautela |
| Extensões ESUIT (álbuns, vídeos, posts, comentários, reações, membros), InsFo, IGFET, InsC, Growman, IG Downloader, Exact Time Viewer | Exportação e download em redes Meta | L, ToS, $ (limites gratuitos 50–300) | L cap. 9–10 | Cautela |
| TTExporter, TTCommentExporter | Seguidores e comentários do TikTok | L, ToS | K c.9.2–9.3 | Cautela; só conta de investigação |
| Exportcomments | Comentários (100 grátis) | T, $ | L p.286; K c.9.5 | Cautela |
| Compare Friends, Highlight This!, JSON Formatter, Simple AutoScroll, Scroll To Top | Cruzar listas, destacar texto, ver JSON, rolar | Local | L p.208, 248, 270 | Usar |
| Scripts colados no console do navegador | Exportar membros de grupo | ToS, self-XSS | L p.406–411 | **Não usar** |

## 6. Preservação e arquivo

| Ferramenta | Função | Risco | Origem | Conduta |
|---|---|---|---|---|
| `scripts/evidence_log.py` | Log com hash encadeado | Local | skill | Usar |
| Wayback Machine (consulta e "salvar página") | Histórico e preservação | Cópia **pública** ao salvar | K c.10.4 | Cautela |
| SingleFile, ArchiveWeb.page (WACZ/WARC), `wget --warc-file`, archive.today | Captura completa da página | T (archive.today) | `[ADD]` | Usar/Cautela |
| Hunchly | Captura contínua de caso | $ | `[ADD]` | Usar (pago) |
| Ata notarial | Prova com fé pública | Custo | CPC art. 384 | Usar (nível 3) |

## 7. Espelhos e visualizadores `[VOL]`

Tikvib, Tikface, Urlebird (TikTok; K c.10.3) · Picuki, Picnob e visualizadores de stories de terceiros (Instagram; L p.520–523): exploram APIs sem autorização, duram pouco, recebem o termo buscado e podem estar desatualizados. **Cautela**.

## 8. Linha de comando, APIs e plataformas de análise

| Ferramenta | Função | Risco | Origem | Conduta |
|---|---|---|---|---|
| TikSpyder (SerpAPI, Apify, yt-dlp) | Coleta TikTok com JSON/CSV | $, chaves, ToS | K c.12.1 | Cautela; chaves em variáveis de ambiente |
| Clawk | Coleta TikTok por username | ToS | K c.12.2 | Cautela |
| Telethon, python-telegram-bot, BotFather | Scripts e bots próprios | L, token | T s.141–153 | Usar para o **próprio** bot de alertas |
| TelegramScraper, Telerecon, inTelligram, TEx | Membros, mensagens, encaminhamentos, URLs | L (conta logada), ToS | T s.105–114 | Cautela |
| Osintgram | Coleta em massa no Instagram com credenciais | L, ToS, P | L p.563–565 | Restrito |
| Lampyre, Epieos, IntelX | Pesquisa por e-mail/telefone/domínio; enriquecimento | T, $, P (podem incluir dado vazado) | L p.244–245, 654 | Restrito |
| Hunterintel (Xhunt) | Locais por área | $, T | L p.540–544 | Cautela |
| Maltego, SpiderFoot, Gephi, networkx | Grafos e automação | Variável | L bibliografia; `[ADD]` | Usar; `scripts/build_graph.py` é a opção local |
| `scripts/to_bundle.py` | Exporta o caso (evidências, grafo, achados, hipóteses, timeline, pivôs) como `intel-bundle/1.0` para o Investigative Notebook | Local | skill | Usar |

## 9. Bots do Telegram e serviços de terceiros

| Bot ou serviço | Função | Conduta |
|---|---|---|
| ID Bot, Creation Date Bot, SangMata, MotherSearch, Search4TG, Telegram DB Search | ID, estimativa de data, histórico de nomes, busca de canais | Cautela: o bot **lê e pode guardar** o que você consulta (T s.127) |
| Regrambot (monitor de Instagram) | Exige credenciais da conta; vigilância de pessoa | Restrito (só conta de organização autorizada) |
| TrueCaller Bot, US2Leak, AllInOneLeaks, Mr. Homes e bots de "puxada" de CPF | Consultam agendas e vazamentos; "puxadas" vendem dados obtidos ilicitamente | **Não usar** (LGPD, `00`) |

## 10. OPSEC e ambiente (`02`)

VirtualBox, VMware Workstation Player, TL OSINT VM (Trace Labs), OriON, Genymotion, MuMu Player, LDPlayer, MEmu · VPNs (evitar gratuitas) · ipinfo.io, dnsleaktest.com, BrowserLeaks, Cover Your Tracks (EFF) · Firefox, Brave, Tor Browser · NoScript, uBlock Origin, Privacy Badger, Canvas Fingerprint Defender, extensão de User-Agent. Origem: L p.120–166; T s.10–37.

## 11. Telefone, e-mail e vazamentos

| Ferramenta | Uso aceito | Uso **não** aceito |
|---|---|---|
| Have I Been Pwned, SpyCloud | Checar e monitorar **seus** e-mails/telefones e os de organização que autorizou | Consultar terceiros privados |
| Busca por telefone em Telegram/WhatsApp/Skype, "TG Phone Number Checker", Bizum, buscadores de vazamento (ex.: FuckFacebook) | Verificar o **próprio** número ou número com consentimento | Associar número a pessoa física (`00`) |
| Monitores de "online" do WhatsApp, WA Web Plus (mensagens apagadas, status anônimo), geradores de print falso | — | **Não usar** (`platforms/whatsapp.md`) |

## 12. Como validar uma ferramenta nova (Berkeley Protocol, Anexo V)

- **Características**: código aberto ou fechado; paga ou gratuita; quem é o dono, afiliações e interesses; como é financiada e qual a vida útil provável.
- **Segurança**: quem é dono da ferramenta e do código; auditoria independente; **onde os dados coletados ficam e quem tem acesso**; infraestrutura de segurança; obrigações legais que afetam o uso; existe direito de reparação em caso de violação.
- **Operação**: funcionalidades; usabilidade; suporte; frequência de atualização; compatibilidade com o restante do ambiente.
- Decisão: registrar no plano de coleta a ferramenta, a versão e o que ela recebe do caso (`assets/plano-de-coleta.md`).
