# 05 — Busca avançada, dorks e busca reversa

Quando ler: ao montar consultas em buscadores, descobrir conteúdo de redes sociais pela indexação, fazer busca reversa de imagem ou escolher mecanismos de busca por username. Gerador: `scripts/dork_builder.py`. Fontes: livro cap. 6 e 8 (L p.97–118, 232–266), slides do Telegram (T s.82–101), EPUB (K c.9.1). `last_reviewed: 2026-10`

## Conteúdo
1. Por que dorks funcionam em redes sociais
2. Operadores
3. Regras de sintaxe
4. Padrões por plataforma
5. Truques úteis
6. Mecanismos de busca reversa de imagem
7. Busca por username, nome e e-mail
8. Limites
9. Volatilidade e fontes

## 1. Por que dorks funcionam em redes sociais

Redes sociais costumam ter busca interna fraca e não indexam textos de bio; o Google indexa legendas, bios e menções (L p.533). Por isso "as buscas em redes sociais estão apoiadas pelos dorks do Google e pela informação indexada" (L p.532). O rastreador do Google descobre páginas por links, sitemaps e `robots.txt` (L p.97). Dorks são uma técnica **legítima de pesquisa**, também usada para achar credenciais e falhas; o uso deve respeitar o gate (`00`).

## 2. Operadores (L p.101–117)

| Operador | Efeito | Exemplo |
|---|---|---|
| `site:` | Restringe a um domínio ou caminho | `site:linkedin.com "Nome Sobrenome"` |
| `inurl:` / `allinurl:` | Termo na URL | `inurl:instagram.com/p/ "texto"` |
| `intext:` / `allintext:` | Termo no corpo | `intext:"Nome Sobrenome"` |
| `intitle:` / `allintitle:` | Termo no título | `intitle:"Trump x Biden"` |
| `inanchor:` | Termo no texto do link | |
| `filetype:` / `ext:` | Tipo de arquivo | `intext:"CV Nome" filetype:pdf` |
| `"frase exata"` | Combinação exata | `"contact us" site:t.me` |
| `OR` / `\|` | Um ou outro | `Trump OR Biden` |
| `-termo` | Exclui | `intext:"Nome" -site:facebook.com/perfil` |
| `*` | Curinga | `site:*.empresa.*` |
| `( )` | Agrupa | `(Tesla OR SpaceX) site:x.com` |
| `AROUND(n)` | Palavras a no máximo n palavras de distância `[ADD]` | `"fulano" AROUND(5) "empresa"` |
| `before:` / `after:` | Janela de datas `[ADD][VOL]` (`dork_builder.py --after/--before`) | `after:2026-01-01` |
| `related:`, `link:`, `define:`, `location:` | Citados no livro; alguns foram descontinuados `[VOL]` | |

## 3. Regras de sintaxe (L p.117)

Operadores em minúsculas (`AND` e `OR` em maiúsculas) · **sem espaço** depois de `:` · aspas quando a expressão tem mais de uma palavra · combine operadores e repita termos na mesma consulta. Suporte varia entre Google, Bing, DuckDuckGo e Yandex; `inurl:` e `intext:` são mais confiáveis no Google. Confirme no motor usado `[VOL]`.

## 4. Padrões por plataforma (detalhes e fonte em cada playbook)

| Plataforma | Padrões principais |
|---|---|
| Instagram | `site:instagram.com "texto da bio"` · `inurl:instagram.com/p/ "legenda"` · `site:instagram.com "quemmenciona" @alias` · `site:instagram.com/explore/locations/ "local"` |
| Facebook | `intext:"Nome" inurl:facebook.com` · `"termo" site:facebook.com inurl:ref=page_internal` · `site:facebook.com/groups/<ID>/posts "Nome"` · `site:facebook.com inurl:/about_contact_and_basic_info "e-mail"` |
| Threads | `site:threads.com/@ "termo"` · `site:threads.com/t/ "termo"` e as variantes `.net` |
| TikTok | `"@usuario" site:tiktok.com` · `site:tiktok.com #hashtag` · `"nome" site:tiktok.com` |
| Kwai | `site:kwai.com "termo"` · `site:kwai.com/@<kwai_id>` · `site:kwai.com inurl:video "termo"` |
| Telegram | `<termo> site:t.me` · `site:t.me/joinchat inurl:<termo>` · `"Telegram @usuario" site:linkedin.com` |
| WhatsApp | `site:chat.whatsapp.com "termo"` · `intext:chat.whatsapp.com/invite/ intitle:<termo>` |
| Discord | `site:discord.gg "termo"` · `site:discord.com/invite "termo"` |
| Reddit | `site:reddit.com/user/<nome>` · busca interna `author:`, `subreddit:`, `title:` |
| X | `site:x.com "termo"` · operadores nativos `from:`, `since:`, `until:` |
| LinkedIn | `site:linkedin.com/in "Nome Sobrenome"` |
| YouTube | `site:youtube.com "termo"` · `site:youtube.com/@handle` |

## 5. Truques úteis

- **Excluir o perfil já achado** para ver outros perfis e menções: `intext:"Nome" -site:facebook.com/<perfil>` (L p.233).
- **Nome em currículo**: `intext:"CV Nome Sobrenome" filetype:pdf` (L p.111); currículos costumam trazer redes e portfólio (L p.233).
- **Emojis**: o Google indexa o texto como o usuário o digitou; combinar `intext:` com emojis de telefone para achar contato publicado (L p.112). Bios do Instagram trazem muitos emojis.
- **Variações de grafia**: nome com e sem acento, ordem de sobrenomes (o país de origem define a ordem materno/paterno, L p.233), apelidos, nome de solteira.
- **Imagens**: pesquisar por texto que a plataforma gera automaticamente para imagens, como "May be an image of…" (L p.330).
- **Arquivos e cache**: Wayback e arquivos públicos para versões antigas (`08`). O link "em cache" do Google foi descontinuado `[VOL]`.
- **Documentos expostos por engano** (Drive etc., L p.112–114): útil na **auditoria da própria organização** (`10`). Ao achar documento sensível de terceiros, não baixe nem redistribua; avise o titular ou a plataforma.

## 6. Mecanismos de busca reversa de imagem

| Ferramenta | Uso | Observação |
|---|---|---|
| Google Lens, Yandex Images, Bing Visual Search, TinEye | Origem e reuso de uma imagem | Resultados diferem muito entre motores; testar vários (K c.13.3; L p.252–254) |
| Extensão "Search by Image" | Envia a imagem a mais de 30 motores de uma vez | Local ao navegador; a imagem sai para terceiros |
| PimEyes, FaceCheck.ID | Busca **por rosto** | **Identifica pessoa por dado biométrico** (dado pessoal sensível, LGPD arts. 5º II e 11). Só com base legal; **não** usar para identificar pessoa privada. O PimEyes implantou detecção de idade para limitar buscas com rostos infantis (L p.260) |
| Face++, Betaface | Comparar rosto A × B para decidir se são a mesma pessoa em um caso **já autorizado** | Mesma cautela de dado sensível |

Fotos de perfil são reutilizadas com mais frequência que aliases (L p.251), por isso valem como pivô, mas **foto sozinha é indício fraco** (`06`).

## 7. Busca por username, nome e e-mail

- **Username**: WhatsMyName (consulta vários *usernames* e categorias, exporta CSV/PDF), Blackbird (570+ sites), Sherlock, Instant Username (mostra onde o nome está "ocupado") (L p.246–251). Punctuação: `.`, `-` e `_` não valem em todas as redes: consultar variações (L p.251). O prefixo de um e-mail costuma ser usado como username (L p.246). `scripts/name_variants.py` gera candidatos.
- **Nome**: Webmii e geradores de padrões (NAMINT) (L p.233–236); NAMEINT é o nome dado à investigação por nome. Sempre acompanhado de **verificação de identidade** (`06`).
- **E-mail e telefone**: Epieos, Lampyre e IntelX (pagos) mostram em que serviços um dado está cadastrado ou exposto. São pivôs **fortes e invasivos**: usar para e-mails do próprio caso, da organização ou publicados pelo titular; para pessoa privada, gate (`00`). Telefone: ver limites em `platforms/whatsapp.md` e `platforms/telegram.md`.
- **Telegram**: CSEs e indexadores em `platforms/telegram.md` seção 6.

## 8. Limites

- Dorks para achar **credenciais, painéis administrativos, arquivos privados ou falhas** de terceiros (categorias do Google Hacking Database) estão fora do escopo (CP art. 154-A e `00`).
- Não usar consultas para localizar endereço ou rotina de pessoa privada (`00` seção 4).
- Cada termo digitado fica registrado no buscador: usar o ambiente isolado (`02`). Por isso o `dork_builder.py` gera links só para Google, Bing e DuckDuckGo por padrão; motores sob outra jurisdição (Yandex) entram só com `--engines`, por decisão consciente. Para busca reversa de imagem o Yandex segue útil (seção 6), com a mesma ressalva.

## 9. Volatilidade e fontes

`[VOL]`: suporte de operadores, índices de plataformas, ferramentas. Fontes: L p.97–118 (dorks e GHDB), L p.232–266 (nome, alias, foto), K c.9.1, T s.82–101; "Mastering Google Search Operators in 67 Easy Steps" (Moz) é a referência citada pelo livro para ampliar (L p.114).
