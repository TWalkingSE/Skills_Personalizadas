# 10 — Autodefesa e exposição (uso defensivo)

Quando ler: o usuário quer saber o que o mundo vê sobre ele ou sobre a organização que consentiu, proteger contas, checar vazamentos dos **próprios** e-mails e telefones, configurar 2FA e privacidade, ou recuperar conta. Fontes: livro cap. 5 e 12.6 (L p.66–96, 660), slides do Telegram (T s.64–69), pesquisa complementar `[ADD]`. `last_reviewed: 2026-10` (caminhos de menus mudam: `[VOL]`)

## Conteúdo
1. Princípio
2. Auditoria de pegada digital (pessoa)
3. O que fica visível mesmo com perfil fechado
4. Vazamentos: checar só o que é seu
5. 2FA e segurança de conta
6. Privacidade por plataforma
7. Conta hackeada
8. Direitos e remoção de conteúdo
9. Auditoria de exposição organizacional (com consentimento)
10. Checklist

## 1. Princípio

Usar as técnicas de SOCMINT **sobre si mesmo** (ou sobre organização que autorizou) mostra a superfície que outras pessoas veem. O mesmo conjunto de pivôs que serve a quem investiga serve a quem ataca: username reutilizado, e-mail na bio, foto reaproveitada, geotag, lista de amigos. Esta referência é defensiva: nada aqui autoriza aplicar a auditoria a terceiros sem consentimento (`00`).

## 2. Auditoria de pegada digital (pessoa)

1. **Inventário**: listar contas, e-mails, telefones e usernames; marcar contas esquecidas.
2. **Reuso**: o mesmo username, foto e bio em várias redes liga todas as contas (`06`). Variar o que for sensível.
3. **Pesquisar a si mesmo** com os mesmos dorks e a busca reversa de imagem (`05`): nome, username, e-mail exato, telefone, foto de perfil. Anotar o que aparece.
4. **Bios e links**: remover e-mail e telefone desnecessários, links para outras contas pessoais, datas e locais.
5. **Fotos**: metadados e fundo (placas, uniforme, fachada), geotags; evitar rosto de crianças em perfil aberto.
6. **Listas**: seguidores, amigos e "seguindo"; ocultar quando possível.
7. **Contas antigas**: apagar ou proteger; revisar apps conectados e sessões ativas.
8. **Marketplace e avaliações**: perfis de venda e comentários criados expõem cidade, data de entrada e opinião (L p.372, 351).

## 3. O que fica visível mesmo com perfil fechado

Pelos achados do livro (cap. 9–11), costuma permanecer público:
- **Facebook**: foto de perfil (se a audiência não for "Só eu"), **foto de capa** (sempre) com reações e comentários de amigos, família e relacionamentos, comentários criados em estabelecimentos, perfil do Marketplace, menções de terceiros em grupos públicos, nomes alternativos (L p.304, 315–317, 351, 372).
- **Instagram**: foto, bio e, se for conta profissional, contato público; menu "Sobre esta conta" (data de entrada, país, número de trocas de nome); **Threads aberto** em conta privada (L p.460, 553).
- **WhatsApp**: foto de perfil para quem tiver o número, conforme a configuração; membros de um grupo veem o número uns dos outros (L p.635, 610).
- **Telegram**: username público, foto e bio, conforme privacidade; número visível se não ocultado (T s.66–67).

## 4. Vazamentos: checar só o que é seu

- **Have I Been Pwned** (haveibeenpwned.com): confirma se **seu** e-mail (e, em alguns casos, telefone) apareceu em vazamentos conhecidos; o serviço de telefone cobre só alguns vazamentos, o que não exclui outros (L p.71–74). **SpyCloud** oferece monitoramento corporativo pago (L p.74). Serviços de monitoramento de dark web de consumo existem (L p.76) `[VOL]`.
- Ativar **notificações de vazamento** para todos os seus e-mails, inclusive de trabalho. É uma ação **ativa**: não fazer em e-mail de terceiros sem autorização (L p.77–78).
- Se aparecer em um vazamento: trocar a senha da conta e de todas que a reutilizam, ativar 2FA, revisar e-mail de recuperação e sessões, desconfiar de phishing que cite dados do vazamento.
- Não use bases vazadas para consultar terceiros (`00`).

## 5. 2FA e segurança de conta

Fatores: conhecimento (senha), posse (aplicativo, token, telefone), inerência (biometria), localização e tempo (L p.79–81). Preferir **aplicativo autenticador** ou chave de segurança a SMS; guardar **códigos de recuperação**; usar **gerenciador de senhas**.

Onde ativar (rótulos do livro; menus mudam `[VOL]`): Facebook: Configurações e privacidade › Configurações › Segurança e login · Instagram e Threads: app › Perfil › Configurações › Segurança › Autenticação em dois fatores (a web só aceita SMS; Threads usa as configurações do Instagram) · X: Configurações e privacidade › Segurança e acesso à conta › Segurança · TikTok: Perfil › menu › Segurança › Verificação em 2 etapas (SMS ou e-mail) · LinkedIn: Configurações › Login e segurança › Verificação em duas etapas · Telegram: Configurações › Privacidade e segurança › Verificação em duas etapas (definir senha, dica que **não** revele a senha, e-mail de recuperação) · WhatsApp: Configurações › Conta › Verificação em duas etapas (PIN de 6 dígitos e e-mail; sem e-mail, redefinir leva 7 dias) (L p.78–96).

## 6. Privacidade por plataforma

- **Telegram**: as mesmas configurações da conta do investigador servem para proteção pessoal; lista completa em `02` seção 6 (T s.64–69). Para uso pessoal, vale também restringir a adição a grupos e canais a contatos. Desativar qualquer recurso de localização por proximidade; o **People Nearby foi removido em set/2024** `[ADD]`.
- **WhatsApp**: revisar foto, "visto por último", recado e quem pode adicionar a grupos; **usernames** (quando disponíveis) permitem não revelar o número, e a chave opcional restringe quem consegue iniciar conversa `[VOL]` (L p.660; D s.84–85). Cuidado com extensões de terceiros que leem conversas.
- **Instagram/Facebook**: tornar conta privada; foto de perfil com audiência restrita; ocultar lista de amigos e seguidores; restringir quem pode marcar; revisar "Sobre esta conta" e contato público; desativar sincronização de contatos se não for necessária.
- **Reddit** (`[ADD]`): "Curate your profile" oculta posts e comentários do perfil por comunidade; o histórico continua visível nas comunidades e na busca.
- **Dispositivo**: bloqueio de tela, atualizações, permissões de apps, revisão de sessões ativas.

## 7. Conta hackeada

- **Instagram**: fluxo oficial em `instagram.com/hacked`, em um dispositivo ou navegador já usado na conta; informar o username antigo ou atual; escolher e-mail ou telefone válido; se o atacante trocou os dados, usar "outro método"; o passo final é um **vídeo-selfie** de verificação seguindo as instruções do suporte; acompanhar o e-mail de resposta; criar novo e-mail com 2FA se o antigo foi comprometido (L p.577–587) `[VOL]`.
- Em qualquer rede: trocar senha e e-mail de recuperação, encerrar sessões, ativar 2FA, avisar contatos, denunciar à plataforma, **preservar evidências** do incidente (`08`) e, se houve fraude, registrar ocorrência.
- Contas profissionais e de influenciadores são alvo frequente; o risco é financeiro e reputacional (L p.577).

## 8. Direitos e remoção de conteúdo

- LGPD art. 18: o titular pode pedir confirmação de tratamento, acesso, correção, eliminação e outras medidas aos controladores `[conferir texto vigente]`.
- Pedir remoção a plataformas (denúncia por violação de privacidade, impersonação) e a buscadores (pedidos de remoção de resultados com dados pessoais) `[VOL]`.
- Apagar nesta ordem: publicações, depois perfis, depois desindexar o que restou nos buscadores (L p.173–174). Arquivos públicos (Wayback) exigem pedido ao arquivo.

## 9. Auditoria de exposição organizacional (com consentimento)

Escopo escrito e autorização do responsável (`00`, `assets/checklist-gate.md`). Itens:
1. **Perfis oficiais** (lista de todos os canais da marca) e **perfis falsos ou impostores** (nome, logotipo, domínio parecido; K c.14.1): preservar, comparar IDs e datas, denunciar à plataforma.
2. **Exposição de funcionários e executivos**: perfis profissionais, e-mails publicados, organogramas inferíveis, viagens e rotinas públicas; orientar sem perfilar pessoas além do necessário.
3. **Documentos expostos por engano** na **própria** organização (planilhas, contratos, pastas abertas em nuvem; L p.112–114): localizar com dorks restritos ao domínio e fechar o acesso.
4. **Vazamentos** de e-mails corporativos (HIBP/serviços de monitoramento de domínio, com autorização do titular do domínio).
5. **Engenharia social**: que informação pública ajuda um golpista (cargos, fornecedores, horários)? Treinar a equipe.
6. **Plano de resposta**: quem decide, quem denuncia, prazos, evidências (`08`), comunicação.
Relatório com Observação/Inferência/Desconhecido e recomendações priorizadas (`09`).

## 10. Checklist

- [ ] 2FA por aplicativo em e-mail, redes e bancos; códigos de recuperação guardados
- [ ] Senhas únicas em gerenciador
- [ ] Notificações de vazamento ativas para os seus e-mails
- [ ] Contas antigas apagadas ou protegidas
- [ ] Username, foto e bio não ligam todas as contas sem necessidade
- [ ] Bios sem e-mail/telefone/local desnecessários; fotos sem metadados e geotags
- [ ] Configurações de privacidade revisadas em cada plataforma
- [ ] Sessões e apps conectados revisados
