# 00 — Gate legal e ético

Quando ler: antes de aceitar um alvo que seja pessoa física, ao receber pedido sensível, ao fundamentar o escopo de um relatório, ou quando a coleta serve a procedimento de polícia judiciária (seção 10). Não é aconselhamento jurídico; conferir o texto vigente das normas. `last_reviewed: 2026-10`

## Conteúdo
1. Gate de 5 perguntas
2. Categorias de alvo
3. Resultado do gate
4. Limites rígidos
5. Modelos de recusa
6. Ajustes por contexto de uso
7. Princípios de referência
8. Ponteiros legais (Brasil)
9. Privacidade do próprio caso
10. Contexto policial (inquérito, VPI, BO)

## 1. Gate de 5 perguntas

Fazer as perguntas que faltarem, de forma curta, antes de coletar. Resposta ausente ou evasiva = tratar como "não atendido".

| # | Pergunta | Sinal de alerta |
|---|---|---|
| 1 | **Pergunta de investigação**: que decisão ou dano a investigação resolve? Deve ser específica e verificável. Bom: "identificar vínculos societários, ativos digitais e exposição pública da empresa XYZ". Ruim: "investigar uma empresa" (K c.13.6) | "Descobrir tudo sobre fulano" |
| 2 | **Contexto e autorização**: quem demanda e com que respaldo (contrato/cliente, redação, ofício ou ordem, ambiente de treino/CTF, pesquisa com ética)? | Motivação pessoal (ex-parceiro, vizinho, desafeto) ou urgência emocional |
| 3 | **Categoria do alvo** (seção 2) | Pessoa privada, menor, vítima, denunciante, jornalista, ativista |
| 4 | **Necessidade e minimização**: quais dados são estritamente necessários e por quanto tempo serão guardados? | Coleta "por via das dúvidas"; endereço, rotina ou família sem relação com a pergunta |
| 5 | **Passivo ou ativo**: só observar o que é público, ou interagir (conta de investigação, mensagem, entrar em grupo)? | Engano para obter acesso |

## 2. Categorias de alvo

| Categoria | Tratamento padrão |
|---|---|
| Organização (empresa, ONG, órgão) | Seguir: ativos digitais, perfis oficiais e falsos, vínculos societários, exposição |
| Figura pública, no papel público | Seguir com foco em atividade e conteúdo públicos; evitar vida privada e família |
| Ator de ameaça, golpista, rede de desinformação | Seguir: indicadores técnicos e comportamentais, preservar, encaminhar à plataforma/autoridade; evitar identificar a pessoa fora de contexto legal |
| Pessoa privada | Seguir **com restrições**: só com base legal/contrato e necessidade; sem endereço, rotina ou localização; sem perfis privados |
| Menor de idade | Não coletar sobre o menor (exceto proteção por canal institucional) |
| Vítima, denunciante, jornalista, ativista, pessoa em risco | Não desanonimizar; orientar proteção e canais legais |

## 3. Resultado do gate

- **Seguir**: pergunta específica + contexto legítimo + categoria permitida + coleta passiva.
- **Seguir com restrições**: registrar no plano os campos proibidos, a retenção, a ausência de contato e a máscara de PII.
- **Recusar e redirecionar**: seção 4 e 5. Responder em 1–2 frases e oferecer alternativa lícita, sem sermão.

## 4. Limites rígidos (sempre, mesmo com autorização declarada)

Lista de referência. O resumo no `SKILL.md` (seção 2) e as caixas de `assets/checklist-gate.md` repetem estes oito itens, na mesma ordem: ao alterar um item aqui, altere os dois.

1. Localizar endereço, rotina ou posição em tempo real de pessoa privada (risco de perseguição, CP art. 147-A).
2. Acessar contas, dispositivos ou mensagens de terceiros, ou contornar controles de acesso e privacidade (CP art. 154-A). Inclui pretexto de "recuperar senha", token roubado e self-bot.
3. Desanonimizar crítico, denunciante, jornalista, vítima ou perfil pseudônimo sem base legal.
4. Material de abuso sexual infantil: não baixar, não descrever, não encaminhar; interromper e orientar a denúncia (SaferNet Brasil, Disque 100, polícia) `[VOL]`.
5. Fabricar identidade, documento, foto de pessoa real, print ou conversa falsos; personificar terceiros.
6. Operar redes de perfis falsos para influenciar, assediar ou fraudar.
7. Usar bases vazadas ou agendas de terceiros para identificar pessoa física.
8. Infiltração enganosa em grupos criminosos: a lei admite infiltração virtual de **agentes de polícia**, com autorização judicial (Lei 12.850/2013, art. 10-A; ECA, art. 190-A). Particular não tem esse respaldo.

## 5. Modelos de recusa

- **Localizar/monitorar pessoa**: "Não posso ajudar a localizar ou monitorar uma pessoa física; isso pode configurar perseguição. Se há risco real, registre ocorrência/medida protetiva; se for cobrança ou citação, use advogado ou oficial de justiça. Posso ajudar a avaliar a sua própria exposição."
- **Conta privada/senha**: "Não posso ajudar a acessar conta ou conteúdo privado de terceiros. Posso mapear o que é público e lícito ou orientar um pedido formal (ofício/ordem judicial) pelos canais da plataforma."
- **Perfis falsos para entrar em grupo**: "Não vou orientar a criar identidades falsas para entrar em grupos. Posso estruturar coleta passiva de canais públicos, preservar evidências e preparar a denúncia à plataforma ou à autoridade."
- **Vazamentos**: "Não consulto bases vazadas para identificar pessoas. Posso verificar a exposição dos *seus* e-mails/domínios, com consentimento, e propor medidas de proteção."

## 6. Ajustes por contexto de uso

| Contexto | Ajuste |
|---|---|
| Estudo/CTF | Alvos fictícios, contas próprias ou CTFs com regras de escopo (ex.: CTFs de busca de pessoas desaparecidas de entidades como a Trace Labs). Nunca alvo real sem autorização |
| Perícia, segurança pública, compliance | Base legal formal, hash e cadeia de custódia completos, ata notarial quando for prova, relatório reprodutível (`08`, `09`) |
| Polícia judiciária (IPL, VPI, BO) | Seção 10: base legal própria, pedido de preservação à plataforma em paralelo à captura, variante policial do relatório |
| Jornalismo/checagem | Interesse público, verificação em múltiplas fontes, proteção de fontes e vítimas, direito de resposta |
| CTI, fraude, marca | Escopo contratual; foco em infraestrutura e indicadores (handles, IDs, URLs, domínios); encaminhar takedown à plataforma e à autoridade; não identificar a pessoa sem base |

## 7. Princípios de referência

- **Berkeley Protocol** (ONU/UC Berkeley): princípios profissionais, metodológicos e éticos; segurança; preparação (avaliação de ameaça e risco digital, avaliação do cenário digital, plano de investigação online, plano de resiliência e autocuidado, políticas de dados e ferramentas); processo (consultas online, avaliação preliminar, coleta, preservação, verificação, análise investigativa); relato. Modelos de anexo: plano, avaliação de risco, cenário digital, formulário de coleta (D s.33).
- **Fonte aberta** (Berkeley, via D s.34): conteúdo acessível a qualquer usuário na jurisdição, inclusive com login ou cadastro abertos a todos, **sem violar controles de privacidade ou segurança**. Informação privilegiada, classificada ou protegida pode ter uso restrito como prova e problemas de autoria e verificação.
- **Demos/SOCMINT** (Omand, Bartlett, Miller, 2012): causa suficiente e sustentável; integridade de motivo; métodos proporcionais e necessários; autoridade adequada, com supervisão externa; recurso a meios secretos só como último recurso se fontes abertas bastarem; perspectiva razoável de sucesso.
- **Princípios éticos do EPUB** (K c.15): legalidade (leis locais, termos de serviço, consentimento quando necessário), privacidade, transparência (documentar métodos e limites), responsabilidade (evitar dano, considerar consequências). Violações: ações legais, banimento, dano reputacional, responsabilidade civil.
- **Aviso do livro** (L p.24–25): ferramentas gratuitas podem usar ou vender os dados que você consulta; as exigências legais variam por país e são responsabilidade de quem investiga.

## 8. Ponteiros legais (Brasil) — conferir texto vigente

| Norma | Para que serve aqui |
|---|---|
| LGPD (Lei 13.709/2018), art. 6º | Princípios de qualquer tratamento: finalidade, adequação, necessidade, transparência, segurança, prevenção, não discriminação, responsabilização |
| LGPD art. 7º §§3º, 4º, 7º | Dado de acesso público: considerar finalidade, boa-fé e interesse público que justificaram a publicação. Consentimento dispensado para dado tornado manifestamente público pelo titular, sem afastar princípios e direitos. Novo uso exige propósito legítimo e específico |
| LGPD art. 10 e §1º | Legítimo interesse: finalidades legítimas, situações concretas, só dados estritamente necessários, transparência |
| LGPD art. 4º | Exceções para fins exclusivamente jornalísticos/artísticos, acadêmicos (com arts. 7º e 11) e de segurança pública/investigação penal (lei específica). O §2º veda esse último tratamento por pessoa de direito privado, salvo sob tutela de pessoa jurídica de direito público: **particular não pode invocar a exceção policial** |
| Código Penal art. 147-A (Lei 14.132/2021) | Perseguição reiterada, por qualquer meio, que invada ou perturbe a liberdade ou a privacidade; pena aumentada contra criança, adolescente, idoso, mulher por razões de sexo feminino |
| Código Penal art. 154-A (Lei 12.737/2012; ver redação atual após Lei 14.155/2021) | Invasão de dispositivo informático |
| Marco Civil da Internet (Lei 12.965/2014), arts. 7º e 22 | Privacidade e sigilo das comunicações; registros de conexão/acesso por ordem judicial |
| CPP arts. 158-A a 158-F (Lei 13.964/2019) | Cadeia de custódia (reconhecimento, isolamento, fixação, coleta, acondicionamento, transporte, recebimento, processamento, armazenamento, descarte), aplicável por analogia à prova digital |
| CPC art. 384 | Ata notarial atesta a existência e o modo de existir de um fato, inclusive dados eletrônicos de imagem e som |
| Lei 12.850/2013 art. 10-A | Infiltração virtual por agentes de polícia, com autorização judicial |
| ABNT NBR ISO/IEC 27037, RFC 3227, NIST SP 800-86 | Boas práticas de identificação, coleta e preservação de evidência digital |

Fora do Brasil: perguntar a jurisdição (GDPR e leis locais). Em caso de dúvida jurídica, recomendar advogado.

## 9. Privacidade do próprio caso

- Dados enviados ao chat são processados pelo provedor: minimizar PII, mascarar (`--redact` em `make_report.py`), nunca enviar material ilícito. Casos sensíveis pedem ambiente local ou controlado conforme a política da organização.
- Nunca pedir nem guardar senhas, tokens, `api_id`/`api_hash`, chaves de SerpAPI/Apify: usar variáveis de ambiente (T s.73; K c.12.1).
- Definir retenção e descarte seguro no `case.json`.
- Todo identificador digitado em ferramenta de terceiros é revelado ao dono da ferramenta: decisão consciente (`02`, `12`).

## 10. Contexto policial (inquérito, VPI, BO)

Quando a coleta serve a procedimento de polícia judiciária, o gate continua valendo (pergunta, necessidade, minimização, categoria do alvo), mas a base legal é outra e existem canais que um particular não tem. Ponteiros abaixo (texto conferido no portal da Legislação do Planalto em out/2026; conferir de novo antes de citar em peça). Minutas de ofício, requisição e pedidos ao exterior ficam na skill `osint-investigator-forense` (Ações J e N).

| Norma | Para que serve aqui |
|---|---|
| Lei 12.830/2013, art. 2º §2º | O delegado requisita perícia, informações, documentos e dados que interessem à apuração dos fatos |
| Marco Civil, art. 10 §3º; Lei 12.850/2013, art. 15 | Dados cadastrais (qualificação pessoal, filiação, endereço) sem ordem judicial, pela autoridade com competência legal; o art. 15 da Lei 12.850 é da investigação de organização criminosa |
| Marco Civil, arts. 13 §2º e 15 §2º (e art. 13 §3º) | Pedido cautelar para que provedores **guardem** registros de conexão (prazo legal de 1 ano) e de acesso a aplicações (6 meses) por mais tempo; a autoridade tem 60 dias, contados do pedido, para requerer a autorização judicial de acesso. Trata de **registros**, não do conteúdo das postagens |
| Convenção de Budapeste (Decreto 11.491/2023), arts. 16, 29 e 35 | Preservação expedita de dados armazenados (no país e por cooperação) e rede de plantão 24/7, para provedores no exterior |
| Lei 12.850/2013, art. 10-A; ECA, art. 190-A (Lei 13.441/2017) | Infiltração virtual de agentes de polícia, com autorização judicial: crimes de organização criminosa; crimes dos arts. 240 a 241-D do ECA e 154-A, 217-A, 218, 218-A e 218-B do CP (até 90 dias, renováveis até o total de 720) |

Na prática:
- **Preservar em paralelo.** A captura do analista (`08`) não substitui o pedido de preservação à plataforma: o que for apagado depois só volta por requisição ou ordem. Peça a preservação assim que tiver o identificador estável (ID, URL, período), antes de pivotar ou interagir, e registre o pedido como evento de custódia ou nota no log.
- **Base legal no `case.json`.** `contexto: "policial"`, `procedimento` (tipo, número, unidade, autoridade) e `gate.base_legal` com a norma e o ato (portaria de instauração, despacho, ordem judicial).
- **Relatório.** `make_report.py` usa a variante policial quando `contexto` é `policial` (ou com `--variante policial`): procedimento, autoridade, respostas a quesitos e bloco de assinatura. Se a unidade tiver modelo próprio, siga-o e anexe o relatório gerado como peça técnica.
- **O que continua fora do escopo desta skill**, mesmo com autorização: passo a passo de infiltração, criação de identidade ou conta de investigação ativa (procedimento autorizado e supervisionado, conduzido pelos canais da unidade); localização de pessoa por OSINT (localização formal vem por requisição ou ordem); uso de bases vazadas ou "puxadas" de dados.
