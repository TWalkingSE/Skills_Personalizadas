# 03 — Modelo de acesso, ecossistemas e algoritmos

Quando ler: ao decidir onde e como coletar, ao classificar uma plataforma, ao mapear uma comunidade que migra entre redes, ou ao explicar por que o feed do investigador não é amostra neutra. `last_reviewed: 2026-10`

## Conteúdo
1. Por que trocar o "iceberg" pelo modelo de acesso
2. Aberta, híbrida e fechada
3. Comparativo de plataformas
4. Quatro lógicas de organização de conteúdo
5. Anonimato técnico × pseudo-anonimato social
6. Migração de comunidades e mapa de ecossistema
7. Algoritmos, engajamento e comunidades de risco `[ADD]`
8. Tipos de rede social (livro)

## 1. Por que trocar o "iceberg" pelo modelo de acesso

- O modelo Surface/Deep/Dark nasceu com o white paper de Bergman (2000), que estimou a Deep Web em 400 a 550 vezes a Surface Web. A proporção é **obsoleta**; vale só como contexto histórico (D s.9–12).
- Ser invisível ao Google não define a utilidade tática do dado, a dificuldade de extração nem a expectativa real de privacidade do alvo (D s.28–30). Redes "fechadas" concentram hoje o maior volume de evidência digital.
- O paradigma operacional troca a **barreira de indexação** pela **barreira de acesso** (D s.31). Pergunta central: *"Eu consigo acessar sem autorização especial?"* (D s.44). Para Bazzell, se o investigador acessa o conteúdo sem autorização especial, ele é tratado como coleta aberta, qualquer que seja a taxonomia acadêmica (D s.45–46).

| | Modelo clássico (iceberg) | Modelo operacional (acesso) |
|---|---|---|
| Critério | Indexação por buscadores | Dinâmica de acesso do investigador |
| Categorias | Surface / Deep / Dark | Aberta / Híbrida / Fechada |
| Utilidade hoje | Baixa para orientar coleta | Alta: orienta técnica e estratégia |

## 2. Aberta, híbrida e fechada (D s.38–43)

| Tipo | Definição | Exemplos | Implicação |
|---|---|---|---|
| **Aberta** | Difusão global sem atrito de entrada; consumo passivo, independente de buscador | Repositórios abertos, fóruns públicos, canais públicos do Telegram, subreddits públicos | Coleta passiva; preservar e analisar |
| **Híbrida** | "Privatizou a praça pública": exige autenticação por razão comercial, às vezes bloqueia rastreadores, mas a barreira humana é irrisória. Núcleo da coleta atual | Instagram, Facebook, servidores Discord | Pode exigir conta; conta de investigação é **interação** (gate, `02`) |
| **Fechada** | Isolamento intencional: chaves criptográficas, aprovação de administradores ou redes de confiança (HUMINT) | Grupos privados e chats secretos do Telegram, servidores Discord com aprovação manual, grupos de WhatsApp restritos | Entrar exige engajamento: **gate obrigatório**; sem engano |

Definição de fonte aberta do Berkeley Protocol (D s.34): conteúdo que exige login ou cadastro é aberto desde que o processo esteja aberto a todos na jurisdição onde o acesso é legal e nenhum controle de privacidade ou segurança seja violado. Conteúdo privilegiado, classificado ou legalmente protegido pode não ser fonte aberta e ter uso restrito como prova.

## 3. Comparativo de plataformas (D s.52, com acréscimos)

| Plataforma | Tipo | Unidade estrutural | Anonimato | Relevância para OSINT |
|---|---|---|---|---|
| Instagram | Híbrida | Feed, Stories, DM | Baixo | Geolocalização em posts, grafo social, metadados |
| TikTok | Híbrida | Feed algorítmico | Baixo–médio | Padrões de áudio e hashtag, rede de interações |
| Telegram | Canais públicos: aberta. Grupos públicos: aberto (por link ou busca). Grupos privados: fechada | Canais e grupos | Alto | Canais públicos são fonte rica; grupos privados exigem HUMINT |
| Discord | Híbrida/fechada | Servidor › canal › cargo | Alto (correlacionável) | Hierarquia de cargos, convites residuais |
| WhatsApp | Fechada | Grupos e conversas | Médio (número de telefone) | Vínculo forte ao número |
| Reddit | Aberta | Subreddit | Alto | Histórico de posts permite perfilamento profundo |
| Facebook `[ADD]` | Híbrida | Perfil, página, grupo, marketplace | Baixo–médio | Vínculos familiares, grupos públicos, anúncios |
| Threads `[ADD]` | Híbrida | Perfil e threads, ligados à conta do Instagram | Baixo | Rede de contatos diferente da do Instagram (L p.592) |
| X/Twitter `[ADD]` | Híbrida | Perfil, post, lista | Médio–alto | Texto público, horário, interações |
| Kwai `[ADD]` | Híbrida | Feed algorítmico de vídeos curtos | Baixo–médio | Muito usado no Brasil; golpes de "renda extra" e vendas, reposts de outras redes (`platforms/kwai.md`) |

O Telegram não cabe limpo em "híbrida": é uma plataforma **multiestrutura**. Canais públicos são legíveis em `t.me/s/<canal>` sem login; grupos privados são genuinamente fechados; bots pagos e premium formam uma camada híbrido-comercial (D s.63).

## 4. Quatro lógicas de organização de conteúdo (D s.53–58)

- **Feed algorítmico** (Instagram, TikTok): ranking por engajamento previsto, não por ordem cronológica nem escolha explícita. O TikTok foi construído sobre um **grafo de interesse**; o feed principal do Instagram pesa sinais de relacionamento (DMs, comentários, visitas a perfil) e só em Explore e Reels se aproxima da lógica do TikTok (D s.55).
- **Canal broadcast** (Telegram): um emissor (ou poucos) para muitos leitores, sem hierarquia interna de cargos.
- **Servidor hierárquico** (Discord): árvore servidor → categorias → canais de texto/voz → cargos com permissões diferentes.
- **Comunidade por tópico** (Reddit): subreddits como fóruns temáticos, moderação distribuída e reputação (karma).

## 5. Anonimato técnico × pseudo-anonimato social (D s.90)

- **Técnico**: sem identificador estável, sem conta persistente, sem histórico vinculável. Difícil de correlacionar diretamente, mas difícil de sustentar; deixa rastros indiretos (horário, estilo de escrita, metadados).
- **Pseudo-anonimato social**: identidade estável sob pseudônimo, com reputação e vínculos visíveis (Discord, Reddit). Costuma ser **mais rastreável** que o anonimato puro: a persistência gera padrões correlacionáveis no tempo e entre plataformas.

## 6. Migração de comunidades e mapa de ecossistema (D s.89)

Padrão recorrente: 1) origem em rede híbrida (servidor Discord, grupo público) → 2) ruptura (moderação, banimento ou exposição) → 3) êxodo do núcleo para rede fechada (Telegram/WhatsApp) → 4) redundância (canal aberto mantido como "vitrine" e ponto de recaptação).

Consequência: mapear só a plataforma onde a denúncia surgiu costuma ser insuficiente. Planejar a coleta já com o ecossistema inteiro. Modelo de mapa:

| Camada | O que registrar | Exemplo |
|---|---|---|
| Vitrine (aberta) | Canal/servidor/subreddit público, convites divulgados | Canal público com link de convite |
| Núcleo (fechado) | Grupo privado, regras de entrada, papéis | Grupo que exige aprovação |
| Backup | Canais reserva, contas espelho | Canal de reserva citado no fixado |
| Automação | Bots de entrada, pagamento, moderação, venda | Bot que cobra e libera acesso |
| Pontes | Links cruzados, usernames reutilizados, administradores comuns (T s.65) | Canal → grupo → bot → canal reserva |

## 7. Algoritmos, engajamento e comunidades de risco `[ADD]`

Temas: algoritmos de recomendação; engajamento, retenção e personalização; feed algorítmico × cronológico; bolhas e câmaras de eco; relação com comunidades de risco; amplificação de conteúdo extremo (D s.3). Implicações práticas para o analista:

1. **O feed do investigador não é amostra neutra.** Ele reflete o histórico da conta e do dispositivo. Não estimar prevalência de um tema pelo que o feed mostra; usar buscas e listas públicas explícitas.
2. **Curtir, seguir e assistir são sinais que moldam o feed e podem ser visíveis ao alvo ou à plataforma.** "Conduzir o algoritmo" (D s.55) é interação ativa: tratar a conta de investigação conforme `02`.
3. **Comunidades de risco**: sinais úteis incluem migração para canais fechados, convites em cadeia, vocabulário codificado ou eufemístico, e ressurgimento sob novos nomes após banimento.
4. **Amplificação**: picos coordenados, contas recém-criadas e repetição de texto são indicadores a verificar, nunca prova (`07`).

## 8. Tipos de rede social (L p.58–65)

A classificação do livro por tipo de rede está em `11` seção 8 (material de estudo). Para decidir onde e como coletar, use o modelo de acesso das seções 2 e 3.
