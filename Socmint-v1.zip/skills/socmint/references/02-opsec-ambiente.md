# 02 — OPSEC e ambiente de investigação

Quando ler: ao preparar o ambiente de coleta, decidir se uma conta de investigação é necessária, escolher ferramentas de terceiros ou revisar riscos de exposição do investigador. Fontes: livro cap. 7 (L p.119–176), slides do Telegram (T s.10–37, 64–69), EPUB (K c.9.2, c.16). `last_reviewed: 2026-10`

## Conteúdo
1. Princípio e modelo de ameaça
2. Níveis de OPSEC
3. Rede: VPN e vazamento de DNS
4. Isolamento do laboratório
5. Navegador, rastreamento e fingerprinting
6. Higiene de contas e credenciais
7. Conta de investigação (política)
8. Vazamento por ferramentas de terceiros
9. Encerramento do caso
10. Volatilidade e fontes

## 1. Princípio e modelo de ameaça

OPSEC protege informação e operações contra exposição (L p.119). Na investigação em redes sociais há quatro ativos a proteger: a **identidade do investigador**, a **confidencialidade da investigação** (não alertar o alvo), a **integridade das evidências** e a **segurança de terceiros** (vítimas, fontes). Pergunta-guia: *o que a plataforma, o alvo e as ferramentas de terceiros conseguem aprender sobre mim e sobre o caso a partir desta ação?*

Regra de ouro (L p.134): **nunca** usar contas pessoais para investigar; várias redes registram visualizações de perfil, stories e transmissões.

## 2. Níveis de OPSEC

| Nível | Quando | Medidas mínimas |
|---|---|---|
| 0 — Leitura pública | Conteúdo aberto, sem login, baixo risco | Perfil de navegador dedicado; sem contas pessoais logadas; extensões de privacidade |
| 1 — Ambiente isolado | Casos de rotina | Nível 0 + VPN confiável sem vazamento de DNS, máquina virtual ou perfil/dispositivo separado, backups e atualizações |
| 2 — Conta de investigação passiva | Plataforma exige login para ver conteúdo público | Nível 1 + conta **de pesquisa** (preferencialmente institucional), comportamento estritamente passivo, 2FA, política de dados |
| 3 — Interação ativa | Contato com o alvo, entrada em grupo fechado | **Fora do escopo desta skill**: exige autorização formal e base legal (`00`); em investigações complexas a identidade do investigador não pode ser associada nem antes nem depois (L p.169) |

## 3. Rede: VPN e vazamento de DNS (L p.120–134)

- Sem VPN, o provedor de internet (ISP) pode guardar registros de navegação por longos períodos, mesmo com aba anônima (L p.120).
- **Evite VPN gratuita**: muitas se financiam vendendo dados (L p.121). Considere a jurisdição (alianças 5/9/14 Eyes) e políticas de registro; o livro cita NordVPN, ProtonVPN, ExpressVPN, Mullvad e IVPN, com contas anonimizadas e pagamento variado `[VOL]`.
- **Teste, não confie**: conferir IP público e ISP (ex.: ipinfo.io) e **vazamento de DNS** (dnsleaktest.com, dnsleak.com, ipleak.net, browserleaks.com) com e sem VPN. O resultado deve mostrar só o provedor da VPN. Muitos testes pertencem a empresas de VPN: fazer **dupla checagem** (L p.133).
- Plataformas detectam IPs de VPN e podem marcar contas por isso (L p.175): outro motivo para preferir leitura passiva sem conta.
- Tor Browser: roteia por nós distribuídos; muitos sites bloqueiam saídas Tor e a navegação é lenta (L p.155–157).

## 4. Isolamento do laboratório (L p.134–148; T s.10–37)

- Ideal: computador e celular **dedicados** à investigação. Alternativa: máquina virtual.
- **Máquinas virtuais**: VirtualBox ou VMware Workstation Player; exigem virtualização habilitada no BIOS. Sistemas: Windows 10 em VM e distribuições prontas para OSINT, como a **TL OSINT VM** (Trace Labs, baseada em Kali) e a **OriON** (VM em espanhol com ferramentas de OSINT) (L p.139–146).
- **Android virtualizado** para apps que escondem funções na web: Genymotion (pago, empresa francesa), MuMu Player e LDPlayer (gratuitos, leves, de empresas chinesas com pouca transparência) (L p.146–148); Android em VirtualBox, MEmu e LDPlayer (T s.10–37). Tire *snapshot* após configurar (T s.32).
- Contas e perfis do investigador ficam **dentro** do ambiente isolado; nada pessoal.

## 5. Navegador, rastreamento e fingerprinting (L p.148–166)

- Cookies e rastreadores guardam preferências e atividade; o *fingerprinting* combina versão, extensões, fontes, GPU, resolução e SO em uma **impressão digital** mais persistente que IP ou cookies (L p.150).
- Uma impressão única identifica o navegador **independentemente da conta**: várias contas da mesma máquina são ligadas e viram suspeitas de bot (L p.152). Testar em Cover Your Tracks (EFF) e BrowserLeaks; no exemplo do livro, 1 em 160.846 navegadores tinha a mesma impressão.
- **Canvas fingerprinting** é o aspecto mais forte; a extensão Canvas Fingerprint Defender injeta ruído.
- **User-Agent**: string enviada ao site; pode ser alterada, e isso serve para ver versões móveis (L p.153–155).
- Navegadores: Firefox (proteção contra rastreamento, `about:preferences#privacy`), Brave (escudos; janela com Tor), base Chromium (L p.148). Extensões: NoScript, uBlock Origin, Privacy Badger, Canvas Fingerprint Defender (L p.163–166). Elas podem quebrar páginas: ajustar exceções.

## 6. Higiene de contas e credenciais

- Senhas únicas, gerenciador de senhas, **2FA** em tudo que for da investigação (L p.135); atualizações de sistema e programas; backups.
- Nunca guardar `api_id`, `api_hash`, tokens, chaves de SerpAPI/Apify em arquivos do caso nem no chat: variáveis de ambiente (T s.73; K c.12.1).
- **Não vincular** a conta de investigação a sites de terceiros com senha (L p.262, 499).
- Configurações do Telegram do investigador (T s.64–69; lista de referência, citada por `10` e `platforms/telegram.md`): idioma inglês; telefone, "visto por último", bio e data de nascimento para ninguém; foto para contatos; encaminhamentos para ninguém; grupos só para contatos; 2FA ligado; limite de download automático de arquivos; remover contatos; usar VPN e dispositivo seguro; reduzir dispositivos conectados; abrir PDFs com cuidado.

## 7. Conta de investigação (política)

Perguntas do livro antes de criar ou usar (L p.168): *qual é o objetivo? tenho certeza de que não consigo extrair o que preciso sem conta? qual será o nível de interação?*

| Perfil | Definição (L p.169–172) | Postura da skill |
|---|---|---|
| **Passivo** | Só observa: não segue, não solicita, não reage, evita ações que registram presença (stories, lives) | Permitido no nível 2, com gate e justificativa |
| **Ativo** | Interage: mensagens, comentários, reações, pedidos de amizade; chama a atenção do alvo e do círculo | **Fora do escopo** sem autorização formal e base legal (`00`) |

A skill **não** fornece receita de criação de identidade falsa (nomes sintéticos, fotos geradas por IA para passar por filtros, aquecimento de contas, evasão de antifraude) nem de números descartáveis obtidos por meios que ocultam a origem do pagamento. O livro e os slides descrevem esses passos; aqui só se registram **riscos**: a plataforma detecta VPN, fingerprint e e-mails anônimos; pede selfie ou documento; suspende contas; e uma falha de consistência pode expor o investigador (L p.169–178). **Alternativas lícitas**: usar apenas conteúdo público sem conta; conta institucional da organização, clara quanto à finalidade, nos termos da plataforma; canais formais (denúncia, ofício, ordem judicial); em segurança pública, procedimentos autorizados e supervisionados (Lei 12.850/2013, art. 10-A, para infiltração virtual).

## 8. Vazamento por ferramentas de terceiros

Tudo o que se digita em um site, extensão ou bot de terceiros (username, e-mail, telefone, ID, foto) pode ser lido, guardado ou vendido: "uma ferramenta gratuita pode estar usando seus dados" (L p.24); bots de Telegram "podem ler e armazenar todos os dados consultados" (L p.565; T s.127). Antes de recomendar uma ferramenta, dizer ao usuário **o que ela recebe**. Para casos sigilosos, prefira ferramentas locais (scripts desta skill, extensões auditadas) e valide a ferramenta com o checklist de `12`.

## 9. Encerramento do caso

Encerrar sessões e dispositivos conectados; salvar o `evidence_log` e rodar `verify`; mover evidências para armazenamento criptografado; apagar dados temporários do ambiente isolado; registrar retenção e descarte no `case.json`; revisar o que foi exposto durante a investigação (contas usadas, convites aceitos).

## 10. Volatilidade e fontes

`[VOL]`: provedores de VPN, extensões, emuladores, comportamento antifraude das plataformas. Fontes: L p.24, 119–178, 262, 499, 565; T s.10–37, 64–69, 73, 127; K c.9.2, c.12.1, c.16.
