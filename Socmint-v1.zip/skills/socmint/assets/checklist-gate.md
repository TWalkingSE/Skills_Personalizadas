# Checklist do gate legal e ético — [ID do caso]

Referência completa: `references/00-gate-legal-etico.md`. Responder antes de coletar sobre qualquer pessoa física.

| # | Pergunta | Resposta | OK? |
|---|---|---|---|
| 1 | Qual é a pergunta de investigação (específica e verificável)? | | |
| 2 | Quem demanda e com que respaldo (contrato, redação, ofício/ordem, procedimento policial com número, treino/CTF, pesquisa com ética)? | | |
| 3 | Categoria do alvo: organização / figura pública no papel público / ator de ameaça / pessoa privada / menor / vítima-denunciante-jornalista | | |
| 4 | Quais dados são estritamente necessários e por quanto tempo serão guardados? | | |
| 5 | Coleta passiva ou haverá interação (conta de investigação, mensagem, entrada em grupo)? | | |

## Limites rígidos (qualquer "sim" encerra ou redireciona)
- [ ] Pedido de localizar endereço, rotina ou posição de pessoa privada
- [ ] Acesso a conta, dispositivo ou mensagem de terceiros, ou contorno de privacidade
- [ ] Desanonimização de crítico, denunciante, jornalista ou vítima
- [ ] Material de abuso sexual infantil envolvido
- [ ] Criação de identidade, documento, print ou conversa falsos
- [ ] Rede de perfis falsos para influenciar, assediar ou fraudar
- [ ] Uso de base vazada ou agenda de terceiros para identificar pessoa física
- [ ] Infiltração enganosa em grupo criminoso por particular

## Resultado
- [ ] Seguir
- [ ] Seguir com restrições: __________________________
- [ ] Recusar e redirecionar para: ______________________

Base legal registrada (LGPD art. 7º/10, contrato, exercício regular de direito, interesse jornalístico/acadêmico, etc.):

Responsável e data (UTC):
