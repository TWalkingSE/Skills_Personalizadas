# Relatório de investigação SOCMINT — [Título]

| Campo | Valor |
|---|---|
| ID do caso | |
| Versão / data (UTC) | |
| Fuso do caso | nome IANA da localidade do fato (ex.: America/Sao_Paulo, America/Maceio) |
| Autor / coletor | |
| Classificação | |
| Nível de profundidade | 1 Triagem · 2 Padrão · 3 Formal |

## 1. Resumo executivo
Conclusão principal, nível de confiança e recomendação em até 10 linhas.

## 2. Objetivo e perguntas de investigação
-

## 3. Escopo e base legal
- Contexto e autorização:
- Categoria do alvo e restrições:
- Coleta: passiva / com interação (justificar):
- Retenção e descarte:

## 4. Metodologia (ODPAR)
- **Organizar**: plano de coleta, hipóteses, OPSEC.
- **Documentar**: camadas de preservação, hash, log de evidências.
- **Pivotar**: pivôs realizados (de → para, técnica, resultado).
- **Analisar**: verificação, correlação, linha do tempo, grafo.
- **Relatar**: este documento.
- Plataformas e fontes, período, ferramentas e versões:

## 5. Evidências
| ID | Descrição | URL | Coleta (UTC) | SHA-256 |
|---|---|---|---|---|

## 6. Achados
| ID | Tipo | Afirmação | Evidências | Admiralty | Confiança | Notas |
|---|---|---|---|---|---|---|
| F-001 | Observação | | EV-0001 | B2 | alta | |
| F-002 | Inferência | | EV-0001, EV-0002 | C3 | moderada | |
| F-003 | Desconhecido | | | | | |

## 7. Análise
### 7.1 Linha do tempo
| Data (UTC) | Evento | Evidência |
|---|---|---|

### 7.2 Mapa de vínculos
Diagrama Mermaid ou imagem do grafo (`build_graph.py`).

### 7.3 Hipóteses × evidências
| Hipótese | Confirmaria se | Refutaria se | Evidências a favor | Evidências contra | Avaliação |
|---|---|---|---|---|---|

## 8. Conclusões e recomendações
- Conclusões (o que as evidências sustentam):
- O que **não** foi possível concluir:
- Recomendações acionáveis:

## 9. Limitações
-

## 10. Anexos
- Log de evidências (`evidence_log.csv`) e verificação de hashes
- Planilhas e exports
- Glossário
- Anexo restrito (dados pessoais de terceiros), se houver
