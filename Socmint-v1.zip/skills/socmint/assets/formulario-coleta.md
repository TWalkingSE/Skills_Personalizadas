# Formulário de coleta online — [ID do caso] / [EV-0000]

Baseado no formulário de coleta do Berkeley Protocol (Anexo IV). Um formulário por pacote de coleta. Os campos de hash são preenchidos por `scripts/evidence_log.py add`; entre parênteses, a opção do `add` que guarda o campo no log.

## 1. Coletor
- Investigação:
- Coletor (`--collector`):
- Endereço IP de saída (VPN/rede usada) (`--network`):
- Início da coleta (data/hora UTC) (`--captured`):
- Fim da coleta (data/hora UTC):

## 2. Alvo
- URL:
- Código-fonte HTML/JSON (arquivo):
- Captura de tela (arquivo):
- Dados capturados (descrição):
- IP(s) do servidor, se relevante:

## 3. Pacote de coleta
- Nome do arquivo do pacote:
- Lista de hashes dos arquivos (SHA-256) (`export --format sha256sums`):
- Hash do arquivo da lista de hashes (impresso pelo export):

## 4. Serviços utilizados
- Software (nome e versão) (`--tool`, `--tool-version`; navegador em `--browser`):
- Serviço de hora (fonte do relógio):
- Serviço de IP:
- Serviço WHOIS:

## 5. Observações
- Conta usada (investigação ou nenhuma) (`--account`):
- Camadas de preservação aplicadas (`references/08-preservacao-e-evidencias.md`):
- Intercorrências (erro, bloqueio, conteúdo removido durante a coleta):
