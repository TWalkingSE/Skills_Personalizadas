# Plano de coleta — [ID do caso]

Preencher antes de abrir qualquer ferramenta (O de ODPAR). Campos inspirados no modelo de plano de investigação online do Berkeley Protocol (Anexo I), adaptados ao ODPAR.

## 1. Identificação
- ID do caso:
- Data (UTC) e fuso do caso (nome IANA da localidade do fato, ex.: America/Sao_Paulo, America/Maceio para SE/AL):
- Responsável / coletor:
- Nível de profundidade (1 Triagem · 2 Padrão · 3 Formal):

## 2. Gate (resumo; detalhes em `checklist-gate.md`)
- Pergunta de investigação (específica e verificável):
- Contexto e autorização:
- Categoria do alvo e restrições:
- Passivo ou ativo:
- Resultado: seguir / seguir com restrições / recusar

## 3. Hipóteses
| # | Hipótese | Evidência que confirma | Evidência que refuta | Status |
|---|---|---|---|---|
| H1 | | | | aberta |
| H2 | | | | aberta |

## 4. Escopo
- Plataformas e fontes (ordenar por modelo de acesso: aberta → híbrida → fechada):
- Período:
- Idiomas e gírias relevantes:
- Geografia:
- Fora de escopo (explícito):

## 5. Identificadores semente
| Tipo | Valor | Origem | Preservado? (EV-…) |
|---|---|---|---|
| username | | | |
| ID | | | |
| URL | | | |

## 6. Cenário digital resumido (ver `avaliacao-cenario-digital.md`)
- Plataformas e apps populares entre as partes:
- Mecanismos de busca usados:

## 7. Mitigação de riscos e OPSEC (ver `avaliacao-risco-ameacas.md`)
- Ambiente de coleta (navegador/perfil/VM, rede):
- Conta de investigação necessária? Justificativa (`references/02-opsec-ambiente.md`):
- Medidas de proteção do investigador e de terceiros:

## 8. Atores relevantes
- Arquivos digitais, provedores e serviços que podem ter versões originais ou metadados (plataformas, arquivos da web, primeiros respondentes que coletaram conteúdo que depois sumiu):
- Canais formais disponíveis (denúncia à plataforma, ofício, autoridade):

## 9. Papéis e recursos
- Responsável pelas atividades online e ponto focal:
- Quem pode ser chamado a depor, se houver prova:
- Pessoas, treinamento e equipamento necessários:

## 10. Atividades e cronograma
| Atividade | Responsável | Prazo | Entrega |
|---|---|---|---|

## 11. Dados, documentação e retenção
- Onde e como documentar (`evidence_log.py`, pastas ODPAR):
- Camadas de preservação previstas (`references/08-preservacao-e-evidencias.md`):
- Retenção e descarte:
- Mascaramento de PII no relatório:

## 12. Critérios
- Relevância (o que entra e o que fica de fora):
- Parada (quando encerrar):
