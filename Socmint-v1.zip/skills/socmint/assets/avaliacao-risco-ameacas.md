# Avaliação de ameaças e riscos digitais — [ID do caso]

Baseada no modelo do Berkeley Protocol (Anexo II). Responder antes da coleta e revisar quando o alvo ou o escopo mudarem.

- ID do caso / data (UTC):
- Resumo: tema, escopo territorial e temporal:
- Objetivos da investigação:

## 1. Ativos (o que proteger)
- Pessoas (investigadores, fontes, vítimas, testemunhas; considerar diferenças de gênero e vulnerabilidade):
- Bens tangíveis (dispositivos, locais):
- Bens intangíveis (dados, contas, credenciais, reputação):

## 2. Vulnerabilidades
- Técnicas (navegador, rede, contas pessoais ligadas, metadados, fingerprinting):
- Humanas (hábitos, reuso de identificadores, exposição em redes pessoais):
- Organizacionais (políticas de dados, retenção, acesso):

## 3. Ameaças que exploram essas vulnerabilidades
- Retaliação ao investigador ou a terceiros:
- Alerta ao alvo (queima de investigação):
- Vazamento do caso por ferramentas de terceiros:
- Malware em downloads e links:

## 4. Atores de ameaça
| Ator | Interesses | Capacidades | Probabilidade de ataque |
|---|---|---|---|

## 5. Medidas de mitigação
Considerar três tipos de dano e registrar a medida para cada um.

| Dano | Medida | Responsável |
|---|---|---|
| Físico | | |
| Digital | | |
| Psicossocial (exposição a conteúdo violento ou abusivo, assédio; plano de autocuidado e rodízio) | | |

- Ambiente isolado e rede (`references/02-opsec-ambiente.md`):
- Ferramentas permitidas e validadas (`references/12-catalogo-de-ferramentas.md`, seção de validação):
- Plano de contingência (o que fazer se a identidade do investigador for exposta):
