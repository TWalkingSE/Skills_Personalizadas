# Avaliação do cenário digital — [ID do caso]

Baseada no modelo do Berkeley Protocol (Anexo III). Itens marcados com * pedem considerar idade, gênero, local e outros dados demográficos relevantes.

- ID do caso / data (UTC):
- Resumo: tema, escopo territorial e temporal:
- Objetivos:

| # | Item | Observações |
|---|---|---|
| 1 | Partes relevantes (comunidades, grupos). Há diferença de uso de tecnologia ou de representação online por gênero, idade ou deficiência? | |
| 2 | Idiomas relevantes, incluindo gírias e linguagem interna* | |
| 3 | Mecanismos de busca mais usados* | |
| 4 | Redes sociais populares* | |
| 5 | Sites populares* | |
| 6 | Uso e penetração de internet (por gênero, idade etc.) | |
| 7 | Preferências de celular e sistema operacional | |
| 8 | Aplicativos móveis populares | |
| 9 | Operadoras de telecomunicações | |
| 10 | Conectividade (Wi-Fi, torres de celular) | |
| 11 | Leis relevantes (liberdade de expressão, acesso à informação, privacidade) | |
| 12 | Veículos de mídia e repórteres com presença online | |
| 13 | Bases abertas (dados governamentais, de ONGs e pesquisadores) | |
| 14 | Bases pagas (governamentais, privadas, de pesquisadores) | |
| 15 | Representatividade do conteúdo online (grupos incluídos × excluídos) | |

Uso: o preenchimento define **onde** o alvo e a comunidade vivem (ex.: um grupo que usa Telegram e TikTok exige playbooks diferentes de outro que usa Discord) e **qual viés** a coleta terá.
