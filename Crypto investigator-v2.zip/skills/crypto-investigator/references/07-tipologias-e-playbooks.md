# R07 — Tipologias e playbooks por tipo de crime

Carregue ao classificar um esquema (Ação 7) ou montar plano de investigação por tipo. Cada tipologia segue o modelo:
**fluxo típico → assinaturas on-chain → pontos de pivô → fontes e pedidos → armadilhas → casos públicos**.
Heurísticas e graus de confiança: [R03](03-metodos-de-rastreamento.md). Atribuição: [R05](05-atribuicao-osint.md).
Constrição/custódia: [R06](06-prova-custodia-apreensao.md). Casos citados são **referências públicas** (aprendizado); confira
fatos e datas em fonte primária antes de citar em peça formal.

## 1. Mercados ilícitos e serviços pagos em cripto

- **Fluxo:** compradores → endereço de depósito (frequentemente um por usuário) → varredura → carteiras do operador → mistura/exchange/OTC.
- **Assinaturas:** muitos depósitos pequenos varridos para um endereço central; consolidações periódicas; saques de vendedores em lote.
- **Pivôs:** (a) pagadores que vêm de exchanges com KYC; (b) o ponto de saque do operador; (c) infraestrutura (hospedagem, e-mail);
  (d) bancos de dados apreendidos do serviço, que costumam trazer endereços, e-mails e IPs.
- **Fontes/pedidos:** exchanges e processadores; provedores de hospedagem/e-mail; cooperação internacional.
- **Armadilhas:** carteira compartilhada do mercado mistura clientes; golpe de saída (exit scam); rótulos incorretos.
- **Casos públicos:** o mercado Silk Road (2013) teve o operador identificado por pistas **fora da cadeia** (postagens antigas e
  infraestrutura), e a análise de blockchain serviu para seguir fundos (mais de 144 mil BTC estavam nos equipamentos apreendidos);
  AlphaBay e Hansa (2017) mostram o valor de infraestrutura e de dados antigos, e da tomada controlada de um mercado.

## 2. Mixers e serviços de mistura

- **Fluxo:** entrada em contrato/serviço de mistura → saque em endereço novo, com atraso e/ou valores padronizados.
- **Assinaturas:** denominações fixas (Tornado Cash), muitos participantes com valores iguais (CoinJoin), uso de relayers.
- **Pivôs:** entrada e saída (qual exchange antes? qual depois?), reuso de endereço, tempo/valor/gás, erros do usuário.
- **Armadilhas:** correspondência por tempo e valor produz falsos positivos em pools densos; trate como Baixa/Hipótese (R03).
- **Casos públicos:** Bitcoin Fog (operador condenado nos EUA em 2024; decisão de apelação em 2026 — confira o resultado);
  Tornado Cash e Samourai/Wasabi (status e processos em [R04](04-crosschain-defi-privacidade.md), *datados*).

## 3. Plataformas de conteúdo ilícito pago (abuso sexual infantil)

- **Foco exclusivo:** **análise financeira e preservação**. **Nunca** acesse, baixe ou armazene o material; **não** facilite acesso.
- **Fluxo:** clientes pagam em Bitcoin a endereços do site (por cliente) → consolidação → saque do operador em exchange.
- **Assinaturas:** endereços de pagamento por usuário; reuso de carteira; valores característicos de assinatura.
- **Pivôs:** cada pagador tem origem (exchange com KYC); o operador tem ponto de cash-out; contas antigas de exchange identificam pessoas.
- **Fontes/pedidos:** exchanges (cadastro e operações), cooperação internacional; **só a autoridade** faz compras de teste.
- **Canais de denúncia no Brasil** *(verificado em 2026-10-19)*: Disque 100; COMUNICA PF (repercussão internacional); SaferNet Brasil
  (denuncie.org.br); Polícia Civil e Ministério Público.
- **Caso público:** a operação internacional contra um site de vídeos pagos em Bitcoin levou a 337 prisões a partir de pagamentos
  rastreados até contas em exchanges, mostrando que a pseudonimidade não protegeu os usuários.

## 4. Ransomware

- **Fluxo:** vítima → endereço de resgate (comumente único por vítima) → consolidação → mistura/OTC/exchange.
- **Assinaturas:** pagamentos em BTC/XMR; consolidação rápida; peel chain; saída para serviços de mistura.
- **Pivôs:** endereço informado na nota; bases públicas de endereços de ransomware; exchanges de saída.
- **Ação imediata:** preservar a nota de resgate (hash), o endereço e o log; **não** orientar a pagar; acionar autoridade; pedir congelamento se os fundos chegarem a custodiante.
- **Armadilhas:** transação de resgate não prova autoria; "afiliados" e operadores diferentes; moedas de privacidade (R04).
- **Caso público:** DarkSide/Colonial Pipeline (2021) teve recuperação parcial pelo governo dos EUA.

## 5. Hacks de exchanges/pontes e atores estatais (ex.: DPRK)

- **Fluxo:** saque ilícito → fragmentação em muitos endereços → swaps (para ETH/BTC), pontes, mixers → OTC/exchanges.
- **Assinaturas:** movimentação **imediata** e em massa; peel chains longas; reuso de padrões e infraestrutura entre incidentes.
- **Pivôs:** alerta imediato a emissores de stablecoin, exchanges e pontes; listas de IOCs públicas (OFAC/FBI); acompanhar o ponto de cash-out.
- **Armadilhas:** esgotamento de atenção (volume); rótulos de ferramentas variam; sanções mudam (consultar fonte com data).
- **Caso público:** o ataque à Bybit (fev/2025, cerca de US$ 1,5 bilhão) foi atribuído ao grupo Lazarus pelo FBI (referência de TTP).

## 6. Tomada de conta (SIM swap, takeover de exchange/carteira)

- **Fluxo:** acesso indevido → saída rápida para várias contas/exchanges, muitas vezes de madrugada.
- **Assinaturas:** esvaziamento total em poucos minutos; destinos novos; swap imediato para stablecoin.
- **Pivôs:** logs da vítima (IP, dispositivo), operadora (SIM swap), exchange de destino (congelamento rápido), emissor de stablecoin.
- **Prioridade:** **velocidade** — pedido de preservação e bloqueio nas primeiras horas.

## 7. Extorsão, sequestro e "wrench attacks"

- **Fluxo:** exigência de pagamento em endereço indicado pelo criminoso.
- **Prioridade absoluta:** **segurança da vítima**. Monitorar o endereço em tempo real exige consentimento e amparo; `live_lookup.py monitor`
  é limitado e **só** acompanha saldo/nonce (EVM) ou estatísticas do endereço (BTC).
- **Pivôs:** quem recebe o dinheiro e como o converte; stablecoins podem ser congeladas rapidamente (a T3 FCU relata congelamentos em até
  24 h em emergências violentas *(verificado em 2026-10-19)*).
- **Armadilhas:** pagamento não garante libertação; evitar ações que alertem o criminoso.

## 8. Fraudes de investimento, pirâmides, "pig butchering" e rug pull

- **Fluxo:** vítima deposita em plataforma falsa → fundos consolidados → exchanges/P2P/OTC; "saques" iniciais pequenos geram confiança.
- **Assinaturas:** depósitos graduais; endereços de depósito por vítima; consolidação periódica; pagamentos a investidores antigos
  vindos de novos depósitos (pirâmide); liquidez removida abruptamente (rug pull).
- **Pivôs:** endereços de depósito da plataforma, cluster do operador, contas de saque, domínios e anúncios; contrato do token (R02 §11).
- **Armadilhas:** vítimas também lavam sem saber (laranjas); plataformas revendem a mesma "marca".

## 9. Lavagem de dinheiro com cripto (P2P, OTC, apostas, varejo, laranjas)

- **Fluxo:** dinheiro ilícito → compra de cripto (P2P/OTC/ATM/contas de terceiros) → movimentação (stablecoins, pontes) → saída em outra jurisdição ou reintegração.
- **Assinaturas:** entradas fragmentadas, ciclos, uso intenso de stablecoin em redes de baixo custo, contas de passagem.
- **Pivôs:** contas bancárias que enviam/recebem PIX/TED de P2P; relatórios de inteligência financeira (via autoridade, sigilosos); exchanges.
- **Fontes/pedidos:** ordem judicial a custodiantes (R06 §8); COAF fornece RIF **apenas** a autoridades (R08).
- **Armadilhas:** P2P legítimo parece lavagem; ausência de KYC não prova crime.

## 10. Drainers, phishing, envenenamento de endereço e delegação EIP-7702

| Golpe | Padrão on-chain | Como investigar |
|---|---|---|
| Phishing com `approve`/`permit` | Allowance a contrato malicioso, depois `transferFrom` | Aprovações da vítima; contrato drenador e endereço de cash-out comum a várias vítimas |
| Delegação EIP-7702 | Autorização assinada delega a EOA a contrato malicioso | Código da conta da vítima; contrato delegado; cash-out compartilhado |
| *Wallet drainer* como serviço | Kits comerciais com afiliados; drenagem de tudo em segundos | Contrato drenador (muitas vítimas, uso de Permit2), rótulos e bases de golpes |
| Envenenamento de endereço | TX de valor zero/ínfimo de endereço lookalike | `validate_address.py --compare`, `analyze_explorer_csv.py` (poeira + lookalike) |
| *Fake airdrop* / honeypot | Token não solicitado cuja interação drena | Contrato do token (R02 §11); alertar a não interagir |
| MEV / sandwich | Bot enquadra swap pendente | Mesmo bloco, mesmo par, lados opostos; avaliar elemento criminal (em geral não) |
| Exploit com flash loan | Empréstimo e quitação no mesmo bloco, manipulação de oráculo | Trace da TX; simuladores (Tenderly, Phalcon) |

## 11. Lições transversais

1. **Dados antigos persistem:** contas antigas em exchange e e-mails de cadastro identificam pessoas anos depois.
2. **Observe até a saída alcançável:** a cadeia vale pelo ponto em que toca um custodiante.
3. **Bancos de dados apreendidos** de serviços/exchanges (endereços, IPs, e-mails) multiplicam o valor da análise on-chain.
4. **Instituição financeira + perito digital** trabalhando juntos encurtam o caminho.
5. **Preserve cedo** (Ação 9): explorers somem, mempool some, logs expiram (retenção legal curta: R08).
6. **Pistas fora da cadeia costumam decidir** o caso; a cadeia dá a prova de fluxo.
7. **Declare os limites** (privacidade, mistura, jurisdição) em vez de forçar uma atribuição.
8. **Brasil — caso de referência de cooperação:** a Operação Lusocoin (Polícia Federal) teve congelamento de ativos
  em coordenação com a T3 FCU, segundo comunicado do consórcio de maio/2026 *(verificado; confira detalhes na fonte oficial)*.
