# R03 — Métodos de rastreamento, graus de confiança e viabilidade

Carregue este arquivo em qualquer análise de fluxo (Ações 1 e 2), ao identificar troco/cluster, ao atribuir
fundos misturados ou ao decidir se um caso vale o esforço. Complementos: [R01](01-bitcoin-utxo.md) (UTXO),
[R02](02-evm-contas-tokens.md) (EVM), [R04](04-crosschain-defi-privacidade.md) (pontes/mixers),
[R05](05-atribuicao-osint.md) (identificar pessoas/serviços).

## 1. Disciplina de evidência

1. **Literal ≠ inferido.** Cada afirmação do relatório é rotulada FATO OBSERVADO (dado verificável: hash, bloco,
   valor, horário) ou INFERÊNCIA (interpretação, com método e grau de confiança).
2. **Copie, não redigite.** Endereços e hashes entram no relatório exatamente como vieram da fonte e passam por
   `scripts/validate_address.py` (checksum, tamanho, envenenamento). Notação abreviada (`bc1q…xyz`) só em
   rascunho; no relatório vão os valores completos.
3. **Pare de clicar para preservar.** Ao achar um ponto de pivô (primeiro depósito em exchange, saída de mixer,
   comprador identificado), registre bloco, hash e horário e preserve (Ação 9) antes de seguir adiante.
4. **Horários em UTC, com UTC-3 ao lado**, e a altura do bloco de cada observação. Nunca "ontem", "há 2 horas".
5. **Rótulo de ferramenta é alegação, não fato.** Pergunte de onde o rótulo vem (depósito de teste, fonte
   primária, resposta do serviço, heurística de cluster). Rótulo sem origem sustenta no máximo confiança Baixa.
6. **Registre alternativas.** Para cada elo, escreva ao menos uma explicação concorrente plausível e por que foi
   (ou não) descartada.

## 2. Escala de confiança

| Grau | Definição operacional | Exemplo |
|---|---|---|
| **Alta** | Evidência direta (assinatura criptográfica, resposta do provedor com cadastro, registros do próprio custodiante) **ou** ≥ 2 heurísticas independentes sem contradição **mais** corroboração fora da cadeia | Exchange confirma titular do endereço de depósito e o fluxo on-chain até ele é contínuo |
| **Média** | Uma heurística forte, coerente com valores e horários, sem corroboração externa | Co-gasto sem sinais de CoinJoin + troco identificado por duas regras |
| **Baixa** | Heurística isolada ou padrão compatível com várias explicações | Único critério: saída com valor "quebrado" |
| **Hipótese** | Ideia a testar, sem suporte direto | "Parece o mesmo operador pelo horário" |

Regras de combinação:
- Heurística isolada **nunca** passa de Média.
- Alta exige corroboração fora da cadeia (provedor, perícia, confissão documentada) **ou** duas ou mais heurísticas
  realmente independentes (não derivadas uma da outra) sem contradição conhecida.
- **O caminho vale o elo mais fraco:** um salto Baixo limita a conclusão do trecho inteiro.
- Rótulos e clusters de ferramentas comerciais entram como Baixa/Média até serem corroborados.
- Escreva sempre o **modo de falha** conhecido da heurística (tabela abaixo).

## 3. Catálogo de heurísticas (H1–H13)

| Cód. | Heurística | Aplica-se a | Falha quando | Confiança típica isolada |
|---|---|---|---|---|
| H1 | **Co-gasto de entradas**: endereços que assinam a mesma transação têm o mesmo controlador | UTXO | CoinJoin, PayJoin, transação coletiva de custodiante, carteira compartilhada, financiamento de canal Lightning por mais de uma parte | Média |
| H2 | **Troco em endereço novo**: de duas saídas, a que vai para endereço nunca usado antes é troco | UTXO | Quando as duas saídas são para endereços novos (destinatário com carteira moderna) ou ambas reutilizadas | Baixa |
| H3 | **Entrada desnecessária / troco ótimo**: se uma entrada poderia ser dispensada, a saída menor que todas as entradas tende a ser troco | UTXO | Carteiras que consolidam UTXOs de propósito ou usam seleção de moedas atípica | Baixa |
| H4 | **Tipo de script**: a saída com o mesmo tipo de script das entradas é o troco | UTXO | Destinatário usa o mesmo tipo (hoje comum); perde força com Taproot | Baixa |
| H5 | **Valor redondo**: pagamentos tendem a ser redondos (em BTC ou em moeda local), troco "quebrado" | UTXO | Preço fixado em fiat (valor quebrado em BTC), varredura total, taxas | Baixa |
| H6 | **Co-gasto posterior**: a saída depois gasta junto com UTXOs do remetente confirma o troco | UTXO | Se o co-gasto ocorre em CoinJoin; exige o rastreamento adiante | Média |
| H7 | **Impressão digital de software**: nLockTime, nSequence, versão, ordenação de entradas/saídas, assinaturas low-R, tipo de script do troco | UTXO | Carteiras com o mesmo comportamento padrão (milhões de usuários); serve para desempatar, não para provar | Baixa |
| H8 | **Valor e tempo entre depósito e saque** (pontes, mixers, exchanges) | UTXO/EVM | Pools densos, denominações fixas, saques em lote, relayers | Baixa |
| H9 | **Peel chain**: a cada salto sai um pagamento pequeno e o restante volta como troco para novo endereço | UTXO | Ramificações (descasque para vários), consolidações, folha de pagamento legítima | Média (com H2/H3) |
| H10 | **Rotulagem por serviço / unpeeling**: pagamento recebido por cluster de serviço conhecido | UTXO/EVM | Rótulo sem origem; hot wallet reaproveitada; custodiante ≠ pessoa | Baixa a Média |
| H11 | **Tagging**: endereços que interagem com um cluster rotulado herdam a ligação | UTXO/EVM | Erro de rótulo propaga; serviços compartilhados (exchanges, pontes, protocolos) | Baixa |
| H12 | **Primeiro financiador de gás**: o endereço que enviou a primeira moeda nativa a uma conta nova | EVM | Financiador compartilhado (exchange, faucet, relayer, paymaster ERC-4337, patrocinador de delegação EIP-7702) | Baixa a Média |
| H13 | **Nonce, ordem e horário**: sequência de nonces e janela de atividade ligam contas ao mesmo operador/bot | EVM | Bots multi-conta, MEV, relayers, automação 24 h | Baixa |

Como combinar: H1 + H6 (sem sinais de mistura) → Média/Alta para "mesma carteira"; H2 + H3 + H4 independentes e
concordantes → Média para "saída X é troco"; H7 só desempata.

## 4. Peel chain e unpeeling

Padrão: cada transação envia um valor pequeno a um destino e o restante, maior, volta como troco para um novo endereço
da mesma carteira; a cadeia pode ter dezenas de saltos.

Método:
1. Em cada salto aplique H2/H3/H4 para escolher a saída-troco; confirme com H6 quando possível.
2. Siga o troco; registre cada pagamento "descascado" como candidato a pivô (serviço? pessoa?).
3. Marque cada salto com grau de confiança; interrompa quando houver ramificação ambígua (duas saídas plausíveis).
4. **Unpeeling:** para cada pagamento descascado, verifique se o destino pertence a serviço identificável
   (H10) — é aí que a cadeia costuma encontrar um ponto alcançável.
5. Pare em: consolidação com outras origens, entrada em serviço, mistura, ou endereço dormente.

Atenção: descasque nem sempre é ofuscação (folha de pagamento, repasses periódicos).

## 5. Identificar exchange/serviço e seus clientes

| Sinal | Sugere | Como confirmar |
|---|---|---|
| Muitos endereços de depósito que varrem periodicamente para um endereço central | Custodiante (exchange, processador) | Depósito de teste (se autorizado), fonte primária, rótulo com origem conhecida |
| 1 entrada e dezenas de saídas de valores variados | Saque em lote (batching) de custodiante | Verifique se as saídas são de clientes distintos; **não** atribua todas ao mesmo dono |
| Entradas de muitos remetentes e saída única consolidada | Varredura de depósitos | Rastreie a saída adiante até hot wallet/cold wallet |
| Endereço de pagamento por comprador, valores característicos de preço fixo | Serviço ilícito com enumeração possível de clientes | Cada pagador tem origem (exchange?) → ponte para KYC |

Cluster de custodiante ≠ cluster de pessoa: nunca atribua titularidade individual a um cluster gigante.

## 6. Análise temporal

- A transação **não** registra a hora em que o usuário agiu; o horário é o do bloco. O "primeiro visto" (mempool)
  só existe para quem observou a rede.
- Use `scripts/analyze_explorer_csv.py` (histograma por hora UTC e estimativa de fuso).
- **Amostra mínima:** 30 eventos de saída (o script recusa abaixo disso); preferível 100+. Com amostra pequena,
  não infira fuso: Baixa/Hipótese.
- Confirme com mais de um endereço do mesmo cluster; desconfie de atividade 24 h (automação ou vários operadores).
- Limitações: viagens, horário de verão, bots, transações pré-assinadas e agendadas.
- O resultado é **indicativo** (jamais prova de localização).

## 7. Valoração em fiat

Converta pela cotação **na data e hora da transação** (ou do swap), não pela cotação atual. Declare fonte, horário da
cotação e moeda (ex.: média diária de um provedor de preços; para BRL, a fonte da conversão). Em swaps, prefira o
preço implícito da própria negociação. O script de CSV não converte moeda: faça a valoração como etapa separada e
documentada.

## 8. Atribuição de fundos misturados (FIFO, LIFO, Haircut, Poison, Last-touch)

Quando fundos investigados se misturam a fundos limpos na mesma carteira/pool, escolha, **declare** e justifique o método.

| Método | Lógica | Vantagem | Limitação |
|---|---|---|---|
| **FIFO** | O primeiro valor que entrou é o primeiro a sair | Intuitivo; análogo à regra tradicional de rastreamento patrimonial; usado por ferramentas comerciais | Pode criar ligações artificiais |
| **LIFO** | O último que entrou sai primeiro | Útil quando o fluxo investigado é recente | Viés para a transação mais nova |
| **Haircut / pro-rata** | Cada saída leva fração proporcional de cada entrada | Estatisticamente neutro, sem assumir ordem | Dilui a rastreabilidade em muitos saltos |
| **Poison (taint)** | Qualquer mistura contamina todo o saldo seguinte | Máximo alcance investigativo | Muitos falsos positivos; fraco como prova |
| **Last-touch** | Considera só o salto mais recente | Simples; bom para cash-out | Não reconstrói origem profunda |

Regras de uso:
1. Declare o método. 2. Se a conclusão muda conforme o método (ex.: muda o destinatário final), apresente **FIFO e
Haircut lado a lado**. 3. Em mixers/CoinJoin, nenhum método é confiável: declare a quebra de cadeia.
Observação: não verifiquei jurisprudência consolidada no Brasil sobre qual método adotar; fundamente a escolha e
deixe o ônus metodológico explícito (referência educacional — ver [R08](08-legal-brasil.md)).
Em EVM, aplique o método **por token** e considere que protocolos DeFi agrupam fundos de muitos usuários.

## 9. Contaminação de cluster e sanity checks

Antes de afirmar "estes endereços são da mesma entidade":
1. Procure sinais de CoinJoin/PayJoin/batching no co-gasto (muitas entradas e saídas, valores iguais).
2. O cluster é gigante ou tem milhões de TXs? Provavelmente é serviço ou erro de fusão.
3. Algum endereço do cluster tem rótulo conflitante (exchange + pessoa)?
4. Reproduza o resultado com **duas ferramentas independentes** ou à mão.
5. Valide manualmente ao menos três transações que sustentam a ligação.
6. Guarde a lista de endereços com a regra que os uniu (H#) e a data da consulta.

## 10. Corroboração e antiarmadilha

- Uma pista (denúncia, post, dica) pode ser **plantada** por quem quer desviar a investigação ou por golpistas que
  "semeiam" endereços. Trate como Hipótese até corroborar.
- Regra **2 + 1**: duas fontes independentes (ex.: OSINT + fluxo on-chain) **mais** uma confirmação em registro
  primário (resposta de provedor/perícia).
- Nunca atribua identidade só por cluster, rótulo de ferramenta ou nome ENS.
- Registre a hipótese alternativa e o que a refutaria.

## 11. Triagem de viabilidade

Antes de gastar horas, pergunte:

| Pergunta | Se "não" |
|---|---|
| O dinheiro chega a um ponto **alcançável** (exchange com KYC em jurisdição que coopera, stablecoin congelável, serviço intimável)? | Documente e priorize outros casos; preserve as evidências |
| Há quebra de cadeia (Monero, shielded, mixer, ponte opaca) **antes** desse ponto? | Foque em entrada e saída; relate os limites |
| O alvo ou o serviço está em jurisdição acessível por cooperação? | Avalie preservação via canais 24/7 e cooperação (ver R08) |
| O prazo permite agir (volatilidade, fuga, retenção de logs)? | Priorize pedido de preservação imediata |
| O valor/risco justifica? | Registre a decisão e a base |
| Existe pista fora da cadeia (dispositivo apreendido, KYC, testemunha)? | Pode compensar a quebra on-chain |

Resultado: **Priorizar**, **Preservar e aguardar** ou **Encerrar com relatório de limites**.

## 12. Padrões comportamentais e explicações inocentes

| Padrão | Descrição | Pode indicar | Explicação inocente a descartar |
|---|---|---|---|
| Peel chain | Pequenos pagamentos sucessivos, troco volta | Distribuição ou ofuscação | Folha de pagamento, repasses |
| Fan-out / fan-in | Um endereço para muitos, que convergem de volta | Quebra e reconsolidação | Airdrop, pagamento em lote legítimo |
| Round-trip | Fundos saem e retornam ao mesmo endereço | Wash trading, volume artificial | Teste de carteira, estorno |
| Dormência e movimento súbito | Anos parados e movimentação total | Chave comprometida ou "esfriamento" | Herança, troca de carteira |
| Fragmentação uniforme | Valor dividido em partes iguais | Layering coordenado | Divisão de pagamentos |
| Timing coordenado | Várias contas agem no mesmo minuto | Automação / mesmo operador | Bot de terceiros, relayer |
| Swap imediato | Recebe token A, troca por B em segundos | Converter ativo rastreável | Arbitragem, MEV |
| Bridge hop | Cruza de rede logo após receber | Ofuscação cross-chain | Uso normal de L2 |
| Consolidação pré-exchange | Várias contas enviam a uma, que deposita | Preparar cash-out | Tesouraria |
| Depósito em mixer | Valor entra em contrato de mistura | Quebra de vínculo | Privacidade legítima |

`analyze_explorer_csv.py` detecta sweep, fan-in/fan-out, ida e volta, poeira e lookalikes; a interpretação continua sendo sua.

## 13. Formato do raciocínio investigativo

Use em fluxos com 3+ saltos, ofuscação, cross-chain, risco de contrato ou conclusão não óbvia:

```
RACIOCÍNIO INVESTIGATIVO
Etapa 1 — Observação: [o que os dados brutos mostram; com hash/bloco]
Etapa 2 — Padrão: [comportamento que emerge]
Etapa 3 — Hipótese: [interpretação, como HIPÓTESE]
Etapa 4 — Alternativas: [explicações concorrentes e por que foram aceitas/descartadas]
Etapa 5 — Verificação: [dado adicional que confirmaria ou refutaria]
Etapa 6 — Conclusão: [resultado + grau de confiança + modo de falha]
```
