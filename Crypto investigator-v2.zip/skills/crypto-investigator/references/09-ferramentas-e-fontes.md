# R09 — Ferramentas, explorers e fontes (com status e risco de log)

Carregue ao indicar ferramenta, explorer, API ou lista (Ação 3), ao orientar coleta de dados ou escolher como consultar. **Status** é um retrato datado:
itens marcados *(verificado em 2026-10-19)* foram conferidos na web nesta rodada; os demais vêm do material anterior e **devem ser reconfirmados**
antes de citar em relatório. Regras de OPSEC (consultar revela o alvo): SKILL.md e [R05](05-atribuicao-osint.md).

## 1. Como escolher: o risco de log

Toda consulta a explorer/SaaS de terceiro pode registrar **IP, navegador, endereço e horário** e correlacionar buscas. Alternativas:

| Opção | Privacidade | Custo/esforço |
|---|---|---|
| Explorer/SaaS público | Baixa: o serviço vê seu interesse | Nenhum |
| Explorer público via rede controlada (VPN/Tor/proxy do órgão) | Média: esconde seu IP, não o dado consultado | Baixo |
| **Nó próprio + explorer próprio** | Alta: nada sai | Alto (disco/manutenção) |
| Exportação do dado já obtido por meio legal | Alta | Depende do caso |

Auto-hospedagem: Bitcoin Core + indexador (Electrs/Esplora/mempool); para EVM, nó completo ou de arquivo (Geth/Erigon/Reth) + explorer
open source (ex.: Blockscout) e métodos de trace. `live_lookup.py` aceita `--base-url`/`--rpc` para apontar para a sua instância.

## 2. APIs verificadas

| API | Uso | Pontos-chave *(verificado em 2026-10-19)* |
|---|---|---|
| **Esplora** (Blockstream; compatível em mempool.space) | Bitcoin: `/tx/:txid`, `/tx/:txid/status`, `/tx/:txid/hex`, `/tx/:txid/outspends`, `/address/:addr`, `/address/:addr/txs`, `/address/:addr/txs/chain/:last_seen`, `/address/:addr/utxo`, `/blocks/tip/height` | Valores em satoshis; a documentação recomenda **auto-hospedar** para privacidade |
| **Etherscan API V2** | Multi-rede EVM: `https://api.etherscan.io/v2/api?chainid=…&module=account&action=txlist|txlistinternal|tokentx|tokennfttx…` | Chave obrigatória (guardar em variável de ambiente); plano gratuito: 3 chamadas/s e até 100 mil/dia em **redes selecionadas**; resposta `status/message/result`; consultas limitadas a ~10 mil registros |
| **JSON-RPC EVM** | `eth_getTransactionByHash`, `eth_getTransactionReceipt`, `eth_getCode`, `eth_blockNumber`… | Use **seu** nó/provedor; URLs de provedor podem conter chave (não gravar em evidência) |

Uso integrado: `scripts/live_lookup.py` (consentimento obrigatório, resposta bruta salva com SHA-256).

## 3. Explorers por rede (material anterior; reconfirmar)

**UTXO**

| Rede | Moeda | Endereço | Explorer |
|---|---|---|---|
| Bitcoin | BTC | `1…`, `3…`, `bc1q…`, `bc1p…` | mempool.space, blockchair.com |
| Litecoin | LTC | `L…`, `M…`, `ltc1…` | blockchair.com/litecoin |
| Bitcoin Cash | BCH | `bitcoincash:q…` ou legado | blockchair.com/bitcoin-cash |
| Dash / Dogecoin | DASH / DOGE | `X…` / `D…` | blockchair.com |
| Zcash | ZEC | `t1…` (transparente), `zs1…` (blindado) | blockchair.com/zcash |

**EVM** (chainId): Ethereum (1) etherscan.io · BNB Smart Chain (56) bscscan.com · Polygon PoS (137) polygonscan.com ·
Avalanche C-Chain (43114) snowtrace.io · Arbitrum One (42161) arbiscan.io · Optimism (10) optimistic.etherscan.io ·
Base (8453) basescan.org · Sonic (146; sucessora da Fantom, 250) sonicscan.org · Cronos (25) cronoscan.com · Gnosis (100) gnosisscan.io ·
zkSync Era (324) explorer.zksync.io · Linea (59144) lineascan.build · Celo (42220) celoscan.io.

**Conta não-EVM:** Solana (solscan.io; explorer.solana.com) · Tron (tronscan.org) · Cardano (cardanoscan.io) · XRP (xrpscan.com; bithomp.com) ·
Cosmos (mintscan.io) · Polkadot (subscan.io) · TON (tonscan.org) · Algorand (allo.info) · NEAR (explorer.near.org).

Verifique o domínio exato antes de usar (phishing de explorers existe: `etherscan.io` ≠ `etherscam.io`).

## 4. Verificação multi-rede de um endereço 0x

| Ferramenta | O que faz | Observação |
|---|---|---|
| DeBank | Saldo e atividade do endereço em várias redes EVM | Registra consulta |
| Arkham Intelligence | Carteira multi-rede e entidades rotuladas | Plataforma em **intel.arkm.com** *(verificado; o domínio antigo/errado citado em material anterior não existe)* |
| Zapper | Painel de carteira multi-rede | Registra consulta |
| Blockchair | Explorer multi-rede | Útil para exportação |
| Nansen | Análise de carteiras | Pago |

## 5. Análise e visualização de grafos

| Ferramenta | Função | Status/observação |
|---|---|---|
| Arkham | Entidades e grafo | Ativo *(verificado)*; rótulos próprios: tratar como alegação |
| Breadcrumbs | Investigação em grafo; programa para autoridades | Ativo; ~21 redes; plano gratuito limitado e plano para autoridades *(verificado)* |
| MetaSleuth (BlockSec) | Rastreio visual multi-rede e pontuação de risco | Gratuito, sem cadastro, ~12 redes, exporta CSV/PNG *(verificado em 13/10/2026 por terceiro)* |
| MistTrack (SlowMist) | Rastreio de fundos roubados e AML | Ativo; versão Light gratuita; lista de endereços de stablecoin bloqueados *(verificado)* |
| GraphSense | Análise de grafos open source/acadêmica | Material anterior |
| Chainalysis Reactor, TRM Labs, Elliptic, Crystal | Rastreio institucional e compliance | Licença; sites ativos em 13/10/2026 *(verificado por terceiro)*; tratar saídas como atribuição, não como fato |

## 6. Segurança de contratos, tokens e golpes

| Ferramenta | Função |
|---|---|
| Token Sniffer, De.Fi Scanner, GoPlus, honeypot.is | Scanners automáticos de tokens/honeypots (indício, não laudo) |
| Tenderly, Phalcon (BlockSec) | Simulação e trace de transações |
| revoke.cash | Auditar e revogar allowances |
| Chainabuse (TRM) | Denúncias públicas ou **privadas** (visíveis só a autoridades parceiras); consulta de endereços/URLs *(verificado)* |
| Scam Sniffer / bases de drenadores | Detecção de phishing e contratos drenadores |

## 7. NFTs e monitoramento de mercado

OpenSea, Blur, Magic Eden (Solana, Ordinals, Polygon), NFTScan; DexScreener, DEXTools; Whale Alert (grandes movimentações). Todos exibem dados públicos, mas **registram consultas**.

## 8. Sanções e listas

| Fonte | Observação |
|---|---|
| OFAC SDN (EUA) | Consulta direta no Tesouro; registre a data. Tornado Cash removido em 21/03/2025 *(verificado)* |
| UE (lista consolidada), HMT (Reino Unido) | Conferir na fonte oficial |
| ONU (CSNU) | No Brasil, executoriedade imediata; lista pública do DRCI/MJSP *(verificado)* |
| API de sanções de provedores de analytics | Verifique disponibilidade e termos (material anterior cita acesso gratuito; não reverificado) |

COAF **não** publica lista de PEP nem RIF; o cadastro de PEP é da CGU (R08).

## 9. Ferramentas encerradas, alteradas ou com ressalvas

| Item | Situação |
|---|---|
| **OXT.me** | Fora do ar desde abr/2024 *(verificado)*; relatórios antigos que o citam não são reproduzíveis |
| **Samourai Whirlpool** | Encerrado em abr/2024 *(verificado)* |
| **Wasabi (coordenador zkSNACKs)** | Suspenso em 01/06/2024; coordenadores alternativos *(verificado)* |
| **WalletExplorer** | Ainda ativo; pertence à **Chainalysis** e **registra IP e URL consultada** (aviso de privacidade do próprio site, atualizado em 14/10/2021) *(verificado)*: não use em alvo sensível sem rede controlada |
| AlgoExplorer, LocalBitcoins, Multichain | Citados como encerrados/colapsados em 2023 no material anterior; reconfirmar |
| Explorers de pontes | LayerZero Scan, Axelarscan e aba Cross-Chain do Etherscan *(verificados)*; agregadores de terceiros: avaliar |

## 10. Pontos de conversão (para planejar requisições)

| Ponto | KYC | Rastreabilidade | Abordagem |
|---|---|---|---|
| Exchange centralizada | Sim (varia) | Alta (registros internos) | Ordem judicial/cooperação |
| DEX | Não | On-chain visível, sem identidade | Rastrear on-chain; identidade por outros meios |
| P2P | Variável | Baixa (off-chain) | Contraparte via plataforma; dados bancários |
| ATM de cripto | Variável | Média | Localização, câmeras, limites |
| OTC | Variável | Baixa a média | Ordem judicial; muitas vezes sem registro formal |
| Cartão cripto | Sim | Alta na emissão | Dados da operadora |
| Processador de pagamentos | Variável | Média | Comerciante recebedor |

No Brasil, as prestadoras de serviços de ativos virtuais dependem de autorização do BCB (Resoluções 519/520/521, em vigor desde 02/02/2026) e a
DeCripto (IN RFB 2.291/2025, vigência a partir de 01/07/2026) substitui a IN 1.888/2019 *(verificado; ver [R08](08-legal-brasil.md))*.

## 11. Categorias de ativos relevantes à investigação

- **Moeda nativa × token:** movimentações de token não aparecem como valor da transação nativa (R02 §5).
- **Stablecoins:** USDT/USDC permitem bloqueio pelo emissor; DAI não (R04 §5).
- **O mesmo token em várias redes** (USDT em Ethereum/Tron/BSC…) são ativos tecnicamente distintos, em explorers distintos.
- **NFTs:** wash trading entre carteiras do mesmo controlador, transferência de patrimônio sem converter em fiat, preços fora de mercado;
  verifique quem criou (*mint*), histórico de transferências e preços.
