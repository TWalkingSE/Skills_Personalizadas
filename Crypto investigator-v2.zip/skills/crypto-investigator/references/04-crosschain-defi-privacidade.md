# R04 — Cross-chain, DeFi, mixers, moedas de privacidade e congelamento

Carregue em rastreamento multi-hop (Ação 2), pontes, swaps, mixers/CoinJoin, Monero/Zcash, stablecoins congeláveis ou sanções.
Métodos e confiança: [R03](03-metodos-de-rastreamento.md). Contas/logs EVM: [R02](02-evm-contas-tokens.md). Base UTXO: [R01](01-bitcoin-utxo.md).
Itens voláteis levam a data de verificação; sem data, confirme antes de citar em relatório.

## 1. DeFi como principal vetor de ofuscação

| Tipo | Exemplos | Uso para ofuscar | Como investigar |
|---|---|---|---|
| **DEX** | Uniswap, PancakeSwap, SushiSwap, Curve, Jupiter | Trocar ativo rastreado por outro, sem KYC | Eventos `Swap` do pool; decodificar a TX (R02); analisar pares e rota |
| **Agregadores** | 1inch, Paraswap, 0x | Roteiam por várias DEXs, escondendo a rota | Trace da TX para ver os pools usados |
| **Pontes** | Wormhole, Stargate/LayerZero, Across, Hop, Synapse, THORChain | Mudar de rede e quebrar a trilha de um explorer | Seção 2 |
| **Mixers** | Tornado Cash, Railgun, Cyclone | Romper o vínculo origem-destino | Seção 3 |
| **Empréstimos** | Aave, Compound, Venus | Colateral → saque em outro ativo; flash loans | Eventos de depósito/saque e traces |
| **Pools/yield** | LPs, Convex | "Estacionar" fundos | Rastrear os tokens de LP e quando saem |

Atenção: rota com swap + ponte + novo endereço em minutos é padrão compatível com ofuscação (R03 §12), mas não prova crime.

## 2. Pontes: achar a perna de destino

Tipos (afetam como se segue o dinheiro):
- **Lock/mint** e **burn/mint:** o ativo é bloqueado/queimado na origem e emitido/liberado no destino (ativo "embrulhado" ou nativo).
- **Pool de liquidez:** o usuário entrega na origem e recebe de um pool no destino; **o destinatário pode ser outro endereço**.
- **Baseadas em intenção/relayers:** um terceiro entrega no destino e é reembolsado depois.

Procedimento:
1. Na rede de origem, identifique o contrato da ponte, o evento (depósito/envio/lock/burn) e o **identificador da mensagem**.
2. Use o explorer da ponte/mensageria para achar a perna de destino pelo hash de origem: **LayerZero Scan** (busca por hash de
   transação, status entregue/falho) e **Axelarscan** *(verificados)*; o Etherscan traz aba **Cross-Chain Transactions** com lista de
   pontes suportadas *(verificado em 2026-10-19)*. Existem agregadores de terceiros: avalie com cautela (podem registrar a consulta).
   Wormholescan e explorers do THORChain são conhecidos, mas **não foram reverificados** nesta rodada.
3. Confirme **valor menos taxa**, janela de tempo e o destinatário na rede de destino; continue o rastreamento lá.
4. Registre as duas pernas (hash, bloco, horário) e o **grau de confiança** da ligação (R03 §2).
5. Cuidado com "mesmo endereço em outra rede": para EOA é o mesmo controlador; para contrato/carteira inteligente, **não** presuma (R02 §1).
Pontes colapsadas ou descontinuadas (ex.: Multichain, 2023) só interessam a casos históricos *(informação do material anterior; reconfirmar)*.

## 3. Mixers e CoinJoin

| Serviço | Natureza | Rastreabilidade | Observações |
|---|---|---|---|
| **Tornado Cash** | Contratos em Ethereum e redes EVM (denominações fixas, saques por relayers) | Média a baixa: tempo, valor, preço de gás, reuso de endereços e erros do usuário podem ligar depósito a saque | Status: sanções do OFAC **removidas em 21/03/2025** (precedida pela decisão do 5º Circuito de 26/11/2024 em *Van Loon v. Treasury*, que concluiu que contratos imutáveis não são "propriedade" sob a IEEPA). Processo criminal do cofundador **Roman Storm**: condenado em 06/08/2025 em uma acusação (conspiração para operar serviço de transmissão de dinheiro sem licença); sem veredito nas demais; **retrial previsto para 26/04/2027** e pedido de absolvição pendente em 26/08/2026 *(verificado em 2026-10-19; acompanhe os autos)*. O DOJ anunciou em 21/08/2025 que não processará desenvolvedores de software realmente descentralizado e não-custodial sob o mesmo dispositivo |
| **Railgun** | Contratos com provas de conhecimento zero (várias redes) | Baixa | Análise complexa |
| **Wasabi / Whirlpool / JoinMarket** | CoinJoin em Bitcoin | Reduzida; erro comum é agrupar entradas de CoinJoin como "mesmo dono" | Whirlpool (Samourai) foi encerrado pelo FBI em abr/2024; o coordenador zkSNACKs do Wasabi 2.x suspendeu em **01/06/2024**, e coordenadores menores o substituíram *(verificado)*; **OXT.me** está fora do ar desde abr/2024 |
| **PayJoin** | Pagamento em que o destinatário também contribui com entrada | Baixa | Quebra H1 sem parecer CoinJoin |
| **Lightning** | Pagamentos fora da cadeia | Muito baixa para pagamentos internos | Visível só abertura/fechamento (R01 §9) |

Postura: quando fundos entram em mixer, o rastreamento on-chain pode ser inviável. Foque no **ponto de entrada** (qual exchange antes?) e
no **ponto de saída** (qual depois?). Exchanges com KYC são o elo mais frágil da cadeia de privacidade. Declare a quebra de cadeia no relatório.

## 4. Moedas e protocolos de privacidade

| Ativo | Privacidade | Postura investigativa |
|---|---|---|
| **Monero (XMR)** | Muito alta: assinaturas em anel, endereços furtivos, valores ocultos | Rastreamento on-chain geralmente inviável. Foque em **entrada e saída** (exchanges que listam XMR), em *chain-hopping* (BTC ↔ XMR) e em erros operacionais. Afirmações de fornecedores de ferramentas sobre rastrear XMR são **probabilísticas**: peça método e taxa de erro; não as trate como fato |
| **Zcash** | Blindado (`zs1…`/`u1…`): muito alta; transparente (`t1…`): baixa | Verifique qual pool a TX usa; a maioria é transparente; saídas do pool blindado para transparente são pontos de observação |
| **Dash, Litecoin (extensão de privacidade)** | Opcional | Verifique se a função de privacidade foi usada (não verificado) |

Antes de gastar esforço: aplique a **triagem de viabilidade** (R03 §11).

## 5. Congelamento de stablecoins

- USDT e USDC permitem ao emissor **bloquear endereços** (lista de bloqueio on-chain). Confirme o status no contrato/explorer
  (ex.: função de consulta de bloqueio) e o canal oficial vigente.
- **T3 Financial Crime Unit** (Tron, Tether e TRM Labs): iniciativa que apoia autoridades no congelamento de USDT em Tron; os comunicados
  informam mais de US$ 450 milhões congelados desde 2024 e congelamentos em até 24 h após pedido de autoridades *(verificado em 2026-10-19, comunicado de 14/05/2026)*.
  Em casos brasileiros, o consórcio cita a Operação Lusocoin (Polícia Federal). **Confirme o canal e o procedimento atuais antes de oficiar.**
- Stablecoins descentralizadas (ex.: DAI) **não** têm essa possibilidade.
- Sanções: bloqueio do emissor costuma ser seguido por conformidade com listas oficiais; trate a lista como fonte datada.

## 6. Sanções e listas (screening)

- Cruze endereços relevantes com **ao menos OFAC e UE**; registre a **data da consulta**: listas mudam (inclusões e remoções; ex.: Tornado Cash
  removido em 21/03/2025, endereços ligados ao Lazarus mantidos *(verificado)*).
- Listas úteis: OFAC SDN; UE; ONU (Conselho de Segurança); Reino Unido (HMT).
- **Brasil:** as sanções do CSNU têm **executoriedade imediata** (Lei 13.810/2019; Decreto 9.825/2019), com indisponibilidade de ativos
  "sem demora"; o MJSP/DRCI mantém lista pública *(verificado)*. Detalhes em [R08](08-legal-brasil.md).
- O COAF **não** publica lista de PEP nem os RIFs (sigilosos); o cadastro de PEP é da CGU (R08).

## 7. Registro dos saltos cross-chain

Para cada perna: rede, hash, bloco, horário UTC, tipo de operação (transfer/swap/ponte/mixer), valor (bruto e legível), contrato envolvido, e o
**grau de confiança** da ligação com a perna seguinte. Use `assets/mapa-de-fluxo.md`.
