# R10 — Roteiro de estudo (Ação 10)

Carregue ao montar plano de capacitação. Pergunte antes: **perfil** (perito, delegado/promotor, analista de compliance, estudante), **nível atual**,
**rede de interesse** (Bitcoin, EVM, ambas) e **carga semanal disponível**. Monte só os módulos necessários; os tempos são **carga de estudo sugerida**
para o aluno, ajustável.

Formato de cada módulo:

```
Módulo N — Título
Objetivo: competência a desenvolver
Conteúdo: tópicos (e o reference correspondente)
Prática: exercício ou simulação
Ferramenta: o que usar
Critério de domínio: como saber que aprendeu
Carga sugerida: horas
```

Regra de segurança dos exercícios: use **dados fictícios, redes de teste** (Bitcoin testnet/signet; Sepolia/Holesky) e endereços públicos notórios.
Nunca use chaves, seeds ou dados de casos reais em treino.

## Nível iniciante

**Módulo 1 — Fundamentos de blockchain para investigação**
- Objetivo: explicar endereço, chave pública/privada, transação, bloco, taxa, UTXO × conta.
- Conteúdo: modelo de dados; por que a cadeia é pública e pseudônima; diferença entre carteira, endereço e saldo (R01 §1, R02 §1).
- Prática: abrir uma transação Bitcoin e uma EVM em explorers e nomear cada campo.
- Critério: explicar a um leigo, em 5 frases, por que "dono do endereço" não é um dado da cadeia.
- Carga: 3 h.

**Módulo 2 — Ler explorers**
- Objetivo: navegar abas (Transactions, Internal Txns, Token Transfers, Logs) e exportar CSV.
- Prática: decodificar uma transação bruta com `decode_btc_tx.py`; comparar com o explorer; decodificar um `input` ERC-20 com `decode_evm_input.py`.
- Critério: apontar, numa TX de token, o contrato do token, o destinatário real e o valor com decimais corretos.
- Carga: 4 h.

**Módulo 3 — Validar insumos e detectar envenenamento**
- Conteúdo: endereço (40 hex) × hash (64 hex); checksums; EIP-55; lookalikes; ENS não é identidade.
- Prática: classificar uma lista mista com `validate_address.py`; usar `--compare` em pares lookalike.
- Critério: nunca aceitar endereço sem validação e fonte primária.
- Carga: 2 h.

**Módulo 4 — Preservação básica**
- Conteúdo: dados brutos × captura de tela; hash; PDF; snapshot independente; manifesto (R06 §2).
- Prática: criar manifesto com `evidence_manifest.py`, alterar um arquivo e ver `verify` falhar.
- Critério: montar um pacote de evidência que sobreviva a questionamento.
- Carga: 3 h.

**Módulo 5 — OPSEC, ética e limites**
- Conteúdo: carteira queimada, ambiente isolado, consulta revela interesse, consentimento, finalidade legal, anti-stalking, dados de vítimas.
- Prática: revisar um roteiro de investigação e marcar onde o investigador se expõe.
- Critério: justificar quando **não** consultar um serviço público.
- Carga: 2 h.

## Nível intermediário

**Módulo 6 — Heurísticas UTXO e graus de confiança**
- Conteúdo: H1–H7, CoinJoin/PayJoin/batching, peel chain, escala Alta/Média/Baixa/Hipótese (R03 §2–§4, §9).
- Prática: em conjunto de TXs fictícias (3 entradas/2 saídas), identificar troco, declarar método e confiança, listar o modo de falha.
- Critério: nunca passar de Média com heurística isolada; saber quando H1 não vale.
- Carga: 6 h.

**Módulo 7 — EVM em profundidade**
- Conteúdo: nonce, logs, traces, allowances/Permit, tokens falsos, contratos e CREATE/CREATE2, EIP-7702 (R02).
- Prática: decodificar logs `Transfer`/`Approval`; auditar allowances de uma conta de teste; identificar uma conta com delegação em testnet.
- Critério: diferenciar "tentativa" (TX revertida) de "movimentação".
- Carga: 6 h.

**Módulo 8 — DeFi e pontes**
- Conteúdo: swaps, agregadores, tipos de ponte, achar a perna de destino (R04 §1–§2).
- Prática: caso simulado cross-chain (Exemplo 3 em R11): mapa de fluxo com confiança por elo.
- Critério: produzir mapa com as duas pernas da ponte documentadas.
- Carga: 5 h.

**Módulo 9 — Análise de CSV e padrões temporais**
- Conteúdo: totais por ativo, contrapartes, sweep/fan-in/fan-out/ida e volta, poeira e lookalike, histograma UTC (R03 §6, §12).
- Prática: rodar `analyze_explorer_csv.py` num CSV sintético e escrever o relatório com limitações.
- Critério: recusar inferir fuso com amostra pequena; separar padrão de prova.
- Carga: 4 h.

**Módulo 10 — Atribuição e OSINT**
- Conteúdo: o que cada provedor guarda, mitos de IP, pivôs de identidade, regra 2 + 1 (R05).
- Prática: redigir um pedido de guarda e outro de acesso usando `assets/requisicao-a-provedor.md` (com dados fictícios).
- Critério: explicar por que "IP de relay" não identifica o autor.
- Carga: 5 h.

## Nível avançado

**Módulo 11 — Contratos e honeypots**
- Conteúdo: red flags, proxies, simulação de venda, scanners e seus limites (R02 §11).
- Prática: auditar, em testnet, contratos de exemplo (com e sem `mint` ilimitado/`blacklist`).
- Critério: relatório de risco com evidência por função e quem a controla.
- Carga: 6 h.

**Módulo 12 — Privacidade e limites da cadeia**
- Conteúdo: mixers, CoinJoin, Monero/Zcash, Lightning, Taproot; triagem de viabilidade (R01 §9, R03 §11, R04 §3–§4).
- Prática: relatório de **limites** para um fluxo que passa por mixer: o que é possível provar e o que não.
- Critério: justificar "encerrar com relatório de limites" quando for o caso.
- Carga: 5 h.

**Módulo 13 — Prova, custódia e constrição**
- Conteúdo: CPP 158-A–F, árvore de decisão, controles de execução, custódia multisig (R06, R08).
- Prática: simulação em **testnet** de transferência para carteira de custódia com dois operadores e destino pré-conferido (sem chaves reais).
- Critério: registro completo (hash, bloco, endereços, valor, horário, responsáveis) e conferência por segundo canal.
- Carga: 6 h.

**Módulo 14 — Tipologias e playbooks**
- Conteúdo: mercados, ransomware, hacks, tomada de conta, extorsão, fraudes, lavagem, drenadores (R07).
- Prática: construir um playbook para uma tipologia (fluxo, assinaturas, pivôs, pedidos, armadilhas).
- Critério: indicar o pivô fora da cadeia que mais encurta o caso.
- Carga: 6 h.

**Módulo 15 — Integração e qualidade**
- Conteúdo: relatório completo (`assets/relatorio-investigativo.md`), auto-avaliação, revisão por pares, manutenção do conhecimento volátil (datar fontes).
- Prática: investigação simulada ponta a ponta com todos os artefatos.
- Critério: relatório em que todo fato tem fonte e todo elo tem confiança e alternativa.
- Carga: 8 h.

## Trilhas por perfil

| Perfil | Módulos prioritários |
|---|---|
| Perito digital | 1, 2, 4, 6, 7, 9, 11, 13, 15 |
| Delegado/promotor | 1, 3, 4, 5, 8, 10, 12, 13, 14 |
| Compliance/AML | 1, 3, 6, 7, 8, 9, 12, 14, 15 |
| Estudante/curioso | 1, 2, 3, 5, 6, 7 |

## Ferramentas de treino

Scripts da skill (offline); testnets e faucets; explorers públicos para endereços notórios (ciente do risco de log: R09); nó próprio, se possível.
Evite casos reais e dados sensíveis em material de ensino.
