# R08 — Contexto legal e regulatório (Brasil) — referência educacional

Carregue quando a pergunta envolver normas, prazos, prova, requisição a provedor, busca/apreensão, regulação de exchanges, sanções ou
cooperação internacional. **Não é parecer jurídico**: valide com advogado/membro da carreira antes de aplicar.
Convenção: *(verificado em 2026-10-19)* = conferido em fonte oficial ou de referência nesta rodada; sem a marca, o item vem de material
anterior ou conhecimento geral e **deve ser reconfirmado**. Procedimentos práticos: [R06](06-prova-custodia-apreensao.md).

## 1. Cadeia de custódia e prova digital

| Norma/decisão | Conteúdo | Verificação |
|---|---|---|
| **CPP, arts. 158-A a 158-F** (Lei 13.964/2019) | Define cadeia de custódia e vestígio; etapas do art. 158-B: reconhecimento, isolamento, fixação, coleta, acondicionamento, transporte, recebimento, processamento, armazenamento, descarte | Verificado (as três últimas etapas: conferir texto consolidado) |
| **STJ, AgRg no HC 828.054/RN** (5ª T., 23/04/2024; Informativo 811) | Prova digital sem metodologia/integridade (capturas de tela, sem hash e sem registro) é inadmissível; auditabilidade, repetibilidade, reprodutibilidade, justificabilidade e **mesmidade** (hash); ônus do Estado | Verificado |
| Enunciados da CIRAJUD Recife (TRF5; **não vinculantes**) | Enunciado 05: hash imediato, isolamento e documentação cronológica; descumprimento não gera nulidade automática (avalia-se o prejuízo concreto) | Verificado |

## 2. Busca, apreensão e medidas assecuratórias

| Norma/orientação | Conteúdo | Verificação |
|---|---|---|
| **CPP, art. 240 e ss.** | Busca e apreensão | Material anterior |
| **Lei 9.613/1998, art. 4º** | Medidas assecuratórias sobre bens/direitos/valores do investigado ou de interpostas pessoas, instrumento, produto ou proveito | Verificado |
| **Lei 9.613/1998, art. 4º-A** | **Alienação antecipada** para preservar valor: petição autônoma, avaliação, leilão por valor não inferior a 75% da avaliação; o §4º, I recebeu nova redação pela Lei 15.358/2026 (consulte o texto consolidado) | Verificado |
| CIRAJUD Recife, enunciados 02–04 (não vinculantes) | Carteira **não custodial**: pedir e autorizar expressamente a **transferência imediata** a carteira do Estado, no ato; só apreender o dispositivo é insuficiente. Indisponibilidade pode alcançar ativos lícitos quando não há como segregar; confisco alargado (CP art. 91-A) | Verificado |
| MPF (2ª CCR): roteiro de atuação em criptoativos e persecução patrimonial | Orientação funcional com modelos de peças | Verificado (existência) |
| Enunciados **162 e 209** do CJF (III Jornada de Direito Processual **Civil**) | **Execução cível**: medidas coercitivas para o devedor transferir criptoativos a endereço indicado em ordem judicial (162); cabível penhora de criptoativos com diligências indicadas (209). *Não* são enunciados penais | Verificado |
| STJ, REsp 2.127.038 (3ª T., 18/02/2025) | Cível: cabível ofício a corretoras de criptoativos para localizar e penhorar | Verificado |

## 3. Dados de provedores: Marco Civil da Internet (Lei 12.965/2014)

| Dispositivo | Conteúdo | Verificação |
|---|---|---|
| Art. 13 | Provedor de **conexão** guarda registros de conexão por **1 ano**; a autoridade policial/administrativa/MP pode requerer **guarda cautelar por prazo maior**, com pedido judicial de acesso em até 60 dias (§§ 2º–4º) | Verificado |
| Art. 15 | Provedor de **aplicações** guarda registros de acesso por **6 meses** | Verificado |
| Art. 22 | Ordem judicial para acesso: fundados indícios, justificativa de utilidade e **período** | Verificado |
| STJ, HC 626.983/PR (2022) | O pedido de **guarda** (congelamento) dispensa autorização judicial prévia; o **acesso** exige ordem | Verificado |

Consequência prática: faça o pedido de guarda **cedo** (os prazos são curtos) e depois o pedido judicial de acesso. Em CGNAT, inclua a **porta lógica de
origem** e o horário em UTC com precisão de segundos *(prática comum; confirme norma/jurisprudência vigente)*.

## 4. Organizações criminosas (Lei 12.850/2013)

| Dispositivo | Conteúdo | Verificação |
|---|---|---|
| Art. 8º | Ação controlada | Verificado |
| Art. 10-A | **Infiltração virtual** (autorização judicial; até 6 meses, renovável; limite de 720 dias) | Verificado |
| Art. 15 | Delegado e MP acessam, **sem ordem judicial**, apenas dados cadastrais (qualificação, filiação, endereço) mantidos por Justiça Eleitoral, empresas telefônicas, instituições financeiras, provedores de internet e administradoras de cartão | Verificado |

## 5. Lavagem de dinheiro (Lei 9.613/1998)

- **Art. 17-B:** acesso a **dados cadastrais** sem autorização judicial; o STF julgou constitucional (ADI 4906, 11/09/2024) *(verificado)*.
- Arts. 4º e 4º-A: ver §2.
- O COAF produz Relatórios de Inteligência Financeira (RIF), **sigilosos**, enviados por sistema próprio **somente às autoridades competentes**;
  divulgar fora das hipóteses legais é crime. O COAF **não** publica lista de PEP; o cadastro de PEP é mantido pela **CGU** (atualizado mensalmente) *(verificado)*.

## 6. Sigilo das operações: LC 105/2001

- A **Resolução CMN nº 5.280, de 26/02/2026** incluiu as **sociedades prestadoras de serviços de ativos virtuais (SPSAV)** no escopo da Lei Complementar 105/2001
  *(verificado)*. Efeito prático: informações sobre operações e serviços dessas prestadoras ficam sob o regime de sigilo (em regra, acesso por ordem judicial
  e nas hipóteses legais), sem prejuízo do acesso a dados cadastrais (Lei 9.613, art. 17-B; Lei 12.850, art. 15). Confira o texto da resolução e eventuais
  prazos de adequação.

## 7. Regulação de ativos virtuais

| Norma | Conteúdo | Verificação |
|---|---|---|
| Lei 14.478/2022 | Marco legal dos prestadores de serviços de ativos virtuais | Verificado (citada nas normas do BCB) |
| Decreto 11.563/2023 | Designa o Banco Central como órgão regulador | Verificado (citado em norma do BCB) |
| **Resoluções BCB 519, 520 e 521, de 10/11/2025** | 519: processos de autorização; 520: constituição e funcionamento das SPSAV (intermediação, custódia, corretagem; governança, segregação patrimonial, segurança cibernética) e prestação desses serviços por outras instituições autorizadas; 521: ativos virtuais no mercado de câmbio (inclui transferência de/para carteira autocustodiada e ativos referenciados em moeda fiduciária). **519 e 520 em vigor desde 02/02/2026**; 521 com vigência escalonada (parte em 02/02/2026; reporte e códigos de finalidade em 04/05/2026) | Verificado |

Implicação: exchanges autorizadas são alvos de requisição; empresas já em atividade tinham regime de transição (verifique a situação da prestadora específica).

## 8. Informação tributária: DeCripto

- **IN RFB 2.291, de 14/11/2025 (DeCripto)**: obrigação de prestação de informações sobre operações com criptoativos, com **vigência a partir de 01/07/2026**,
  em substituição à IN RFB 1.888/2019; faz referência ao acordo multilateral CARF (troca automática de informações) *(verificado)*.
- Para períodos anteriores, os dados vieram pela IN RFB 1.888/2019. Prazos, obrigados e leiaute: consulte o site da RFB. Dados fiscais têm sigilo e só chegam à
  investigação por canal legal.

## 9. Sanções

- **Lei 13.810/2019 e Decreto 9.825/2019:** sanções do Conselho de Segurança da ONU têm **executoriedade direta e imediata**; a indisponibilidade de ativos ocorre
  "sem demora" (imediatamente ou em horas); também por requerimento de autoridade central estrangeira; o DRCI/MJSP mantém lista pública *(verificado)*.
- Sanções **estrangeiras** (OFAC, UE, HMT) não têm efeito direto no Brasil, mas orientam a conformidade de exchanges globais. **Tornado Cash** foi removido da SDN em
  21/03/2025; endereços ligados ao Lazarus permanecem *(verificado; ver [R04](04-crosschain-defi-privacidade.md))*.

## 10. Cooperação internacional

- **Convenção de Budapeste** (Decreto 11.491/2023; em vigor para o Brasil desde 01/03/2023): art. 29 prevê **conservação expedita** de dados; existe rede de
  pontos de contato **24/7**, com ponto na Polícia Federal. A autoridade central brasileira para cooperação jurídica é o **DRCI/MJSP** *(verificado)*.
- Use preservação rápida por canais 24/7 e, em paralelo, o pedido formal de cooperação (MLAT/carta rogatória).

## 11. Proteção de dados

LGPD (Lei 13.709/2018): o tratamento para fins exclusivos de investigação e repressão de infrações penais é regido por legislação específica (art. 4º),
mas **minimização**, necessidade e proteção de vítimas e terceiros continuam boas práticas (material anterior; reconfirmar).

## 12. Canais de denúncia (abuso sexual infantil)

Disque 100; COMUNICA PF (repercussão internacional); SaferNet Brasil (denuncie.org.br); Polícia Civil e Ministério Público *(verificado)*.

## 13. Itens não verificados ou sensíveis (atenção)

- CGNAT/porta lógica de origem em requisições (prática; conferir normas e jurisprudência vigentes).
- Existência de jurisprudência consolidada sobre método de atribuição de fundos misturados (FIFO/Haircut): não identificada; justifique e declare o método (R03 §8).
- Prazos de adequação das SPSAV e eventuais normas complementares do BCB posteriores.
- Resultados de processos citados em R04/R07 (Tornado Cash, Bitcoin Fog): confira nos autos/fontes oficiais.
- Qualquer artigo citado de memória: confira o texto consolidado antes de usar em peça.

## 14. Salvaguardas obrigatórias

Ao citar normas em caso concreto, inclua:

> Referência educacional. Para aplicação em caso concreto, consulte advogado especializado em direito digital/criptoativos e/ou perito.

Ao concluir análise com dados reais:

> Esta análise baseia-se nos dados fornecidos e em raciocínio inferencial sobre padrões on-chain. Resultados devem ser validados com ferramentas e perícia
> especializadas antes de uso em contexto jurídico ou institucional.
