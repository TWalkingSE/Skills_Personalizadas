# R06 — Prova, cadeia de custódia, constrição e custódia de criptoativos

Carregue em qualquer tema de **preservação de prova (Ação 9)**, **busca/apreensão/bloqueio (Ação 8)**, custódia e destinação.
Base legal e prazos: [R08](08-legal-brasil.md). Modelos: `assets/artefato-cadeia-custodia.md`, `assets/requisicao-a-provedor.md`.
Scripts: `scripts/evidence_manifest.py`, `scripts/live_lookup.py` (apenas com consentimento).

> Fronteira desta skill: **não fornece** procedimento para extrair, recuperar ou "carvar" chaves/seeds de discos ou memória,
> quebrar senha de carteira, importar/varrer chave privada em software de carteira ou procurar carteiras em diretórios.
> Isso é perícia oficial, com ferramentas validadas e cadeia de custódia própria. Aqui está o **procedimento lícito**:
> reconhecer, preservar, acionar o perito e documentar.

## 1. Cadeia de custódia (CPP 158-A a 158-F) aplicada a dados on-chain

O CPP define cadeia de custódia como o conjunto de procedimentos que documentam a história cronológica do vestígio, da
identificação ao descarte (art. 158-A), e lista as etapas no art. 158-B: **reconhecimento, isolamento, fixação, coleta,
acondicionamento, transporte, recebimento, processamento, armazenamento e descarte** *(verificado em 2026-10-19; as três últimas
confirmar no texto consolidado)*.

| Etapa | Equivalente digital |
|---|---|
| Reconhecimento | Identificar endereço/TX/arquivo como vestígio relevante; quem reconheceu e quando |
| Isolamento | Não alterar o dispositivo/conta; preservar o estado (ver §6) |
| Fixação | Registrar a evidência como encontrada: TX hash, bloco, hash do bloco, horário UTC, URL, captura com metadados |
| Coleta | Obter dados brutos (RPC/explorer) e exportações (CSV/PDF) por ferramenta e responsável identificados |
| Acondicionamento | Arquivos em mídia/pasta de evidência; hash SHA-256 de cada artefato (`evidence_manifest.py`) |
| Transporte / recebimento | Registrar quem movimentou e quando; verificar o hash no destino |
| Processamento | Análise sobre **cópias**; relatório com metodologia e versões de ferramentas |
| Armazenamento / descarte | Local seguro, controle de acesso, política de retenção/descarte |

Jurisprudência de referência: o STJ (AgRg no HC 828.054/RN, 5ª Turma, 23/04/2024) declarou inadmissível prova digital sem metodologia
de integridade (capturas de tela sem documentação), destacando **auditabilidade, repetibilidade, reprodutibilidade, justificabilidade**
e a **mesmidade** (uso de hash, com software confiável e auditável), e que cabe ao Estado demonstrar a integridade da fonte de prova
*(verificado)*. Conclusão prática: **captura de tela isolada não basta**.

## 2. Protocolo de preservação on-chain (Ação 9)

1. **Captura primária — dados brutos.** TX hash, número e **hash do bloco**, horário UTC, endereços, valores em unidade mínima
   (wei/satoshi) e legível, confirmações e status de finalidade. Prefira consultar um nó com bloco **fixado** (nada de "latest"
   para evidência) e salve a resposta bruta com SHA-256 (`live_lookup.py` faz isso, **com consentimento**; ver SKILL.md).
2. **Captura secundária — explorer.** PDF da página (preserva URL e horário), exportação CSV oficial, captura completa de tela.
   Explorers saem do ar; a captura primária é a evidência mais forte.
3. **Arquivamento independente.** archive.today, Wayback Machine e/ou carimbo **OpenTimestamps** (ancora o hash de arquivos
   na cadeia do Bitcoin).
4. **Hash dos artefatos.** `python scripts/evidence_manifest.py create PASTA --case … --operator …` gera manifesto JSON/MD com
   SHA-256 por arquivo, UTC e UTC-3 e hash do próprio manifesto; `verify` detecta alteração/ausência. Registre o hash do
   manifesto em local independente.
5. **Registro de custódia.** Use `assets/artefato-cadeia-custodia.md` (quem, quando, onde, em que dispositivo, com qual
   ferramenta/versão, hash, snapshot independente, observações).
6. **Evidência volátil (mempool, ordens abertas).** Capture **imediatamente** e registre o estado na hora (taxa, confirmação pendente).
7. A combinação *dados brutos + PDF + snapshot independente + hash + registro* é robusta a contraditório; qualquer item isolado, não.

## 3. Árvore de decisão: como constringir

```
Onde estão os ativos?
├─ Em custodiante regulado (exchange/corretora/SPSAV)
│     → Ordem judicial de bloqueio/requisição de dados. Dados cadastrais: acesso previsto em lei (art. 17-B da Lei 9.613).
│       Dados transacionais: regime de sigilo (LC 105/2001; prestadoras de ativos virtuais incluídas pela Res. CMN 5.280/2026).
│       Peça bloqueio do saldo e preservação de registros.
├─ Em stablecoin com emissor que pode bloquear (USDT/USDC), em endereço próprio
│     → Solicitação via autoridade ao emissor ou canal de cooperação (ex.: T3 FCU para USDT-TRC20, que
│       relata congelamento em até 24 h após pedido de autoridades). Confirmar o canal vigente antes de oficiar.
├─ Em carteira não custodial (self-hosted)
│     → Busca e apreensão com **pedido expresso de transferência imediata** dos ativos a carteira controlada pelo Estado,
│       executada no ato (a mera apreensão do dispositivo é considerada insuficiente por orientação não vinculante
│       *(CIRAJUD/TRF5; verificado)*). Chaves/seeds: **perito oficial**.
├─ Em outra jurisdição
│     → Pedido de preservação por canais 24/7 (Convenção de Budapeste, em vigor no Brasil desde 01/03/2023) e cooperação
│       jurídica via autoridade central (DRCI/MJSP) *(verificado)*.
└─ Em protocolo DeFi/contrato sem custodiante
      → Avaliar viabilidade técnica/jurídica com perícia; evitar medidas que alertem o alvo antes de executar.
```

Manter × liquidar: a alienação antecipada para preservar valor está prevista na Lei 9.613 (art. 4º-A: petição autônoma, avaliação,
leilão por valor não inferior a 75% da avaliação) *(verificado; o §4º, I recebeu nova redação pela Lei 15.358/2026: consulte o texto
consolidado)*. A volatilidade e a perda de acesso são argumentos para decisão fundamentada.

## 4. Controles de execução da apreensão on-chain

Objetivo: reduzir risco de erro e de desvio. **Sem passo a passo com chave privada** (acione a unidade/perícia especializada).

1. **Dois operadores** (quatro olhos) em todas as etapas; registre ambos.
2. **Destino pré-acordado**, preparado antes e conferido por **segundo canal** (leitura em voz alta, QR, comparação
   caractere a caractere com `validate_address.py --compare`). Atenção a malware que troca o endereço colado.
3. **Transferência-teste** de valor pequeno antes da principal, quando o risco de perda justificar e a ordem permitir.
4. **Política de taxa e confirmação** definida antes (RBF em BTC, nonce/gás em EVM); acompanhe até o nível de confirmação/finalidade
   estipulado.
5. **Máquina confiável**, limpa e isolada para executar e conferir; registrar versões.
6. **Presumir cópias da chave com terceiros** (o investigado, cúmplices, backups): quem controla a chave pode mover a qualquer momento;
   por isso o ativo deve ir **o quanto antes** para carteira nova sob controle do Estado.
7. **Registro completo:** hash da TX, bloco, endereços de origem e destino, valor exato, data/hora UTC-3, responsáveis, capturas.
8. **Conferência pós-transferência** do saldo no destino e arquivamento (Ação 9).
9. Considere que o alvo pode monitorar a carteira (OPSEC: rede controlada; não "consultar" repetidamente antes da execução).

## 5. Custódia depois da apreensão

- **Carteira institucional** sob controle do órgão ou depositário judicial; **nunca** carteira pessoal de agente.
- **Multisig m-de-n** com chaves em dispositivos e pessoas distintos; backups cifrados e lacrados; armazenamento frio.
- **Uma carteira (ou subconta) por caso:** evita mistura, facilita auditoria e prestação de contas.
- Controle de acesso com registro (quem abriu o cofre, quando); auditoria independente periódica; rodízio de responsáveis.
- **Risco interno:** há casos públicos de agentes que desviaram criptoativos apreendidos; os controles duplos e a auditoria existem por isso.
- Alternativa: custódia em exchange determinada judicialmente, com bloqueio de movimentação.
- Treine com **testnet** (Bitcoin testnet/signet; Sepolia/Holesky) e dados fictícios; nunca com fundos reais.

## 6. Integridade de dispositivos e mídias

- **Não altere o original:** não ligue, atualize ou conecte à rede sem isolamento; **não abra aplicativos de carteira** para "ver o saldo"
  (altera estado, sincroniza, pode acionar notificações ou *wipe* remoto). Considere isolar de rede.
- Fotografe o local, telas e conexões; anote modelo, número de série, estado de energia, etiquetas.
- Imagem forense feita por **perito**, com hash da imagem; trabalhe só em cópias.
- Registre senhas/PINs/frases **somente** se o ato legal e o protocolo da unidade previrem; **nunca** em chat, e-mail ou ferramentas
  de produtividade; trate qualquer segredo como material de risco.

## 7. Checklist de busca: reconhecer (sem extrair)

| Procure | Observação |
|---|---|
| Carteiras de hardware (Ledger, Trezor etc.), cartões metálicos/papéis com 12–24 palavras ou QR | Fotografar *in loco*, lacrar, acionar o perito |
| Computadores/celulares com aplicativos de carteira, extensões de navegador, aplicativos de exchange | Não abrir; preservar; imagem pelo perito |
| Arquivos de carteira, *keystores*, backups em nuvem/USB | Preservar mídia, não executar |
| Anotações de senhas, cadernos, gerenciadores de senha | Documentar, não testar |
| Comprovantes bancários com PIX/TED para exchanges, e-mails de corretoras | Fonte para requisição a custodiantes (R05) |
| Endereços em recibos, QR codes, mensagens | Valide por script; compare com a fonte |

Oitiva (revisão jurídica obrigatória; respeitar o direito ao silêncio): quais carteiras e exchanges, onde estão backups, quem tem acesso,
quem mais conhece as credenciais, há autenticação em dois fatores. **Nunca** tente obter senhas por coação nem sem amparo legal.

## 8. Carteira custodial e ordem judicial

Quando os ativos estão em exchange, o caminho é **ordem judicial** ao custodiante: dados cadastrais, histórico, saldos, endereços,
IPs, bloqueio e preservação. Modelo: `assets/requisicao-a-provedor.md`. Especifique período em UTC, identificadores completos e
formato de resposta com hash.

## 9. Lista final de verificação

- [ ] Evidência primária (bloco, hash do bloco, horário UTC) registrada
- [ ] PDF/CSV + snapshot independente + hash/manifesto
- [ ] Responsável, dispositivo, ferramenta e versão anotados
- [ ] Destino pré-conferido por segundo canal; dois operadores
- [ ] Status de finalidade/confirmações registrado
- [ ] Nenhuma chave/seed trafegou em chat ou arquivo desta análise
- [ ] Revisão jurídica das medidas e prazos
