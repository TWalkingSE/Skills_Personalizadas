# R02 — EVM e redes de conta: contas, transações, tokens e contratos

Carregue ao analisar endereços/transações EVM, tokens, contratos, allowances, ENS, honeypots, ou redes de conta
não-EVM (Tron, Solana, XRP…). Heurísticas: [R03](03-metodos-de-rastreamento.md). Pontes/DeFi: [R04](04-crosschain-defi-privacidade.md).
Scripts: `scripts/decode_evm_input.py`, `scripts/validate_address.py`, `scripts/analyze_explorer_csv.py`, `scripts/live_lookup.py`.

## 1. Contas: EOA, contrato e delegação

| Tipo | Controle | Como reconhecer |
|---|---|---|
| **EOA** | Chave privada | `eth_getCode` = `0x` |
| **Contrato** | Código (pode ter `owner`, ser imutável ou *upgradeable* via proxy) | `eth_getCode` com bytecode; aba "Contract" no explorer |
| **EOA com delegação (EIP-7702)** | Chave privada + código delegado | Código começa com `0xef0100` seguido de 20 bytes (endereço do contrato delegado) *(verificado em 2026-10-19; Pectra ativou em 07/05/2025; tipo de TX 0x04)* |

- O estado de uma conta tem **nonce**, saldo, código e armazenamento.
- Delegação 7702: o explorer pode ainda exibir "EOA". Verifique o código da conta e investigue o contrato delegado
  (padrões de *drainer* surgiram logo após o fork; telemetria inicial apontou maioria das delegações ligadas a contratos maliciosos).
- **Mesmo endereço em outra rede ≠ mesmo controle** para contratos/carteiras inteligentes: o caso da Safe da Wintermute
  na Optimism (2022) mostra que um terceiro pode implantar contrato no mesmo endereço em outra rede
  (assinatura de deploy sem proteção de chain ID reproduzida) *(verificado)*. Para EOA, a mesma chave controla o mesmo endereço em todas as redes EVM.

## 2. Nonce como ferramenta forense

- O nonce de uma EOA conta as transações **enviadas**; nonce 0 com saldo = a conta só recebeu.
- Ordem estrita: um nonce só entra depois do anterior. **Lacuna** (nonce 7 pendente, 8 aguardando) indica TX presa; o cancelamento é uma TX com o mesmo nonce, taxa maior (muitas vezes 0 valor para si mesmo).
- Nonce muito alto e cadência regular sugere hot wallet/bot; compare com horários (H13 em R03).
- Em contratos, o nonce conta contratos criados (CREATE), não "transações enviadas".
- Para monitoramento leve: `live_lookup.py monitor --kind evm` acompanha **saldo e nonce** (não vê tokens).

## 3. Anatomia da transação

| Campo | Observação forense |
|---|---|
| `from` | Derivado da assinatura (recuperação da chave pública); não é digitado: é verificável |
| `to` | Vazio = criação de contrato. Em transferência de token, é o **contrato do token** |
| `value` | Moeda nativa em wei (1 ETH = 10^18 wei). **0 em transferências de token** |
| `input` (data) | Seletor + argumentos (ver §4) |
| `nonce`, `gas`, `maxFeePerGas`, `maxPriorityFeePerGas` | Ordem e custo; taxa incomum pode indicar urgência/bot |
| `chainId` e assinatura | Proteção contra replay entre redes (EIP-155); sem ela a TX pode ser reproduzida em outra rede |
| `type` | 0 legada, 1 (acesso), 2 (EIP-1559), 3 (blob/EIP-4844), 4 (set-code/EIP-7702) |

Recibo (`eth_getTransactionReceipt`): status (sucesso/revertida), gás usado, endereço do contrato criado e **logs**.
Transação revertida **não move valor**, mas consome taxa e prova tentativa.

## 4. `input data`: seletor + ABI

- Os primeiros 4 bytes = seletor da função (`keccak256("assinatura")[:4]`); o restante são palavras de 32 bytes.
- `scripts/decode_evm_input.py input 0x…` identifica funções conhecidas (ERC-20/721/1155, Permit, multicall, swaps,
  Safe…), decodifica argumentos e avisa de allowances ilimitadas e `setApprovalForAll`. Para seletor desconhecido,
  mostra as palavras com dicas heurísticas e orienta consultar bases públicas de assinaturas ou o ABI do contrato verificado.
- `decode_evm_input.py sig "transfer(address,uint256)"` calcula seletor e hash de tópico.
- Tabela de seletores usuais: `a9059cbb` transfer · `095ea7b3` approve · `23b872dd` transferFrom · `a22cb465`
  setApprovalForAll · `42842e0e`/`b88d4fde` safeTransferFrom (721) · `f242432a` safeTransferFrom (1155) · `d505accf` permit ·
  `d0e30db0` deposit · `2e1a7d4d` withdraw · `ac9650d8` multicall · `3593564c` execute (roteadores universais).
- **Proxies:** o contrato chamado delega a uma implementação; o ABI relevante é o da implementação. Verifique o slot
  de implementação e o histórico de upgrades.
- Seleção de função não prova intenção: confirme pelos logs e pelo efeito no saldo.

## 5. Transferência de token (a armadilha mais comum)

1. A transação vai para o **contrato do token**; `value` = 0; destinatário e quantidade estão **nos argumentos** e no
   **log `Transfer`**.
2. O "saldo" de um token é uma entrada no armazenamento do contrato do token, não algo "dentro" do endereço do usuário.
3. A aba "Token Transfers" do explorer é derivada dos logs. Contratos mal-intencionados podem emitir eventos falsos ou
   não emitir; confira o saldo com `balanceOf`.
4. **Token falso com o mesmo símbolo/nome:** sempre compare o **endereço do contrato**, nunca o símbolo.
5. Decimais variam (USDT/USDC costumam usar 6; muitos usam 18). A quantidade bruta precisa ser dividida por 10^decimais.
6. Taxas na transferência, *rebase* e contratos com lista de bloqueio alteram o que chega ao destino.
7. Transferência de NFT: ERC-721 (`Transfer` com 4 tópicos: o 4º é o `tokenId`); ERC-1155 (`TransferSingle/Batch`).

## 6. Logs, eventos e traces

| Evento | Tópicos | Dados |
|---|---|---|
| `Transfer` ERC-20 | topic0, from, to | valor |
| `Transfer` ERC-721 | topic0, from, to, tokenId | vazio |
| `Approval` | topic0, owner, spender | valor (máximo = ilimitado) |
| `ApprovalForAll` | topic0, owner, operator | booleano |
| `TransferSingle`/`TransferBatch` (1155) | topic0, operator, from, to | id(s) e valor(es) |

`decode_evm_input.py log --topic … --data …` decodifica. O endereço que **emitiu** o log identifica o token.

**Transações internas (traces):** uma única TX pode mover valor por vários contratos. Explorers listam "Internal Txns"
(chamadas com valor). Para o rastro completo (CALL, DELEGATECALL, CREATE, SELFDESTRUCT) use métodos de trace do nó
(`debug_traceTransaction`/`trace_transaction`) ou simuladores (Tenderly, Phalcon). Em DeFi, a análise sem trace é incompleta.

## 7. Criação de contratos

- TX com `to` vazio. Endereço = últimos 20 bytes de `keccak256(rlp(implantador, nonce))`.
- **CREATE2:** endereço = `keccak256(0xff ‖ implantador ‖ salt ‖ keccak256(initcode))[12:]`: previsível antes do deploy;
  fábricas criam contratos "sem TX" do implantador final. *(fórmulas padrão do protocolo)*
- "Quem implantou" ≠ "dono". Veja `owner()`, papéis de administração e `transferOwnership` recente.
- `selfdestruct`: após a atualização Dencun só apaga o contrato se criado na mesma transação (efeito limitado), mas ainda relevante em outras redes EVM.

## 8. Endereços especiais

- `0x0000…0000` (zero) e `0x…dEaD`: **queima ou erro**, não destino de lavagem. Fundos ali são irrecuperáveis.
- Contratos pré-compilados (`0x1`…`0x9`…) e contas de sistema de L2: não são pessoas.
- Verifique se o endereço-alvo não é um contrato público (Uniswap, ponte, token) antes de "investigar o dono".

## 9. Tokens, allowances e permissões

- **Allowance** (`approve`): autoriza o gastador a mover tokens sem nova assinatura. `max uint256` = ilimitado.
- **Permit/Permit2:** autorização por **assinatura off-chain**; terceiro pode submeter a TX. Muito usado em *drainers*.
- `setApprovalForAll` (NFT): poder sobre **todos** os tokens da coleção.
- Auditar: use scanners de aprovações (ex.: revoke.cash) e os eventos `Approval`/`ApprovalForAll` do alvo.
- Concentração: veja os maiores detentores, % da oferta, liquidez bloqueada ou removível, funções `mint`, `pause`, `blacklist`, taxas ajustáveis.
- Stablecoins centralizadas (USDT/USDC) podem **bloquear** endereços (lista de bloqueio on-chain); DAI e similares, não.

## 10. ENS e nomes legíveis

Nome → endereço é **configuração do dono do nome** (resolver). O registro reverso (endereço → nome) é definido por quem controla o
endereço. Nomes expiram e mudam de dono; a resolução atual pode diferir da de uma data passada (consulte o histórico por eventos
do registro). Homógrafos Unicode imitam nomes. **Nome ENS não é prova de identidade.**

## 11. Contratos suspeitos: red flags e honeypots (Ação 6)

| Red flag | Significado | Risco |
|---|---|---|
| `mint()` sem teto pelo dono | Diluição infinita | CRÍTICO |
| `pause()`/`blacklist()` pelo dono | Congelar transferências ou impedir vendas | ALTO |
| `setFee()`/`setTax()` ilimitado | Taxa de 99%: honeypot | CRÍTICO |
| Venda bloqueada na prática (limite máximo de TX, lista de venda, taxa dinâmica) | Honeypot | CRÍTICO |
| `transferOwnership()` recente | Ocultar criador/tomada de controle | MÉDIO |
| Código não verificado | Não auditável | ALTO |
| Proxy *upgradeable* | Lógica pode mudar após o deploy | MÉDIO |
| `approve()` para endereço externo fixo / `delegatecall` para endereço controlável | Drenagem/execução arbitrária | CRÍTICO |
| Autenticação por `tx.origin`, reentrância, retorno de chamada não verificado, aritmética sem proteção (versões antigas) | Vulnerabilidades clássicas exploráveis | ALTO |
| Oráculo manipulável / dependência de preço de um só pool | Exploits por flash loan | ALTO |
| `selfdestruct` | Destruição do contrato (efeito limitado após Dencun) | ALTO |

Procedimento: confirme endereço e rede → código verificado? → funções privilegiadas e quem as detém → simule a venda
(ferramentas de simulação; consultar scanners tem custo de log) → liquidez e histórico do implantador → registre achados com hash/bloco.
Scanners automáticos (Token Sniffer, De.Fi, GoPlus, honeypot.is) dão indício, não laudo.

## 12. Finalidade em redes de conta

Prefira o marcador nativo de finalização (`finalized` do RPC/explorer) quando existir. Valores abaixo são indicativos e devem ser
reconfirmados na data do relatório.

| Rede | Observação |
|---|---|
| Ethereum (PoS) | Finalização em ~2 épocas (≈ 13 min); aguarde "finalized" |
| Rollups otimistas (Arbitrum, OP Mainnet, Base) | "Soft finality" pelo sequenciador; irreversível na L1 só após a janela de contestação (~7 dias para saques) |
| Rollups ZK (zkSync, Linea) | Finalidade após prova verificada na L1 |
| Polygon PoS | Checkpoints na Ethereum (dezenas de minutos) |
| BSC / Tron / Avalanche | Finalidade rápida, mas atenção a reorgs históricos; confirme no explorer |
| Solana | Status "finalized" (~13 s) |

Em apreensão ou relatório formal sobre TX recente, registre bloco, hash do bloco e o status de finalidade na hora da consulta.

## 13. Forks EVM

ETH/ETC/ETHW compartilham histórico até o fork e têm chain IDs distintos; saldos podem existir em duplicidade
(origem de dúvida: "qual rede?"). Pré-EIP-155, transações podiam ser reproduzidas entre forks.

## 14. Redes de conta não-EVM: o que muda

| Rede | Formato | Particularidades forenses |
|---|---|---|
| **Tron** | `T…` (34 caracteres, Base58Check) | USDT-TRC20 em grande volume; custos em energia/banda; congelamento via emissor/T3 FCU ([R04](04-crosschain-defi-privacidade.md)) |
| **Solana** | Base58, 32–44 caracteres, **sem checksum** | Tokens ficam em **contas de token** associadas ao endereço (o explorer mostra "token accounts"); risco alto de erro de digitação |
| **XRP** | `r…` | **Destination tag** identifica o cliente em exchanges: sem ela não há como creditar/identificar |
| **TON** | `EQ…`/`UQ…` | Endereços amigáveis com CRC; formatos "bounceable" diferentes para o mesmo endereço |
| **Cosmos e família** | bech32 com prefixo (`cosmos1…`) | O prefixo (hrp) indica a rede; transferências entre redes via IBC |
| **Cardano** | `addr1…` | UTXO estendido (eUTXO) |
| **Algorand / NEAR / Polkadot** | Formatos próprios | Explorers próprios; nomes legíveis (NEAR) devem ser verificados |

`validate_address.py` classifica esses formatos (e avisa onde não há checksum).

## 15. Procedimento prático (EVM)

```
1. Valide insumo (endereço 40 hex × hash 64 hex; EIP-55; envenenamento): scripts/validate_address.py.
2. Confirme a rede (protocolo do 0x no SKILL.md). Em dúvida: peça a fonte do endereço e use o verificador multi-rede.
3. Tipo de conta: EOA / contrato / delegação 7702 (eth_getCode). Se contrato: verificado? proxy? dono?
4. Colete: Transactions, Internal Txns, Token Transfers (ERC-20/721/1155), Logs. Para histórico extenso, exporte CSV e rode
   scripts/analyze_explorer_csv.py (totais por ativo, contrapartes, sweeps, poeira/envenenamento, histograma UTC).
5. Decodifique o input de TXs relevantes e os logs (decode_evm_input.py).
6. Aplique H8/H12/H13 (R03) com graus de confiança; para trocas/pontes, R04.
7. Preserve (Ação 9): hash, bloco, horário UTC, RPC/explorer, manifesto SHA-256.
```
