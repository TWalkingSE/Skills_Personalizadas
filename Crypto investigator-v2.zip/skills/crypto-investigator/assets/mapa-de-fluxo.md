# Mapa de fluxo de fundos — modelo

> Use texto (ASCII) para colar no relatório. Cada **aresta** leva hash, horário UTC, valor e a **confiança** da ligação (A = Alta, M = Média, B = Baixa, H = Hipótese).
> Marque pontos alcançáveis (`[PONTO ALCANÇÁVEL]`), quebras de cadeia (`[QUEBRA]`) e trechos não verificados. Endereços completos ficam na tabela abaixo; no desenho use rótulos curtos.

## Legenda
```
[N1]  nó (endereço, cluster ou serviço)      ==>  fluxo com confiança A/M
-->   fluxo com confiança B                  ..>  fluxo hipotético (H)
(M)   confiança Média na aresta              [Q]  quebra de cadeia (mixer, ponte opaca, privacidade)
```

## Desenho (exemplo)
```
[N0 Exchange A (CEX)]
     |
     | 10 BTC  tx:abc…123  2025-03-01 14:30 UTC  (A)
     v
[N1 Endereço 1 — cluster "Carteira do alvo" (H1 + H6, M)]
     |
     +==(M)== 3 BTC  tx:def…456 ==> [N2 Endereço 2] ==(M)== 3 BTC ==> [N3 Exchange B (CEX)]  [PONTO ALCANÇÁVEL]
     |
     +--(B)-- 5 BTC  tx:ghi…789 --> [N4 Mixer/CoinJoin]  [Q: rastreamento interrompido]
     |
     +==(M)== 2 BTC troco (H2+H4) ==> [N5 Endereço 3 — mesmo cluster] ..(H).. 2 BTC ..> [P2P off-chain]
                                                                                     investigar: dados bancários
```

## Tabela de nós
| Nó | Endereço(s) completo(s) | Rede | Tipo (pessoa? serviço? contrato?) | Origem do rótulo | Confiança do rótulo |
|---|---|---|---|---|---|
| N0 | | | | | |

## Tabela de arestas
| De | Para | Ativo | Valor (bruto/legível) | Hash da TX | Bloco | Horário (UTC) | Heurística/método | Confiança | Modo de falha |
|---|---|---|---|---|---|---|---|---|---|
| N0 | N1 | | | | | | | | |

## Notas
- **O caminho vale o elo mais fraco** (R03 §2): indique o menor grau do trecho.
- Para fundos misturados, declare o método (FIFO/Haircut…) e apresente variantes se divergirem.
- Em pontes: registre as duas pernas (origem e destino) com hash e bloco de cada uma (R04 §2).
- Em mixers/CoinJoin: marque a quebra e foque nos pontos de entrada e saída.
- Pontos alcançáveis: indique o tipo de requisição cabível (R05/R06/R08).
