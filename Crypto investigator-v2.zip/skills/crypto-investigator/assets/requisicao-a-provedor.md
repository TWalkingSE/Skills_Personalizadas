# Requisição a provedor/custodiante — modelo educacional

> **Modelo educacional**: adapte à legislação, ao rito e ao formulário da autoridade; **não substitui orientação jurídica**. Distinga os dois tempos:
> (1) **pedido de guarda/preservação** (urgente; os registros têm retenção curta) e (2) **requisição de acesso** (ordem judicial para registros e conteúdo; dados cadastrais
> têm regimes próprios). Conferir R08 (Marco Civil, Lei 9.613 art. 17-B, Lei 12.850 art. 15, LC 105/2001) antes de usar.

## Parte A — Pedido de preservação (guarda)

```
À [razão social do provedor / exchange / ISP] — [canal oficial de requisições legais]
De: [autoridade requisitante, cargo, matrícula, contato institucional]
Referência: [procedimento/inquérito nº]    Data: [AAAA-MM-DD]
Assunto: PEDIDO DE PRESERVAÇÃO DE REGISTROS

Solicito, com base em [dispositivo legal aplicável], a PRESERVAÇÃO dos registros abaixo, até a chegada de ordem judicial de acesso, no prazo legal:

Identificadores (completos, validados por script):
  - Endereços/Contas/Hashes: [lista]
  - IPs: [IP, data/hora UTC com precisão de segundos, FUSO, porta lógica de origem se houver CGNAT]
  - E-mails/identificadores de conta: [lista]
Período: [início UTC — fim UTC]
Registros a preservar: [cadastro; logs de acesso/login; IPs e dispositivos; operações e saldos; endereços de depósito/saque; comunicações com a conta]
Sigilo: solicita-se que o titular NÃO seja notificado, quando permitido pela norma aplicável.
Confirmação de recebimento e do prazo de guarda: solicita-se resposta para [contato].

Assinatura: ______________________
```

## Parte B — Requisição de acesso (anexar a ordem judicial)

```
À [provedor/exchange]
De: [autoridade requisitante]      Ordem judicial: [nº, juízo, data]      Procedimento: [nº]

Com fundamento na ordem anexa, requisita-se:

1. Dados cadastrais do titular do(s) identificador(es): [nome, CPF/CNPJ, documentos, endereço, telefone, e-mail, data de abertura]
2. Registros de acesso: IPs, datas/horas (UTC) e dispositivos de login e de operação no período [início — fim]
3. Operações e movimentações no período, incluindo: [depósitos/saques (cripto e fiat: PIX/TED), ordens, saldos, taxas]
   - Para cada operação: data/hora UTC, ativo, quantidade, hash da transação, endereços de origem e destino
4. Endereços de depósito e de saque vinculados à conta (histórico completo)
5. Situação atual de saldos e BLOQUEIO preventivo de [ativos/contas] (se determinado pela ordem)
6. Informações sobre outras contas vinculadas por mesmo documento/dispositivo/IP (se autorizado)

Formato de resposta: [CSV/JSON], acompanhado de hash SHA-256 e ofício de autenticidade; canal seguro: [endereço].
Prazo: [conforme ordem].
Em caso de impossibilidade de cumprimento, informe o motivo e a data de retenção dos registros.

Assinatura: ______________________
```

## Dicas de preenchimento
- Valores completos e validados (`validate_address.py`); nunca abreviados.
- Horários sempre em **UTC com fuso explícito** e precisão adequada (segundos); em CGNAT, inclua a **porta de origem**.
- Peça **endereços de depósito e saque** (cria novos pivôs on-chain) e **IPs** (cria pivôs de infraestrutura).
- Prefira prazo curto para a preservação e mantenha registro do protocolo de envio.
- Exchanges estrangeiras: avalie cooperação internacional e preservação via canais 24/7 (R08 §10).
