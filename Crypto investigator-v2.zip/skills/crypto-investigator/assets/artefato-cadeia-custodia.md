# Artefato de cadeia de custódia — modelo (um por artefato)

> Gere os hashes com `python scripts/evidence_manifest.py create PASTA --case "…" --operator "…" --md MANIFESTO.md`. Registre o **hash do manifesto** em local independente
> (ex.: carimbo OpenTimestamps) e no relatório. Capturas de tela isoladas não bastam: combine **dados brutos + PDF/CSV + snapshot independente + hash + este registro**.

```
ARTEFATO #N
Caso/Procedimento: [número]
Tipo: [dados brutos de RPC | PDF de página de explorer | CSV de transações | captura de tela | resposta de provedor | imagem forense]
Descrição: [o que é e por que é relevante]
Origem: [URL completa / endpoint / provedor / dispositivo de origem]
Rede e referência: [rede; altura e HASH do bloco; hash da transação; status de finalidade; confirmações]
Data/hora da coleta: [AAAA-MM-DD HH:MM:SS UTC / UTC-3]
Coletor: [nome/matrícula]
Dispositivo e sistema: [modelo, SO, navegador ou ferramenta e versão]
Ferramenta/método de coleta: [live_lookup.py vX (consentimento: quem/quando) | explorer manual | exportação oficial | perícia]
Nome do arquivo: [arquivo]
Tamanho (bytes): [n]
Hash SHA-256: [hash]
Snapshot independente: [URL archive.today / Wayback / carimbo OpenTimestamps]
Estado/observações: [bloco confirmado N vezes; mempool; limitações; conteúdo volátil]
Armazenamento: [local, mídia, acesso restrito a quem]
Movimentações do artefato:
  [data/hora] [quem entregou] -> [quem recebeu] [finalidade] [hash conferido: sim/não]
Assinatura do responsável: ____________________   Data: ____/____/______
```

## Lista de verificação de preservação
- [ ] Dados brutos (hash e **hash do bloco**, horário UTC) registrados antes das capturas secundárias
- [ ] PDF/CSV obtido de forma reproduzível (URL e horário visíveis)
- [ ] Snapshot independente criado
- [ ] SHA-256 de cada arquivo gerado e conferido após cada transferência
- [ ] Manifesto criado e seu hash guardado em local independente
- [ ] Dispositivo/original **não alterado**; trabalho sobre cópia
- [ ] Evidência volátil (mempool, ordem aberta) capturada imediatamente, com o estado no momento
- [ ] Nenhuma chave/seed/senha em chat, e-mail ou arquivos desta análise
