# Relatório investigativo on-chain — modelo

> Preencha todos os campos. Se um campo não se aplica, escreva "não aplicável" e o motivo. **Fato observado** exige fonte e método de verificação;
> **inferência** exige método (H#), grau de confiança e modo de falha. Não invente dados.

```
+------------------------------------------------------------------+
| RELATÓRIO INVESTIGATIVO ON-CHAIN                                  |
+------------------------------------------------------------------+
| Tipo ............ [ANÁLISE REAL — dados do investigador/consulta] |
|                   [ANÁLISE SIMULADA — dados fictícios]            |
| Procedimento .... [nº do procedimento / caso / solicitante]       |
| Blockchain(s) ... [rede(s) identificada(s) e como foi confirmada] |
| Modelo .......... [UTXO / Conta]                                  |
| Endereço(s)/Hash  [valores COMPLETOS; validados por script: sim/não]
| Data da análise . [AAAA-MM-DD HH:MM UTC / UTC-3]                  |
| Analista ........ [nome/matrícula]                                |
| Referência de bloco/altura [altura e hash do bloco na consulta]   |
| Ferramentas e versões [scripts, explorers, nó, data da consulta]  |
+------------------------------------------------------------------+
```

## 1. Resumo executivo
[3–5 frases: o que foi encontrado; conclusão principal **com grau de confiança** (Alta/Média/Baixa/Hipótese); nível de risco; próximos passos.]

## 2. Dados observados (fatos verificáveis)
| # | Fato | Hash/endereço | Bloco | Horário (UTC) | Valor | Fonte e verificação |
|---|---|---|---|---|---|---|
| 1 | | | | | | [explorer/RPC/script; data da consulta] |

- Saldo atual: [valor e ativo; data/hora e bloco da leitura]
- Volume transacionado: [entradas / saídas por ativo]
- Período de atividade: [primeira → última]
- Tokens relevantes: [contrato, símbolo, decimais]
- Contrapartes identificadas: [endereços ou entidades; origem do rótulo]
- Interações com contratos: [DEX, ponte, mixer, DeFi, NFT]
- Valoração em fiat: [moeda; fonte; **cotação da data da transação**]

## 3. Mapa de fluxo de fundos
[Use `mapa-de-fluxo.md`: nós, arestas com hash/horário/valor e **confiança por aresta**; marque quebras de cadeia e pontos alcançáveis.]

## 4. Análise de padrões e método
- Heurísticas aplicadas: [H# e resultado]
- Método de atribuição para fundos misturados: [FIFO / LIFO / Haircut / Poison / Last-touch; resultados lado a lado se divergirem]
- Padrões observados: [fragmentação, consolidação, timing, ponte/DEX/mixer, peel chain, ida e volta, dormência] — descrição + evidência
- Hipóteses alternativas consideradas e por que foram aceitas/descartadas: [...]

## 5. Classificação de risco
**[BAIXO / MÉDIO / ALTO / CRÍTICO]** — justificativa: [base]. Confiança da classificação: [Alta/Média/Baixa].

## 6. Pontos de investigação prioritários
| # | Ação recomendada | Objetivo | Prioridade | Base/cautela legal |
|---|---|---|---|---|
| 1 | | | ALTA/MÉDIA/BAIXA | [ver R08; revisão jurídica] |

## 7. Ferramentas e fontes recomendadas
[Para esta investigação; com status e **risco de log** de cada uma (R09).]

## 8. Limitações e ressalvas
- [dados parciais; rede com privacidade; trecho não rastreável após mixer; amostra pequena; rótulos de terceiros]
- Resultados baseados nos dados fornecidos/consultados e em análise inferencial; recomenda-se validação cruzada antes de uso processual.

## 9. Evidências e cadeia de custódia
- Manifesto (`evidence_manifest.py`): arquivo [nome], hash do manifesto SHA-256 [valor], nº de artefatos [n]
- Artefatos: use `artefato-cadeia-custodia.md` para cada item
- Snapshots independentes: [URLs/carimbos]

## 10. Consultas de rede realizadas
| Data/hora (UTC) | Serviço/host | Dado enviado | Finalidade | Consentimento (quem/quando) | Arquivo de evidência |
|---|---|---|---|---|---|
| | | | | | |
(Se nenhuma consulta de rede foi feita: "nenhuma; análise apenas sobre dados fornecidos".)

## 11. Triagem de viabilidade (opcional)
[Ponto alcançável? Quebra de cadeia? Jurisdição? Prazo? Decisão: Priorizar / Preservar e aguardar / Encerrar com relatório de limites.]

---
Salvaguardas (incluir quando houver dados reais):
> Esta análise baseia-se nos dados fornecidos/consultados e em raciocínio inferencial sobre padrões on-chain. Os resultados devem ser validados com ferramentas e perícia especializadas
> antes de uso em contexto jurídico ou institucional.
> Referência educacional quanto às normas citadas. Para aplicação em caso concreto, consulte advogado especializado e/ou perito.
