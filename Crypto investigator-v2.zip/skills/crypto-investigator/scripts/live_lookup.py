#!/usr/bin/env python3
"""Consulta ao vivo (OPT-IN) — a ÚNICA peça desta skill que usa a rede.

ATENÇÃO — consultar um explorer/nó de terceiros REVELA o dado investigado (endereço/hash) e o seu IP ao serviço.
Por isso o script FALHA FECHADO: sem --confirm-disclosure nada é enviado. Prefira nó/explorer próprio
(--base-url / --rpc) ou uma saída de rede controlada (--proxy). Chaves de API só por variável de ambiente.

Subcomandos:
  btc-tx      TXID         [--base-url URL_ESPLORA]          transação Bitcoin (Esplora) + decodificação local do hex
  btc-addr    ENDERECO     [--base-url URL_ESPLORA] [--max-pages N]
  evm-tx      HASH         (--rpc URL | --rpc-env VAR)       transação EVM via JSON-RPC (nó do usuário)
  evm-txlist  ENDERECO     --chainid N [--action txlist|txlistinternal|tokentx|tokennfttx] [--csv-out ARQ]  (Etherscan V2)
  monitor     ENDERECO     --kind btc|evm --max-runs N --interval S   (acompanha mudanças; limitado)

Cada resposta bruta é salva em --out (corpo exato + metadados com SHA-256, UTC e host) para a cadeia de custódia;
use depois `evidence_manifest.py create` na pasta. NÃO há rastreamento recursivo automático: no máximo --max-pages
páginas por invocação; o investigador decide cada salto seguinte.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import ipaddress
import json
import os
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from decimal import Decimal

import _common as c
import decode_btc_tx as BTX
import decode_evm_input as EVM
import validate_address as V

MIN_INTERVAL = 30
MAX_BODY = 50 * 1024 * 1024
DEFAULT_ESPLORA = "https://blockstream.info/api"
DEFAULT_ETHERSCAN = "https://api.etherscan.io/v2/api"
UA = f"crypto-investigator-live/{c.VERSION}"
CHAINS = {1: "Ethereum", 10: "Optimism", 25: "Cronos", 56: "BNB Smart Chain", 100: "Gnosis", 137: "Polygon PoS",
          146: "Sonic", 250: "Fantom", 324: "zkSync Era", 8453: "Base", 42161: "Arbitrum One", 42220: "Celo",
          43114: "Avalanche C-Chain", 59144: "Linea"}
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]")


class LiveError(Exception):
    pass


class Refusal(Exception):
    pass


def clean(value) -> str:
    """Neutraliza caracteres de controle (ESC etc.) em qualquer texto vindo da cadeia/serviço antes de imprimir."""
    return _CTRL.sub("?", str(value))


def check_url(url: str, what: str) -> urllib.parse.SplitResult:
    u = urllib.parse.urlsplit(url or "")
    if u.scheme not in ("http", "https") or not u.hostname:
        raise LiveError(f"a URL de {what} deve começar com http:// ou https:// e conter um host")
    return u


def host_kind(host: str) -> str:
    try:
        ip = ipaddress.ip_address(host)
        return "local/privado (sem divulgação a terceiros, se for mesmo seu)" if (ip.is_private or ip.is_loopback) \
            else "PÚBLICO (terceiro)"
    except ValueError:
        h = host.lower()
        if h == "localhost" or h.endswith((".local", ".internal", ".lan")):
            return "local/privado (sem divulgação a terceiros, se for mesmo seu)"
        return "PÚBLICO (terceiro)"


def shown_url(url: str, redact_path: bool = False) -> str:
    u = urllib.parse.urlsplit(url)
    host = u.netloc.split("@")[-1]
    if redact_path:
        return f"{u.scheme}://{host}/[caminho omitido: pode conter chave]"
    q = re.sub(r"(?i)\b(apikey|api_key|key|token)=[^&]*", r"\1=REDACTADO", u.query)
    return urllib.parse.urlunsplit((u.scheme, host, u.path, q, ""))


class _SameHostRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        old, new = urllib.parse.urlsplit(req.full_url), urllib.parse.urlsplit(newurl)
        if (old.hostname or "").lower() != (new.hostname or "").lower():
            raise LiveError(f"redirecionamento para outro host recusado ({clean(new.hostname)})")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class Response:
    def __init__(self, status, body, ctype, saved, persist):
        self.status, self.body, self.ctype, self.saved, self._persist = status, body, ctype, saved, persist

    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")

    def json(self):
        try:
            return json.loads(self.body.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise LiveError("a resposta não é JSON válido") from exc

    def persist(self):
        if self.saved is None and self._persist:
            self.saved = self._persist()
        return self.saved


class Session:
    def __init__(self, out_dir=None, delay=1.0, timeout=20.0, proxy=None, user_agent=UA, retries=2):
        stamp = time.strftime("%Y%m%d-%H%M%SZ", time.gmtime())
        self.out_dir = out_dir or os.path.join("evidencias-live", stamp)
        self.delay, self.timeout, self.retries, self.ua = delay, timeout, retries, user_agent
        handlers = [_SameHostRedirect()]
        if proxy:
            check_url(proxy, "proxy")
            handlers.append(urllib.request.ProxyHandler({"http": proxy, "https": proxy}))
        self.opener = urllib.request.build_opener(*handlers)
        self.saved: list[str] = []
        self._n = 0
        self._last = 0.0
        self._banner = False

    def banner(self, host: str, datum: str) -> None:
        if self._banner:
            return
        self._banner = True
        print("=== AVISO DE DIVULGAÇÃO (consulta ao vivo) ===\n"
              f"Destino     : {clean(host)} — {host_kind(host)}\n"
              f"Dado enviado: {clean(datum)}\n"
              "Serviços de terceiros podem registrar seu IP e o dado consultado e correlacioná-los.\n"
              "Alternativas: nó/explorer próprio (--base-url / --rpc) e saída de rede controlada (--proxy).\n"
              "Autorizado explicitamente por --confirm-disclosure. Nenhum salto adicional é seguido automaticamente.\n"
              "==============================================", file=sys.stderr)

    def _pace(self):
        wait = self.delay - (time.monotonic() - self._last)
        if self._last and wait > 0:
            time.sleep(wait)

    def _save(self, label, method, url_shown, extra, status, body, ctype) -> str:
        os.makedirs(self.out_dir, exist_ok=True)
        self._n += 1
        base = f"{self._n:03d}-{re.sub(r'[^A-Za-z0-9_.-]', '_', label)[:60]}"
        body_path = os.path.join(self.out_dir, base + ".body")
        meta_path = os.path.join(self.out_dir, base + ".meta.json")
        with open(body_path, "wb") as fh:
            fh.write(body)
        now = time.time()
        meta = {"tool": f"live_lookup.py (crypto-investigator {c.VERSION})",
                "request": {"method": method, "url": url_shown, "utc": c.fmt_utc(now), "brt": c.fmt_brt(now),
                            "host": urllib.parse.urlsplit(url_shown).netloc, **extra},
                "http_status": status, "content_type": ctype, "bytes": len(body),
                "sha256": hashlib.sha256(body).hexdigest(), "body_file": os.path.basename(body_path)}
        with open(meta_path, "w", encoding="utf-8", newline="\n") as fh:
            json.dump(meta, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
        self.saved.append(meta_path)
        return meta_path

    def request(self, method, url, label, payload=None, redact_path=False, save=True) -> Response:
        shown = shown_url(url, redact_path)
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        headers = {"User-Agent": self.ua, "Accept": "application/json, text/plain;q=0.9"}
        if data is not None:
            headers["Content-Type"] = "application/json"
        extra = {}
        if payload is not None:
            extra["payload"] = payload
        status, body, ctype = 0, b"", ""
        for attempt in range(self.retries + 1):
            self._pace()
            req = urllib.request.Request(url, data=data, method=method, headers=headers)
            wait = 0.0
            try:
                with self.opener.open(req, timeout=self.timeout) as resp:
                    status, body, ctype = resp.status, resp.read(MAX_BODY + 1), resp.headers.get("Content-Type", "")
                self._last = time.monotonic()
                break
            except urllib.error.HTTPError as exc:
                self._last = time.monotonic()
                status = exc.code
                body = exc.read(1024) if hasattr(exc, "read") else b""
                if status == 429 or status >= 500:
                    ra = exc.headers.get("Retry-After") if exc.headers else None
                    wait = min(float(ra), 30.0) if ra and ra.isdigit() else float(2 ** attempt)
                else:
                    raise LiveError(f"HTTP {status} ao consultar {shown}") from None
                if attempt == self.retries:
                    raise LiveError(f"HTTP {status} ao consultar {shown} (após {attempt + 1} tentativas)") from None
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                self._last = time.monotonic()
                reason = getattr(exc, "reason", exc)
                wait = float(2 ** attempt)
                if attempt == self.retries:
                    raise LiveError(f"falha de rede ao consultar {shown}: {clean(reason)}") from None
            time.sleep(wait)
        if len(body) > MAX_BODY:
            raise LiveError("resposta excede 50 MB; consulta abortada")
        persist = (lambda: self._save(label, method, shown, extra, status, body, ctype))
        saved = persist() if save else None
        return Response(status, body, ctype, saved, persist)

    def rpc(self, url, method, params, label=None, save=True):
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        resp = self.request("POST", url, label or f"rpc-{method}", payload=payload, redact_path=True, save=save)
        obj = resp.json()
        if isinstance(obj, dict) and obj.get("error"):
            msg = obj["error"].get("message") if isinstance(obj["error"], dict) else obj["error"]
            raise LiveError(f"erro do nó em {method}: {clean(msg)}")
        return (obj or {}).get("result"), resp


# ----------------------------------------------------------------------------- validação


def _need_bitcoin_address(addr: str) -> str:
    r = V.classify(addr)
    ok = (r["kind"] == "address" and r["candidates"] and r["candidates"][0]["valid"]
          and r["candidates"][0]["family"] == "bitcoin")
    if not ok:
        raise LiveError(f"endereço Bitcoin inválido ou de outra rede ({clean(addr)}): {r['summary']}")
    return addr.strip()


def _need_evm_address(addr: str) -> str:
    r = V.classify(addr)
    ok = (r["kind"] == "address" and r["candidates"] and r["candidates"][0]["valid"]
          and r["candidates"][0]["family"] == "evm")
    if not ok:
        raise LiveError(f"endereço EVM inválido ({clean(addr)}): {r['summary']}")
    return addr.strip()


def _need_hex64(text: str, with_prefix: bool) -> str:
    t = text.strip().lower()
    body = t[2:] if t.startswith("0x") else t
    if len(body) != 64 or not re.fullmatch(r"[0-9a-f]{64}", body) or (with_prefix and not t.startswith("0x")):
        raise LiveError("hash inválido: esperado 64 caracteres hexadecimais" + (" com prefixo 0x" if with_prefix else ""))
    return ("0x" + body) if with_prefix else body


def _hexint(x):
    return int(x, 16) if isinstance(x, str) and x.startswith("0x") else (int(x) if x is not None else None)


def _eth(wei: int) -> str:
    return format(Decimal(wei) / Decimal(10 ** 18), "f")


def _emit(args, summary: dict, lines: list[str]) -> None:
    if args.json:
        print(json.dumps(summary, ensure_ascii=False, indent=2, default=str))
    else:
        print("\n".join(lines))


# ----------------------------------------------------------------------------- Bitcoin (Esplora)


def cmd_btc_tx(args, S: Session):
    txid = _need_hex64(args.txid, False)
    base = args.base_url.rstrip("/")
    host = check_url(base, "base-url").netloc
    S.banner(host, txid)
    tx = S.request("GET", f"{base}/tx/{txid}", "btc-tx").json()
    status = S.request("GET", f"{base}/tx/{txid}/status", "btc-tx-status").json()
    lines = [f"Transação Bitcoin {clean(txid)}", f"Fonte: {clean(host)}"]
    summary = {"txid": txid, "host": host, "status": status}
    conf = None
    if status.get("confirmed"):
        tip = int(S.request("GET", f"{base}/blocks/tip/height", "btc-tip").text().strip())
        conf = tip - int(status["block_height"]) + 1
        when = ""
        if status.get("block_time"):
            when = f" em {c.fmt_utc(status['block_time'])} / {c.fmt_brt(status['block_time'])}"
        lines.append(f"Status: CONFIRMADA no bloco {clean(status['block_height'])} ({clean(status.get('block_hash', ''))}){when}; "
                     f"confirmações: {conf}")
        if conf < 6:
            lines.append("AVISO: menos de 6 confirmações — para relatório formal/apreensão, aguarde e reverifique.")
    else:
        lines.append("Status: NÃO CONFIRMADA (mempool): pode ser substituída (RBF) ou cair; não use como definitiva.")
    lines.append(f"Taxa: {clean(tx.get('fee', '?'))} sats; entradas: {len(tx.get('vin', []))}; saídas: {len(tx.get('vout', []))}")
    summary["confirmations"] = conf
    if not args.no_decode:
        raw_hex = S.request("GET", f"{base}/tx/{txid}/hex", "btc-tx-hex").text().strip()
        dec = BTX.decode_tx(raw_hex)
        same = dec["txid"] == txid
        lines.append(f"Verificação local: txid recalculado a partir do hex {'CONFERE' if same else 'NÃO CONFERE (resposta inconsistente!)'}")
        lines.append("--- decodificação local (offline) ---")
        lines.append(BTX.render(dec))
        summary["decoded"] = dec
        summary["txid_matches_hex"] = same
    lines.append(f"Evidência bruta salva em: {S.out_dir} ({len(S.saved)} resposta(s) com SHA-256)")
    _emit(args, summary, lines)


def cmd_btc_addr(args, S: Session):
    addr = _need_bitcoin_address(args.address)
    base = args.base_url.rstrip("/")
    host = check_url(base, "base-url").netloc
    S.banner(host, addr)
    stats = S.request("GET", f"{base}/address/{addr}", "btc-addr").json()
    cs, ms = stats.get("chain_stats", {}), stats.get("mempool_stats", {})
    bal = cs.get("funded_txo_sum", 0) - cs.get("spent_txo_sum", 0)
    lines = [f"Endereço Bitcoin {clean(addr)}", f"Fonte: {clean(host)}",
             f"saldo confirmado: {bal} sats ({bal // 10**8}.{bal % 10**8:08d} BTC)",
             f"recebido total: {cs.get('funded_txo_sum', 0)} sats em {cs.get('funded_txo_count', 0)} saída(s); "
             f"gasto total: {cs.get('spent_txo_sum', 0)} sats em {cs.get('spent_txo_count', 0)} saída(s)",
             f"transações confirmadas: {cs.get('tx_count', 0)}; no mempool: {ms.get('tx_count', 0)}"]
    txs, page = [], S.request("GET", f"{base}/address/{addr}/txs", "btc-addr-txs-p1").json()
    txs.extend(page if isinstance(page, list) else [])
    for p in range(2, args.max_pages + 1):
        confirmed = [t for t in txs if (t.get("status") or {}).get("confirmed")]
        if not confirmed:
            break
        nxt = S.request("GET", f"{base}/address/{addr}/txs/chain/{confirmed[-1]['txid']}", f"btc-addr-txs-p{p}").json()
        if not nxt:
            break
        txs.extend(nxt)
    lines.append(f"Transações listadas ({len(txs)}; até {args.max_pages} página(s) — o investigador decide a próxima):")
    for t in txs:
        st = t.get("status") or {}
        when = f" · {c.fmt_utc(st['block_time'])}" if st.get("block_time") else ""
        where = f"bloco {clean(st.get('block_height'))}{when}" if st.get("confirmed") else "mempool"
        lines.append(f"  {clean(t.get('txid'))} · {where} · taxa {clean(t.get('fee', '?'))} · {len(t.get('vin', []))}→{len(t.get('vout', []))}")
    lines.append("Nota: a lista mostra transações, não o fluxo por saída: aplique as heurísticas de rastreamento e confira "
                 "cada TX (btc-tx).")
    lines.append(f"Evidência bruta salva em: {S.out_dir} ({len(S.saved)} resposta(s) com SHA-256)")
    _emit(args, {"address": addr, "host": host, "chain_stats": cs, "mempool_stats": ms, "tx_count_listed": len(txs),
                 "txids": [t.get("txid") for t in txs]}, lines)


# ----------------------------------------------------------------------------- EVM (JSON-RPC)


def _rpc_url(args) -> str:
    url = os.environ.get(args.rpc_env, "") if args.rpc_env else (args.rpc or "")
    if not url:
        raise Refusal("informe o endpoint do nó com --rpc URL ou --rpc-env VARIAVEL (a escolha do destino é deliberada)")
    check_url(url, "RPC")
    return url


def cmd_evm_tx(args, S: Session):
    h = _need_hex64(args.hash, True)
    url = _rpc_url(args)
    host = check_url(url, "RPC").netloc.split("@")[-1]
    S.banner(host, h)
    chain_hex, _ = S.rpc(url, "eth_chainId", [])
    chain_id = _hexint(chain_hex)
    tx, _ = S.rpc(url, "eth_getTransactionByHash", [h])
    if not tx:
        raise LiveError("Transação não encontrada neste endpoint/rede (confira a rede e se o nó indexa a transação)")
    receipt, _ = S.rpc(url, "eth_getTransactionReceipt", [h])
    tip_hex, _ = S.rpc(url, "eth_blockNumber", [])
    bn = _hexint(tx.get("blockNumber"))
    block = None
    if bn is not None:
        block, _ = S.rpc(url, "eth_getBlockByNumber", [tx["blockNumber"], False])
    to_kind = ""
    if tx.get("to"):
        code, _ = S.rpc(url, "eth_getCode", [tx["to"], "latest"])
        if code in ("0x", "0x0"):
            to_kind = "EOA (sem código)"
        elif isinstance(code, str) and code.lower().startswith("0xef0100"):
            to_kind = f"EOA com delegação EIP-7702 para 0x{code[8:48]}"
        elif isinstance(code, str):
            to_kind = "CONTRATO"
    lines = [f"Transação EVM {clean(h)}", f"Fonte: {clean(host)}",
             f"chainId: {chain_id} ({CHAINS.get(chain_id, 'rede não catalogada: confirme no chainlist')})"]
    conf = None
    if bn is not None:
        conf = _hexint(tip_hex) - bn + 1
        ts = _hexint((block or {}).get("timestamp"))
        when = f" · {c.fmt_utc(ts)} / {c.fmt_brt(ts)}" if ts else ""
        lines.append(f"Bloco: {bn}{when} · confirmações: {conf}")
        lines.append("Nota: confirmações ≠ finalidade; em L2/sidechains confira a liquidação em L1 e o status 'finalized'.")
    else:
        lines.append("Bloco: PENDENTE (ainda não incluída)")
    if receipt:
        lines.append(f"Resultado: {'SUCESSO' if _hexint(receipt.get('status')) == 1 else 'FALHA/REVERTIDA'}; gás usado: {_hexint(receipt.get('gasUsed'))}")
    val = _hexint(tx.get("value")) or 0
    lines += [f"De  : {clean(tx.get('from'))}", f"Para: {clean(tx.get('to'))} {('— ' + to_kind) if to_kind else ''}".rstrip(),
              f"Valor (moeda nativa): {val} wei ({_eth(val)} unidades)", f"Nonce: {_hexint(tx.get('nonce'))}"]
    if not tx.get("to") and receipt:
        lines.append(f"Criação de contrato: endereço criado {clean(receipt.get('contractAddress'))}")
    dec = EVM.decode_input(tx.get("input") or "0x")
    lines.append("--- input data (decodificação local) ---")
    lines.append(EVM._render_input(dec))
    logs = (receipt or {}).get("logs") or []
    decoded_logs = []
    lines.append(f"--- logs ({len(logs)}) ---")
    for lg in logs:
        try:
            d = EVM.decode_log(lg.get("topics", []), lg.get("data", "0x"))
        except ValueError as exc:
            d = {"event": None, "fields": {}, "notes": [str(exc)], "topic0": None}
        decoded_logs.append({"emitter": lg.get("address"), **d})
        lines.append(f"* emitido por {clean(lg.get('address'))} (confira se é o contrato do token correto)")
        lines.append("  " + EVM._render_log(d).replace("\n", "\n  "))
    lines.append(f"Evidência bruta salva em: {S.out_dir} ({len(S.saved)} resposta(s) com SHA-256)")
    _emit(args, {"hash": h, "chain_id": chain_id, "confirmations": conf, "tx": tx, "receipt": receipt,
                 "decoded_input": dec, "decoded_logs": decoded_logs}, lines)


# ----------------------------------------------------------------------------- Etherscan V2


def _write_csv(path, action, address, rows, native):
    addr = address.lower()
    out = io.StringIO()
    w = csv.writer(out, quoting=csv.QUOTE_ALL, lineterminator="\n")
    if action in ("txlist", "txlistinternal"):
        w.writerow(["Txhash", "UnixTimestamp", "DateTime (UTC)", "From", "To", f"Value_IN({native})",
                    f"Value_OUT({native})", "Status", "Method"])
        for r in rows:
            wei = int(r.get("value", "0") or 0)
            amount = format(Decimal(wei) / Decimal(10 ** 18), "f")
            to, frm = (r.get("to") or "").lower(), (r.get("from") or "").lower()
            vin = amount if to == addr and frm != addr else "0"
            vout = amount if frm == addr and to != addr else "0"
            bad = r.get("isError") not in (None, "", "0")
            w.writerow([r.get("hash"), r.get("timeStamp"), c.fmt_utc(int(r["timeStamp"]))[:19], frm, to, vin, vout,
                        "Error(1)" if bad else "", r.get("functionName") or r.get("methodId") or ""])
    else:
        w.writerow(["Txhash", "UnixTimestamp", "DateTime (UTC)", "From", "To", "TokenValue", "TokenSymbol", "ContractAddress"])
        for r in rows:
            dec = int(r.get("tokenDecimal") or 0)
            val = format(Decimal(int(r.get("value", "0") or 0)) / Decimal(10 ** dec), "f")
            w.writerow([r.get("hash"), r.get("timeStamp"), c.fmt_utc(int(r["timeStamp"]))[:19],
                        (r.get("from") or "").lower(), (r.get("to") or "").lower(), val, r.get("tokenSymbol", ""),
                        (r.get("contractAddress") or "").lower()])
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(out.getvalue())


def cmd_evm_txlist(args, S: Session):
    addr = _need_evm_address(args.address)
    base = args.base_url
    host = check_url(base, "base-url").netloc
    key = os.environ.get(args.key_env, "")
    if not key:
        raise Refusal(f"defina a variável de ambiente {args.key_env} com a sua chave de API (a chave nunca é aceita "
                      "por argumento nem gravada)")
    S.banner(host, f"{addr} (chainid {args.chainid})")
    rows, pages = [], 0
    for page in range(args.page, args.page + args.max_pages):
        q = {"chainid": args.chainid, "module": "account", "action": args.action, "address": addr,
             "startblock": args.start_block, "endblock": args.end_block, "page": page, "offset": args.offset,
             "sort": args.sort, "apikey": key}
        obj = S.request("GET", base + "?" + urllib.parse.urlencode(q), f"etherscan-{args.action}-p{page}").json()
        pages += 1
        res = obj.get("result")
        if str(obj.get("status")) != "1":
            if isinstance(res, list) or "no transactions" in str(obj.get("message", "")).lower():
                break
            raise LiveError(f"Etherscan retornou erro: {clean(res if isinstance(res, str) else obj.get('message'))}")
        rows.extend(res)
        if len(res) < args.offset:
            break
    lines = [f"Etherscan V2 · {args.action} · {clean(addr)} · chainid {args.chainid} ({CHAINS.get(args.chainid, 'rede não catalogada')})",
             f"Fonte: {clean(host)}", f"registros obtidos: {len(rows)} em {pages} página(s) (--max-pages {args.max_pages})"]
    if rows:
        ts = sorted(int(r["timeStamp"]) for r in rows if r.get("timeStamp"))
        lines.append(f"período: {c.fmt_utc(ts[0])} → {c.fmt_utc(ts[-1])}")
    lines.append("Limite do serviço: consultas retornam no máximo 10.000 registros; para históricos maiores, fatie por intervalo de blocos.")
    if args.csv_out:
        if args.action == "tokennfttx":
            lines.append("CSV não gerado para tokennfttx (use o JSON bruto).")
        else:
            _write_csv(args.csv_out, args.action, addr, rows, args.native_symbol)
            lines.append(f"CSV compatível com analyze_explorer_csv.py gravado em: {args.csv_out}")
    lines.append(f"Evidência bruta salva em: {S.out_dir} ({len(S.saved)} resposta(s) com SHA-256; a chave de API não é gravada)")
    _emit(args, {"address": addr, "action": args.action, "chainid": args.chainid, "rows": len(rows)}, lines)


# ----------------------------------------------------------------------------- monitor


def cmd_monitor(args, S: Session):
    if args.max_runs < 1:
        raise LiveError("--max-runs deve ser ≥ 1: o monitor é sempre limitado (nada de laço infinito)")
    if args.interval < MIN_INTERVAL:
        raise LiveError(f"intervalo mínimo: {MIN_INTERVAL} s (evita sobrecarregar serviços e gerar tráfego suspeito)")
    if args.kind == "btc":
        addr = _need_bitcoin_address(args.address)
        base = args.base_url.rstrip("/")
        host = check_url(base, "base-url").netloc
    else:
        addr = _need_evm_address(args.address)
        url = _rpc_url(args)
        host = check_url(url, "RPC").netloc.split("@")[-1]
    S.banner(host, addr)
    if args.kind == "evm":
        print("Limitação: o monitor EVM acompanha apenas saldo nativo e nonce; transferências de tokens "
              "(ERC-20/721/1155) não aparecem — use logs/explorer para tokens.")
    log_path = args.log or os.path.join(S.out_dir, "monitor.jsonl")
    os.makedirs(os.path.dirname(os.path.abspath(log_path)), exist_ok=True)

    def poll():
        if args.kind == "btc":
            resp = S.request("GET", f"{base}/address/{addr}", "mon-btc-addr", save=False)
            st = resp.json()
            cs, ms = st.get("chain_stats", {}), st.get("mempool_stats", {})
            snap = {"tx_count": cs.get("tx_count", 0), "mempool_tx_count": ms.get("tx_count", 0),
                    "funded_sum": cs.get("funded_txo_sum", 0), "spent_sum": cs.get("spent_txo_sum", 0),
                    "mempool_funded": ms.get("funded_txo_sum", 0), "mempool_spent": ms.get("spent_txo_sum", 0)}
            return snap, [resp]
        bal, r1 = S.rpc(url, "eth_getBalance", [addr, "latest"], "mon-evm-balance", save=False)
        nonce, r2 = S.rpc(url, "eth_getTransactionCount", [addr, "latest"], "mon-evm-nonce", save=False)
        return {"balance_wei": _hexint(bal), "nonce": _hexint(nonce)}, [r1, r2]

    prev, events = None, []

    def log(ev):
        ev.update({"utc": c.fmt_utc(time.time()), "brt": c.fmt_brt(time.time()), "address": addr, "kind": args.kind})
        events.append(ev)
        with open(log_path, "a", encoding="utf-8", newline="\n") as fh:
            fh.write(json.dumps(ev, ensure_ascii=False) + "\n")
        print(f"[{ev['utc']}] {ev['type'].upper()}: " + json.dumps({k: v for k, v in ev.items() if k in ('before', 'after', 'newest_txids')}, ensure_ascii=False))

    for run in range(args.max_runs):
        snap, resps = poll()
        if prev is None:
            for r in resps:
                r.persist()
            log({"type": "baseline", "after": snap})
        elif snap != prev:
            for r in resps:
                r.persist()
            ev = {"type": "mudanca", "before": prev, "after": snap}
            if args.kind == "btc":
                txs = S.request("GET", f"{base}/address/{addr}/txs", "mon-btc-txs").json()
                ev["newest_txids"] = [t.get("txid") for t in (txs if isinstance(txs, list) else [])[:5]]
            else:
                ev["nonce_increased"] = snap["nonce"] > prev["nonce"]
                ev["balance_delta_wei"] = snap["balance_wei"] - prev["balance_wei"]
            log(ev)
        prev = snap
        if run < args.max_runs - 1:
            time.sleep(args.interval)
    print(f"Monitoramento encerrado: {len(events)} evento(s) em {log_path}. Evidência bruta (baseline/mudanças) em {S.out_dir}.")


# ----------------------------------------------------------------------------- CLI


def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--confirm-disclosure", action="store_true",
                        help="OBRIGATÓRIO: confirma que você entende que o dado e o seu IP serão enviados ao destino")
    common.add_argument("--out", help="pasta da evidência bruta (padrão: evidencias-live/<UTC>)")
    common.add_argument("--delay", type=float, default=1.0, help="pausa entre requisições (s)")
    common.add_argument("--timeout", type=float, default=20.0)
    common.add_argument("--proxy", help="proxy HTTP(S) (ex.: túnel controlado)")
    common.add_argument("--user-agent", default=UA)
    common.add_argument("--json", action="store_true")
    ap = argparse.ArgumentParser(description="Consulta ao vivo (opt-in) a explorers/nós. Falha fechada sem --confirm-disclosure.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("btc-tx", parents=[common], help="transação Bitcoin (Esplora)")
    p.add_argument("txid")
    p.add_argument("--base-url", default=DEFAULT_ESPLORA)
    p.add_argument("--no-decode", action="store_true", help="não baixa/decodifica o hex")
    p.set_defaults(func=cmd_btc_tx)

    p = sub.add_parser("btc-addr", parents=[common], help="endereço Bitcoin (Esplora)")
    p.add_argument("address")
    p.add_argument("--base-url", default=DEFAULT_ESPLORA)
    p.add_argument("--max-pages", type=int, default=1)
    p.set_defaults(func=cmd_btc_addr)

    p = sub.add_parser("evm-tx", parents=[common], help="transação EVM via JSON-RPC")
    p.add_argument("hash")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--rpc", help="URL do nó (pode conter chave: não será impressa nem gravada)")
    g.add_argument("--rpc-env", help="nome da variável de ambiente que contém a URL do nó")
    p.set_defaults(func=cmd_evm_tx)

    p = sub.add_parser("evm-txlist", parents=[common], help="histórico via Etherscan API V2")
    p.add_argument("address")
    p.add_argument("--chainid", type=int, default=1)
    p.add_argument("--action", choices=["txlist", "txlistinternal", "tokentx", "tokennfttx"], default="txlist")
    p.add_argument("--base-url", default=DEFAULT_ETHERSCAN)
    p.add_argument("--key-env", default="ETHERSCAN_API_KEY")
    p.add_argument("--page", type=int, default=1)
    p.add_argument("--offset", type=int, default=100)
    p.add_argument("--sort", choices=["asc", "desc"], default="asc")
    p.add_argument("--start-block", type=int, default=0)
    p.add_argument("--end-block", type=int, default=99999999)
    p.add_argument("--max-pages", type=int, default=1)
    p.add_argument("--csv-out", help="grava CSV compatível com analyze_explorer_csv.py")
    p.add_argument("--native-symbol", default="ETH")
    p.set_defaults(func=cmd_evm_txlist)

    p = sub.add_parser("monitor", parents=[common], help="acompanha mudanças de um endereço (limitado)")
    p.add_argument("address")
    p.add_argument("--kind", choices=["btc", "evm"], required=True)
    p.add_argument("--base-url", default=DEFAULT_ESPLORA, help="Esplora (kind=btc)")
    p.add_argument("--rpc")
    p.add_argument("--rpc-env")
    p.add_argument("--interval", type=float, default=60.0)
    p.add_argument("--max-runs", type=int, default=20)
    p.add_argument("--log", help="arquivo JSONL de eventos")
    p.set_defaults(func=cmd_monitor)
    return ap


def main(argv=None) -> int:
    c.ensure_utf8()
    ap = build_parser()
    try:
        args = ap.parse_args(argv)
    except SystemExit as exc:
        return exc.code if isinstance(exc.code, int) else 2
    try:
        if not args.confirm_disclosure:
            raise Refusal("esta consulta ENVIARÁ o dado investigado e o seu IP a um serviço. Reexecute com "
                          "--confirm-disclosure se (e somente se) o investigador autorizou a divulgação; prefira nó/explorer próprio.")
        S = Session(args.out, args.delay, args.timeout, args.proxy, args.user_agent)
        args.func(args, S)
        return 0
    except Refusal as exc:
        print(f"Recusado: {exc}", file=sys.stderr)
        return 2
    except LiveError as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        return 1
    except ValueError as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("Interrompido pelo usuário.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
