"""Utilidades compartilhadas pelos scripts da skill (somente biblioteca padrão, sem rede).

Inclui: Keccak-256 (NÃO é o SHA3 do hashlib), RIPEMD-160, Base58/Base58Check, Bech32/Bech32m,
CashAddr, checksum EIP-55 e formatação de tempo (UTC e UTC-3).
"""
from __future__ import annotations

import datetime as _dt
import hashlib
import sys

VERSION = "4.0.0"

# --------------------------------------------------------------------------- console


def ensure_utf8() -> None:
    """Evita UnicodeEncodeError em consoles Windows (cp1252)."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
        except Exception:  # pragma: no cover
            pass


# --------------------------------------------------------------------------- hashes

_MASK64 = 0xFFFFFFFFFFFFFFFF
_KECCAK_RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000,
    0x000000000000808B, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
    0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003,
    0x8000000000008002, 0x8000000000000080, 0x000000000000800A, 0x800000008000000A,
    0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]
_KECCAK_ROT = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]


def _rol64(v: int, n: int) -> int:
    n %= 64
    if n == 0:
        return v
    return ((v << n) | (v >> (64 - n))) & _MASK64


def _keccak_f(a: list[int]) -> None:
    for rnd in range(24):
        c = [a[x] ^ a[x + 5] ^ a[x + 10] ^ a[x + 15] ^ a[x + 20] for x in range(5)]
        d = [c[(x - 1) % 5] ^ _rol64(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                a[x + 5 * y] ^= d[x]
        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5 * ((2 * x + 3 * y) % 5)] = _rol64(a[x + 5 * y], _KECCAK_ROT[x][y])
        for y in range(5):
            for x in range(5):
                a[x + 5 * y] = b[x + 5 * y] ^ ((~b[(x + 1) % 5 + 5 * y]) & b[(x + 2) % 5 + 5 * y])
        a[0] ^= _KECCAK_RC[rnd]


def _keccak(data: bytes, suffix: int, outlen: int, rate: int = 136) -> bytes:
    """Esponja Keccak. suffix=0x01 -> Keccak original (Ethereum); suffix=0x06 -> SHA3 (NIST)."""
    state = [0] * 25
    padded = bytearray(data)
    padded.append(suffix)
    while len(padded) % rate:
        padded.append(0)
    padded[-1] |= 0x80
    for off in range(0, len(padded), rate):
        block = padded[off:off + rate]
        for i in range(rate // 8):
            state[i] ^= int.from_bytes(block[8 * i:8 * i + 8], "little")
        _keccak_f(state)
    out = b"".join(state[i].to_bytes(8, "little") for i in range(rate // 8))
    return out[:outlen]


def keccak256(data: bytes) -> bytes:
    """Keccak-256 como usado pela Ethereum (difere do SHA3-256 do NIST no padding)."""
    return _keccak(bytes(data), 0x01, 32)


def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()


def double_sha256(data: bytes) -> bytes:
    return sha256(sha256(data))


_R1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
       7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11, 8,
       3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12,
       1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5, 6, 2,
       4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13]
_R2 = [5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12,
       6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1, 2,
       15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13,
       8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7, 10, 14,
       12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11]
_S1 = [11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8,
       7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7, 13, 12,
       11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5,
       11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5, 6, 8, 6, 5, 12,
       9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6]
_S2 = [8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6,
       9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15, 13, 11,
       9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5,
       15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12, 9, 12, 5, 15, 8,
       8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11]
_K1 = [0x00000000, 0x5A827999, 0x6ED9EBA1, 0x8F1BBCDC, 0xA953FD4E]
_K2 = [0x50A28BE6, 0x5C4DD124, 0x6D703EF3, 0x7A6D76E9, 0x00000000]
_M32 = 0xFFFFFFFF


def _rol32(v: int, n: int) -> int:
    return ((v << n) | (v >> (32 - n))) & _M32


def _rmd_f(j: int, x: int, y: int, z: int) -> int:
    if j < 16:
        return x ^ y ^ z
    if j < 32:
        return (x & y) | (~x & _M32 & z)
    if j < 48:
        return (x | (~y & _M32)) ^ z
    if j < 64:
        return (x & z) | (y & (~z & _M32))
    return x ^ (y | (~z & _M32))


def ripemd160(data: bytes) -> bytes:
    """RIPEMD-160 em Python puro (o OpenSSL 3 do Windows costuma não expor este algoritmo)."""
    msg = bytearray(data)
    bitlen = (len(msg) * 8) & 0xFFFFFFFFFFFFFFFF
    msg.append(0x80)
    while len(msg) % 64 != 56:
        msg.append(0)
    msg += bitlen.to_bytes(8, "little")
    h = [0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0]
    for off in range(0, len(msg), 64):
        x = [int.from_bytes(msg[off + 4 * i:off + 4 * i + 4], "little") for i in range(16)]
        a1, b1, c1, d1, e1 = h
        a2, b2, c2, d2, e2 = h
        for j in range(80):
            t = (_rol32((a1 + _rmd_f(j, b1, c1, d1) + x[_R1[j]] + _K1[j // 16]) & _M32, _S1[j]) + e1) & _M32
            a1, e1, d1, c1, b1 = e1, d1, _rol32(c1, 10), b1, t
            t = (_rol32((a2 + _rmd_f(79 - j, b2, c2, d2) + x[_R2[j]] + _K2[j // 16]) & _M32, _S2[j]) + e2) & _M32
            a2, e2, d2, c2, b2 = e2, d2, _rol32(c2, 10), b2, t
        t = (h[1] + c1 + d2) & _M32
        h[1] = (h[2] + d1 + e2) & _M32
        h[2] = (h[3] + e1 + a2) & _M32
        h[3] = (h[4] + a1 + b2) & _M32
        h[4] = (h[0] + b1 + c2) & _M32
        h[0] = t
    return b"".join(v.to_bytes(4, "little") for v in h)


def hash160(data: bytes) -> bytes:
    return ripemd160(sha256(data))


# --------------------------------------------------------------------------- Base58

B58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
XRP_ALPHABET = "rpshnaf39wBUDNEGHJKLM4PQRST7VWXYZ2bcdeCg65jkm8oFqi1tuvAxyz"


def b58encode(data: bytes, alphabet: str = B58_ALPHABET) -> str:
    n = int.from_bytes(data, "big")
    out = ""
    while n:
        n, r = divmod(n, 58)
        out = alphabet[r] + out
    pad = len(data) - len(data.lstrip(b"\x00"))
    return alphabet[0] * pad + out


def b58decode(text: str, alphabet: str = B58_ALPHABET) -> bytes:
    n = 0
    for ch in text:
        i = alphabet.find(ch)
        if i < 0:
            raise ValueError(f"caractere inválido para Base58: {ch!r}")
        n = n * 58 + i
    body = n.to_bytes((n.bit_length() + 7) // 8, "big") if n else b""
    pad = len(text) - len(text.lstrip(alphabet[0]))
    return b"\x00" * pad + body


def b58check_encode(payload: bytes, alphabet: str = B58_ALPHABET) -> str:
    return b58encode(payload + double_sha256(payload)[:4], alphabet)


def b58check_decode(text: str, alphabet: str = B58_ALPHABET) -> bytes:
    raw = b58decode(text, alphabet)
    if len(raw) < 5:
        raise ValueError("Base58Check curto demais")
    payload, chk = raw[:-4], raw[-4:]
    if double_sha256(payload)[:4] != chk:
        raise ValueError("checksum Base58Check inválido")
    return payload


# --------------------------------------------------------------------------- Bech32 / Bech32m

BECH32_CHARSET = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
_BECH32_CONST = {"bech32": 1, "bech32m": 0x2BC830A3}


def _bech32_polymod(values: list[int]) -> int:
    gen = [0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3]
    chk = 1
    for v in values:
        top = chk >> 25
        chk = ((chk & 0x1FFFFFF) << 5) ^ v
        for i in range(5):
            if (top >> i) & 1:
                chk ^= gen[i]
    return chk


def _bech32_hrp_expand(hrp: str) -> list[int]:
    return [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]


def bech32_encode(hrp: str, data: list[int], spec: str = "bech32") -> str:
    values = _bech32_hrp_expand(hrp) + list(data)
    polymod = _bech32_polymod(values + [0] * 6) ^ _BECH32_CONST[spec]
    checksum = [(polymod >> 5 * (5 - i)) & 31 for i in range(6)]
    return hrp + "1" + "".join(BECH32_CHARSET[d] for d in list(data) + checksum)


def bech32_decode(text: str) -> tuple[str, list[int], str]:
    """Retorna (hrp, dados5bits, spec) onde spec é 'bech32' ou 'bech32m'. Levanta ValueError se inválido."""
    if any(ord(x) < 33 or ord(x) > 126 for x in text):
        raise ValueError("caractere fora do intervalo ASCII imprimível")
    if text.lower() != text and text.upper() != text:
        raise ValueError("maiúsculas e minúsculas misturadas")
    text = text.lower()
    pos = text.rfind("1")
    if pos < 1 or pos + 7 > len(text) or len(text) > 90:
        raise ValueError("estrutura Bech32 inválida")
    if not all(x in BECH32_CHARSET for x in text[pos + 1:]):
        raise ValueError("caractere inválido na parte de dados")
    hrp = text[:pos]
    data = [BECH32_CHARSET.find(x) for x in text[pos + 1:]]
    const = _bech32_polymod(_bech32_hrp_expand(hrp) + data)
    spec = "bech32" if const == 1 else "bech32m" if const == _BECH32_CONST["bech32m"] else None
    if spec is None:
        raise ValueError("checksum Bech32 inválido")
    return hrp, data[:-6], spec


def convertbits(data, frombits: int, tobits: int, pad: bool = True) -> list[int]:
    acc = 0
    bits = 0
    ret: list[int] = []
    maxv = (1 << tobits) - 1
    max_acc = (1 << (frombits + tobits - 1)) - 1
    for value in data:
        if value < 0 or (value >> frombits):
            raise ValueError("valor fora da faixa")
        acc = ((acc << frombits) | value) & max_acc
        bits += frombits
        while bits >= tobits:
            bits -= tobits
            ret.append((acc >> bits) & maxv)
    if pad:
        if bits:
            ret.append((acc << (tobits - bits)) & maxv)
    elif bits >= frombits or ((acc << (tobits - bits)) & maxv):
        raise ValueError("preenchimento inválido")
    return ret


def segwit_decode(hrp: str, addr: str) -> tuple[int, bytes, str]:
    """Decodifica endereço SegWit/Taproot. Retorna (versão, programa, spec). Levanta ValueError se inválido."""
    got_hrp, data, spec = bech32_decode(addr)
    if got_hrp != hrp:
        raise ValueError(f"HRP inesperado: {got_hrp!r}")
    if not data:
        raise ValueError("sem dados")
    ver = data[0]
    if ver > 16:
        raise ValueError("versão de witness inválida")
    prog = bytes(convertbits(data[1:], 5, 8, False))
    if not 2 <= len(prog) <= 40:
        raise ValueError("tamanho de programa inválido")
    if ver == 0 and len(prog) not in (20, 32):
        raise ValueError("programa v0 deve ter 20 ou 32 bytes")
    if (ver == 0) != (spec == "bech32"):
        raise ValueError("constante de checksum não corresponde à versão (v0 = Bech32; v1+ = Bech32m)")
    return ver, prog, spec


def segwit_encode(hrp: str, ver: int, prog: bytes) -> str:
    spec = "bech32" if ver == 0 else "bech32m"
    addr = bech32_encode(hrp, [ver] + convertbits(prog, 8, 5, True), spec)
    segwit_decode(hrp, addr)
    return addr


# --------------------------------------------------------------------------- CashAddr (BCH)


def _cashaddr_polymod(values: list[int]) -> int:
    gen = [0x98F2BC8E61, 0x79B76D99E2, 0xF33E5FB3C4, 0xAE2EABE2A8, 0x1E4F43E470]
    c = 1
    for d in values:
        c0 = c >> 35
        c = ((c & 0x07FFFFFFFF) << 5) ^ d
        for i in range(5):
            if (c0 >> i) & 1:
                c ^= gen[i]
    return c ^ 1


def cashaddr_decode(addr: str, default_prefix: str = "bitcoincash") -> tuple[int, bytes]:
    """Retorna (tipo, hash). tipo 0 = P2PKH, 1 = P2SH. Levanta ValueError se inválido."""
    if addr.lower() != addr and addr.upper() != addr:
        raise ValueError("maiúsculas e minúsculas misturadas")
    addr = addr.lower()
    prefix, payload = addr.split(":", 1) if ":" in addr else (default_prefix, addr)
    if not payload or not all(ch in BECH32_CHARSET for ch in payload):
        raise ValueError("caractere inválido")
    data = [BECH32_CHARSET.find(ch) for ch in payload]
    if _cashaddr_polymod([ord(ch) & 31 for ch in prefix] + [0] + data) != 0:
        raise ValueError("checksum CashAddr inválido")
    raw = convertbits(data[:-8], 5, 8, False)
    version = raw[0]
    sizes = {0: 20, 1: 24, 2: 28, 3: 32, 4: 40, 5: 48, 6: 56, 7: 64}
    digest = bytes(raw[1:])
    if len(digest) != sizes[version & 7]:
        raise ValueError("tamanho de hash inconsistente com a versão")
    return (version >> 3) & 0x0F, digest


# --------------------------------------------------------------------------- EIP-55


def to_checksum_address(addr: str) -> str:
    """Converte um endereço EVM (40 hex, com ou sem 0x) para a forma com checksum EIP-55."""
    a = addr.lower()
    if a.startswith("0x"):
        a = a[2:]
    if len(a) != 40 or any(ch not in "0123456789abcdef" for ch in a):
        raise ValueError("endereço EVM deve ter 40 caracteres hexadecimais")
    h = keccak256(a.encode("ascii")).hex()
    return "0x" + "".join(ch.upper() if int(h[i], 16) >= 8 else ch for i, ch in enumerate(a))


# --------------------------------------------------------------------------- tempo

_BRT = _dt.timezone(_dt.timedelta(hours=-3))


def normalize_ts(ts: float) -> float:
    """Aceita segundos ou milissegundos (13 dígitos) e devolve segundos."""
    return ts / 1000 if ts > 1e11 else ts


def fmt_utc(ts: float) -> str:
    return _dt.datetime.fromtimestamp(ts, _dt.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def fmt_brt(ts: float) -> str:
    """UTC-3 fixo (horário de Brasília sem horário de verão; antes de 2019 pode ter havido UTC-2)."""
    return _dt.datetime.fromtimestamp(ts, _BRT).strftime("%Y-%m-%d %H:%M:%S") + " UTC-3"


def is_hex(text: str) -> bool:
    try:
        int(text, 16)
        return len(text) % 2 == 0 or True
    except ValueError:
        return False
