#!/usr/bin/env python3
"""Manifesto de evidências com SHA-256 (cadeia de custódia digital) — 100% offline.

Uso:
  python evidence_manifest.py create PASTA --case "IP 123/2026" --operator "Nome/matrícula" \
         [--note "texto"] [--out MANIFESTO.json] [--md MANIFESTO.md] [--include-host]
  python evidence_manifest.py verify MANIFESTO.json [--root PASTA] [--strict]

O manifesto lista cada arquivo (caminho relativo, tamanho, SHA-256, data de modificação), registra data/hora
(UTC e UTC-3), versão da ferramenta e um hash do próprio manifesto. Registre o hash do manifesto em local
independente (ex.: carimbo de tempo OpenTimestamps) para que alterações posteriores sejam detectáveis.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import sys
import time

import _common as c

MANIFEST_VERSION = "1"


def sha256_file(path: str, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


def _self_hash(m: dict) -> str:
    body = {k: v for k, v in m.items() if k != "manifest_sha256"}
    blob = json.dumps(body, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def _rel_files(root: str, exclude_abs: set[str]):
    out = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        dirnames.sort()
        for name in sorted(filenames):
            full = os.path.abspath(os.path.join(dirpath, name))
            if full in exclude_abs or os.path.islink(full):
                continue
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            out.append((rel, full))
    return sorted(out)


def build_manifest(root: str, case: str = "", operator: str = "", note: str = "", include_host: bool = False,
                   exclude: list[str] | None = None) -> dict:
    root = os.path.abspath(root)
    if not os.path.isdir(root):
        raise ValueError(f"pasta inexistente: {root}")
    excl = {os.path.abspath(p) for p in (exclude or [])}
    now = time.time()
    files = []
    for rel, full in _rel_files(root, excl):
        files.append({"path": rel, "size": os.path.getsize(full), "sha256": sha256_file(full),
                      "mtime_utc": c.fmt_utc(os.path.getmtime(full))})
    m = {
        "manifest_version": MANIFEST_VERSION,
        "tool": f"evidence_manifest.py (crypto-investigator {c.VERSION})",
        "case": case,
        "operator": operator,
        "note": note,
        "created_utc": c.fmt_utc(now),
        "created_brt": c.fmt_brt(now),
        "python": platform.python_version(),
        "platform": platform.platform(),
        "root_name": os.path.basename(root),
        "file_count": len(files),
        "files": files,
    }
    if include_host:
        m["host"] = platform.node()
    m["manifest_sha256"] = _self_hash(m)
    return m


def render_markdown(m: dict) -> str:
    L = ["# Manifesto de evidências", "",
         f"- Caso/Procedimento: {m.get('case') or '(não informado)'}",
         f"- Responsável pela coleta: {m.get('operator') or '(não informado)'}",
         f"- Gerado em: {m['created_utc']} / {m['created_brt']}",
         f"- Ferramenta: {m['tool']} · Python {m['python']} · {m['platform']}",
         f"- Pasta de origem: {m['root_name']} ({m['file_count']} arquivo(s))",
         f"- **Hash do manifesto (SHA-256):** `{m['manifest_sha256']}`"]
    if m.get("note"):
        L.append(f"- Observações: {m['note']}")
    L += ["", "| # | Arquivo | Tamanho (bytes) | SHA-256 | Modificado (UTC) |", "|---:|---|---:|---|---|"]
    for i, f in enumerate(m["files"], 1):
        L.append(f"| {i} | {f['path']} | {f['size']} | `{f['sha256']}` | {f['mtime_utc']} |")
    L += ["", "## Cadeia de custódia (preencher e assinar)", "",
          "```", "ARTEFATO(S): conforme tabela acima",
          "Origem: [URL completa / descrição da fonte]",
          "Data/hora da coleta: [AAAA-MM-DD HH:MM:SS UTC-3]",
          f"Coletor: {m.get('operator') or '[nome/matrícula]'}",
          "Dispositivo e ferramenta: [modelo/sistema; versão do navegador/explorer/script]",
          "Snapshot independente: [URL archive.today / Wayback / carimbo OpenTimestamps do hash do manifesto]",
          "Observações: [blocos confirmados na coleta; mempool; limitações]",
          "Assinatura do responsável: ______________________  Data: ____/____/______", "```", "",
          "> Orientação: registre o hash do manifesto em local independente; qualquer alteração em arquivo ou manifesto "
          "será detectada por `verify`. O manifesto documenta integridade, não substitui o laudo pericial."]
    return "\n".join(L) + "\n"


def write_manifest(m: dict, json_path: str, md_path: str | None = None) -> None:
    with open(json_path, "w", encoding="utf-8", newline="\n") as fh:
        json.dump(m, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    if md_path:
        with open(md_path, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(render_markdown(m))


def verify_manifest(manifest_path: str, root: str | None = None) -> dict:
    with open(manifest_path, encoding="utf-8") as fh:
        m = json.load(fh)
    root = os.path.abspath(root or os.path.dirname(os.path.abspath(manifest_path)))
    manifest_hash_ok = m.get("manifest_sha256") == _self_hash(m)
    files = []
    for f in m.get("files", []):
        p = os.path.join(root, *f["path"].split("/"))
        if not os.path.isfile(p):
            status = "ausente"
        else:
            status = "ok" if sha256_file(p) == f["sha256"] else "alterado"
        files.append({"path": f["path"], "status": status})
    listed = {f["path"] for f in m.get("files", [])}
    skip = {os.path.abspath(manifest_path), os.path.splitext(os.path.abspath(manifest_path))[0] + ".md"}
    extra = [rel for rel, full in _rel_files(root, skip) if rel not in listed]
    ok = manifest_hash_ok and all(f["status"] == "ok" for f in files)
    return {"ok": ok, "manifest_hash_ok": manifest_hash_ok, "files": files, "extra": extra,
            "case": m.get("case", ""), "created_utc": m.get("created_utc", "")}


def main(argv=None) -> int:
    c.ensure_utf8()
    ap = argparse.ArgumentParser(description="Manifesto SHA-256 de evidências (offline).")
    sub = ap.add_subparsers(dest="cmd", required=True)
    pc = sub.add_parser("create", help="cria o manifesto de uma pasta")
    pc.add_argument("folder")
    pc.add_argument("--case", default="")
    pc.add_argument("--operator", default="")
    pc.add_argument("--note", default="")
    pc.add_argument("--out", help="arquivo JSON de saída (padrão: PASTA/MANIFESTO.json)")
    pc.add_argument("--md", help="arquivo Markdown de saída (relatório de cadeia de custódia)")
    pc.add_argument("--include-host", action="store_true", help="registra o nome da máquina (opcional)")
    pv = sub.add_parser("verify", help="verifica o manifesto")
    pv.add_argument("manifest")
    pv.add_argument("--root")
    pv.add_argument("--strict", action="store_true", help="falha também se houver arquivos fora do manifesto")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "create":
            out_json = os.path.abspath(args.out or os.path.join(args.folder, "MANIFESTO.json"))
            out_md = os.path.abspath(args.md) if args.md else None
            m = build_manifest(args.folder, args.case, args.operator, args.note, args.include_host,
                               exclude=[p for p in (out_json, out_md) if p])
            write_manifest(m, out_json, out_md)
            print(f"Manifesto criado: {out_json} ({m['file_count']} arquivo(s))")
            print(f"Hash do manifesto (SHA-256): {m['manifest_sha256']}")
            print("Registre este hash em local independente (ex.: OpenTimestamps) e no relatório.")
            return 0
        res = verify_manifest(args.manifest, args.root)
    except (ValueError, OSError, KeyError, json.JSONDecodeError) as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        return 1
    label = {"ok": "OK       ", "alterado": "ALTERADO ", "ausente": "AUSENTE  "}
    for f in res["files"]:
        print(f"{label[f['status']]}{f['path']}")
    for e in res["extra"]:
        print(f"AVISO: arquivo fora do manifesto: {e}")
    if not res["manifest_hash_ok"]:
        print("ALERTA: o hash do próprio manifesto não confere (manifesto editado após a criação).")
    bad = (not res["ok"]) or (args.strict and res["extra"])
    print("RESULTADO: " + ("FALHA DE INTEGRIDADE" if bad else "ÍNTEGRO"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
