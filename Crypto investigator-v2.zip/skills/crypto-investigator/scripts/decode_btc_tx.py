#!/usr/bin/env python3
"""Decodifica uma transação Bitcoin bruta (hex) — legado, SegWit e Taproot — 100% offline.

Uso:
  python decode_btc_tx.py HEX [--network mainnet|testnet] [--json]
  python decode_btc_tx.py --file tx.hex
  echo HEX | python decode_btc_tx.py -

Mostra versão, entradas (txid/vout/nSequence/witness), saídas (tipo de script, endereço derivado, OP_RETURN),
nLockTime, tamanho/vsize/peso e sinalizadores úteis à análise (RBF, locktime, Taproot, micromensagem).
Os "indícios" de impressão digital de carteira são FRACOS: nunca são prova de autoria.
"""
from __future__ import annotations

import argparse
import json
import sys

import _common as c

_PRINTABLE = set(range(0x20, 0x7F))


class _Reader:
    def __init__(self, data: bytes):
        self.b = data
        self.i = 0

    def read(self, n: int) -> bytes:
        if n < 0 or self.i + n > len(self.b):
            raise ValueError("transação truncada ou malformada (leitura além do fim)")
        out = self.b[self.i:self.i + n]
        self.i += n
        return out

    def u8(self) -> int:
        return self.read(1)[0]

    def u32(self) -> int:
        return int.from_bytes(self.read(4), "little")

    def u64(self) -> int:
        return int.from_bytes(self.read(8), "little")

    def varint(self) -> int:
        n = self.u8()
        if n < 0xFD:
            return n
        if n == 0xFD:
            return int.from_bytes(self.read(2), "little")
        if n == 0xFE:
            return int.from_bytes(self.read(4), "little")
        return int.from_bytes(self.read(8), "little")

    def peek(self, n: int) -> bytes:
        return self.b[self.i:self.i + n]


def _clean_hex(text: str) -> bytes:
    t = "".join(text.split())
    if t.lower().startswith("0x"):
        t = t[2:]
    if not t or len(t) % 2:
        raise ValueError("hex vazio ou com número ímpar de caracteres")
    try:
        return bytes.fromhex(t)
    except ValueError as exc:
        raise ValueError("a entrada contém caracteres não hexadecimais") from exc


def _parse_pushes(script: bytes) -> list[bytes]:
    """Extrai os blocos de dados empurrados (push) de um script; opcodes OP_1..OP_16 viram 1 byte."""
    out: list[bytes] = []
    i = 0
    while i < len(script):
        op = script[i]
        i += 1
        if op == 0x00:
            out.append(b"")
        elif 0x01 <= op <= 0x4B:
            out.append(script[i:i + op])
            i += op
        elif op in (0x4C, 0x4D, 0x4E):
            size = {0x4C: 1, 0x4D: 2, 0x4E: 4}[op]
            ln = int.from_bytes(script[i:i + size], "little")
            i += size
            out.append(script[i:i + ln])
            i += ln
        elif 0x51 <= op <= 0x60:
            out.append(bytes([op - 0x50]))
        else:
            break
    return out


def _ascii_if_printable(data: bytes, min_ratio: float = 1.0):
    if not data:
        return None
    ok = sum(1 for b in data if b in _PRINTABLE or b in (9, 10, 13))
    if ok / len(data) >= min_ratio:
        return data.decode("latin-1")
    return None


def _addr(kind: str, digest: bytes, network: str) -> str | None:
    test = network == "testnet"
    if kind == "P2PKH":
        return c.b58check_encode(bytes([0x6F if test else 0x00]) + digest)
    if kind == "P2SH":
        return c.b58check_encode(bytes([0xC4 if test else 0x05]) + digest)
    hrp = "tb" if test else "bc"
    if kind == "P2WPKH" or kind == "P2WSH":
        return c.segwit_encode(hrp, 0, digest)
    if kind == "P2TR":
        return c.segwit_encode(hrp, 1, digest)
    return None


def classify_script(spk: bytes) -> tuple[str, bytes | None]:
    """Retorna (tipo, dado-chave) do scriptPubKey."""
    n = len(spk)
    if n == 25 and spk[:3] == b"\x76\xa9\x14" and spk[23:] == b"\x88\xac":
        return "P2PKH", spk[3:23]
    if n == 23 and spk[0] == 0xA9 and spk[1] == 0x14 and spk[22] == 0x87:
        return "P2SH", spk[2:22]
    if n == 22 and spk[:2] == b"\x00\x14":
        return "P2WPKH", spk[2:]
    if n == 34 and spk[:2] == b"\x00\x20":
        return "P2WSH", spk[2:]
    if n == 34 and spk[:2] == b"\x51\x20":
        return "P2TR", spk[2:]
    if n in (35, 67) and spk[-1] == 0xAC and spk[0] == n - 2:
        return "P2PK", spk[1:-1]
    if spk[:1] == b"\x6a":
        return "OP_RETURN", spk
    if 4 <= n <= 42 and (spk[0] == 0x00 or 0x51 <= spk[0] <= 0x60) and spk[1] == n - 2:
        ver = 0 if spk[0] == 0 else spk[0] - 0x50
        return f"witness v{ver}", spk[2:]
    if n >= 37 and 0x51 <= spk[0] <= 0x60 and spk[-1] == 0xAE and 0x51 <= spk[-2] <= 0x60:
        m, total = spk[0] - 0x50, spk[-2] - 0x50
        keys = _parse_pushes(spk[1:-2])
        if len(keys) == total and all(len(k) in (33, 65) for k in keys):
            return f"multisig-nu ({m}-de-{total})", None
    return "não padrão", None


def _op_return_info(spk: bytes) -> dict:
    pushes = [p for p in _parse_pushes(spk[1:]) if p]
    data = b"".join(pushes)
    info = {"op_return_hex": data.hex(), "op_return_text": _ascii_if_printable(data, 0.95)}
    notes = []
    if spk[1:2] == b"\x5d":
        notes.append("OP_RETURN seguido de OP_13: padrão de runestone (protocolo Runes) — decodifique com ferramenta própria")
    if data[:4] == b"omni":
        notes.append("prefixo 'omni': Omni Layer")
    prefix = bytes(data[:12])
    txt = _ascii_if_printable(prefix[:8], 1.0) if len(prefix) >= 4 else None
    if txt and not info["op_return_text"]:
        info["op_return_prefix"] = txt
        notes.append(f"prefixo textual '{txt}': possível protocolo/serviço de notarização (verifique o protocolo)")
    info["op_return_notes"] = notes
    return info


def _looks_like_control_block(item: bytes) -> bool:
    return len(item) >= 33 and (len(item) - 33) % 32 == 0 and (item[0] & 0xFE) == 0xC0


def _guess_input_type(script_sig: bytes, witness: list[bytes], coinbase: bool) -> str:
    if coinbase:
        return "coinbase"
    if witness:
        if not script_sig:
            if len(witness) == 2 and 70 <= len(witness[0]) <= 73 and len(witness[1]) == 33:
                return "P2WPKH (provável)"
            if len(witness) == 1 and len(witness[0]) in (64, 65):
                return "P2TR key-path (provável)"
            if len(witness) >= 2 and _looks_like_control_block(witness[-1]):
                return "P2TR script-path (provável)"
            return "P2WSH ou outro script de witness (provável; último item = witnessScript)"
        if len(script_sig) in (23, 35) and script_sig[0] in (22, 34):
            return "P2SH-P2WPKH ou P2SH-P2WSH (SegWit embrulhado; provável)"
        return "SegWit com scriptSig atípico"
    if not script_sig:
        return "scriptSig vazio"
    pushes = _parse_pushes(script_sig)
    if len(pushes) == 2 and 70 <= len(pushes[0]) <= 73 and len(pushes[1]) in (33, 65):
        return "P2PKH (provável)"
    if len(pushes) == 1 and 70 <= len(pushes[0]) <= 73:
        return "P2PK (provável)"
    if pushes and pushes[0] == b"" and len(pushes) >= 2:
        return "P2SH multisig (provável)"
    return "indeterminado (scriptSig)"


def decode_tx(raw_hex: str, network: str = "mainnet") -> dict:
    raw = _clean_hex(raw_hex)
    rd = _Reader(raw)
    version = rd.u32()
    segwit = rd.peek(2) == b"\x00\x01"
    if segwit:
        rd.read(2)
    body_start = rd.i
    n_in = rd.varint()
    if n_in == 0:
        raise ValueError("transação sem entradas (hex inválido ou formato não suportado)")
    inputs = []
    for _ in range(n_in):
        prev = rd.read(32)[::-1].hex()
        vout = rd.u32()
        script_sig = rd.read(rd.varint())
        seq = rd.u32()
        inputs.append({"txid": prev, "vout": vout, "script_sig": script_sig, "sequence": seq})
    n_out = rd.varint()
    outputs = []
    for _ in range(n_out):
        value = rd.u64()
        spk = rd.read(rd.varint())
        outputs.append({"value_sats": value, "spk": spk})
    body_end = rd.i
    if segwit:
        for inp in inputs:
            inp["witness"] = [rd.read(rd.varint()) for _ in range(rd.varint())]
    else:
        for inp in inputs:
            inp["witness"] = []
    locktime = rd.u32()
    if rd.i != len(raw):
        raise ValueError(f"{len(raw) - rd.i} byte(s) sobrando após o locktime (hex com lixo ou truncado em outro ponto)")

    legacy = raw[:4] + raw[body_start:body_end] + raw[-4:]
    txid = c.double_sha256(legacy)[::-1].hex()
    wtxid = c.double_sha256(raw)[::-1].hex() if segwit else txid
    weight = len(legacy) * 3 + len(raw)
    vsize = -(-weight // 4)

    coinbase = n_in == 1 and inputs[0]["txid"] == "00" * 32 and inputs[0]["vout"] == 0xFFFFFFFF
    out_inputs = []
    for inp in inputs:
        item = {
            "txid": inp["txid"],
            "vout": inp["vout"],
            "sequence": inp["sequence"],
            "sequence_hex": f"0x{inp['sequence']:08x}",
            "script_sig_hex": inp["script_sig"].hex(),
            "witness": [w.hex() for w in inp["witness"]],
            "type_guess": _guess_input_type(inp["script_sig"], inp["witness"], coinbase),
        }
        if coinbase:
            item["coinbase_text"] = "".join(chr(b) for b in inp["script_sig"] if b in _PRINTABLE)
        out_inputs.append(item)

    out_outputs = []
    chunks: list[str] = []
    for o in outputs:
        kind, key = classify_script(o["spk"])
        item = {
            "value_sats": o["value_sats"],
            "value_btc": f"{o['value_sats'] // 10**8}.{o['value_sats'] % 10**8:08d}",
            "script_hex": o["spk"].hex(),
            "type": kind,
            "address": None,
        }
        if kind in ("P2PKH", "P2SH", "P2WPKH", "P2WSH", "P2TR"):
            item["address"] = _addr(kind, key, network)
        elif kind == "P2PK":
            item["address"] = _addr("P2PKH", c.hash160(key), network)
            item["address_note"] = "derivado do hash160 da chave pública (P2PK não tem endereço nativo)"
            item["pubkey"] = key.hex()
        elif kind == "OP_RETURN":
            item.update(_op_return_info(o["spk"]))
        if kind in ("P2PKH", "P2SH") and o["value_sats"] <= 10_000:
            ascii_part = _ascii_if_printable(key, 0.85)
            if ascii_part:
                chunks.append(ascii_part)
        out_outputs.append(item)

    locktime_kind = "none" if locktime == 0 else "height" if locktime < 500_000_000 else "time"
    seqs = [i["sequence"] for i in out_inputs]
    flags = {
        "segwit": segwit,
        "coinbase": coinbase,
        "rbf_signaled": any(s < 0xFFFFFFFE for s in seqs),
        "locktime_kind": locktime_kind,
        "locktime_enforced": any(s != 0xFFFFFFFF for s in seqs) and locktime != 0,
        "relative_timelock_bip68": version >= 2 and any(not (s & 0x80000000) for s in seqs) and not coinbase,
        "op_return": any(o["type"] == "OP_RETURN" for o in out_outputs),
        "taproot_output": any(o["type"] == "P2TR" for o in out_outputs),
        "micromessage_suspect": bool(chunks),
        "output_types": sorted({o["type"] for o in out_outputs}),
    }
    result = {
        "txid": txid,
        "wtxid": wtxid,
        "version": version,
        "locktime": locktime,
        "size": len(raw),
        "vsize": vsize,
        "weight": weight,
        "inputs": out_inputs,
        "outputs": out_outputs,
        "total_output_sats": sum(o["value_sats"] for o in out_outputs),
        "flags": flags,
        "micromessage_text": "".join(chunks) if chunks else None,
        "network": network,
    }
    result["hints"] = _hints(result)
    return result


def _hints(r: dict) -> list[str]:
    f = r["flags"]
    h: list[str] = []
    if f["rbf_signaled"]:
        h.append("Sinaliza substituição (RBF, nSequence < 0xfffffffe): enquanto não confirmada, a transação pode ser "
                 "substituída; não use como definitiva.")
    if f["locktime_kind"] == "height":
        h.append("nLockTime na faixa de altura de bloco: típico de carteiras que aplicam proteção anti-fee-sniping "
                 "(várias, inclusive o Bitcoin Core); outras usam 0. Indício FRACO de software; não é prova de autoria.")
    elif f["locktime_kind"] == "time":
        h.append("nLockTime em formato de data/hora (≥ 500.000.000): incomum em pagamentos comuns; pode indicar "
                 "transação pré-assinada/contrato. Verifique se o locktime é de fato imposto (nSequence ≠ 0xffffffff).")
    if f["relative_timelock_bip68"]:
        h.append("Versão ≥ 2 com nSequence sem o bit de desativação: há timelock relativo (BIP68) em ao menos uma entrada.")
    if f["taproot_output"]:
        h.append("Saída Taproot (P2TR): gastos por key-path não distinguem chave única, multisig sem script (MuSig) e "
                 "demais casos; heurísticas baseadas em tipo de script perdem poder.")
    if len(f["output_types"]) > 1 and not f["op_return"]:
        h.append("Saídas de tipos diferentes: uma saída do mesmo tipo das entradas costuma ser o troco (heurística "
                 "FRACA; combine com valor, histórico e co-gasto posterior).")
    if f["op_return"]:
        h.append("Há saída OP_RETURN (dado embutido, não gastável): identifique o protocolo (Runes, Omni, notarização) "
                 "e decodifique o conteúdo.")
    if f["micromessage_suspect"]:
        h.append("Possível micromensagem: saídas de valor ínfimo cujos hashes de 20 bytes são texto ASCII. "
                 "Verifique o texto remontado e trate como indício.")
    if r["version"] == 1 and f["segwit"]:
        h.append("Versão 1 em transação SegWit: menos comum hoje que a versão 2; indício fraco de software.")
    h.append("Todos os indícios acima são impressões digitais de software e padrões de uso: não é prova de "
             "autoria nem de propriedade.")
    return h


def render(r: dict) -> str:
    f = r["flags"]
    lines = [
        f"TXID : {r['txid']}",
        f"WTXID: {r['wtxid']}",
        f"Versão: {r['version']} | nLockTime: {r['locktime']} ({f['locktime_kind']}) | "
        f"tamanho: {r['size']} B | vsize: {r['vsize']} vB | peso: {r['weight']} WU",
        f"Entradas ({len(r['inputs'])}):",
    ]
    for n, i in enumerate(r["inputs"]):
        extra = " [RBF]" if i["sequence"] < 0xFFFFFFFE else ""
        lines.append(f"  #{n} {i['txid']}:{i['vout']} seq={i['sequence_hex']}{extra} · {i['type_guess']}")
        if i.get("coinbase_text"):
            lines.append(f"      texto do coinbase: {i['coinbase_text']}")
    total = r["total_output_sats"]
    lines.append(f"Saídas ({len(r['outputs'])}) — total {total} sats ({total // 10**8}.{total % 10**8:08d} BTC):")
    for n, o in enumerate(r["outputs"]):
        addr = o["address"] or "-"
        lines.append(f"  #{n} {o['value_sats']} sats ({o['value_btc']} BTC) · {o['type']} · {addr}")
        if o.get("op_return_text"):
            lines.append(f"      OP_RETURN texto: {o['op_return_text']}")
        elif o.get("op_return_hex"):
            lines.append(f"      OP_RETURN hex: {o['op_return_hex']}")
        for note in o.get("op_return_notes", []):
            lines.append(f"      nota: {note}")
    if r["micromessage_text"]:
        lines.append(f"Micromensagem remontada (indício): {r['micromessage_text']}")
    lines.append("Indícios (fracos, não são prova):")
    lines.extend(f"  - {h}" for h in r["hints"])
    return "\n".join(lines)


def main(argv=None) -> int:
    c.ensure_utf8()
    ap = argparse.ArgumentParser(description="Decodifica transação Bitcoin bruta (offline).")
    ap.add_argument("hex", nargs="?", help="hex da transação; '-' lê da entrada padrão")
    ap.add_argument("--file", help="arquivo com o hex")
    ap.add_argument("--network", choices=["mainnet", "testnet"], default="mainnet")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    try:
        if args.file:
            with open(args.file, encoding="utf-8") as fh:
                text = fh.read()
        elif args.hex == "-":
            text = sys.stdin.read()
        elif args.hex:
            text = args.hex
        else:
            ap.print_usage(sys.stderr)
            return 1
        res = decode_tx(text, args.network)
    except (ValueError, OSError) as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(res, ensure_ascii=False, indent=2) if args.json else render(res))
    return 0


if __name__ == "__main__":
    sys.exit(main())
