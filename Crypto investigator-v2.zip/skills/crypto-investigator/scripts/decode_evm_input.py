#!/usr/bin/env python3
"""Decodifica `input data` (seletor + ABI) e logs de eventos de redes EVM — 100% offline.

Uso:
  python decode_evm_input.py input 0xa9059cbb000...           [--sig "foo(address,uint256)"] [--json]
  python decode_evm_input.py sig "transfer(address,uint256)"   (calcula seletor e hash de tópico)
  python decode_evm_input.py log --topic 0xddf2... --topic 0x... --data 0x... [--json]

Ponto crítico: em transferência de TOKEN o campo `to` da transação é o CONTRATO do token e o `value` é 0;
o destinatário real e a quantidade estão no input data (e no log Transfer).
"""
from __future__ import annotations

import argparse
import json
import re
import sys

import _common as c

MAX_ARRAY = 4096
MAX_UINT256 = (1 << 256) - 1

KNOWN_SIGNATURES = {
    "transfer(address,uint256)": "ERC-20: transfere tokens do remetente para o destinatário",
    "approve(address,uint256)": "ERC-20/ERC-721: concede allowance (ERC-20: quantidade; ERC-721: tokenId)",
    "transferFrom(address,address,uint256)": "ERC-20/ERC-721: move tokens de 'from' para 'to' usando allowance/aprovação",
    "balanceOf(address)": "ERC-20/721: consulta saldo (leitura)",
    "allowance(address,address)": "ERC-20: consulta allowance (leitura)",
    "totalSupply()": "ERC-20: oferta total (leitura)",
    "increaseAllowance(address,uint256)": "ERC-20 (extensão): aumenta allowance",
    "decreaseAllowance(address,uint256)": "ERC-20 (extensão): reduz allowance",
    "permit(address,address,uint256,uint256,uint8,bytes32,bytes32)": "EIP-2612: allowance por assinatura off-chain",
    "safeTransferFrom(address,address,uint256)": "ERC-721: transferência segura de NFT",
    "safeTransferFrom(address,address,uint256,bytes)": "ERC-721: transferência segura de NFT com dados",
    "setApprovalForAll(address,bool)": "ERC-721/1155: autoriza um operador sobre TODOS os tokens da coleção",
    "ownerOf(uint256)": "ERC-721: dono do tokenId (leitura)",
    "isApprovedForAll(address,address)": "ERC-721/1155: consulta aprovação total (leitura)",
    "safeTransferFrom(address,address,uint256,uint256,bytes)": "ERC-1155: transfere uma quantidade de um id",
    "safeBatchTransferFrom(address,address,uint256[],uint256[],bytes)": "ERC-1155: transferência em lote",
    "deposit()": "WETH-like: embrulha a moeda nativa (value da TX = quantidade)",
    "withdraw(uint256)": "WETH-like: desembrulha para a moeda nativa",
    "transferOwnership(address)": "Ownable: transfere a propriedade/administração do contrato",
    "renounceOwnership()": "Ownable: renuncia à propriedade do contrato",
    "multicall(bytes[])": "Multicall: executa várias chamadas em uma TX (roteadores, carteiras)",
    "multicall(uint256,bytes[])": "Multicall com prazo (roteadores Uniswap V3)",
    "aggregate3((address,bool,bytes)[])": "Multicall3: agrega chamadas a contratos diferentes",
    "swapExactTokensForTokens(uint256,uint256,address[],address,uint256)": "Uniswap V2: troca token por token (rota em address[])",
    "swapExactETHForTokens(uint256,address[],address,uint256)": "Uniswap V2: troca moeda nativa por token",
    "swapExactTokensForETH(uint256,uint256,address[],address,uint256)": "Uniswap V2: troca token por moeda nativa",
    "execute(bytes,bytes[],uint256)": "Universal Router: executa comandos codificados (swaps, permit2…) com prazo",
    "execute(bytes,bytes[])": "Universal Router: executa comandos codificados (swaps, permit2…)",
    "exactInputSingle((address,address,uint24,address,uint256,uint256,uint256,uint160))": "Uniswap V3: swap de entrada exata em um pool",
    "exactInput((bytes,address,uint256,uint256,uint256))": "Uniswap V3: swap de entrada exata por rota multi-pool",
    "approve(address,address,uint160,uint48)": "Permit2: allowance com validade (spender recebe poder sobre o token)",
    "execTransaction(address,uint256,bytes,uint8,uint256,uint256,uint256,address,address,bytes)": "Safe (multisig): executa a transação aprovada pelos donos",
    "deposit(uint256,address)": "ERC-4626 (vault): deposita ativos e emite cotas",
    "redeem(uint256,address,address)": "ERC-4626 (vault): resgata cotas por ativos",
}


def selector(signature: str) -> str:
    return "0x" + c.keccak256(signature.encode()).hex()[:8]


def topic(signature: str) -> str:
    return "0x" + c.keccak256(signature.encode()).hex()


SELECTOR_TABLE = {selector(sig): (sig, desc) for sig, desc in KNOWN_SIGNATURES.items()}

TOPIC_TRANSFER = topic("Transfer(address,address,uint256)")
TOPIC_APPROVAL = topic("Approval(address,address,uint256)")
TOPIC_APPROVAL_FOR_ALL = topic("ApprovalForAll(address,address,bool)")
TOPIC_TRANSFER_SINGLE = topic("TransferSingle(address,address,address,uint256,uint256)")
TOPIC_TRANSFER_BATCH = topic("TransferBatch(address,address,address,uint256[],uint256[])")
TOPIC_DEPOSIT = topic("Deposit(address,uint256)")
TOPIC_WITHDRAWAL = topic("Withdrawal(address,uint256)")


# ----------------------------------------------------------------------------- ABI


def _clean(text: str) -> bytes:
    t = "".join(text.split())
    if t.lower().startswith("0x"):
        t = t[2:]
    if len(t) % 2:
        raise ValueError("hex com número ímpar de caracteres")
    try:
        return bytes.fromhex(t)
    except ValueError as exc:
        raise ValueError("a entrada contém caracteres não hexadecimais") from exc


def _split_top(s: str) -> list[str]:
    parts: list[str] = []
    depth = 0
    cur = ""
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    if cur:
        parts.append(cur)
    return parts


def _params_of(signature: str) -> list[str]:
    lo, hi = signature.find("("), signature.rfind(")")
    if lo < 0 or hi < lo:
        raise ValueError(f"assinatura inválida: {signature!r}")
    return _split_top(signature[lo + 1:hi])


def _array_parts(t: str):
    m = re.match(r"^(.*)\[(\d*)\]$", t)
    if not m:
        return None
    return m.group(1), (int(m.group(2)) if m.group(2) else None)


def _is_dynamic(t: str) -> bool:
    if t in ("bytes", "string"):
        return True
    arr = _array_parts(t)
    if arr:
        base, n = arr
        return n is None or _is_dynamic(base)
    if t.startswith("("):
        return any(_is_dynamic(x) for x in _split_top(t[1:-1]))
    return False


def _slice(data: bytes, pos: int, n: int) -> bytes:
    if pos < 0 or n < 0 or pos + n > len(data):
        raise ValueError("dados ABI truncados ou offsets inconsistentes")
    return data[pos:pos + n]


def _word(data: bytes, pos: int) -> int:
    return int.from_bytes(_slice(data, pos, 32), "big")


def _scalar(t: str, w: bytes):
    if t == "address":
        return c.to_checksum_address(w[-20:].hex())
    if t == "bool":
        return int.from_bytes(w, "big") != 0
    m = re.fullmatch(r"(u?)int(\d*)", t)
    if m:
        v = int.from_bytes(w, "big")
        if not m.group(1) and v >= 1 << 255:
            v -= 1 << 256
        return v
    m = re.fullmatch(r"bytes(\d+)", t)
    if m and 1 <= int(m.group(1)) <= 32:
        return "0x" + w[:int(m.group(1))].hex()
    raise ValueError(f"tipo ABI não suportado: {t}")


def _decode_static(t: str, data: bytes, pos: int):
    arr = _array_parts(t)
    if arr:
        base, n = arr
        vals = []
        for _ in range(n or 0):
            v, pos = _decode_static(base, data, pos)
            vals.append(v)
        return vals, pos
    if t.startswith("("):
        vals = []
        for ct in _split_top(t[1:-1]):
            v, pos = _decode_static(ct, data, pos)
            vals.append(v)
        return vals, pos
    return _scalar(t, _slice(data, pos, 32)), pos + 32


def _decode_dynamic(t: str, data: bytes, at: int):
    if t in ("bytes", "string"):
        ln = _word(data, at)
        body = _slice(data, at + 32, ln)
        return "0x" + body.hex() if t == "bytes" else body.decode("utf-8", errors="replace")
    arr = _array_parts(t)
    if arr:
        base, n = arr
        if n is None:
            n = _word(data, at)
            at += 32
            if n > MAX_ARRAY or n * 32 > len(data):
                raise ValueError("tamanho de array improvável ou hostil")
        return _decode_seq([base] * n, data, at)
    if t.startswith("("):
        return _decode_seq(_split_top(t[1:-1]), data, at)
    raise ValueError(f"tipo ABI não suportado: {t}")


def _decode_seq(types: list[str], data: bytes, base: int) -> list:
    out = []
    pos = base
    for t in types:
        if _is_dynamic(t):
            out.append(_decode_dynamic(t, data, base + _word(data, pos)))
            pos += 32
        else:
            v, pos = _decode_static(t, data, pos)
            out.append(v)
    return out


def decode_abi(types: list[str], data: bytes) -> list:
    """Decodifica argumentos ABI. Suporta address, bool, (u)intN, bytesN, bytes, string, T[], T[N] e tuplas."""
    return _decode_seq(list(types), bytes(data), 0)


# ----------------------------------------------------------------------------- input data


def _word_hint(w: bytes) -> str:
    if int.from_bytes(w, "big") == 0:
        return "zero"
    if w[:12] == b"\x00" * 12:
        return f"possivelmente endereço: {c.to_checksum_address(w[-20:].hex())}"
    n = int.from_bytes(w, "big")
    if n < 1 << 64:
        return f"possivelmente número: {n}"
    return "dado de 32 bytes (hash, valor grande ou dado empacotado)"


def _notes_for(sig: str, args: list[dict]) -> list[str]:
    notes: list[str] = []
    name = sig.split("(")[0]
    if sig in ("transfer(address,uint256)", "transferFrom(address,address,uint256)"):
        notes.append("Em transferência de token, o campo 'to' da transação é o contrato do token (e o 'value' da TX é 0): "
                     "o destinatário real e a quantidade estão nos argumentos. A quantidade vem na menor unidade do "
                     "token (consulte os decimais do contrato).")
    if sig == "transferFrom(address,address,uint256)":
        notes.append("Quem envia a TX (gastador) pode ser diferente do titular ('from'): identifique ambos.")
    if sig in ("approve(address,uint256)", "increaseAllowance(address,uint256)") and args[1]["value"] == MAX_UINT256:
        notes.append("Allowance ilimitada (valor máximo): o gastador pode mover todo o saldo do token a qualquer momento; "
                     "alto risco se o gastador for malicioso ou comprometido.")
    if sig == "approve(address,uint256)":
        notes.append("Se o contrato for ERC-721, o 2º argumento é o tokenId, não uma quantidade.")
    if sig == "setApprovalForAll(address,bool)" and args[1]["value"] is True:
        notes.append("Autoriza o operador a mover TODOS os tokens da coleção do titular: padrão recorrente em phishing "
                     "de NFTs; confira quem é o operador.")
    if name == "permit" or sig.startswith("approve(address,address,uint160"):
        notes.append("Autorização por assinatura/allowance com validade (permit/Permit2): pode ser submetida por terceiro; "
                     "verifique spender, valor e prazo — padrão comum em drainers.")
    if sig == "transferOwnership(address)":
        notes.append("Troca de dono/administrador do contrato: pode indicar ocultação do criador original ou tomada de controle.")
    return notes


def decode_input(data_hex: str, extra_sigs: list[str] | None = None) -> dict:
    raw = _clean(data_hex)
    res = {"selector": None, "known": False, "function": None, "description": None, "args": [], "raw_words": [],
           "notes": []}
    if not raw:
        res["notes"].append("Sem input data: transferência simples de moeda nativa (ou chamada à função receive/fallback "
                            "de um contrato).")
        return res
    if len(raw) < 4:
        raise ValueError("input data curto demais para conter um seletor de 4 bytes")
    if raw[:5] in (bytes.fromhex("6080604052"), bytes.fromhex("6060604052")):
        res["notes"].append("O dado parece bytecode de criação de contrato (compilador solc): se o campo 'to' estiver vazio, "
                            "é implantação; o endereço do contrato deriva de (implantador, nonce).")
        return res
    sel = "0x" + raw[:4].hex()
    res["selector"] = sel
    table = dict(SELECTOR_TABLE)
    for s in extra_sigs or []:
        table[selector(s)] = (s, "assinatura informada pelo usuário")
    body = raw[4:]
    if sel in table:
        sig, desc = table[sel]
        res["known"], res["function"], res["description"] = True, sig, desc
        types = _params_of(sig)
        try:
            vals = decode_abi(types, body)
            res["args"] = [{"type": t, "value": v} for t, v in zip(types, vals)]
            res["notes"].extend(_notes_for(sig, res["args"]))
            return res
        except ValueError as exc:
            res["decode_error"] = str(exc)
            res["notes"].append(f"Seletor reconhecido, mas os argumentos não puderam ser decodificados: {exc}")
    else:
        res["notes"].append("Seletor desconhecido: consulte bases públicas de assinaturas (ex.: 4byte/OpenChain) ou o ABI "
                            "do contrato verificado no explorer; as palavras abaixo são uma leitura heurística.")
    for i in range(0, len(body), 32):
        w = body[i:i + 32].ljust(32, b"\x00")
        res["raw_words"].append({"index": i // 32, "hex": "0x" + w.hex(), "hint": _word_hint(w)})
    return res


# ----------------------------------------------------------------------------- logs


def _topic_addr(t: str) -> str:
    return c.to_checksum_address(t[-40:])


def decode_log(topics: list[str], data_hex: str) -> dict:
    if not topics:
        raise ValueError("log sem tópicos (evento anônimo): não é possível identificar o evento")
    tp = [t.lower() for t in topics]
    data = _clean(data_hex)
    t0, n = tp[0], len(tp)
    res = {"topic0": t0, "event": None, "fields": {}, "notes": []}
    try:
        if t0 == TOPIC_TRANSFER and n == 3 and len(data) == 32:
            res["event"] = "Transfer (ERC-20)"
            res["fields"] = {"from": _topic_addr(tp[1]), "to": _topic_addr(tp[2]), "value": int.from_bytes(data, "big")}
        elif t0 == TOPIC_TRANSFER and n == 4 and not data:
            res["event"] = "Transfer (ERC-721)"
            res["fields"] = {"from": _topic_addr(tp[1]), "to": _topic_addr(tp[2]), "tokenId": int(tp[3], 16)}
        elif t0 == TOPIC_APPROVAL and n == 3 and len(data) == 32:
            res["event"] = "Approval (ERC-20)"
            val = int.from_bytes(data, "big")
            res["fields"] = {"owner": _topic_addr(tp[1]), "spender": _topic_addr(tp[2]), "value": val}
            if val == MAX_UINT256:
                res["notes"].append("Allowance ilimitada (valor máximo).")
        elif t0 == TOPIC_APPROVAL and n == 4 and not data:
            res["event"] = "Approval (ERC-721)"
            res["fields"] = {"owner": _topic_addr(tp[1]), "approved": _topic_addr(tp[2]), "tokenId": int(tp[3], 16)}
        elif t0 == TOPIC_APPROVAL_FOR_ALL and n == 3 and len(data) == 32:
            res["event"] = "ApprovalForAll (ERC-721/1155)"
            res["fields"] = {"owner": _topic_addr(tp[1]), "operator": _topic_addr(tp[2]),
                             "approved": int.from_bytes(data, "big") != 0}
        elif t0 == TOPIC_TRANSFER_SINGLE and n == 4 and len(data) == 64:
            res["event"] = "TransferSingle (ERC-1155)"
            res["fields"] = {"operator": _topic_addr(tp[1]), "from": _topic_addr(tp[2]), "to": _topic_addr(tp[3]),
                             "id": int.from_bytes(data[:32], "big"), "value": int.from_bytes(data[32:], "big")}
        elif t0 == TOPIC_TRANSFER_BATCH and n == 4:
            ids, values = decode_abi(["uint256[]", "uint256[]"], data)
            res["event"] = "TransferBatch (ERC-1155)"
            res["fields"] = {"operator": _topic_addr(tp[1]), "from": _topic_addr(tp[2]), "to": _topic_addr(tp[3]),
                             "ids": ids, "values": values}
        elif t0 in (TOPIC_DEPOSIT, TOPIC_WITHDRAWAL) and n == 2 and len(data) == 32:
            res["event"] = "Deposit (WETH-like)" if t0 == TOPIC_DEPOSIT else "Withdrawal (WETH-like)"
            res["fields"] = {"account": _topic_addr(tp[1]), "value": int.from_bytes(data, "big")}
    except ValueError as exc:
        res["event"] = None
        res["notes"].append(f"Falha ao decodificar o evento: {exc}")
    if res["event"] is None:
        res["notes"].append("Evento desconhecido ou formato inesperado: consulte o ABI do contrato verificado ou bases "
                            "públicas de assinaturas de eventos.")
    elif res["event"].startswith("Transfer"):
        res["notes"].append("A aba 'Token Transfers' dos explorers é derivada destes logs: o contrato que emitiu o log "
                            "(endereço do log) identifica o token — confira o endereço, não apenas o símbolo.")
    return res


# ----------------------------------------------------------------------------- CLI


def _render_input(r: dict) -> str:
    lines = [f"Seletor: {r['selector'] or '-'}"]
    if r["function"]:
        lines.append(f"Função : {r['function']} — {r['description']}")
    for i, a in enumerate(r["args"]):
        lines.append(f"  [{i}] {a['type']} = {a['value']}")
    for w in r["raw_words"]:
        lines.append(f"  palavra {w['index']}: {w['hex']}  ({w['hint']})")
    lines.extend(f"Nota: {n}" for n in r["notes"])
    return "\n".join(lines)


def _render_log(r: dict) -> str:
    lines = [f"Evento: {r['event'] or 'desconhecido'} (topic0 {r['topic0']})"]
    lines.extend(f"  {k} = {v}" for k, v in r["fields"].items())
    lines.extend(f"Nota: {n}" for n in r["notes"])
    return "\n".join(lines)


def main(argv=None) -> int:
    c.ensure_utf8()
    ap = argparse.ArgumentParser(description="Decodifica input data e logs EVM (offline).")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p_in = sub.add_parser("input", help="decodifica o input data de uma transação")
    p_in.add_argument("data")
    p_in.add_argument("--sig", action="append", default=[], help="assinatura candidata, ex.: foo(address,uint256)")
    p_in.add_argument("--json", action="store_true")
    p_sig = sub.add_parser("sig", help="calcula seletor (4 bytes) e hash de tópico de uma assinatura")
    p_sig.add_argument("signature")
    p_log = sub.add_parser("log", help="decodifica um log de evento")
    p_log.add_argument("--topic", action="append", default=[], required=True)
    p_log.add_argument("--data", default="0x")
    p_log.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    try:
        if args.cmd == "input":
            r = decode_input(args.data, args.sig)
            print(json.dumps(r, ensure_ascii=False, indent=2) if args.json else _render_input(r))
        elif args.cmd == "sig":
            print(f"Seletor (4 bytes): {selector(args.signature)}")
            print(f"Hash/tópico (32 bytes): {topic(args.signature)}")
        else:
            r = decode_log(args.topic, args.data)
            print(json.dumps(r, ensure_ascii=False, indent=2) if args.json else _render_log(r))
    except ValueError as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
