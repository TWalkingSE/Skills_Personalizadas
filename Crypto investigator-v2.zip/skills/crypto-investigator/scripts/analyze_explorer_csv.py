#!/usr/bin/env python3
"""Analisa o CSV exportado de um explorer (Etherscan-like, Blockchair, transferências de token) — 100% offline.

Uso:
  python analyze_explorer_csv.py exportacao.csv [--address 0x...] [--json] [--top 20]

Gera: resumo e totais por ativo, contrapartes, histograma por hora (UTC), estimativa INDICATIVA de fuso,
e padrões (sweep, fan-in/fan-out, poeira/envenenamento, ida-e-volta). Os resultados são INDÍCIOS de padrão de uso:
não são prova de autoria, localização ou propriedade.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import io
import json
import math
import re
import sys
from collections import Counter, defaultdict
from decimal import Decimal, InvalidOperation

import _common as c

REGION_HINTS = {
    -8: "costa oeste da América do Norte", -7: "oeste dos EUA/Canadá", -6: "América Central/centro dos EUA",
    -5: "costa leste dos EUA/Canadá, Colômbia, Peru", -4: "Venezuela, Bolívia, Atlântico (Canadá)",
    -3: "Brasil (Brasília), Argentina, Uruguai", 0: "Reino Unido, Portugal, África Ocidental",
    1: "Europa Central, Nigéria", 2: "Europa Oriental, África do Sul, Egito", 3: "Moscou, Turquia, Leste da África, Arábia",
    4: "Golfo Pérsico", 5: "Paquistão/Ásia Central", 7: "Sudeste Asiático (Tailândia, Vietnã)",
    8: "China, Singapura, Hong Kong, Filipinas", 9: "Japão, Coreia do Sul", 10: "leste da Austrália",
}


# ----------------------------------------------------------------------------- parsing


def _dec(text) -> Decimal:
    t = (text or "").strip().replace(" ", "")
    if not t:
        return Decimal(0)
    if "," in t and "." in t:
        t = t.replace(",", "")
    elif "," in t:
        t = t.replace(",", ".")
    try:
        return Decimal(t)
    except InvalidOperation:
        return Decimal(0)


def _parse_dt(text: str):
    t = (text or "").strip().replace("UTC", "").replace("Z", "").strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%m/%d/%Y %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return dt.datetime.strptime(t, fmt).replace(tzinfo=dt.timezone.utc).timestamp()
        except ValueError:
            continue
    return None


def _find(headers: dict, *names: str):
    for n in names:
        if n in headers:
            return headers[n]
    return None


def _find_prefix(headers: dict, prefix: str, exclude: str = ""):
    for low, orig in headers.items():
        if low.startswith(prefix) and (not exclude or exclude not in low):
            return orig, low
    return None, None


def parse_csv(text: str):
    """Converte o CSV em linhas normalizadas. Retorna (linhas, meta). Levanta ValueError se não reconhecer."""
    text = text.lstrip("\ufeff")
    first = text.split("\n", 1)[0]
    delim = max((",", ";", "\t"), key=first.count)
    reader = csv.DictReader(io.StringIO(text), delimiter=delim)
    if not reader.fieldnames:
        raise ValueError("CSV vazio")
    headers = {h.strip().lower(): h for h in reader.fieldnames if h}
    h_hash = _find(headers, "txhash", "transaction hash", "hash", "tx_hash", "tx hash")
    h_unix = _find(headers, "unixtimestamp", "timestamp", "timestamp(unix)")
    h_dt = _find(headers, "datetime (utc)", "datetime", "date (utc)", "date", "time")
    h_from = _find(headers, "from")
    h_to = _find(headers, "to")
    h_vin, low_vin = _find_prefix(headers, "value_in")
    h_vout, _ = _find_prefix(headers, "value_out")
    h_tok = _find(headers, "tokenvalue", "value", "amount")
    h_sym = _find(headers, "tokensymbol", "tokenname", "symbol")
    h_bal = _find(headers, "balance_change")
    h_fee, _ = _find_prefix(headers, "txnfee(", exclude="usd")
    h_status = _find(headers, "status", "txreceipt_status")
    h_method = _find(headers, "method")
    if not h_hash or not (h_unix or h_dt):
        raise ValueError("colunas não reconhecidas: esperado hash e data/timestamp (formatos Etherscan, Blockchair ou transferências de token)")
    if h_bal:
        fmt, asset_default = "blockchair", "BTC"
    elif h_vin and h_vout:
        m = re.search(r"\(([^)]+)\)", low_vin or "")
        fmt, asset_default = "explorer-txs", (m.group(1).upper() if m else "NATIVO")
    elif h_tok and h_from and h_to:
        fmt, asset_default = "token-transfers", "TOKEN"
    else:
        raise ValueError("colunas de valor não reconhecidas (esperado Value_IN/Value_OUT, TokenValue ou balance_change)")
    rows = []
    for rec in reader:
        ts = None
        if h_unix and (rec.get(h_unix) or "").strip():
            try:
                ts = c.normalize_ts(float(rec[h_unix]))
            except ValueError:
                ts = None
        if ts is None and h_dt:
            ts = _parse_dt(rec.get(h_dt, ""))
        if ts is None:
            continue
        row = {
            "hash": (rec.get(h_hash) or "").strip(),
            "ts": ts,
            "from": ((rec.get(h_from) or "").strip().lower() if h_from else ""),
            "to": ((rec.get(h_to) or "").strip().lower() if h_to else ""),
            "in_amt": None,
            "out_amt": None,
            "amount": None,
            "asset": asset_default,
            "status": (rec.get(h_status) or "").strip() if h_status else "",
            "method": (rec.get(h_method) or "").strip() if h_method else "",
            "fee": _dec(rec.get(h_fee)) if h_fee else None,
            "signed_dir": None,
        }
        if fmt == "explorer-txs":
            row["in_amt"], row["out_amt"] = _dec(rec.get(h_vin)), _dec(rec.get(h_vout))
            row["amount"] = row["in_amt"] + row["out_amt"]
        elif fmt == "blockchair":
            v = _dec(rec.get(h_bal)) / Decimal(10**8)
            row["signed_dir"] = "in" if v >= 0 else "out"
            row["in_amt"], row["out_amt"] = (v, Decimal(0)) if v >= 0 else (Decimal(0), -v)
            row["amount"] = abs(v)
        else:
            row["amount"] = _dec(rec.get(h_tok))
            if h_sym and (rec.get(h_sym) or "").strip():
                row["asset"] = rec[h_sym].strip().upper()
        rows.append(row)
    if not rows:
        raise ValueError("nenhuma linha válida (verifique datas/timestamps)")
    return rows, {"format": fmt, "asset_default": asset_default}


def infer_subject(rows):
    """Infere o endereço-alvo: primeiro pelo sentido (Value_IN -> To; Value_OUT -> From); depois por frequência,
    exigindo maioria clara e sem empate. Retorna None se houver ambiguidade (use --address)."""
    votes = Counter()
    for r in rows:
        if r["in_amt"] and r["in_amt"] > 0 and r["to"]:
            votes[r["to"]] += 1
        if r["out_amt"] and r["out_amt"] > 0 and r["from"]:
            votes[r["from"]] += 1
    top = votes.most_common(2)
    if top and (len(top) == 1 or top[0][1] > top[1][1]):
        return top[0][0]
    cnt = Counter()
    for r in rows:
        for a in {r["from"], r["to"]} - {""}:
            cnt[a] += 1
    top = cnt.most_common(2)
    if top and (len(top) == 1 or top[0][1] > top[1][1]) and top[0][1] / len(rows) >= 0.8:
        return top[0][0]
    return None


# ----------------------------------------------------------------------------- análises


def estimate_utc_offset(timestamps, min_events: int = 30, window_hours: int = 8) -> dict:
    """Estimativa INDICATIVA de fuso a partir da janela de menor atividade (assume ~03:00 local no centro do 'sono')."""
    n = len(timestamps)
    hours = [0] * 24
    for ts in timestamps:
        hours[int(ts // 3600) % 24] += 1
    res = {"n": n, "enough": n >= min_events, "offset": None, "confidence": "insuficiente", "hourly_utc": hours,
           "quiet_window_utc": None, "region_hint": None, "note": ""}
    if n < min_events:
        res["note"] = f"amostra insuficiente (<{min_events} eventos): não inferir fuso."
        return res
    sums = [sum(hours[(s + k) % 24] for k in range(window_hours)) for s in range(24)]
    m = min(sums)
    avg = n * window_hours / 24
    contrast = 1 - m / avg if avg else 0
    if contrast < 0.6:
        res["confidence"] = "inconclusivo"
        res["note"] = ("atividade distribuída ao longo das 24h: padrão 24/7 sugere automação, vários operadores ou "
                       "rotina irregular — não inferir fuso.")
        return res
    starts = [s for s in range(24) if sums[s] == m]
    sx = sum(math.cos(2 * math.pi * s / 24) for s in starts)
    sy = sum(math.sin(2 * math.pi * s / 24) for s in starts)
    mean_start = (math.atan2(sy, sx) * 24 / (2 * math.pi)) % 24
    center_utc = (mean_start + window_hours / 2) % 24
    off = round(3 - center_utc)
    off = ((off + 12) % 24) - 12
    res.update(offset=off, confidence="indicativa", quiet_window_utc=[int(mean_start) % 24, int(mean_start + window_hours) % 24],
               region_hint=REGION_HINTS.get(off))
    res["note"] = ("estimativa baseada na janela de menor atividade; hora do bloco ≠ hora em que o usuário agiu "
                   "(TX pode ser preparada offline; bots e rotinas noturnas distorcem). Use só como pista.")
    return res


def _direction(r, subject):
    if r["signed_dir"]:
        return r["signed_dir"]
    if subject:
        if r["to"] == subject and r["from"] != subject:
            return "in"
        if r["from"] == subject and r["to"] != subject:
            return "out"
        if r["from"] == subject == r["to"]:
            return "self"
    if r["in_amt"] and r["in_amt"] > 0:
        return "in"
    if r["out_amt"] and r["out_amt"] > 0:
        return "out"
    return "?"


def _legit_key(addr: str):
    a = addr[2:] if addr.startswith("0x") else addr
    return a[:4], a[-4:]


def analyze(rows, subject=None, sweep_minutes=60, sweep_ratio=0.9, fan_k=5, fan_window_min=10,
            dust=Decimal("0.00001"), tz_min_events=30, top=20) -> dict:
    subject = (subject or infer_subject(rows) or "")
    subject = subject.lower() or None
    warnings = []
    if not subject:
        warnings.append("Endereço-alvo não identificado: direção inferida pelas colunas de valor; contrapartes podem ficar incompletas.")
    events = []
    for r in sorted(rows, key=lambda x: x["ts"]):
        d = _direction(r, subject)
        other = r["to"] if d == "out" else r["from"] if d == "in" else ""
        events.append({**r, "dir": d, "other": other})
    n_failed = sum(1 for e in events if re.search(r"error|fail", e["status"], re.I))
    if n_failed:
        warnings.append(f"{n_failed} transação(ões) com status de erro/falha: não movimentaram valor, mas indicam tentativas.")

    by_asset = defaultdict(lambda: {"in": Decimal(0), "out": Decimal(0)})
    days = set()
    for e in events:
        days.add(dt.datetime.fromtimestamp(e["ts"], dt.timezone.utc).date())
        if e["dir"] == "in":
            by_asset[e["asset"]]["in"] += e["amount"]
        elif e["dir"] == "out":
            by_asset[e["asset"]]["out"] += e["amount"]
    for v in by_asset.values():
        v["net"] = v["in"] - v["out"]
    first, last = events[0]["ts"], events[-1]["ts"]
    summary = {
        "n": len(events),
        "n_in": sum(1 for e in events if e["dir"] == "in"),
        "n_out": sum(1 for e in events if e["dir"] == "out"),
        "n_self": sum(1 for e in events if e["dir"] == "self"),
        "n_unknown_dir": sum(1 for e in events if e["dir"] == "?"),
        "n_failed": n_failed,
        "first_ts": first, "last_ts": last,
        "first_utc": c.fmt_utc(first), "last_utc": c.fmt_utc(last),
        "span_days": round((last - first) / 86400, 2),
        "active_days": len(days),
        "by_asset": {k: dict(v) for k, v in by_asset.items()},
    }

    cps: dict[str, dict] = {}
    for e in events:
        if not e["other"] or e["dir"] not in ("in", "out"):
            continue
        cp = cps.setdefault(e["other"], {"address": e["other"], "n_in": 0, "n_out": 0, "by_asset": {}, "first_ts": e["ts"], "last_ts": e["ts"]})
        cp["n_in" if e["dir"] == "in" else "n_out"] += 1
        ba = cp["by_asset"].setdefault(e["asset"], {"in": Decimal(0), "out": Decimal(0)})
        ba[e["dir"]] += e["amount"]
        cp["last_ts"] = e["ts"]
    main_asset = max(by_asset, key=lambda a: by_asset[a]["in"] + by_asset[a]["out"]) if by_asset else None
    def _vol(cp):
        b = cp["by_asset"].get(main_asset, {"in": Decimal(0), "out": Decimal(0)})
        return b["in"] + b["out"]
    counterparties = sorted(cps.values(), key=lambda x: (_vol(x), x["n_in"] + x["n_out"]), reverse=True)[:top]

    hourly = [0] * 24
    out_ts = []
    for e in events:
        hourly[int(e["ts"] // 3600) % 24] += 1
        if e["dir"] == "out":
            out_ts.append(e["ts"])
    tz_source = "saídas (iniciadas pelo alvo)" if len(out_ts) >= tz_min_events else "todos os eventos"
    tz = estimate_utc_offset(out_ts if len(out_ts) >= tz_min_events else [e["ts"] for e in events], tz_min_events)
    tz["source"] = tz_source

    # sweeps: entrada seguida de saída do mesmo ativo em ≤ sweep_minutes com ≥ sweep_ratio do valor
    sweeps, used = [], set()
    for i, e in enumerate(events):
        if e["dir"] != "in" or e["amount"] <= 0:
            continue
        for j in range(i + 1, len(events)):
            f = events[j]
            if f["ts"] - e["ts"] > sweep_minutes * 60:
                break
            if f["dir"] == "out" and f["asset"] == e["asset"] and j not in used and f["amount"] >= Decimal(str(sweep_ratio)) * e["amount"]:
                used.add(j)
                sweeps.append({"in_hash": e["hash"], "out_hash": f["hash"], "minutes": round((f["ts"] - e["ts"]) / 60),
                               "in_amount": e["amount"], "out_amount": f["amount"], "asset": e["asset"], "to": f["other"]})
                break

    def fan(direction):
        sel = [e for e in events if e["dir"] == direction and e["other"]]
        out, i = [], 0
        while i < len(sel):
            j = i
            while j + 1 < len(sel) and sel[j + 1]["ts"] - sel[i]["ts"] <= fan_window_min * 60:
                j += 1
            window = sel[i:j + 1]
            distinct = {e["other"] for e in window}
            if len(distinct) >= fan_k:
                out.append({"start_utc": c.fmt_utc(window[0]["ts"]), "end_utc": c.fmt_utc(window[-1]["ts"]),
                            "distinct": len(distinct), "n": len(window)})
                i = j + 1
            else:
                i += 1
        return out

    dust_map: dict[str, dict] = {}
    for e in events:
        if e["dir"] == "in" and e["amount"] <= dust and e["other"]:
            d = dust_map.setdefault(e["other"], {"from": e["other"], "n": 0, "amount_max": Decimal(0), "first_hash": e["hash"]})
            d["n"] += 1
            d["amount_max"] = max(d["amount_max"], e["amount"])
    significant = {a for e in events if e["other"] and e["amount"] > dust for a in [e["other"]]}
    poisoning = []
    for p in dust_map:
        pk = _legit_key(p)
        for legit in sorted(significant):
            if legit != p and len(p) == len(legit) and _legit_key(legit) == pk:
                poisoning.append({"poison": p, "lookalike_of": legit, "common_prefix_suffix": f"{pk[0]}…{pk[1]}",
                                  "first_hash": dust_map[p]["first_hash"]})

    round_trips = []
    for cp in cps.values():
        for asset, v in cp["by_asset"].items():
            if v["in"] > 0 and v["out"] > 0 and abs(v["in"] - v["out"]) / max(v["in"], v["out"]) <= Decimal("0.05"):
                round_trips.append({"address": cp["address"], "asset": asset, "in": v["in"], "out": v["out"],
                                    "n_in": cp["n_in"], "n_out": cp["n_out"]})

    return {
        "subject": subject, "warnings": warnings, "summary": summary, "counterparties": counterparties,
        "hourly_utc": hourly, "timezone": tz, "sweeps": sweeps, "fan_out": fan("out"), "fan_in": fan("in"),
        "dust_in": list(dust_map.values()), "poisoning_suspects": poisoning, "round_trips": round_trips,
        "params": {"sweep_minutes": sweep_minutes, "sweep_ratio": sweep_ratio, "fan_k": fan_k,
                   "fan_window_min": fan_window_min, "dust": str(dust), "tz_min_events": tz_min_events},
    }


# ----------------------------------------------------------------------------- saída


def _jsonable(o):
    if isinstance(o, Decimal):
        return format(o, "f")
    if isinstance(o, dict):
        return {k: _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    return o


def render_markdown(res: dict, top: int = 20) -> str:
    s = res["summary"]
    L = ["# Análise do CSV de explorer", "", "## Resumo", ""]
    L.append(f"- Endereço-alvo: `{res['subject'] or 'não identificado'}`")
    L.append(f"- Eventos: {s['n']} (entradas {s['n_in']}, saídas {s['n_out']}, próprias {s['n_self']}, "
             f"direção indeterminada {s['n_unknown_dir']}, com erro {s['n_failed']})")
    L.append(f"- Período: {s['first_utc']} → {s['last_utc']} ({s['span_days']} dias; {s['active_days']} dias com atividade)")
    L += ["", "| Ativo | Entradas | Saídas | Saldo líquido do período |", "|---|---:|---:|---:|"]
    for a, v in s["by_asset"].items():
        L.append(f"| {a} | {format(v['in'], 'f')} | {format(v['out'], 'f')} | {format(v['net'], 'f')} |")
    L += ["", f"## Contrapartes (top {top})", ""]
    if res["counterparties"]:
        L += ["| Endereço | Entradas | Saídas | Volume por ativo (in/out) | Primeira | Última |", "|---|---:|---:|---|---|---|"]
        for cp in res["counterparties"][:top]:
            vols = "; ".join(f"{a}: {format(v['in'], 'f')}/{format(v['out'], 'f')}" for a, v in cp["by_asset"].items())
            L.append(f"| `{cp['address']}` | {cp['n_in']} | {cp['n_out']} | {vols} | {c.fmt_utc(cp['first_ts'])} | {c.fmt_utc(cp['last_ts'])} |")
    else:
        L.append("Sem contrapartes identificáveis neste formato de exportação.")
    L += ["", "## Distribuição por hora (UTC)", "", "| Hora UTC | " + " | ".join(f"{h:02d}" for h in range(24)) + " |",
          "|---|" + "---:|" * 24, "| Eventos | " + " | ".join(str(x) for x in res["hourly_utc"]) + " |"]
    tz = res["timezone"]
    L += ["", "## Estimativa de fuso (indicativa)", ""]
    if tz["offset"] is None:
        L.append(f"- Resultado: **{tz['confidence']}** — {tz['note']}")
    else:
        sign = "+" if tz["offset"] >= 0 else "−"
        L.append(f"- Fuso compatível: **UTC{sign}{abs(tz['offset'])}** (confiança: {tz['confidence']}; base: {tz['source']}, n={tz['n']}).")
        if tz.get("region_hint"):
            L.append(f"- Regiões compatíveis (apenas ilustrativo): {tz['region_hint']}.")
        L.append(f"- Observação: {tz['note']}")
    L += ["", "## Padrões detectados", ""]
    L.append(f"**Sweeps** (entrada seguida de saída ≥ {int(res['params']['sweep_ratio'] * 100)}% em ≤ {res['params']['sweep_minutes']} min): {len(res['sweeps'])}")
    for x in res["sweeps"][:top]:
        L.append(f"- {x['minutes']} min: entrada `{x['in_hash'][:12]}…` ({format(x['in_amount'], 'f')} {x['asset']}) → saída `{x['out_hash'][:12]}…` ({format(x['out_amount'], 'f')}) para `{x['to']}`")
    L.append(f"\n**Fan-out** (≥ {res['params']['fan_k']} destinatários distintos em ≤ {res['params']['fan_window_min']} min): {len(res['fan_out'])}")
    for x in res["fan_out"][:top]:
        L.append(f"- {x['start_utc']} → {x['end_utc']}: {x['distinct']} destinatários em {x['n']} transações")
    L.append(f"\n**Fan-in** (≥ {res['params']['fan_k']} remetentes distintos em ≤ {res['params']['fan_window_min']} min): {len(res['fan_in'])}")
    for x in res["fan_in"][:top]:
        L.append(f"- {x['start_utc']} → {x['end_utc']}: {x['distinct']} remetentes em {x['n']} transações")
    L.append(f"\n**Poeira/valor zero recebido**: {len(res['dust_in'])} remetente(s)")
    for x in res["dust_in"][:top]:
        L.append(f"- `{x['from']}` ({x['n']}x; máx. {format(x['amount_max'], 'f')})")
    L.append(f"\n**Suspeitas de envenenamento de endereço (lookalike)**: {len(res['poisoning_suspects'])}")
    for x in res["poisoning_suspects"]:
        L.append(f"- `{x['poison']}` imita `{x['lookalike_of']}` (mesmo início/fim {x['common_prefix_suffix']}) — não copie endereços do histórico")
    L.append(f"\n**Ida-e-volta** (entrada ≈ saída com a mesma contraparte): {len(res['round_trips'])}")
    for x in res["round_trips"][:top]:
        L.append(f"- `{x['address']}`: {format(x['in'], 'f')} in / {format(x['out'], 'f')} out ({x['asset']})")
    L += ["", "## Limitações", "",
          "- Estes resultados são indícios de padrão de uso: **não é prova** de autoria, localização ou propriedade.",
          "- Horários são os do bloco (UTC); a transação pode ter sido assinada antes. Valores em fiat devem usar a cotação da data de cada transação.",
          "- Contrapartes podem ser contratos, exchanges (carteiras compartilhadas) ou serviços; identifique-as antes de concluir."]
    for w in res["warnings"]:
        L.append(f"- Aviso: {w}")
    return "\n".join(L) + "\n"


def main(argv=None) -> int:
    c.ensure_utf8()
    ap = argparse.ArgumentParser(description="Analisa CSV de explorer (offline).")
    ap.add_argument("csv_file")
    ap.add_argument("--address", help="endereço-alvo (se a inferência automática falhar)")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--top", type=int, default=20)
    ap.add_argument("--asset", help="força o nome do ativo (ex.: BTC)")
    ap.add_argument("--sweep-minutes", type=int, default=60)
    ap.add_argument("--fan-k", type=int, default=5)
    ap.add_argument("--tz-min-events", type=int, default=30)
    args = ap.parse_args(argv)
    try:
        with open(args.csv_file, encoding="utf-8-sig", newline="") as fh:
            text = fh.read()
        rows, meta = parse_csv(text)
        if args.asset:
            for r in rows:
                r["asset"] = args.asset.upper()
        res = analyze(rows, subject=args.address, sweep_minutes=args.sweep_minutes, fan_k=args.fan_k,
                      tz_min_events=args.tz_min_events, top=args.top)
    except (ValueError, OSError) as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(_jsonable(res), ensure_ascii=False, indent=2))
    else:
        print(render_markdown(res, args.top))
    return 0


if __name__ == "__main__":
    sys.exit(main())
