#!/usr/bin/env python3
"""Valida e classifica endereços, hashes e nomes de criptoativos (100% offline).

Uso:
  python validate_address.py ENDERECO [ENDERECO ...] [--json]
  python validate_address.py --compare ENDERECO_A ENDERECO_B       (alerta de envenenamento/lookalike)
  python validate_address.py --stdin < lista.txt

Códigos de saída: 0 = tudo válido; 1 = algum inválido/desconhecido ou lookalike; 2 = o texto parece
segredo (chave privada/seed) — o valor NUNCA é repetido na saída.
"""
from __future__ import annotations

import argparse
import json
import re
import sys

import _common as c

_B58_RE = re.compile(r"^[1-9A-HJ-NP-Za-km-z]+$")
_HEX_RE = re.compile(r"^[0-9a-fA-F]*$")
_EVM_NETWORK_NOTE = (
    "O formato 0x… é idêntico em dezenas de redes EVM (Ethereum, BSC, Polygon, Arbitrum, Base, Optimism, "
    "Avalanche C-Chain…): confirme a rede antes de analisar."
)
_BURN = {
    "0x" + "0" * 40: "Endereço zero (0x0): usado como destino de criação de contrato e de queima/erro; não é carteira.",
    "0x000000000000000000000000000000000000dead": "Endereço de queima convencional (0x…dEaD): fundos ali são irrecuperáveis.",
}
_XPRV_VERSIONS = {bytes.fromhex(v) for v in ("0488ade4", "049d7878", "04b2430c", "04358394", "044a4e28", "045f18bc")}
_XPUB_VERSIONS = {
    bytes.fromhex("0488b21e"): "xpub (BIP32; legado/P2PKH)",
    bytes.fromhex("049d7cb2"): "ypub (BIP49; P2SH-P2WPKH)",
    bytes.fromhex("04b24746"): "zpub (BIP84; P2WPKH nativo)",
    bytes.fromhex("043587cf"): "tpub (testnet)",
    bytes.fromhex("044a5262"): "upub (testnet BIP49)",
    bytes.fromhex("045f1cf6"): "vpub (testnet BIP84)",
}
_BASE58_V = {
    0x00: ("bitcoin", "P2PKH (Base58Check, prefixo 1…)", "mainnet",
           ["Mesmo formato em forks (Bitcoin Cash legado, BSV): confirme a rede."]),
    0x05: ("bitcoin", "P2SH (Base58Check, prefixo 3…; pode ser multisig ou SegWit embrulhado)", "mainnet",
           ["Mesmo formato em forks (Bitcoin Cash legado): confirme a rede."]),
    0x6F: ("bitcoin", "P2PKH (testnet)", "testnet", []),
    0xC4: ("bitcoin", "P2SH (testnet)", "testnet", []),
    0x30: ("litecoin", "P2PKH (Base58Check, prefixo L…)", "mainnet", []),
    0x32: ("litecoin", "P2SH (Base58Check, prefixo M…)", "mainnet", []),
    0x1E: ("dogecoin", "P2PKH (Base58Check, prefixo D…)", "mainnet", []),
    0x16: ("dogecoin", "P2SH (Base58Check, prefixo 9…/A…)", "mainnet", []),
    0x4C: ("dash", "P2PKH (Base58Check, prefixo X…)", "mainnet", []),
    0x10: ("dash", "P2SH (Base58Check, prefixo 7…)", "mainnet", []),
    0x41: ("tron", "Tron (Base58Check, prefixo T…, 34 caracteres)", "mainnet",
           ["USDT-TRC20 e demais TRC-20 usam este mesmo formato de endereço."]),
}
_SEGWIT_HRP = {
    "bc": ("bitcoin", "mainnet"),
    "tb": ("bitcoin", "testnet/signet"),
    "bcrt": ("bitcoin", "regtest"),
    "ltc": ("litecoin", "mainnet"),
    "tltc": ("litecoin", "testnet"),
}
_NAME_RE = re.compile(
    r"^[a-z0-9\-_.]+\.(eth|sol|near|bnb|arb|crypto|nft|x|wallet|bitcoin|dao|zil|blockchain|kred|888|coin)$"
)
_TON_RE = re.compile(r"^(EQ|UQ|kQ|0Q)[A-Za-z0-9_\-]{46}$")


def _cand(family, fmt, network="mainnet", valid=True, checksum="ok", detail="", notes=None):
    return {
        "family": family,
        "format": fmt,
        "network": network,
        "valid": valid,
        "checksum": checksum,
        "detail": detail,
        "notes": list(notes or []),
    }


def _result(text):
    return {"input": text, "kind": "unknown", "candidates": [], "warnings": [], "summary": ""}


# ----------------------------------------------------------------------------- segredos


def _secret_type(t: str):
    words = t.split()
    if len(words) in (12, 15, 18, 21, 24) and all(re.fullmatch(r"[a-z]{3,8}", w) for w in words):
        return "uma frase de recuperação (seed) de carteira"
    if t.startswith(("xprv", "yprv", "zprv", "tprv")) and len(t) >= 100:
        return "uma chave privada estendida (xprv/zprv…)"
    if _B58_RE.match(t) and 40 <= len(t) <= 120:
        try:
            p = c.b58check_decode(t)
        except ValueError:
            return None
        if p[0] in (0x80, 0xEF) and len(p) in (33, 34):
            return "uma chave privada no formato WIF"
        if len(p) == 78 and p[:4] in _XPRV_VERSIONS:
            return "uma chave privada estendida (xprv/zprv…)"
        if len(p) == 39 and p[:2] in (b"\x01\x42", b"\x01\x43"):
            return "uma chave privada criptografada (BIP38)"
    return None


def _secret_result(desc: str):
    r = _result("[omitido: material sensível]")
    r["kind"] = "secret_like"
    r["warnings"].append(
        f"O texto informado parece {desc}. NÃO cole segredos em ferramentas, chats ou relatórios. "
        "Interrompa a análise, trate o material como sensível sob cadeia de custódia e acione o perito/autoridade "
        "competente. Trabalhe apenas com endereços PÚBLICOS."
    )
    r["summary"] = "SEGREDO — valor omitido por segurança"
    return r


# ----------------------------------------------------------------------------- EVM


def _classify_evm(t: str, r: dict) -> None:
    body = t[2:]
    if not _HEX_RE.match(body):
        r["kind"] = "unknown"
        r["candidates"].append(_cand("evm", "0x + caracteres não hexadecimais", valid=False, checksum="n/a",
                                     detail="contém caracteres que não são hexadecimais"))
        r["warnings"].append("Entrada começa com 0x mas contém caracteres não hexadecimais.")
        return
    n = len(body)
    if n == 64:
        r["kind"] = "tx_hash"
        r["candidates"].append(_cand(
            "evm", "hash de transação ou de bloco EVM (32 bytes)", network="n/a", checksum="n/a",
            notes=["Não é um endereço (endereço EVM tem 40 hex). Use a busca do explorer e teste as redes candidatas: "
                   "o hash só existe na rede onde a transação ocorreu."]))
        return
    r["kind"] = "address"
    if n != 40:
        r["candidates"].append(_cand("evm", "endereço EVM", network="n/a", valid=False, checksum="n/a",
                                     detail=f"tamanho {n} hex; endereço = 40, hash = 64"))
        r["warnings"].append(f"Tamanho inválido: {n} caracteres hex após 0x (endereço = 40; hash de transação = 64).")
        return
    letters = [ch for ch in body if ch.isalpha()]
    mixed = any(ch.islower() for ch in letters) and any(ch.isupper() for ch in letters)
    expected = c.to_checksum_address(body)
    notes = [_EVM_NETWORK_NOTE]
    low = "0x" + body.lower()
    if low in _BURN:
        notes.append(_BURN[low])
    if mixed:
        ok = ("0x" + body) == expected
        cand = _cand("evm", "endereço EVM (EIP-55)", network="n/a", valid=ok,
                     checksum="ok" if ok else "invalid", notes=notes)
        if not ok:
            cand["detail"] = f"checksum EIP-55 não confere; se for o mesmo endereço, a forma correta é {expected}"
            r["warnings"].append("Checksum EIP-55 inválido: o endereço foi digitado/copiado com erro ou foi alterado.")
    else:
        cand = _cand("evm", "endereço EVM (sem checksum EIP-55)", network="n/a", valid=True,
                     checksum="none", notes=notes)
        cand["detail"] = f"forma com checksum: {expected}"
        r["warnings"].append(
            "Endereço todo em minúsculas/maiúsculas: sem checksum EIP-55 — risco de erro silencioso de digitação. "
            "Obtenha o endereço da fonte primária e valide pela forma com checksum.")
    r["candidates"].append(cand)


# ----------------------------------------------------------------------------- Base58


def _classify_base58(t: str, r: dict) -> bool:
    try:
        payload = c.b58check_decode(t)
    except ValueError:
        payload = None
    if payload is not None:
        if len(payload) == 21 and payload[0] in _BASE58_V:
            fam, fmt, net, notes = _BASE58_V[payload[0]]
            r["kind"] = "address"
            r["candidates"].append(_cand(fam, fmt, network=net, notes=notes))
            return True
        if len(payload) == 22 and payload[:2] in (b"\x1c\xb8", b"\x1c\xbd"):
            r["kind"] = "address"
            r["candidates"].append(_cand(
                "zcash", "endereço transparente (t1…/t3…)", notes=[
                    "Transparente = rastreável como Bitcoin. Endereços blindados (zs1…/u1…) têm rastreabilidade muito baixa."]))
            return True
        if len(payload) == 78 and payload[:4] in _XPUB_VERSIONS:
            r["kind"] = "extended_public_key"
            r["candidates"].append(_cand(
                "bitcoin", f"chave pública estendida {_XPUB_VERSIONS[payload[:4]]}", notes=[
                    "Uma chave pública estendida permite derivar TODOS os endereços da carteira (passados e futuros): "
                    "com ela é possível enumerar e monitorar a carteira, mas não gastar.",
                    "Trate como dado sensível de privacidade: quem a possui vê o histórico completo da carteira."]))
            return True
        if len(payload) == 21:
            r["kind"] = "address"
            r["candidates"].append(_cand(
                "unknown-base58", f"Base58Check com versão 0x{payload[0]:02x} não mapeada", valid=True,
                notes=["Checksum confere, mas o prefixo não é de uma rede conhecida por esta ferramenta."]))
            return True
    try:
        xp = c.b58check_decode(t, c.XRP_ALPHABET)
        if len(xp) == 21 and xp[0] == 0:
            r["kind"] = "address"
            r["candidates"].append(_cand(
                "xrp", "endereço XRP Ledger (r…)", notes=[
                    "Contas em exchanges exigem a destination tag: sem ela não há como identificar o cliente."]))
            return True
    except ValueError:
        pass
    if 32 <= len(t) <= 44:
        try:
            raw = c.b58decode(t)
        except ValueError:
            raw = b""
        if len(raw) == 32:
            r["kind"] = "address"
            r["candidates"].append(_cand(
                "solana", "chave pública Solana (Base58, 32 bytes)", network="n/a", checksum="none",
                notes=["Formato também usado por contas de programas/tokens (SPL) na Solana."]))
            r["warnings"].append(
                "Solana não tem checksum interno: um erro de digitação pode gerar OUTRO endereço válido. "
                "Confirme sempre pela fonte primária (URL, QR code, copiar/colar direto).")
            return True
    r["kind"] = "address"
    r["candidates"].append(_cand(
        "base58", "string Base58", network="n/a", valid=False, checksum="invalid",
        detail="checksum Base58Check inválido (erro de digitação ou endereço de rede sem checksum)"))
    r["warnings"].append("Checksum Base58Check inválido: provável erro de digitação/cópia. Peça conferência da fonte.")
    return True


# ----------------------------------------------------------------------------- Bech32 / CashAddr / TON


def _segwit_format(ver: int, prog: bytes) -> str:
    if ver == 0 and len(prog) == 20:
        return "P2WPKH (SegWit nativo, Bech32, bc1q…)"
    if ver == 0 and len(prog) == 32:
        return "P2WSH (SegWit nativo, Bech32, bc1q… de 62 caracteres; costuma ser multisig/script)"
    if ver == 1 and len(prog) == 32:
        return "P2TR (Taproot, Bech32m, bc1p…)"
    return f"SegWit v{ver} (programa de {len(prog)} bytes, Bech32m)"


def _classify_bech32(t: str, r: dict) -> bool:
    low = t.lower()
    looks_segwit = low.startswith(tuple(h + "1" for h in _SEGWIT_HRP))
    try:
        hrp, _data, spec = c.bech32_decode(t)
    except ValueError as exc:
        if looks_segwit:
            r["kind"] = "address"
            r["candidates"].append(_cand("bitcoin", "endereço Bech32/Bech32m", network="n/a", valid=False,
                                         checksum="invalid", detail=str(exc)))
            r["warnings"].append(f"Endereço Bech32 inválido: {exc}.")
            return True
        return False
    if hrp in _SEGWIT_HRP:
        fam, net = _SEGWIT_HRP[hrp]
        r["kind"] = "address"
        try:
            ver, prog, spec = c.segwit_decode(hrp, t)
        except ValueError as exc:
            r["candidates"].append(_cand(fam, "endereço SegWit", network=net, valid=False, checksum=spec,
                                         detail=str(exc)))
            r["warnings"].append(f"Endereço SegWit inválido: {exc}.")
            return True
        r["candidates"].append(_cand(fam, _segwit_format(ver, prog), network=net, checksum="ok",
                                     detail=f"checksum {spec}; versão de witness {ver}"))
        return True
    r["kind"] = "address"
    r["candidates"].append(_cand(
        "bech32-generic", f"Bech32 genérico (hrp={hrp}; ecossistema Cosmos SDK e outros)", network="n/a",
        notes=["Checksum Bech32 confere; identifique a rede pelo prefixo (hrp) e use o explorer correspondente."]))
    return True


def _classify_cashaddr(t: str, r: dict) -> bool:
    low = t.lower()
    if not (low.startswith(("bitcoincash:", "bchtest:")) or re.fullmatch(r"[qp][a-z0-9]{41}", low)):
        return False
    r["kind"] = "address"
    try:
        kind, _h = c.cashaddr_decode(t, "bchtest" if low.startswith("bchtest:") else "bitcoincash")
    except ValueError as exc:
        r["candidates"].append(_cand("bitcoin-cash", "CashAddr", network="n/a", valid=False, checksum="invalid",
                                     detail=str(exc)))
        r["warnings"].append(f"CashAddr inválido: {exc}.")
        return True
    r["candidates"].append(_cand("bitcoin-cash", "CashAddr " + ("P2PKH" if kind == 0 else "P2SH"),
                                 network="testnet" if low.startswith("bchtest:") else "mainnet"))
    return True


def _crc16_xmodem(data: bytes) -> int:
    crc = 0
    for b in data:
        crc ^= b << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc


def _classify_ton(t: str, r: dict) -> bool:
    if not _TON_RE.match(t):
        return False
    import base64

    r["kind"] = "address"
    try:
        raw = base64.urlsafe_b64decode(t + "=" * (-len(t) % 4))
    except Exception:
        raw = b""
    ok = len(raw) == 36 and _crc16_xmodem(raw[:34]) == int.from_bytes(raw[34:], "big")
    r["candidates"].append(_cand("ton", "TON (formato amigável, base64url, 48 caracteres)", network="n/a", valid=ok,
                                 checksum="ok" if ok else "invalid",
                                 detail="" if ok else "CRC16 não confere"))
    if not ok:
        r["warnings"].append("Endereço TON com CRC16 inválido: provável erro de digitação/cópia.")
    return True


# ----------------------------------------------------------------------------- API


def classify(text: str) -> dict:
    t = (text or "").strip()
    r = _result(t)
    if not t:
        r["summary"] = "Entrada vazia."
        return r
    desc = _secret_type(t)
    if desc:
        return _secret_result(desc)
    if t.lower().startswith("0x"):
        _classify_evm(t, r)
    elif len(t) == 64 and _HEX_RE.match(t):
        r["kind"] = "tx_hash"
        r["candidates"].append(_cand(
            "bitcoin-like/evm", "64 hex sem prefixo: txid Bitcoin/Litecoin, hash de bloco ou hash EVM sem 0x",
            network="n/a", checksum="n/a"))
        r["warnings"].append(
            "64 caracteres hex também é o formato de uma chave privada de 256 bits. Se isto for uma chave privada, "
            "NÃO cole em ferramentas e interrompa a análise.")
    elif _NAME_RE.match(t.lower()):
        r["kind"] = "name"
        r["candidates"].append(_cand(
            "name-service", "nome legível (ENS/SNS/…)", network="n/a", checksum="n/a", notes=[
                "Nome não é endereço: faça a resolução e confira. Dono (owner), endereço resolvido e registro reverso "
                "podem ser entidades distintas, e a resolução muda ao longo do tempo (use o histórico por eventos)."]))
    elif _classify_cashaddr(t, r) or _classify_ton(t, r):
        pass
    elif "1" in t.lower() and not re.search(r"\s", t) and _classify_bech32(t, r):
        pass
    elif _B58_RE.match(t) and 25 <= len(t) <= 120:
        _classify_base58(t, r)
    else:
        r["kind"] = "unknown"
        r["warnings"].append(f"Formato não reconhecido ({len(t)} caracteres).")
    r["summary"] = _summary(r)
    return r


def _summary(r: dict) -> str:
    kind = {"address": "endereço", "tx_hash": "hash de transação/bloco", "name": "nome legível",
            "extended_public_key": "chave pública estendida", "unknown": "desconhecido"}.get(r["kind"], r["kind"])
    if not r["candidates"]:
        return f"{kind.upper()}: formato não reconhecido"
    cand = r["candidates"][0]
    state = "VÁLIDO" if cand["valid"] else "INVÁLIDO"
    extra = f"; rede: {cand['network']}" if cand["network"] not in ("n/a", "") else ""
    return f"{state} — {kind}: {cand['family']} · {cand['format']} (checksum: {cand['checksum']}{extra})"


def _levenshtein(a: str, b: str) -> int:
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb)))
        prev = cur
    return prev[-1]


def compare(a: str, b: str) -> dict:
    """Compara dois endereços e sinaliza 'lookalike' (mesmo início e fim, miolo diferente)."""
    a0, b0 = a.strip(), b.strip()
    na, nb = a0.lower(), b0.lower()
    if na.startswith("0x") and nb.startswith("0x"):
        na, nb = na[2:], nb[2:]
    prefix = 0
    for x, y in zip(na, nb):
        if x != y:
            break
        prefix += 1
    suffix = 0
    for x, y in zip(reversed(na), reversed(nb)):
        if x != y:
            break
        suffix += 1
    same_ci = na == nb
    identical = a0 == b0
    lookalike = (not same_ci) and prefix >= 4 and suffix >= 4
    return {
        "a": a0,
        "b": b0,
        "identical": identical,
        "same_ignoring_case": same_ci,
        "common_prefix": prefix,
        "common_suffix": suffix,
        "edit_distance": _levenshtein(na, nb),
        "lookalike": lookalike,
    }


def _render_item(r: dict) -> str:
    lines = [f"Entrada: {r['input']}", f"  {r['summary']}"]
    for cand in r["candidates"]:
        if cand["detail"]:
            lines.append(f"  detalhe: {cand['detail']}")
        for n in cand["notes"]:
            lines.append(f"  nota: {n}")
    for w in r["warnings"]:
        lines.append(f"  AVISO: {w}")
    return "\n".join(lines)


def _render_compare(d: dict) -> str:
    if d["identical"]:
        return "Endereços idênticos (inclusive maiúsculas/minúsculas)."
    if d["same_ignoring_case"]:
        return ("Endereços iguais ignorando maiúsculas/minúsculas, mas a grafia difere: confira o checksum EIP-55 "
                "de cada um com esta ferramenta.")
    if d["lookalike"]:
        return (f"ALERTA DE ENVENENAMENTO (lookalike): os endereços são DIFERENTES, mas começam igual "
                f"({d['common_prefix']} caracteres) e terminam igual ({d['common_suffix']} caracteres). "
                "Não confie em comparação visual do início/fim: compare caractere a caractere e obtenha o "
                "endereço da fonte primária.")
    return f"Endereços diferentes (distância de edição {d['edit_distance']}); não há semelhança suspeita de início/fim."


def main(argv=None) -> int:
    c.ensure_utf8()
    ap = argparse.ArgumentParser(description="Valida e classifica endereços/hashes (offline).")
    ap.add_argument("items", nargs="*", help="endereços, hashes ou nomes a classificar")
    ap.add_argument("--compare", nargs=2, metavar=("A", "B"), help="compara dois endereços (lookalike)")
    ap.add_argument("--json", action="store_true", help="saída em JSON")
    ap.add_argument("--stdin", action="store_true", help="ler itens da entrada padrão, um por linha")
    args = ap.parse_args(argv)
    items = list(args.items)
    if args.stdin:
        items += [ln.strip() for ln in sys.stdin if ln.strip()]
    results = [classify(i) for i in items]
    cmp_res = compare(*args.compare) if args.compare else None
    code = 0
    for r in results:
        if r["kind"] == "secret_like":
            code = 2
        elif code != 2 and (not r["candidates"] or not any(cand["valid"] for cand in r["candidates"])):
            code = max(code, 1)
    if cmp_res and cmp_res["lookalike"] and code == 0:
        code = 1
    if args.json:
        if cmp_res and results:
            print(json.dumps({"items": results, "compare": cmp_res}, ensure_ascii=False, indent=2))
        elif cmp_res:
            print(json.dumps(cmp_res, ensure_ascii=False, indent=2))
        else:
            print(json.dumps(results, ensure_ascii=False, indent=2))
    else:
        for r in results:
            print(_render_item(r))
        if cmp_res:
            print(_render_compare(cmp_res))
    if not items and not args.compare:
        ap.print_usage(sys.stderr)
        return 1
    return code


if __name__ == "__main__":
    sys.exit(main())
