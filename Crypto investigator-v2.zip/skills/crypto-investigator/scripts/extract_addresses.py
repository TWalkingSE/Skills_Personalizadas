#!/usr/bin/env python3
"""Extrai e valida ENDEREÇOS PÚBLICOS de UM arquivo de texto/HTML/CSV informado (offline).

Uso:
  python extract_addresses.py arquivo.txt [--json] [--solana]
  type pagina.html | python extract_addresses.py - --json

Limites deliberados (desenho de segurança):
  * lê apenas o arquivo (ou a entrada padrão) indicado; NÃO varre diretórios;
  * extrai somente endereços PÚBLICOS validados por checksum; NÃO procura nem relata chaves privadas,
    xprv ou frases de recuperação (esses formatos nem são casados pelos padrões);
  * Solana (Base58 de 32 bytes, sem checksum) só com --solana, pois gera muitos falsos positivos.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

import _common as c
import validate_address as V

_B = r"(?<![0-9A-Za-z])"
_E = r"(?![0-9A-Za-z])"
_PATTERNS = [
    re.compile(_B + r"0x[0-9a-fA-F]{40}" + _E),
    re.compile(_B + r"[13LMDX79ATrt][1-9A-HJ-NP-Za-km-z]{24,35}" + _E),
    re.compile(_B + r"(?:bc1|tb1|ltc1|bcrt1)[0-9A-Za-z]{11,87}" + _E, re.I),
    re.compile(_B + r"bitcoincash:[qp][0-9a-z]{41}" + _E, re.I),
]
_SOLANA = re.compile(_B + r"[1-9A-HJ-NP-Za-km-z]{32,44}" + _E)
_ALLOWED = {"bitcoin", "litecoin", "dogecoin", "dash", "zcash", "tron", "xrp", "evm", "bitcoin-cash", "bech32-generic",
            "solana"}
MAX_MB = 50


def extract(text: str, include_solana: bool = False) -> dict:
    patterns = list(_PATTERNS) + ([_SOLANA] if include_solana else [])
    found: dict[str, dict] = {}
    rejected = 0
    seen_spans = set()
    for pat in patterns:
        for m in pat.finditer(text):
            if m.span() in seen_spans:
                continue
            seen_spans.add(m.span())
            token = m.group(0)
            r = V.classify(token)
            if r["kind"] == "secret_like":
                continue
            cand = r["candidates"][0] if r["candidates"] else None
            if r["kind"] != "address" or not cand or not cand["valid"] or cand["family"] not in _ALLOWED:
                rejected += 1
                continue
            if cand["family"] == "solana" and not include_solana:
                continue
            key = token.lower() if cand["family"] == "evm" else token
            if key in found:
                found[key]["count"] += 1
                continue
            found[key] = {"address": token, "family": cand["family"], "format": cand["format"],
                          "network": cand["network"], "checksum": cand["checksum"], "count": 1,
                          "first_offset": m.start()}
    addresses = sorted(found.values(), key=lambda a: a["first_offset"])
    return {"addresses": addresses, "rejected_count": rejected,
            "note": "Endereços públicos validados por checksum; formato válido não prova existência, uso nem propriedade."}


def main(argv=None) -> int:
    c.ensure_utf8()
    ap = argparse.ArgumentParser(description="Extrai endereços públicos de um arquivo (offline).")
    ap.add_argument("path", help="arquivo de texto/HTML/CSV, ou '-' para a entrada padrão")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--solana", action="store_true", help="inclui endereços Solana (muitos falsos positivos)")
    args = ap.parse_args(argv)
    try:
        if args.path == "-":
            text = sys.stdin.read()
        else:
            if os.path.isdir(args.path):
                print("Erro: diretórios não são aceitos (a ferramenta não faz varredura recursiva); informe um arquivo.",
                      file=sys.stderr)
                return 1
            if os.path.getsize(args.path) > MAX_MB * 1024 * 1024:
                print(f"Erro: arquivo maior que {MAX_MB} MB.", file=sys.stderr)
                return 1
            with open(args.path, encoding="utf-8", errors="replace") as fh:
                text = fh.read()
    except OSError as exc:
        print(f"Erro: {exc}", file=sys.stderr)
        return 1
    res = extract(text, include_solana=args.solana)
    if args.json:
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0
    print("Endereços PÚBLICOS encontrados (validados por checksum). Esta ferramenta não varre diretórios nem "
          "procura chaves privadas/seeds.")
    for a in res["addresses"]:
        print(f"- {a['address']}  [{a['family']} · {a['format']}]  ocorrências: {a['count']}")
    if not res["addresses"]:
        print("(nenhum endereço válido encontrado)")
    print(f"Candidatos rejeitados por checksum/formato: {res['rejected_count']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
