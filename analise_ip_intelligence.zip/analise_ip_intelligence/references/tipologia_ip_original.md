---
name: "analise-ip-tipologia"
description: "Classifica o tipo de um IP (residencial, móvel, corporativo, datacenter, VPN, proxy, Tor, CDN) e define como investigar cada tipo e até onde a atribuição é possível. Use junto com analise-ip."
---

# Tipologia de IP e roteiro investigativo por tipo

Complementa a skill `analise-ip` (pipeline, script `ipanalise.py`, regras invioláveis, classificações e estrutura de saída). Use esta skill quando a pergunta for: *"que tipo de IP é esse?"*, *"como investigar?"* ou *"dá para descobrir quem está por trás?"*. Quando houver IP concreto para analisar, execute também o fluxo da `analise-ip` (normalizar → coletar passivamente → correlacionar) e aplique aqui a classificação e o roteiro.

**Princípio:** o tipo de IP define o caminho investigativo e o limite da atribuição. Classificar o tipo é **indício**, nunca prova de autoria. Hierarquia: evidência > correlação > hipótese.

## 1. Tipos de IP

| Tipo (código de base comercial) | O que é | Como reconhecer (indícios) | Quem detém o dado |
|---|---|---|---|
| Residencial (ISP) | IP de provedor de acesso fixo (fibra, cabo, rádio, xDSL). Dinâmico, fixo ou compartilhado por CGNAT | ASN de operadora de acesso; PTR com `dynamic`, `dsl`, `bdl`, `cable`, `pool`; uso ISP | Provedor de acesso |
| Móvel (MOB) | Operadora 3G/4G/5G. CGNAT massivo; troca com frequência; geolocalização aponta para gateway | ASN de operadora móvel; PTR `mobile`, `movel`, `3g`, `4g`, `lte`; uso MOB; faixa CGNAT | Operadora móvel |
| Comercial/corporativo/institucional (COM, ORG, GOV, MIL, EDU, LIB) | IP contratado por empresa, universidade ou órgão; geralmente estático e dedicado; NAT interno | Titular PJ (CNPJ) no RDAP; ASN próprio; PTR com domínio da organização | A própria organização (logs internos) |
| Datacenter/hospedagem/nuvem (DCH) | AWS, Google Cloud, Azure, Oracle, DigitalOcean, Hetzner, OVH, Vultr etc. Multi-inquilino; reputação baixa a média | ASN de hospedagem/nuvem; listas oficiais de faixas; PTR genérico (`ec2-…`); uso DCH | Provedor de hospedagem (cliente/conta) |
| VPN (VPN) | Servidor de serviço que encaminha o tráfego e oculta o IP real. Compartilhado; frequentemente em datacenter, mas há ASN próprio e IP de aparência residencial | Base de VPN; ASN de hospedagem/VPN; portas OpenVPN 1194, WireGuard 51820, IPsec 500/4500; PTR com nome do serviço | Operador do VPN (jurisdição própria) |
| Proxy aberto (PUB) | Faz conexões em nome do usuário, com menos funções que VPN; muitas vezes máquina mal configurada ou comprometida | Base de proxy; portas 3128, 8080, 1080 (SOCKS) como indício | Dono da máquina/operador |
| Web proxy (WEB) | Proxy baseado em site | Base de proxy | Operador do site |
| Proxy residencial (RES) | Proxy via ISP residencial, com ou sem consentimento do assinante (SDK de compartilhamento de banda, malware). O IP é de assinante real, possivelmente inocente | Comportamento atípico (muitos agentes de usuário/países/contas em curto intervalo); base de proxy | Operador do pool/SDK; assinante (pode ser vítima) |
| Tor (TOR) | Nó de saída da rede Tor | Lista de saídas (`check.torproject.org/torbulkexitlist`); Onionoo; ExoneraTor para data passada | Ninguém (por desenho) |
| CDN (CDN) | Cloudflare, Akamai, Fastly, CloudFront; multi-inquilino; esconde a origem | Faixas publicadas pelo provedor; ASN de CDN; cabeçalhos HTTP | Provedor da CDN |
| CPN | Retransmissores de privacidade do consumidor (ex.: iCloud Private Relay); IP visto costuma ser de CDN | Base de proxy (CPN); faixas do serviço | Operador do serviço |
| EPN | SASE/SD-WAN: tráfego do funcionário sai por IP do provedor do serviço | Base de proxy (EPN) | Organização cliente + provedor |
| SES / AIC | Robôs de busca e crawlers de IA | Base de proxy/uso | Não são usuários: descartar falsos positivos |
| Satélite | Ex.: Starlink; em geral CGNAT; geolocalização imprecisa | ASN/uso | Operador do satélite |
| Anycast | Mesmo IP anunciado em vários locais | RIPEstat/BGP | Localização aparente não confiável |
| Reservado/privado/CGNAT | RFC 1918, `100.64.0.0/10`, loopback, link-local, documentação, ULA | `ipanalise.py normalizar` | Não segue para consulta externa |

Taxonomias IP2Location: **tipos de proxy** VPN, PUB, WEB, TOR, SES, DCH, RES, CPN, EPN; **tipos de uso** COM, ORG, GOV, MIL, EDU, LIB, CDN, ISP (linha fixa), MOB, DCH, SES, AIC, RSV. São estimativas de terceiros: compare no mínimo 2 bases.

## 2. Como classificar (ordem de verificação)

1. **Faixa especial** (privado, CGNAT, documentação): resolve sem consulta externa; explique o significado (`100.64.0.0/10` = CGNAT do provedor).
2. **Tor**: lista atual; para evento passado, ExoneraTor na data.
3. **Listas oficiais de cloud/CDN** (AWS, Google, Azure, Oracle, Cloudflare): confirmam a faixa.
4. **ASN + RDAP + PTR**: tipo de rede (acesso fixo, móvel, hospedagem, organização).
5. **Bases de VPN/proxy** (≥ 2) e tipo de uso.
6. **Serviços expostos e portas típicas**: indício.
7. **Comportamento nos logs**: muitos agentes de usuário/países/contas no mesmo IP, rotatividade.

Regras: um IP pode ter mais de um papel (VPN sobre datacenter; proxy sobre IP residencial) — registre todos. Confiança por origem: lista oficial do provedor ou ExoneraTor → alta; ASN/RDAP → média/alta para o tipo de rede; base comercial de VPN/proxy → no máximo "Provável"; PTR e portas → "Possível". Fontes em conflito: declare o conflito. Classificação de hoje ≠ classificação na data do evento: use fontes históricas ou declare a limitação. Escala: Não identificado · Possível · Provável · Confirmado.

## 3. Roteiro investigativo por tipo

| Tipo | A quem recorrer | O que solicitar | Obstáculos | Titular da conexão/conta | Usuário |
|---|---|---|---|---|---|
| Residencial | Provedor de acesso (titular do bloco no RDAP) | Assinante de IP + data/hora + fuso (+ porta se CGNAT): nome, CPF/CNPJ, endereço de instalação, histórico de autenticação | CGNAT sem porta; Wi-Fi compartilhado; roteador comprometido | Alta | Média |
| Móvel | Operadora móvel | Linha/titular da sessão (IP + porta + hora exata); localização (ERB) tem regime próprio | CGNAT massivo; chip em nome de terceiros; hotspot | Média a alta | Média |
| Corporativo/institucional | Organização titular | Logs internos: NAT, proxy, DHCP, autenticação, Wi-Fi de visitantes, VPN corporativa | Organização pode ser vítima/canal comprometido; retenção | Alta (organização) | Média a baixa |
| Datacenter/cloud | Provedor de hospedagem/nuvem | Cliente/conta no instante: e-mail, pagamento, IPs de acesso ao painel, logs; **preservação** | Conta falsa; servidor comprometido; provedor estrangeiro | Alta (nacional) / média (exterior) | Baixa a média |
| VPN | Operador do VPN (jurisdição) | Conta, pagamento, logs de conexão (se houver) | "No-log" não verificável; encadeamento | Baixa a média | Baixa |
| Proxy aberto/residencial | Operador do proxy / dono do IP | Confirmar nó de proxy; dados do operador | Assinante pode ser vítima; rotatividade | Baixa | Muito baixa |
| Tor | ExoneraTor / lista de relays | Apenas confirmar saída Tor na data | Anonimato por desenho | Muito baixa pelo IP | Muito baixa pelo IP |
| CDN | Provedor da CDN | Cliente (dono do site), IP de origem e IP real do visitante nos logs (`CF-Connecting-IP`, `X-Forwarded-For`) | Multi-inquilino; origem oculta | Alta (dono do site) | Depende dos logs da CDN |

Viabilidade é orientativa e varia com o caso, a jurisdição e a qualidade dos registros.

Notas:
- **Proxy residencial:** registre a hipótese de proxy antes de qualquer conclusão sobre o assinante; atribuição direta pode apontar um inocente.
- **Datacenter:** IP de nuvem no log da vítima pode ser serviço legítimo (ferramentas de segurança que abrem links).
- **CDN:** nunca atribuir ao dono do IP o conteúdo do site; relação domínio → IP é fraca. Use RDAP do domínio, DNS histórico, certificados (CT).
- **VPN/Tor/proxy:** o avanço costuma vir de outros elos (acessos da mesma conta sem anonimização, pagamento, dispositivo, vínculos entre contas, rastros financeiros). Não descreva técnicas de desanonimização; encaminhe a unidades especializadas e à autorização judicial.
- **IPv6:** analise o prefixo (/56 ou /64), não o endereço completo.
- **IP forjado:** relevante sobretudo em ataques sem conexão completa (alguns DDoS por UDP); em sessões TCP completas é muito mais difícil.

## 4. Cadeia de atribuição

| Camada | Pergunta | Quem responde | O IP ajuda? |
|---|---|---|---|
| 1. Infraestrutura | De qual rede/provedor é o IP? | RDAP, BGP, DNS | Sim, bem |
| 2. Conexão | Qual assinante/cliente usou o IP (e a porta) naquele instante? | Provedor, por requisição legal | Sim, com os dados corretos |
| 3. Terminal | Qual dispositivo? | Logs internos, perícia | Só como ponto de partida |
| 4. Usuário | Quem usava o dispositivo? | Corroboração | Não |
| 5. Autoria | Quem praticou o fato? | Conjunto probatório e decisão judicial | Não |

**Resposta-padrão a "dá para descobrir quem está por trás?":** "Às vezes sim, mas nunca só com o IP. O IP leva à infraestrutura e, por meio de quem a opera, ao titular da conexão/conta naquele instante. Do titular até quem usou, e daí à autoria, é preciso corroboração." Depois aplique a tabela do item 3 ao tipo identificado.

Corroboração do titular ao usuário: logs da aplicação (cadastro, histórico de logins, outros IPs da conta, ID de dispositivo, cookies, agente de usuário); número de verificação em dois fatores; rastros financeiros (PIX/TED); dispositivos (busca e apreensão, perícia); câmeras, testemunhas, OSINT; interceptação telemática (Lei 9.296/1996) com ordem judicial.

## 5. Dados necessários para individualizar a conexão

IP público · data · **hora com segundos** · **fuso horário** · **porta lógica de origem** (indispensável em CGNAT) · protocolo (TCP/UDP) · IP/porta de destino · identificador da conta/sessão. Marque o que **existe** e o que **falta**. Com CGNAT: "O endereço IP isoladamente pode não ser suficiente para individualização da conexão."

Enfraquecem ou impedem a atribuição: CGNAT sem porta; horário sem segundos/fuso; relógio dessincronizado; retenção expirada (1 ano conexão, 6 meses aplicação, salvo preservação cautelar); provedor estrangeiro; Wi-Fi aberto/compartilhado e hotspot; dispositivo comprometido (botnet/proxy residencial); encadeamento VPN/proxy/Tor; IP forjado.

## 6. Base legal (orientativa; conferir vigência e inteiro teor)

| Norma / precedente | Conteúdo |
|---|---|
| Marco Civil (Lei 12.965/2014) art. 5º, VI e VIII | Define registro de conexão e registros de acesso a aplicações |
| MCI art. 13 | Provedor de conexão guarda registros por 1 ano; preservação cautelar por autoridade policial/administrativa ou MP, com 60 dias para o pedido judicial (§§ 2º a 4º) |
| MCI art. 14 | Provedor de conexão não guarda registros de acesso a aplicações |
| MCI art. 15 | Provedor de aplicação (PJ com fins econômicos) guarda por 6 meses; preservação cautelar (§ 2º) |
| MCI arts. 10 e 22 | Registros e conteúdo por ordem judicial; dados cadastrais por autoridades com competência legal (art. 10, § 3º) |
| Decreto 8.771/2016 art. 11 | Dados cadastrais: filiação, endereço, qualificação pessoal |
| **Decreto 12.975/2026** (20/05/2026; DOU 21/05/2026), art. 15-A do Decreto 8.771/2016 | A guarda de registros de IP abrange a **porta lógica de origem** quando necessária à identificação inequívoca do terminal; independe de requisição prévia; recai sobre cada provedor; fornecimento observa arts. 10 e 22 do MCI. **Vigência:** há análise indicando 20/07/2026; confirmar no texto oficial |
| Lei 12.850/2013 art. 15 | Delegado e MP acessam dados cadastrais sem autorização judicial em investigação de organização criminosa |
| STJ, REsp 1.784.156/SP (3ª T., 2019) | Provedor de aplicação deve fornecer a porta lógica de origem. Conferir inteiro teor. O REsp 2.170.872 (2025), citado em material da skill `analise-ip`, não foi verificado |
| Convenção de Budapeste (Decreto 11.491/2023) | Preservação expedita (arts. 16, 17, 29) e pontos de contato 24 h (art. 35) |
| Lei 9.296/1996 | Interceptação telemática com ordem judicial |
| CPP arts. 158-A a 158-F | Cadeia de custódia |

Três regimes: **cadastrais** (autoridades competentes), **registros de conexão/acesso** (ordem judicial, com preservação cautelar), **conteúdo** (ordem judicial). Provedor estrangeiro: peça preservação expedita cedo.

## 7. Bloco obrigatório de saída: "Classificação do IP e caminho investigativo"

| Campo | Conteúdo |
|---|---|
| Tipo provável (confiança) | Residencial / móvel / corporativo / datacenter / VPN / proxy (PUB/WEB/RES) / Tor / CDN / outro, com Alta · Média · Baixa |
| Indícios que sustentam | ASN, RDAP, PTR, lista oficial, base comercial (fonte e data) |
| Outros papéis possíveis | Ex.: VPN sobre datacenter; proxy sobre IP residencial |
| Anonimização | Não identificada · Possível · Provável · Confirmada |
| Quem detém o dado | Provedor / operadora / organização / hospedagem / operador de VPN / CDN |
| Caminho investigativo | Linha correspondente do item 3 |
| Viabilidade (orientativa) | Titular da conexão/conta e usuário |
| Dados para atribuição | Tem / falta (item 5) |
| Prazo de guarda | 1 ano (conexão) ou 6 meses (aplicação); preservação cautelar se próximo do limite |
| Limitações | CGNAT, data da consulta ≠ data do evento, classificação comercial é estimativa |

## 8. Linguagem

| Pode-se afirmar (com base) | Não se pode afirmar só com o IP |
|---|---|
| O IP X estava anunciado pelo ASN Y (provedor Z) em D, conforme RDAP/BGP | "O titular do bloco praticou o fato" |
| O provedor informou que IP X e porta P, no horário H, foram atribuídos ao assinante A | "O assinante A é o autor" |
| As bases associam o IP à região R, com baixa confiança | "O autor estava em R" |
| O IP consta em lista de reputação L (indício de abuso) | "O dono do IP é criminoso" |
| Não foi encontrada relação nas fontes consultadas | "Não existe relação" |

Formato de conclusão: **Conclusão → Base → Limitação**.

## 9. Erros comuns

IP = pessoa · geolocalização = endereço · blacklist = autoria · titular do bloco = usuário · PTR/domínio = dono · usar a infraestrutura de hoje para evento passado · ignorar fuso (UTC × local) · ignorar CGNAT · ligar domínio a IP em CDN/hospedagem compartilhada · tratar classificação comercial como fato.

## 10. Regras

- Coleta somente passiva e dentro da lei; sem varredura ativa, sem medidas invasivas e sem técnicas de desanonimização.
- Não invente campos ausentes; registre fonte e data/hora de cada consulta.
- Mantenha a separação entre fato, indício, inferência e hipótese.
- Nada aqui substitui a requisição formal a provedores nem a análise jurídica do caso.

## Fontes

IP2Location, *What are the Proxy Types Supported in IP2Proxy* e *What is usage types* (blog.ip2location.com/knowledge-base/); Decreto 12.975/2026 (planalto.gov.br); Migalhas, Conjur, TELETIME e BMA Advogados (análises do decreto); MPF (nota técnica sobre a regulamentação do MCI); Escola Superior do MPU, *Investigação de crimes cibernéticos*; Decreto 11.491/2023.