# Base legal (fonte única) — retenção, preservação e requisição de dados de IP

> **Orientativa.** Confira vigência e inteiro teor antes de citar em peça. Esta é a **única** tabela jurídica da skill: `SKILL.md`, `fontes_e_consultas.md` e as minutas de ofício (`ipanalise.py oficio`) remetem a ela. Se houver divergência entre arquivos, vale este, e a divergência deve ser corrigida.
> Nada aqui substitui a análise jurídica do caso nem a decisão da autoridade competente. Atualizado em 2026-10-24.
>
> **Estrutura:** **Parte A (§1–§6)** = Brasil (regime de referência dos prazos da skill). **§B** = fora do Brasil e cooperação internacional. **§C** = como a skill trata a jurisdição. A análise técnica do IP (tipologia, RDAP, proxycheck, listas) vale em qualquer país; o que muda por país é o **prazo de guarda**, o **instrumento legal** e o **canal**.

## Parte A — Brasil

## 1. Normas

| Norma | Conteúdo relevante para IP | Situação da verificação |
|---|---|---|
| **Marco Civil da Internet (Lei 12.965/2014), art. 5º, VI e VIII** | Define *registro de conexão* e *registros de acesso a aplicações de internet* | Texto legal conhecido; conferir redação vigente |
| **MCI art. 13, caput** | Provedor de **conexão** guarda os registros de conexão por **1 ano**, sob sigilo, em ambiente controlado e seguro | idem |
| **MCI art. 13, §2º** | Autoridade policial, administrativa ou MP pode **requerer cautelarmente** a guarda, inclusive por prazo superior | idem |
| **MCI art. 13, §3º** | A autoridade requerente tem **60 dias**, contados do requerimento, para ingressar com o pedido judicial de acesso aos registros | idem |
| **MCI art. 13, §4º** | O provedor mantém **sigilo** sobre o requerimento; ele **perde a eficácia** se o pedido judicial for indeferido ou não for protocolado no prazo do §3º | idem |
| **MCI art. 14** | Provedor de conexão **não** guarda registros de acesso a aplicações (em regra, o ISP não sabe qual serviço foi acessado) | idem |
| **MCI art. 15, caput e §2º** | Provedor de **aplicação** (pessoa jurídica, atividade organizada, com fins econômicos) guarda registros de acesso por **6 meses**; preservação cautelar nos termos do art. 13, §§3º e 4º | idem |
| **MCI art. 10, §1º e §3º** | Registros e conteúdo: **ordem judicial**. Dados **cadastrais** (qualificação pessoal, filiação, endereço): autoridades administrativas com competência legal | idem |
| **MCI art. 22** | Pedido judicial de registros exige: (I) fundados indícios do ilícito; (II) justificativa motivada da utilidade; (III) período a que se referem os registros | idem |
| **Decreto 8.771/2016, art. 11** | Autoridade que requisita dados cadastrais indica o fundamento legal de sua competência e a motivação; dados cadastrais = filiação, endereço e qualificação pessoal | idem |
| **Decreto 12.975/2026** (de 20/05/2026; DOU de 21/05/2026) — acrescenta o **art. 15-A** ao Decreto 8.771/2016 | A guarda dos registros de IP abrange a **porta lógica de origem** quando necessária à identificação inequívoca do terminal; independe de requisição prévia; recai sobre cada provedor; o fornecimento observa os arts. 10 e 22 do MCI | Existência e conteúdo conferidos em fonte oficial e em análises na consulta de 2026-10-24. **Conferir o texto no Planalto antes de citar** |
| Vigência do Decreto 12.975/2026 | **20/07/2026** (60 dias após a publicação, conforme o art. 2º do decreto) | A skill usa esta data (`VIGENCIA_DEC_12975` em `ipa_oficio.py`). Confirmar no texto oficial |
| **Lei 12.850/2013, art. 15** | Delegado e MP acessam, sem autorização judicial, **apenas** dados cadastrais do investigado (qualificação pessoal, filiação, endereço) mantidos por provedores de internet, empresas telefônicas, instituições financeiras etc., em investigação de **organização criminosa** | Texto legal conhecido |
| **STJ, REsp 1.784.156/SP** (3ª Turma, 2019) | Provedor de **aplicação** deve fornecer a **porta lógica de origem** do IP (essencial com IPv4 compartilhado/CGNAT) | Conferir número, relator, data e ementa no inteiro teor |
| **STJ, REsp 2.170.872/SP** (3ª Turma, 2025) | Provedor de **conexão** deve identificar o usuário a partir do IP e do horário, sem exigir prévia indicação da porta; cabe a ele guardar IP e porta | Tema confirmado em fontes secundárias. **Data de julgamento, relator e redação exata NÃO confirmados**: conferir o inteiro teor antes de citar |
| **Convenção de Budapeste** (Decreto 11.491/2023) | Preservação expedita (arts. 16, 17 e 29) e pontos de contato 24 h (art. 35) | Texto conhecido |
| **Lei 9.296/1996** | Interceptação telemática somente com ordem judicial | Texto conhecido |
| **CPP, arts. 158-A a 158-F** | Cadeia de custódia | Texto conhecido |

## 2. Três regimes

1. **Dados cadastrais** (nome, filiação, endereço de instalação): autoridades com competência legal (MCI art. 10, §3º; Decreto 8.771 art. 11; Lei 12.850 art. 15 em organização criminosa).
2. **Registros de conexão / de acesso a aplicações** (IP, porta, data, hora, fuso): ordem judicial (MCI arts. 10, §1º, e 22), com **preservação cautelar** prévia (arts. 13 §2º e 15 §2º).
3. **Conteúdo de comunicações:** ordem judicial.

Provedor estrangeiro: peça **preservação expedita** cedo (Convenção de Budapeste; canais de cooperação).
IP privado: os registros de DHCP, NAT, proxy e autenticação pertencem a quem opera a rede local; segue-se o regime aplicável a esse detentor e ao tipo de dado, com **preservação imediata** (retenção curta).

## 3. Prazos — como a skill calcula

| Provedor | Prazo-base | A partir de |
|---|---|---|
| Conexão (art. 13) | 12 meses | data/hora do evento, convertida para UTC |
| Aplicação (art. 15) | 6 meses | idem |

- `ipanalise.py prazos "<data hora>" --fuso <fuso>` calcula o vencimento e classifica: **VENCIDO** · **URGENTE** (≤ 30 dias) · **ATENÇÃO** (≤ 90 dias) · **OK**.
- Meses somados em calendário (31/08 + 6 meses = 28/02).
- "VENCIDO" é **presumível**: pode haver preservação cautelar anterior ou prazo maior do provedor. Pergunte ao provedor antes de desistir do dado.
- Com `--preservacao-em AAAA-MM-DD`, a skill calcula os 60 dias do art. 13, §3º, para o pedido judicial; passado o prazo sem o pedido, a preservação perde a eficácia (§4º).

## 4. Cuidados com a porta lógica de origem (Decreto 12.975/2026)

- Para fatos **anteriores a 20/07/2026**, não afirme que o art. 15-A já obrigava a guarda da porta. A minuta de ofício, nesses casos, apoia-se na **jurisprudência do STJ** (REsp 1.784.156/SP e REsp 2.170.872/SP, a conferir) e não no decreto, e registra a ressalva para avaliação da autoridade ou do MP. Em qualquer data, é possível que o provedor **não tenha** o registro de porta de eventos antigos: peça preservação sem demora.
- Para fatos **a partir de 20/07/2026**, a minuta cita o art. 15-A (incluído pelo Decreto 12.975/2026) e pede explicitamente a porta lógica.
- A irretroatividade e a eficácia do decreto são questões jurídicas: a skill sinaliza a cautela, não resolve a controvérsia.

## 5. Canais

Contato de abuso do RDAP/Registro.br (incidente técnico); CERT.br (`cert@cert.br`) para incidentes; ofício/representação para dados de assinante. O canal formal de **atendimento a autoridades** de cada operadora deve vir do diretório oficial da sua instituição — `references/operadoras/BR.json` deliberadamente **não** o preenche.

## 6. Fontes desta referência

Planalto (Decreto 12.975/2026; Lei 12.965/2014; Decreto 8.771/2016; Lei 12.850/2013; Decreto 11.491/2023); análises do decreto (Migalhas, Conjur, TELETIME, BMA Advogados); MPF (nota técnica sobre a regulamentação do MCI); STJ (pesquisa de jurisprudência — conferir os acórdãos); Escola Superior do MPU, *Investigação de crimes cibernéticos*; IANA e RFC 1918, 4193, 6598, 3927, 5737, 6890 (faixas especiais). Fontes da §B: Cornell LII (18 U.S.C. § 2703, <https://www.law.cornell.edu/uscode/text/18/2703>, texto conferido em 2026-10-24); Conventus Law, *EU e-Evidence: day one is approaching* (fonte secundária sobre o Reg. (UE) 2023/1543); Conselho da Europa/T-CY (arts. 29 e 35 da Convenção de Budapeste).

## §B. Fora do Brasil e cooperação internacional

> **Por que existe:** a skill serve a análises de IPs complicados **no Brasil ou fora**. O país do bloco (RDAP) indica onde a rede foi alocada; **não** define, sozinho, a lei aplicável a um provedor (empresas globais atendem por entidades locais, e o Marco Civil alcança serviços ofertados ao público brasileiro — MCI art. 11). Tudo abaixo é **orientativo e deve ser conferido**.

### B.1 Instrumentos

| Instrumento | Conteúdo útil para IP | Situação da verificação |
|---|---|---|
| **Convenção de Budapeste** (Convenção sobre o Crime Cibernético; no Brasil, Decreto 11.491/2023) | Art. 16 (preservação expedita de dados armazenados), 17 (preservação e divulgação parcial de dados de tráfego), 29 (preservação expedita **entre Estados**), 30 (divulgação expedita de dados de tráfego preservados), 31 (assistência quanto ao acesso a dados armazenados), 35 (rede de contatos **24/7**) | Existência e numeração dos artigos conferidas em fontes do Conselho da Europa/Eurojust. **Prazo mínimo de 60 dias da preservação (art. 29(7)) NÃO foi reconfirmado nesta sessão** (a fonte consultada não traz o trecho): conferir o texto |
| **Segundo Protocolo Adicional à Convenção de Budapeste** (2022) | Cooperação reforçada, inclusive pedido direto de dados de assinante a provedores | **Não verificado.** Conferir se o seu país e o país do provedor são Partes/ratificaram |
| **EUA — 18 U.S.C. § 2703(f)** | A pedido de entidade governamental, o provedor "shall take all necessary steps to preserve records and other evidence in its possession" por **90 dias**, prorrogáveis por **mais 90 dias** mediante novo pedido | **Texto conferido** (Cornell LII, 2026-10-24) |
| **EUA — 18 U.S.C. § 2703(c)(2)** | Informações de assinante que o provedor fornece a entidade governamental dos EUA: nome, endereço, registros de sessão (horários e durações), duração do serviço, número/identificador "incluindo qualquer endereço de rede temporariamente atribuído", forma de pagamento | **Texto conferido.** É regime de processo legal **norte-americano**: autoridade estrangeira normalmente depende de cooperação jurídica (MLAT/auxílio direto) ou da política voluntária do provedor — **não verificado**; confirmar com a autoridade central |
| **UE — Regulamento (UE) 2023/1543** (ordens europeias de produção e de preservação) | Em aplicação desde **18/08/2026**: EPOC (produção em **10 dias**; **8 horas** em urgência) e EPOC-PR (preservação por **60 dias**, prorrogável **uma vez**) | **Fonte secundária** (Conventus Law). Instrumento das **autoridades dos Estados-Membros**: não está disponível, em regra, a autoridade de país terceiro. Duração da prorrogação: conferir o art. 11 do Regulamento |
| Demais países (Reino Unido, Canadá, Austrália, Índia, América Latina…) | Retenção e acesso a registros variam por lei nacional e por política do provedor | **Não presumir.** Consultar a lei local e o guia de atendimento a autoridades do provedor |

### B.2 Caminho prático (não é aconselhamento jurídico)

1. **Identifique o provedor e a jurisdição** — RDAP (país do bloco), ASN, quem opera o serviço visível. O país do IP é um indício, não a lei aplicável.
2. **Peça a PRESERVAÇÃO cedo** — pelo canal de atendimento a autoridades do provedor ou pelo ponto de contato 24/7 da sua instituição. Minuta: `ipanalise.py oficio --jurisdicao OUTRA --tipo preservacao`. Preservação **congela o que existe** no momento do pedido; não recupera dado já apagado.
3. **Planeje o instrumento de obtenção dentro da janela** — cooperação jurídica (MLAT, carta rogatória, auxílio direto pela autoridade central), ordem de produção local ou divulgação voluntária conforme a política do provedor.
4. **Controle a janela** — `ipanalise.py prazos "<data do fato>" --fuso <fuso> --preservacao-em AAAA-MM-DD --regime US|UE|BUDAPESTE`.
5. **Registre** a data e o canal do pedido, o número de referência dado pelo provedor e a resposta.

### B.3 Cuidados

- **Retenção ≠ preservação.** O prazo de retenção é obrigação (ou prática) do provedor; a preservação é pedido da autoridade sobre dado que ainda existe.
- **Dados de assinante × registros × conteúdo** têm regimes diferentes na maioria dos países.
- **Provedor estrangeiro costuma exigir o instrumento do seu próprio país**; a requisição brasileira, por si só, não o obriga.
- **IP de CDN/nuvem/VPN** quase sempre leva a provedor estrangeiro e a um cliente (conta), não a um assinante residencial.
- Use o idioma exigido pelo provedor (inglês é o mais comum); a minuta traz resumo em português.

## §C. Como a skill trata a jurisdição

- `--jurisdicao BR` (**padrão**): usa os prazos do Marco Civil (conexão 12 meses; aplicação 6 meses) como referência e as minutas brasileiras.
- `--jurisdicao OUTRA`: **não presume prazo de guarda** (`retencao_desconhecida`); aceita `--retencao conexao=MESES aplicacao=MESES` quando você souber o prazo (lei local ou guia do provedor); `oficio` gera só a **solicitação de preservação** bilíngue.
- IP registrado fora do Brasil analisado com `--jurisdicao BR`: a `tipologia` acrescenta a ressalva de que o art. 13 do MCI pode **não** se aplicar ao provedor de conexão estrangeiro (e de que o art. 15 pode se aplicar a aplicação ofertada ao público brasileiro).
- Janelas de preservação: `prazos --preservacao-em … --regime BR|US|UE|BUDAPESTE`.
