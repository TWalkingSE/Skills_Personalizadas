# IP privado e demais endereços não públicos — tabelas de consulta

Complementa a seção 6 do `SKILL.md`. `ipanalise.py normalizar --origem <tipo>` já devolve a leitura de contexto do tipo de origem; `tipologia` explica a faixa e o caminho. Estas tabelas servem para conferir e para redigir.

## 1. Faixas e significado

| Faixa | Nome | O que indica | Tratamento |
|---|---|---|---|
| `10.0.0.0/8` · `172.16.0.0/12` · `192.168.0.0/16` | Privado (RFC 1918) | Host de rede local atrás de NAT: residência, empresa, órgão, Wi-Fi/hotspot, VPN interna | Sem consulta externa; reconstituir o contexto da rede |
| `fc00::/7` (na prática `fd00::/8`) | ULA IPv6 (RFC 4193) | Equivalente IPv6 do endereço privado | Idem |
| `100.64.0.0/10` | CGNAT (RFC 6598) | Espaço de trânsito do provedor: muitos assinantes compartilham o mesmo IP público. Algumas redes de sobreposição/VPN também usam esta faixa | Sem consulta externa; pedir ao provedor IP público + **porta** + hora |
| `127.0.0.0/8` · `::1` | Loopback | A própria máquina. Em log de servidor: acesso local, serviço interno/proxy reverso na mesma máquina ou cliente real mascarado (procurar cabeçalho de encaminhamento). Em registro DNS de domínio: bloqueio, teste, sinkhole ou configuração interna | Não atribuir a ninguém; registrar o contexto |
| `169.254.0.0/16` · `fe80::/10` | Link-local | Comunicação restrita ao mesmo segmento; em IPv4, geralmente falha de DHCP (autoconfiguração) | Indica host sem configuração de rede válida ou tráfego local |
| `0.0.0.0/8` · `::/128` | Não especificado / "esta rede" | Valor padrão, "qualquer endereço" ou campo vazio; em DNS, `0.0.0.0` costuma ser bloqueio | Tratar como ausência de dado, não como indicador |
| `192.0.2.0/24` · `198.51.100.0/24` · `203.0.113.0/24` · `2001:db8::/32` | Documentação | Reservados para exemplos | Em evidência real: dado de exemplo, modelo, anonimizado/ofuscado ou erro — não é origem real |
| `198.18.0.0/15` | Benchmarking | Testes de desempenho de rede | Provável ambiente de laboratório/teste |
| `224.0.0.0/4` · `ff00::/8` | Multicast | Destino de grupo; não é origem de conexão | Em campo de origem: dado inconsistente |
| `240.0.0.0/4` · `255.255.255.255` | Reservado · broadcast | Não são endereços de host | Dado inconsistente ou tráfego de broadcast local |
| `::ffff:0:0/96` · `64:ff9b::/96` · `2002::/16` · `2001::/32` · `192.88.99.0/24` | Transição IPv4/IPv6 (mapeado, NAT64, 6to4, Teredo) | Podem embutir um IPv4 | `normalizar` extrai o IPv4 como registro **derivado** (indício). Mapeado e 6to4: IPv4 do host/gateway. **Teredo:** cliente (invertido) e servidor — só o cliente é analisável. **NAT64:** o IPv4 embutido é o **destino** traduzido, não o cliente |

## 2. Onde o IP privado aparece e como ler (`--origem`)

| `--origem` | Onde apareceu | Leitura | Próximo passo |
|---|---|---|---|
| `print-wifi` | Print de "meu IP"/configurações de Wi-Fi do celular ou computador (vítima ou investigado) | Endereço local do dispositivo na rede; **não** é o IP de internet | Obter o IP público visto pelo serviço: logs da aplicação, e-mail/plataforma, provedor — com data, hora e fuso |
| `email` | Cabeçalho de e-mail (`Received`, `X-Originating-IP`) | Máquina de origem atrás de NAT ou servidor interno. Só os trechos inseridos por servidores confiáveis são confiáveis; trechos mais antigos podem ser forjados | `ipanalise.py cabecalho` localiza o primeiro `Received` com IP público inserido por servidor confiável |
| `log-web` | Log de servidor/aplicação | Proxy reverso, balanceador, CDN, WAF ou NAT na frente da aplicação | Procurar o IP do cliente em `X-Forwarded-For`/`Forwarded`/`X-Real-IP`/`CF-Connecting-IP` (o cliente pode forjá-los; vale o inserido por proxy confiável — `cabecalho --xff --n-proxies`) |
| `log-interno` / `firewall` | Log de organização (firewall, proxy, DHCP, AD) | Host interno da própria organização | A organização identifica o equipamento por concessão DHCP/ARP (MAC, hostname), autenticação e inventário, na hora exata |
| `camera-iot` | Painel de câmera, DVR, roteador, IoT | Dispositivo na rede local | Se estiver acessível pela internet, há IP público, redirecionamento de porta/UPnP ou nuvem do fabricante: esse é o elo público |
| `dns` | Registro DNS (A/AAAA) de domínio apontando para IP privado ou loopback | Configuração interna (split-horizon), erro, ambiente de teste, bloqueio/sinkhole ou rebinding | Consultar DNS histórico; não atribuir a titular algum |
| `vpn` | Interface de VPN/túnel (concentrador, cliente) | Endereço virtual do túnel, não da pessoa | O IP público do cliente está nos logs do concentrador VPN |
| `malware` | Relatório de malware/IOC | Configuração de rede da vítima ou do laboratório; C2/movimento lateral na rede interna; ou ofuscação | Tratar como indicador interno **com** o contexto da rede |
| `bo` | Boletim de ocorrência/denúncia citando IP privado | A vítima leu um endereço local | Orientar a obter o IP público do evento (logs da plataforma/provedor), com data, hora e fuso |
| `hotspot` | Wi-Fi público/hotspot (café, hotel, transporte, evento) | Muitos usuários na mesma rede; DHCP local | Operador do local: logs de DHCP/portal cativo/autenticação, se existirem |
| `outro` | Origem não listada | Contexto desconhecido | Descrever a origem antes de qualquer conclusão |

## 3. Cuidados adicionais

- **Somente passivo:** não faça ping, varredura nem acesso a endereços privados de terceiros; mesmo na rede de uma organização, só com autorização do responsável.
- **Terminação `.1` ou `.254`** em faixa privada sugere o gateway/roteador (indício): o IP é o equipamento de borda, não o usuário.
- **IPv6:** normalmente cada dispositivo tem endereço global (não há NAT por padrão). Um IPv6 global de rede doméstica é **público**: analise o prefixo (/56 ou /64). ULA e link-local são os equivalentes do privado.
- Não declare o IP "falso" ou "forjado" só porque é privado: pode ser legítimo, apenas sem valor fora da rede de origem.
- **Triagem:** IPs não públicos entram como ⚪ indeterminado (contexto de rede necessário) e não contam para o score de relevância.
- **Plataforma:** modele como entidade `private_ip` com atributo de escopo de rede; nunca mescle entidades por endereço privado igual.
- MAC aleatório (privacidade de Wi-Fi) em celulares atuais impede tratar o MAC como identificador estável entre redes.
