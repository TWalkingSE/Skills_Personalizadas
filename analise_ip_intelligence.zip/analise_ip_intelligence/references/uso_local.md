# Uso local (na máquina do analista) e modo web

## 1. Por que rodar localmente

O script faz a coleta passiva, guarda cada resposta bruta com data/hora UTC e **SHA-256**, mantém cache e trilha de auditoria. Isso só vale como evidência quando roda onde há rede. Em casos reais, **prefira o modo local**. O modo web (ferramenta de leitura do Claude) serve para consulta exploratória e **rebaixa a confiança** (item 4).

## 2. Requisitos

- Python 3.9+ e **somente biblioteca padrão** (nenhum `pip install`).
- Fusos IANA (`America/Maceio`, `America/Sao_Paulo`) exigem a base de fusos do sistema. No Windows: `pip install tzdata`. Sem ela, use deslocamento fixo, como `--fuso=-03:00`.
- Rede liberada para as fontes públicas usadas: `stat.ripe.net`, `rdap.org`, `rdap.registro.br`, `check.torproject.org`, `internetdb.shodan.io`, `www.peeringdb.com`, `proxycheck.io`, `ipinfo.io`, `api.db-ip.com` e as listas oficiais de faixas (`ip-ranges.amazonaws.com`, `www.gstatic.com`, `docs.oracle.com`, `www.cloudflare.com`, `api.fastly.com`, `developers.google.com`, `www.bing.com`, `openai.com`, `mask-api.icloud.com`). A lista exata está em `ipa_fontes.LISTAS`; a do Azure não é consultada automaticamente (download manual do Microsoft Download Center).
- Execute com `python3 -I scripts/ipanalise.py ...` (modo isolado: não carrega arquivos da pasta atual).

## 3. Fluxo típico

```bash
mkdir caso && cd caso
python3 -I ../scripts/ipanalise.py normalizar log.txt --fuso America/Maceio --origem log-web --saida normalizado.json
python3 -I ../scripts/ipanalise.py consultar normalizado.json --data-evento "2026-03-14 21:45:10" --fuso America/Maceio --saida consulta.json --brutos respostas_brutas
python3 -I ../scripts/ipanalise.py tipologia consulta.json --normalizado normalizado.json --md tipologia.md
python3 -I ../scripts/ipanalise.py prazos "2026-03-14 21:45:10" --fuso America/Maceio
python3 -I ../scripts/ipanalise.py oficio --tipo preservacao --ip <IP> --data-hora "2026-03-14 21:45:10" --fuso America/Maceio --consulta consulta.json --saida minuta.md
python3 -I ../scripts/ipanalise.py validar relatorio.md
```

Dicas:
- Valor de fuso que começa com sinal vai com `=`: `--fuso=-03:00` (sem o `=`, o argparse trata `-03:00` como opção).
- `--perfil basico` faz só RIPEstat + RDAP + PTR + Tor (menos exposição do indicador a terceiros); `completo` (padrão) acrescenta listas oficiais, InternetDB, PeeringDB, ipinfo e DB-IP, Registro.br, `routing-history` e ExoneraTor (link manual).
- **proxycheck.io (sem cadastro):** já vem no perfil `completo`. Sem chave são **100 consultas/dia** (por IP de origem); a skill mantém um contador local aproximado em `.cache_ip/proxycheck_cota.json` e declara como lacuna os IPs que não couberam. Chave gratuita (1.000/dia): `export PROXYCHECK_KEY=...` (Windows: `$env:PROXYCHECK_KEY="..."`) — **só por variável de ambiente**; ela nunca é gravada. Para fato antigo, `--proxycheck-dias 60`. Para pular: `--sem-proxycheck`; para usar só ele além do básico: `--perfil basico --proxycheck`. **Primeira execução:** confira `proxycheck.formato_reconhecido` no `consulta.json` (o adaptador não foi testado ao vivo; ver `fontes_e_consultas.md` item 7.1).
- **Fora do Brasil:** `--jurisdicao OUTRA` (em `consultar`, `tipologia`, `prazos`, `oficio`) para não presumir o prazo do Marco Civil; informe `--retencao conexao=24` se souber o prazo do provedor.
- `consultar` imprime o aviso **"Esta etapa requer consulta externa"**: cada fonte de terceiros registra o interesse no IP (OPSEC). Em caso sensível, use `--perfil basico`, `--sem-geo2`, ou rode a partir de rede/identidade adequadas à sua instituição.
- O cache fica em `.cache_ip` (TTL 24 h). Use `--atualizar` para forçar nova consulta e `--cache ""` para desativá-lo.
- Guarde `respostas_brutas/` junto do caso: ali estão as respostas originais, a URL, o horário UTC e o SHA-256 de cada consulta, mais `auditoria.jsonl`.

## 4. Modo web (sem rede no shell)

1. Abra as URLs de `fontes_e_consultas.md` com a ferramenta de leitura web.
2. Transcreva os campos para um JSON no formato do `consultar`, marcando em **cada** item de `fontes` `"origem_dado": "transcrito_web"` (sem `sha256_resposta`).
3. Rode `tipologia`/`oficio` normalmente. O motor trata a fonte como **não preservada**: evidência confirmatória sem SHA-256 cai de Confirmado para **Provável** e a limitação *"Fontes TRANSCRITAS … evidência não preservada"* entra no relatório.
4. Antes de usar em peça, refaça a consulta no modo local.

## 5. Testes

`python3 tests/run_tests.py` (≈ 80 testes, sem rede). Rode depois de editar regras, operadoras ou scripts. Os testes provam a **lógica** com respostas simuladas; não provam a disponibilidade nem o conteúdo atual das fontes.

## 6. Limites conhecidos

- Pacotes de operadoras (`references/operadoras/*.json`): opcionais, orientativos, todas as linhas com `verificado: false`. Só existe pacote para o Brasil; o motor não depende deles.
- proxycheck.io: adaptador escrito a partir da documentação pública e **testado apenas com respostas simuladas**; a cota local é aproximada (a real é por IP de origem).
- Fontes de varredura e reputação (InternetDB, ipinfo, DB-IP) devolvem o estado **atual**; para o passado use `routing-history` (já integrado), ExoneraTor (manual) e DNS passivo (outras skills).
- O script não faz varredura nem toca a rede de terceiros; IPs não públicos nunca são enviados a nenhuma fonte.
