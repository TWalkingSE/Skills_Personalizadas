# Fontes e Consultas (qualquer país) e contexto jurídico

Leia esta referência ao montar a coleta (etapa COLETA DE DADOS) ou quando precisar fundamentar pedidos ao provedor. Todas as consultas listadas são **passivas** (registro, roteamento, DNS e bases públicas). Registre sempre: fonte, URL, data/hora UTC da consulta e resultado (§71–72 da especificação).

> **Data da consulta ≠ data do evento.** Quase todas as fontes abaixo devolvem o estado **atual**. Para eventos passados, use as fontes históricas marcadas com 🕒 e declare a limitação quando não houver histórico.

---

## 1. Como consultar neste ambiente

1. **Script (modo local — preferido em caso real)** — `scripts/ipanalise.py consultar` faz a coleta passiva e guarda cada resposta bruta com URL, data/hora UTC e SHA-256. `--perfil basico` = RIPEstat (prefixo/ASN, geolocalização) + RDAP + PTR + lista Tor; `--perfil completo` (padrão) acrescenta listas oficiais de cloud/CDN/crawlers/iCloud Private Relay, Shodan InternetDB, PeeringDB, `as-overview`, **proxycheck.io** (VPN/proxy/Tor; item 7.1), ipinfo e DB-IP (2ª/3ª geolocalização), Registro.br (só para IPs brasileiros; o RDAP via `rdap.org` cobre todos os RIRs) e, com `--data-evento`, `routing-history` (ASN na data do fato) e o link do ExoneraTor. Detalhes e comandos em `uso_local.md`.
2. **Ferramenta de busca/leitura web do Claude (modo web — exploratório)** — se o shell não tiver rede, abra as URLs abaixo e transcreva os campos para um JSON no formato do `consultar`, marcando cada fonte com `"origem_dado": "transcrito_web"` (sem `sha256_resposta`). O motor de tipologia rebaixa "Confirmado" a "Provável" e declara que a evidência não foi preservada. Refaça no modo local antes de usar em peça.
3. **Fontes com chave/API paga** — só com chave fornecida pelo usuário, **por variável de ambiente** (ex.: `PROXYCHECK_KEY`); a chave nunca vai a argumento de linha de comando, relatório, JSON, auditoria, cache ou nome de arquivo (as URLs registradas mostram `key=***`). Nunca contornar limites ou termos de uso.
4. **Nunca** contornar bloqueio de rede, robots.txt ou paywall.
5. **Consulta externa expõe o indicador** (OPSEC): cada fonte de terceiros registra o interesse no IP. IPs não públicos nunca são enviados.
6. **Resposta 404 do InternetDB** significa "sem registro" (o IP não foi visto pelo Shodan), não erro: o script registra a ausência.

---

## 2. Registro (RDAP / WHOIS) — confiabilidade NÍVEL 1

| Fonte | Consulta | Observações |
|---|---|---|
| RDAP bootstrap | `https://rdap.org/ip/<IP>` | Redireciona ao RIR/NIR responsável. Preferir RDAP a WHOIS (§4) |
| LACNIC RDAP | `https://rdap.lacnic.net/rdap/ip/<IP>` | América Latina e Caribe |
| **Registro.br (NIC.br)** | `https://rdap.registro.br/ip/<IP>` · `https://registro.br/tecnologia/ferramentas/whois/` | **NIR do Brasil** (sob a LACNIC): blocos alocados a provedores brasileiros, com titular, documento (CNPJ do provedor), contato de abuso e responsável técnico. Consultado pelo script **somente** para IPs brasileiros. Pode bloquear leitores automáticos — usar o script ou o navegador |
| Outros NIRs (JPNIC, KRNIC, TWNIC, CNNIC, IRINN…) | sites dos próprios NIRs | **Não automatizado.** Em IP da Ásia-Pacífico, o `rdap.org`/APNIC mostra o bloco do NIR; detalhes do sub-bloco exigem consulta manual ao NIR |
| ARIN / RIPE NCC / APNIC / AFRINIC | via `rdap.org` | Demais regiões |
| RIPEstat whois | `https://stat.ripe.net/data/whois/data.json?resource=<IP>` | Agrega registros do RIR + IRR |

Lembrete obrigatório: *"O registrante do bloco não necessariamente corresponde ao usuário final do IP."*

---

## 3. Roteamento / ASN / BGP — NÍVEL 2

| Fonte | Consulta | Uso |
|---|---|---|
| RIPEstat prefix-overview | `https://stat.ripe.net/data/prefix-overview/data.json?resource=<IP>` | Prefixo anunciado, ASN de origem, titular do ASN, bloco IANA; múltiplos ASNs → MOAS |
| 🕒 RIPEstat routing-history | `https://stat.ripe.net/data/routing-history/data.json?resource=<IP ou prefixo>` | **Histórico de origens** (ASN × período) — essencial para ANALISE_TEMPORAL e para a data do evento |
| RIPEstat as-overview | `https://stat.ripe.net/data/as-overview/data.json?resource=AS<N>` | Nome e titular do ASN |
| RIPEstat announced-prefixes | `https://stat.ripe.net/data/announced-prefixes/data.json?resource=AS<N>` | Prefixos anunciados pelo ASN (pivô ASN → prefixos) |
| RIPEstat asn-neighbours | `https://stat.ripe.net/data/asn-neighbours/data.json?resource=AS<N>` | Vizinhos (upstreams/peers) — contexto de rede, **não** vínculo entre usuários (§87) |
| Hurricane Electric BGP Toolkit | `https://bgp.he.net/ip/<IP>` · `https://bgp.he.net/AS<N>` | Visão rápida de prefixo, ASN, peers, IX |
| Team Cymru IP→ASN | DNS TXT `<IP invertido>.origin.asn.cymru.com` · whois `whois.cymru.com` | Mapeamento rápido em lote |

---

## 4. DNS / PTR / Domínios — NÍVEL 2

| Fonte | Consulta | Observações |
|---|---|---|
| PTR | `dig -x <IP>` · script `consultar` · `https://stat.ripe.net/data/reverse-dns-ip/data.json?resource=<IP>` | Padrões `dynamic`, `static`, `pool`, `dsl`, `cable`, `mobile`, nomes de cidade/POP → **indícios**, não fatos |
| 🕒 Passive DNS | SecurityTrails, VirusTotal, Validin, CIRCL (acesso autorizado) | Normalmente exige chave; separar domínios **atuais** × **históricos** (§9) |
| Certificate Transparency | `https://crt.sh/?q=<domínio>` | Pivô domínio ↔ certificado (busca por IP é limitada) |

---

## 5. Serviços expostos e certificados (dados de varredura de terceiros) — NÍVEL 3

| Fonte | Consulta | Observações |
|---|---|---|
| Shodan InternetDB | `https://internetdb.shodan.io/<IP>` | Gratuito, sem chave: portas, CPEs, hostnames, tags (ex.: `vpn`, `proxy`, `cloud`), CVEs. Dado **observado por terceiro** em data incerta. **404 = sem registro** |
| PeeringDB | `https://www.peeringdb.com/api/net?asn=<N>` | Tipo de rede **declarado pelo operador** do ASN (`info_type`: Cable/DSL/ISP, Enterprise, Educational/Research, Content…). Apoio, não prova; nem todo ASN está cadastrado |
| Shodan / Censys / FOFA / ZoomEye | API com chave | Banners, certificados TLS, histórico de serviços |

A skill **não** faz varredura própria (§14, §112).

---

## 6. Cloud, CDN e hospedagem — NÍVEL 1 (lista publicada pelo próprio provedor)

| Provedor | Lista oficial de faixas |
|---|---|
| AWS | `https://ip-ranges.amazonaws.com/ip-ranges.json` (com região e serviço) |
| Google Cloud | `https://www.gstatic.com/ipranges/cloud.json` (com região) |
| Microsoft Azure | "Azure IP Ranges and Service Tags" (download JSON semanal no Microsoft Download Center) |
| Oracle Cloud | `https://docs.oracle.com/en-us/iaas/tools/public_ip_ranges.json` |
| Cloudflare | `https://www.cloudflare.com/ips-v4` · `https://www.cloudflare.com/ips-v6` |
| Fastly | `https://api.fastly.com/public-ip-list` |
| Googlebot · Bingbot · GPTBot (crawlers — não são usuários) | `https://developers.google.com/search/apis/ipranges/googlebot.json` · `https://www.bing.com/toolbox/bingbot.json` · `https://openai.com/gptbot.json` |
| Apple iCloud Private Relay (saída) | `https://mask-api.icloud.com/egress-ip-ranges.csv` — o IP visto é do relay, não do usuário |

Para os demais (DigitalOcean, Vultr, Hetzner, OVH, Akamai/Linode, Alibaba, M247, etc.), use ASN + RDAP + PTR. IP em CDN/cloud → aplicar §51 e §101 (multi-tenant; baixo poder de atribuição).

---

## 7. Anonimização (VPN / proxy / Tor) — NÍVEL 2 a 3

| Fonte | Consulta | Observações |
|---|---|---|
| Tor — lista atual | `https://check.torproject.org/torbulkexitlist` | Saídas Tor **neste momento** |
| 🕒 **ExoneraTor** | `https://metrics.torproject.org/exonerator.html?ip=<IP>&timestamp=<AAAA-MM-DD>` | **Havia relay Tor nesse IP nessa data?** — a consulta correta para eventos passados. **Fluxo manual:** `consultar --data-evento` imprime o link já montado; o ExoneraTor trabalha com datas em **UTC** (um fato às 21h em UTC−3 já é o dia seguinte em UTC); salve a página (PDF/HTML) com SHA-256 e registre em `confirmacoes_manuais` (`{"tipo":"Tor","fonte":"ExoneraTor","resultado":"positivo","data":"AAAA-MM-DD","sha256":"…"}`) para o motor aceitar a confirmação histórica |
| Onionoo | `https://onionoo.torproject.org/details?search=<IP>` | Detalhes de relays atuais/recentes |
| **proxycheck.io** | API pública **sem cadastro** (100 consultas/dia): item 7.1 — **integrada ao `consultar`** | VPN, proxy, Tor, hospedagem, scraper, servidor comprometido, risco e tipo de rede. Base comercial → no máximo "Provável" |
| Outras bases comerciais | ipinfo (privacy), IPQualityScore, Spur (chaves) | Bases privadas e heurísticas → no máximo "Provável" sem confirmação do operador |
| Indícios técnicos | ASN de hospedagem, PTR genérico de datacenter, tags do InternetDB, portas típicas (OpenVPN 1194, WireGuard 51820, IPsec 500/4500) | Indícios — classificar como Possível/Provável (§11, §60) |

---

### 7.1 proxycheck.io (integrado)

- **API:** `https://proxycheck.io/v3/<IP>` (v3, estável desde 24/06/2026). A v2 (`/v2/`) é legada e continua disponível (`--proxycheck-versao v2`). Documentação: <https://proxycheck.io/api/>.
- **Limites (documentação do serviço, conferida em 2026-10-24):** **sem chave e sem cadastro, 100 consultas/dia**, contadas **por IP de origem** (e 100 endereços por requisição; cache compartilhado de 10 min); chave gratuita 1.000/dia; planos pagos 10.000+/dia. Há também limite por segundo, por região.
- **Como a skill consulta:** 1 IP por requisição (a resposta bruta de cada IP é preservada com SHA-256). Cada IP = 1 consulta. Resposta do cache local (24 h) **não gasta cota**; HTTP 401/403/429 **não** são cacheados. Contador **local e aproximado** em `<cache>/proxycheck_cota.json` (dia em UTC): a cota real é do IP de origem e pode ser compartilhada com outros usuários da mesma rede/NAT/VPN. Aviso a 80%; ao atingir o limite, os IPs restantes ficam como **lacuna declarada** (`--proxycheck-ignorar-cota` ignora só o contador local).
- **Chave opcional:** variável de ambiente `PROXYCHECK_KEY` (sobe o limite local para 1.000). Nunca por argumento de linha de comando.
- **Só IP público.** IP privado/CGNAT/documentação nunca é enviado. **Não** use o parâmetro `tag` com nome de caso.
- **Campos lidos (v3, nomes conforme a documentação):** `network` (`asn`, `range`, `hostname`, `provider`, `organisation`, `type` ∈ Residential · Business · Wireless · Hosting · null), `detections` (`proxy`, `vpn`, `tor`, `scraper`, `hosting`, `compromised`, `anonymous`, `risk` 0–100, `confidence` 0–100, `first_seen`, `last_seen`), `location`, `operator`, `attack_history`, `detection_history`, `last_updated`. Faixas de risco sugeridas pelo serviço: 0–25 · 26–50 · 51–75 · 76–100.
- **⚠ Validação do formato:** a documentação não traz um exemplo completo de resposta e o arquivo OpenAPI do serviço não pôde ser lido ao escrever esta skill; **o adaptador nunca foi testado contra a API ao vivo**. Na primeira execução na sua máquina, confira `resultados[].proxycheck.formato_reconhecido` no `consulta.json`. Se for `false`, a resposta bruta está em `respostas_brutas/` e **nada foi inferido** (a lacuna é declarada); ajuste `parse_proxycheck()` em `scripts/ipa_fontes.py`.
- **Como o motor usa:** detecção de VPN/proxy/Tor/hospedagem (peso 0,40–0,50) e tipo de rede (0,30–0,40) numa **família própria**; `confidence` < 50 reduz o peso (×0,7); **nunca confirma** (máximo "Provável"). Proxy + `Residential` → hipótese de **proxy residencial** (o assinante pode ser vítima). `compromised`, `scraper` e `risk` ≥ 76 viram tags de reputação (indício de abuso, não de autoria). Divergência com a lista oficial de saídas Tor é **declarada**; a lista oficial (e o ExoneraTor para o passado) prevalece.
- **Limites de leitura:** reflete a janela recente de detecção (`--proxycheck-dias`, 0,01–60; para fato antigo use `60`), não necessariamente a data do fato; IP móvel/CGNAT e gateways corporativos podem aparecer como "proxy" (falso positivo); `type` e `risk` são estimativas de terceiros.
- **Termos de uso:** confira os termos do proxycheck.io para o seu tipo de uso institucional; a documentação consultada não detalha uso comercial/institucional no plano sem chave.

---

## 8. Reputação e abuso — NÍVEL 4 (comunitário/agregador)

| Fonte | Observações |
|---|---|
| AbuseIPDB | Relatos comunitários com categoria e data (chave para API) |
| GreyNoise | Distingue varredura em massa/benigna de atividade dirigida |
| Spamhaus (ZEN/DROP) | DNSBL; consultas via resolvedores públicos podem ser recusadas |
| abuse.ch (ThreatFox, URLhaus, Feodo Tracker) | IOCs de malware/C2 |
| VirusTotal, AlienVault OTX | Agregadores (chave) |

Regra §13: *"Nunca afirmar que o proprietário do IP praticou determinado crime apenas porque o IP aparece em uma blacklist."*

---

## 9. Geolocalização — NÍVEL 3 (confiança BAIXA por definição)

RIPEstat `maxmind-geo-lite` (no script), ipinfo, ip-api, IP2Location, DB-IP. Compare ≥ 2 bases e registre divergências (§10, §66). Geolocalização de IP **nunca** é endereço físico; em redes móveis e CGNAT, costuma apontar o POP/cidade do provedor.

---

## 10. Contexto jurídico (Brasil e fora)

A tabela jurídica — **Parte A (Brasil):** Marco Civil, Decreto 8.771/2016, **Decreto 12.975/2026 — art. 15-A**, Lei 12.850/2013, STJ; **§B (exterior):** Convenção de Budapeste, 18 U.S.C. § 2703(f), Reg. (UE) 2023/1543 e cooperação internacional —, os prazos de guarda e a situação de verificação de cada citação estão em **`base_legal.md`** (fonte única; não duplicar aqui).

**Dados normalmente necessários para individualizar uma conexão (§97–98):** IP público, data, hora com segundos, **fuso horário**, **porta de origem** (obrigatória quando há CGNAT), protocolo e, idealmente, o IP/porta de destino. Sem a porta, a resposta do provedor pode listar vários assinantes.

**Canais:** contato de abuso do RDAP (incidente técnico; no Brasil, também o do Registro.br e o CERT.br, `cert@cert.br`) e, para dados de assinante, ofício/representação judicial no Brasil ou solicitação de preservação + cooperação internacional no exterior (minutas: `ipanalise.py oficio`, com `--jurisdicao OUTRA` para provedor estrangeiro).
