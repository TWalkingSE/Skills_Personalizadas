# Tabela de decisão da tipologia (`ipanalise.py tipologia`)

O motor é **determinístico e reprodutível**: o mesmo `consulta.json` com as mesmas regras dá o mesmo resultado. Ele não "adivinha" nem usa modelo de linguagem; só pesa indícios que já estão nas fontes consultadas. **Tipo de IP é indício, nunca prova de autoria.**

Parâmetros: `references/regras_tipologia.json` (limiares, forças, palavras-chave em vários idiomas, PTR, tags, portas, `proxycheck`, grupos, roteiro) e, **opcionalmente**, pacotes regionais de operadoras em `references/operadoras/*.json` (`BR.json` é um deles; `_modelo.json` é o gabarito). O motor **funciona sem nenhum pacote** e vale em qualquer país: os pacotes só acrescentam o indício "este ASN é de uma operadora de acesso". Para outra região, copie os arquivos, edite e passe `--regras` e `--operadoras` (arquivo ou pasta).

## 1. Etapas

1. **Evidências.** Cada indício vira uma evidência com `tipo`, `força` (0–1), `família` de fonte, `confirma` (é lista oficial/ExoneraTor?), `atual` (é do estado de hoje?) e `preservada` (há SHA-256 da resposta bruta?).
2. **Pontuação por tipo.** Dentro de uma **família** vale só a evidência mais forte (RDAP, nome do ASN e ipinfo repetem o **mesmo** registro; contá-los três vezes inflaria a confiança). Entre famílias independentes combina-se por "ou-ruidoso": `score = 1 − Π(1 − força)`.
3. **Escala.** `score ≥ 0,30` Possível · `≥ 0,60` Provável · **Confirmado** exige `score ≥ 0,90` **e** evidência confirmatória **preservada** (com SHA-256). Confirmatória sem preservação é rebaixada a Provável. Base comercial de VPN/proxy nunca passa de Provável.
4. **Volatilidade.** Tor/VPN/proxy comprovados só no estado **atual**, com fato **anterior** à consulta (≥ 2 dias), ficam em **Provável** até haver confirmação na data (ExoneraTor etc., registrada em `confirmacoes_manuais`).
5. **Primário × anonimização.** Se há indício de anonimização ≥ Provável (ou maior que o de base), o primário é o tipo de anonimização (Tor, VPN, proxy) e o tipo de base vira **papel** (ex.: VPN sobre datacenter).
6. **Conflitos.** Tipos de base de grupos diferentes (acesso × hospedagem × institucional), ou dois tipos exclusivos do grupo de acesso (Residencial × Móvel × Satélite) ≥ Possível geram **CONFLITO**: a classificação não é conclusiva e aparecem **hipóteses alternativas** com indícios a favor e contra. Papéis compatíveis (Tor sobre datacenter) não são alternativas.
7. **Acesso genérico.** `Acesso (ISP, fixo/móvel indeterminado)` só apoia Residencial/Móvel quando há evidência específica para eles; ASN de operadora que atende fixo e móvel **nunca** vira "residencial" sozinho.
8. **Saída.** Tipo, escala, qualificador, papéis, anonimização, conflitos, detentor, caminho, obstáculos, viabilidade, **dados para atribuição (tem/falta)**, **prazo de guarda**, limitações e **veredito** de uma linha.

## 2. Forças padrão (`forcas`)

| Evidência | Família | Força |
|---|---|---|
| Lista oficial de cloud/CDN/crawler/Private Relay | `lista_oficial` | 1,00 (confirmatória) |
| Tor — lista atual de saídas | `lista_oficial` | 0,95 (confirmatória, **atual**) |
| Confirmação manual preservada (ExoneraTor etc.) | `confirmacao_manual` | 1,00 (confirmatória, histórica) |
| Nome do ASN/RDAP/ipinfo/PeeringDB — palavra **forte** (AMAZON, M247, NORDVPN…) | `registro` | 0,60 |
| Nome — palavra **genérica** (HOSTING, VPN…) | `registro` | 0,45 |
| Institucional / satélite (nome) | `registro` | 0,45 / 0,55 |
| PeeringDB `info_type` (Cable/DSL/ISP, Enterprise, Educational…) | `peeringdb` | 0,35–0,50 |
| Pacote regional de operadoras (ASN → tipo de rede; opcional) | `operadora_conhecida` | 0,55 (acesso) · 0,45 (específico) |
| **proxycheck.io** — detecção de VPN / proxy / Tor / hospedagem | `proxycheck` | 0,50 · 0,50 · 0,45 · 0,40 (× 0,7 se `confidence` < 50; nunca confirma) |
| **proxycheck.io** — tipo de rede (`Residential`/`Wireless`/`Business`/`Hosting`) | `proxycheck` | 0,35 Residencial · 0,40 Móvel · 0,30 Corporativo · 0,40 Datacenter |
| proxycheck.io + `Residential` + proxy | `proxycheck` | "Proxy residencial" 0,45 (hipótese; o assinante pode ser vítima) |
| PTR (dynamic, pool, mobile, vpn, ec2…) | `ptr` | 0,30 |
| Tags do InternetDB (vpn, proxy, tor, cloud, cdn) | `base_comercial` | 0,30–0,45 |
| Portas típicas (1194, 51820, 3128…) | `portas` | 0,20 |

## 3. Exemplos calculados

| Situação | Cálculo | Resultado |
|---|---|---|
| PeeringDB "Cable/DSL/ISP" (0,50) + PTR `dynamic` (0,30) | 1 − 0,5 × 0,7 = **0,65** | Residencial — **Provável** |
| IP em `ip-ranges.amazonaws.com` (1,0, SHA-256) | ≥ 0,90 + confirmatória preservada | Datacenter/nuvem — **Confirmado, na data da consulta** |
| IP na lista de saídas Tor de hoje; fato de 7 meses atrás | 0,95 confirmatória atual, tipo volátil | Tor — **Provável** + pedido de ExoneraTor |
| ASN M247 (0,60) + tag `vpn` (0,40) + portas 1194/51820 (0,20) | Datacenter: 0,60 (Provável); VPN: 1 − 0,6 × 0,8 = 0,52 (Possível) | primário **Datacenter/nuvem (Provável)**; VPN entra como **papel** (Possível) e a anonimização sai como "Possível (VPN)". Com 0,60+ de indício de VPN, o primário passaria a ser VPN |
| ISP (PeeringDB 0,5 + PTR 0,3 → Residencial 0,65) + tag `cloud` (0,3 → Datacenter) | grupos diferentes ≥ Possível | **CONFLITO** declarado; alternativas listadas |

**Leituras importantes do proxycheck.io:** é uma família **independente** de InternetDB e de PeeringDB, então se combina com elas por "ou-ruidoso" (ex.: proxycheck VPN 0,50 + tag `vpn` do InternetDB 0,40 → 0,70, **Provável**). Mesmo assim continua base comercial: **não passa de Provável**. Se a lista oficial do Tor Project e o proxycheck divergem sobre Tor, a divergência é declarada e a lista oficial prevalece. `compromised`, `scraper` e `risk` ≥ 76 não mudam o tipo: entram como tags de reputação (indício de abuso, não de autoria).

## 4. IP não público

`classificar_nao_publico` não usa o motor acima: a faixa é fato objetivo (**Confirmado — faixa IANA**), sem consulta externa. Devolve o significado da faixa, o contexto de rede (`--origem` do `normalizar`), o IP público a buscar, a retenção curta de DHCP/NAT ("PRESERVAR JÁ") e o alerta de não correlacionar por IP privado.

## 5. O que o motor **não** faz

- Não decide autoria, titular nem usuário.
- Não substitui a requisição ao provedor (ver `base_legal.md`).
- Não vê o passado: usa o estado da consulta. Com `--data-evento` anterior à consulta, **declara** a limitação (e usa `routing-history` quando a rede permite).
- Não reduz a incerteza de fontes ruins: se três bases comerciais copiam o mesmo dado, continuam sendo indícios.

## 6. Como ajustar sem quebrar

Edite uma cópia do JSON de regras; rode `python3 tests/run_tests.py`. Mudanças de limiar ou de força (inclusive as do bloco `proxycheck`) alteram escalas: registre no relatório que usou regras personalizadas (o campo `regras` do `tipologia.json` traz o arquivo usado).
