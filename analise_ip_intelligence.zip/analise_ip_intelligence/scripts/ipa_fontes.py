#!/usr/bin/env python3
"""
Fontes adicionais da coleta passiva (perfil "completo" do subcomando `consultar`) — somente stdlib.

Todas as consultas são passivas e de fontes públicas. Cada função recebe `ctx["baixar"]` (a função de
download do ipanalise.py, com cache, retry, SHA-256 e trilha de auditoria) para não duplicar a lógica
de preservação. Fonte indisponível vira LACUNA declarada — nunca inferência.

Atenção ao significado de AUSÊNCIA: não constar nas listas oficiais de cloud/CDN NÃO prova que o IP não
seja de hospedagem (as listas cobrem só alguns provedores); `cloud_listas_consultadas` registra o que
foi realmente verificado.
"""
import datetime as dt
import ipaddress
import json
import os
import re
import unicodedata
import urllib.parse

import ipa_comum as C

NIVEL_FONTE = {
    "RDAP": 1, "Registro.br RDAP": 1, "Tor bulk exit list": 1,
    "RIPEstat prefix-overview": 2, "RIPEstat routing-history": 2, "RIPEstat as-overview": 2,
    "RIPEstat reverse-dns-ip": 2, "DNS reverso": 2,
    "RIPEstat maxmind-geo-lite": 3, "Shodan InternetDB": 3, "PeeringDB": 3, "ipinfo": 3, "DB-IP": 3,
    "proxycheck.io": 3,
}


# ----------------------------------------------------------------------------- listas oficiais
def _p_aws(j):
    out = [(p.get("ip_prefix"), {"servico": p.get("service"), "regiao": p.get("region")}) for p in j.get("prefixes", [])]
    out += [(p.get("ipv6_prefix"), {"servico": p.get("service"), "regiao": p.get("region")}) for p in j.get("ipv6_prefixes", [])]
    return out


def _p_gcp(j):
    return [(p.get("ipv4Prefix") or p.get("ipv6Prefix"), {"servico": p.get("service"), "regiao": p.get("scope")})
            for p in j.get("prefixes", [])]


def _p_oracle(j):
    out = []
    for reg in j.get("regions", []):
        for c in reg.get("cidrs", []):
            out.append((c.get("cidr"), {"regiao": reg.get("region"), "servico": ",".join(c.get("tags", []) or [])}))
    return out


def _p_fastly(j):
    return [(x, {}) for x in (j.get("addresses", []) + j.get("ipv6_addresses", []))]


def _p_bot(j):
    return [(p.get("ipv4Prefix") or p.get("ipv6Prefix"), {}) for p in j.get("prefixes", [])]


def _p_linhas(texto):
    return [(l.strip(), {}) for l in texto.splitlines() if l.strip() and not l.startswith("#")]


def _p_icloud(texto):
    out = []
    for l in texto.splitlines():
        partes = l.split(",")
        if partes and "/" in partes[0]:
            out.append((partes[0].strip(), {"regiao": ",".join(x for x in partes[1:3] if x)}))
    return out


LISTAS = {
    "aws": {"nome": "AWS", "cat": "Datacenter/nuvem", "fmt": "json", "parse": _p_aws,
            "urls": ["https://ip-ranges.amazonaws.com/ip-ranges.json"]},
    "gcp": {"nome": "Google Cloud", "cat": "Datacenter/nuvem", "fmt": "json", "parse": _p_gcp,
            "urls": ["https://www.gstatic.com/ipranges/cloud.json"]},
    "oracle": {"nome": "Oracle Cloud", "cat": "Datacenter/nuvem", "fmt": "json", "parse": _p_oracle,
               "urls": ["https://docs.oracle.com/en-us/iaas/tools/public_ip_ranges.json"]},
    "cloudflare": {"nome": "Cloudflare", "cat": "CDN", "fmt": "texto", "parse": _p_linhas,
                   "urls": ["https://www.cloudflare.com/ips-v4", "https://www.cloudflare.com/ips-v6"]},
    "fastly": {"nome": "Fastly", "cat": "CDN", "fmt": "json", "parse": _p_fastly,
               "urls": ["https://api.fastly.com/public-ip-list"]},
    "googlebot": {"nome": "Googlebot", "cat": "Crawler/robô", "fmt": "json", "parse": _p_bot,
                  "urls": ["https://developers.google.com/search/apis/ipranges/googlebot.json"]},
    "bingbot": {"nome": "Bingbot", "cat": "Crawler/robô", "fmt": "json", "parse": _p_bot,
                "urls": ["https://www.bing.com/toolbox/bingbot.json"]},
    "gptbot": {"nome": "GPTBot (OpenAI)", "cat": "Crawler/robô", "fmt": "json", "parse": _p_bot,
               "urls": ["https://openai.com/gptbot.json"]},
    "icloud": {"nome": "Apple iCloud Private Relay (egress)", "cat": "iCloud Private Relay (CPN)", "fmt": "texto",
               "parse": _p_icloud, "urls": ["https://mask-api.icloud.com/egress-ip-ranges.csv"]},
}


class IndiceCidr:
    """Índice por (versão, comprimento de prefixo): busca O(nº de comprimentos), não O(nº de prefixos)."""

    def __init__(self):
        self.por_tam = {4: {}, 6: {}}

    def add(self, cidr, info):
        try:
            net = ipaddress.ip_network((cidr or "").strip(), strict=False)
        except ValueError:
            return False
        self.por_tam[net.version].setdefault(net.prefixlen, {}).setdefault(int(net.network_address), []).append(info)
        return True

    def buscar(self, ip):
        achados, bits = [], ip.max_prefixlen
        classe = ipaddress.IPv4Network if ip.version == 4 else ipaddress.IPv6Network
        for plen, mapa in self.por_tam[ip.version].items():
            chave = int(ip) & (((1 << plen) - 1) << (bits - plen))
            for info in mapa.get(chave, []):
                achados.append({**info, "prefixo": str(classe((chave, plen)))})
        return sorted(achados, key=lambda x: -int(x["prefixo"].rsplit("/", 1)[1]))


def carregar_listas(baixar, pasta, chaves):
    """Baixa as listas pedidas UMA vez por execução. Retorna (indice, status_por_lista)."""
    idx, status = IndiceCidr(), {}
    for ch in chaves:
        cfg = LISTAS.get(ch)
        if not cfg:
            status[ch] = {"lista": ch, "ok": False, "erro": "lista desconhecida"}
            continue
        st = {"lista": ch, "nome": cfg["nome"], "ok": False, "urls": cfg["urls"], "prefixos": 0}
        entradas, erros = [], []
        for url in cfg["urls"]:
            reg, corpo = baixar(url, pasta, "*", f"Lista oficial {cfg['nome']}")
            st.update({k: reg.get(k) for k in ("consultado_em_utc", "sha256_resposta", "arquivo_bruto") if reg.get(k)})
            if not corpo or reg.get("erro"):
                erros.append(reg.get("erro") or "sem corpo")
                continue
            try:
                if cfg["fmt"] == "json":
                    entradas += cfg["parse"](C.json_ou_none(corpo) or {})
                else:
                    entradas += cfg["parse"](corpo.decode("utf-8", errors="replace"))
            except Exception as e:  # noqa
                erros.append(f"parse: {type(e).__name__}")
        for cidr, extra in entradas:
            cat = cfg["cat"]
            if ch == "aws" and "CLOUDFRONT" in (extra.get("servico") or "").upper():
                cat = "CDN"
            if idx.add(cidr, {"lista": ch, "provedor": cfg["nome"], "categoria": cat, **extra}):
                st["prefixos"] += 1
        st["ok"] = st["prefixos"] > 0 and not erros
        if erros:
            st["erro"] = "; ".join(erros)
        status[ch] = st
    return idx, status


# ----------------------------------------------------------------------------- coleta por IP
def _pres(reg):
    if reg.get("arquivo_bruto"):
        return "bruta+sha256"
    return "sha256 (sem arquivo bruto)" if reg.get("sha256_resposta") else "sem preservação"


def _buscar(ctx, r, url, indicador, nome, aceitar_404=False):
    reg, corpo = ctx["baixar"](url, ctx["pasta"], indicador, nome)
    for k in ("url", "url_final"):  # defesa em profundidade: chave de API nunca entra no registro (§157)
        if reg.get(k):
            reg[k] = C.redigir(reg[k])
    sem_registro = False
    if aceitar_404 and reg.get("status") == 404:
        reg.pop("erro", None)
        reg["nota"] = "sem registro na fonte (HTTP 404)"
        sem_registro, corpo = True, None
    r["fontes"].append({"fonte": nome, "nivel": NIVEL_FONTE.get(nome), "preservacao": _pres(reg), **reg})
    if reg.get("erro"):
        r["lacunas"].append(f"{nome} ({reg['erro']})")
    return C.json_ou_none(corpo), sem_registro


def _dt(txt):
    if not txt:
        return None
    try:
        d = dt.datetime.fromisoformat(str(txt).replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo else d.replace(tzinfo=dt.timezone.utc)


def origens_na_data(j, evento_utc):
    """routing-history do RIPEstat → origens (ASN) cujo anúncio cobre o instante do evento."""
    achados = []
    for bo in ((j or {}).get("data") or {}).get("by_origin") or []:
        origin = str(bo.get("origin"))
        asn = origin if origin.upper().startswith("AS") else f"AS{origin}"
        for pf in bo.get("prefixes") or []:
            for tl in pf.get("timelines") or []:
                ini, fim = _dt(tl.get("starttime")), _dt(tl.get("endtime"))
                if ini and fim and ini <= evento_utc <= fim:
                    achados.append({"asn": asn, "prefixo": pf.get("prefix"), "de": tl.get("starttime"), "ate": tl.get("endtime")})
    return achados


def consultar_extras(ip, r, ctx):
    """Acrescenta ao registro `r` os dados do perfil completo. Mutação in-place."""
    ipobj = ipaddress.ip_address(ip)
    # 1) listas oficiais de cloud/CDN (já baixadas; sem rede aqui)
    if ctx.get("indice") is not None:
        r["cloud_listas_consultadas"] = ctx["listas_ok"]
        r["cloud_listas_falhas"] = ctx["listas_falha"]
        r["cloud_match"] = []
        for m in ctx["indice"].buscar(ipobj):
            st = ctx["listas_status"].get(m["lista"], {})
            r["cloud_match"].append({**m, "fonte_url": (st.get("urls") or [None])[0],
                                     "consultado_em_utc": st.get("consultado_em_utc"),
                                     "sha256_resposta": st.get("sha256_resposta"), "arquivo_bruto": st.get("arquivo_bruto")})
        if ctx["listas_falha"]:
            r["lacunas"].append("listas oficiais indisponíveis: " + ", ".join(ctx["listas_falha"]))
    # 2) Shodan InternetDB (portas, tags, hostnames) — dado observado por terceiro, data incerta
    j, sem = _buscar(ctx, r, f"https://internetdb.shodan.io/{ip}", ip, "Shodan InternetDB", aceitar_404=True)
    if j:
        r["internetdb"] = {k: j.get(k) for k in ("ports", "tags", "hostnames", "cpes", "vulns")}
    elif sem:
        r["internetdb"] = {"sem_registro": True}
    # 3) PeeringDB e 4) as-overview por ASN (cache por execução)
    for asn in r.get("asn") or []:
        num = asn.upper().replace("AS", "")
        if num not in ctx["peeringdb"]:
            j, _ = _buscar(ctx, r, f"https://www.peeringdb.com/api/net?asn={num}", ip, "PeeringDB")
            dados = ((j or {}).get("data") or [])
            if dados:
                d0 = dados[0]
                tipos = d0.get("info_types") or ([d0["info_type"]] if d0.get("info_type") else [])
                ctx["peeringdb"][num] = {"asn": asn, "nome": d0.get("name"), "info_type": d0.get("info_type"),
                                         "info_types": tipos, "escopo": d0.get("info_scope"), "encontrado": True}
            elif j is not None:
                ctx["peeringdb"][num] = {"asn": asn, "encontrado": False}
        if num in ctx["peeringdb"]:
            r.setdefault("peeringdb", {})[asn] = ctx["peeringdb"][num]
        if num not in ctx["asinfo"]:
            j, _ = _buscar(ctx, r, f"https://stat.ripe.net/data/as-overview/data.json?resource=AS{num}", ip, "RIPEstat as-overview")
            d = (j or {}).get("data") or {}
            if d:
                ctx["asinfo"][num] = {"asn": asn, "titular": d.get("holder"), "anunciado": d.get("announced")}
        if num in ctx["asinfo"]:
            r.setdefault("as_info", {})[asn] = ctx["asinfo"][num]
    # 5) 2ª e 3ª geolocalização (terceiros; BAIXA confiabilidade; comparar, nunca escolher uma)
    if not ctx["sem_geo2"]:
        j, _ = _buscar(ctx, r, f"https://ipinfo.io/{ip}/json", ip, "ipinfo")
        if j and not j.get("bogon"):
            r["geolocalizacao_ipinfo"] = {k: j.get(k) for k in ("country", "region", "city", "loc", "org", "timezone", "hostname")}
        j, _ = _buscar(ctx, r, f"https://api.db-ip.com/v2/free/{ip}", ip, "DB-IP")
        if j and not j.get("errorCode") and not j.get("error"):
            r["geolocalizacao_dbip"] = {k: j.get(k) for k in ("countryCode", "stateProv", "city")}
    # 6) Registro.br (NIR do Brasil): titular, documento do provedor e contato de abuso
    pais_rdap = ((r.get("rdap") or {}).get("pais") or "").upper()
    paises_geo = {(g.get("country") or "").upper() for g in (r.get("geolocalizacao") or [])}
    if pais_rdap == "BR" or "BR" in paises_geo:
        j, _ = _buscar(ctx, r, f"https://rdap.registro.br/ip/{ip}", ip, "Registro.br RDAP")
        if j and j.get("objectClassName") == "ip network":
            ents = []
            for e in j.get("entities") or []:
                ents.append({"handle": e.get("handle"), "papeis": e.get("roles"), "nome": _vcard_nome(e),
                             "documentos": [{"tipo": p.get("type"), "id": p.get("identifier")} for p in e.get("publicIds") or []]})
            r["rdap_nir"] = {"handle": j.get("handle"), "nome": j.get("name"), "inicio": j.get("startAddress"),
                             "fim": j.get("endAddress"), "pais": j.get("country"), "entidades": ents,
                             "eventos": [{"acao": e.get("eventAction"), "data": e.get("eventDate")} for e in j.get("events") or []]}
    # 7) PTR de reserva via RIPEstat (quando o resolvedor local falhou)
    if not ctx["sem_ptr"] and not r.get("ptr"):
        j, _ = _buscar(ctx, r, f"https://stat.ripe.net/data/reverse-dns-ip/data.json?resource={ip}", ip, "RIPEstat reverse-dns-ip")
        res = (((j or {}).get("data") or {}).get("result")) or []
        if res:
            r["ptr"] = str(res[0]).rstrip(".")
            r["ptr_fonte"] = "RIPEstat reverse-dns-ip"
            r["lacunas"] = [x for x in r["lacunas"] if not x.startswith("PTR (")]


# ----------------------------------------------------------------------------- proxycheck.io
# Base comercial de detecção de VPN/proxy/Tor/hospedagem. API pública SEM cadastro: 100 consultas/dia por IP de
# origem (1.000/dia com chave gratuita). É INDÍCIO de terceiros, nunca prova; reflete a janela recente de detecção
# (parâmetro `days`), não necessariamente a data do fato. Chave SOMENTE pela variável de ambiente PROXYCHECK_KEY.
PROXYCHECK_LIMITE_SEM_CHAVE, PROXYCHECK_LIMITE_COM_CHAVE = 100, 1000
PROXYCHECK_AVISO = ("proxycheck.io é base comercial de terceiros: a detecção é INDÍCIO (não prova de autoria) e reflete a janela recente de "
                    "observação, não necessariamente a data do fato; o 'tipo de rede' é estimativa.")


def preparar_proxycheck(ativo, versao="v3", dias=None, limite=None, ignorar_cota=False, chave=None, cota_arquivo=None, agora_utc=None):
    """Monta o estado do adaptador (cota local, chave, versão). `chave` vem do ambiente; nunca é gravada em lugar algum."""
    agora_utc = agora_utc or dt.datetime.now(dt.timezone.utc)
    hoje = agora_utc.strftime("%Y-%m-%d")
    modo = "com_chave" if chave else "sem_chave"
    usadas = 0
    if cota_arquivo and os.path.exists(cota_arquivo):
        try:
            d = json.load(open(cota_arquivo, encoding="utf-8"))
            if d.get("data_utc") == hoje:
                usadas = int((d.get("usadas") or {}).get(modo, 0))
        except (ValueError, OSError, TypeError):
            usadas = 0
    return {"ativo": bool(ativo), "versao": versao, "dias": dias, "chave": chave or None, "modo": modo,
            "limite": limite or (PROXYCHECK_LIMITE_COM_CHAVE if chave else PROXYCHECK_LIMITE_SEM_CHAVE),
            "usadas": usadas, "usadas_inicio": usadas, "ignorar_cota": bool(ignorar_cota), "esgotada": False,
            "nao_consultados": 0, "avisos": [], "avisou_80": False, "cota_arquivo": cota_arquivo, "hoje": hoje}


def _cota_gravar(pc):
    if not pc.get("cota_arquivo"):
        return
    usadas = {}
    try:
        d = json.load(open(pc["cota_arquivo"], encoding="utf-8"))
        if d.get("data_utc") == pc["hoje"]:
            usadas = dict(d.get("usadas") or {})
    except (ValueError, OSError, TypeError):
        usadas = {}
    usadas[pc["modo"]] = pc["usadas"]
    with open(pc["cota_arquivo"], "w", encoding="utf-8") as f:
        json.dump({"data_utc": pc["hoje"], "usadas": usadas,
                   "observacao": "Contador LOCAL e aproximado (dia em UTC). A cota real é por IP de origem no proxycheck.io e pode ser "
                                 "compartilhada com outros usuários da mesma rede."}, f, ensure_ascii=False, indent=2)


def url_proxycheck(pc, ip):
    q = []
    if pc["versao"] == "v2":
        q += ["vpn=3", "asn=1", "risk=1", "seen=1", "port=1"]  # v2 só devolve isso se pedido (vpn=3 gasta 2 unidades se proxy+VPN)
    if pc.get("dias") is not None:
        q.append(f"days={pc['dias']:g}")
    if pc.get("chave"):
        q.append("key=" + urllib.parse.quote(pc["chave"], safe=""))
    return f"https://proxycheck.io/{pc['versao']}/{ip}" + ("?" + "&".join(q) if q else "")


def _bool(v):
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        s = v.strip().lower()
        if s in ("yes", "true", "1"):
            return True
        if s in ("no", "false", "0"):
            return False
    if isinstance(v, (int, float)) and v in (0, 1):
        return bool(v)
    return None


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


def _primeiro(d, *chaves):
    for k in chaves:
        if isinstance(d, dict) and d.get(k) not in (None, ""):
            return d[k]
    return None


def _objeto_ip(j, ip):
    if not isinstance(j, dict):
        return None
    if isinstance(j.get(ip), dict):
        return j[ip]
    try:
        alvo = ipaddress.ip_address(ip)
    except ValueError:
        return None
    for k, v in j.items():  # IPv6 pode vir em notação diferente da enviada
        if isinstance(v, dict):
            try:
                if ipaddress.ip_address(k) == alvo:
                    return v
            except ValueError:
                continue
    return None


def parse_proxycheck(j, ip, versao="v3"):
    """Normaliza a resposta (v3 ou v2) SEM inventar: campo ausente fica None e `campos_ausentes` o declara.
    `formato_reconhecido=False` → a resposta bruta continua preservada, mas NADA é usado como evidência."""
    out = {"versao": versao, "status": None, "mensagem": None, "formato_reconhecido": False, "rede": {}, "deteccoes": {},
           "risco": None, "confianca": None, "primeira_vez": None, "ultima_vez": None, "pais_iso": None, "localizacao": None,
           "operador": None, "historico_ataques": None, "historico_deteccao": None, "atualizado_em": None, "campos_ausentes": []}
    if not isinstance(j, dict):
        return out
    out["status"], out["mensagem"] = j.get("status"), j.get("message")
    if out["status"] in ("denied", "error"):
        return out
    o = _objeto_ip(j, ip)
    if o is None:
        return out
    if isinstance(o.get("detections"), dict):  # ---- v3
        rede, d = o.get("network") or {}, o["detections"]
        out["rede"] = {"asn": rede.get("asn"), "faixa": rede.get("range"), "hostname": rede.get("hostname"),
                       "provedor": rede.get("provider"), "organizacao": rede.get("organisation"), "tipo": rede.get("type")}
        out["deteccoes"] = {k: _bool(d.get(k)) for k in ("proxy", "vpn", "tor", "scraper", "hosting", "compromised", "anonymous")}
        out["campos_ausentes"] = [f"detections.{k}" for k in ("proxy", "vpn", "tor", "hosting") if out["deteccoes"][k] is None]
        risco = _primeiro(d, "risk", "risk_score")
        out["risco"] = _int(risco if risco is not None else o.get("risk"))
        out["confianca"] = _int(d.get("confidence"))
        out["primeira_vez"], out["ultima_vez"] = d.get("first_seen"), d.get("last_seen")
        loc = o.get("location") if isinstance(o.get("location"), dict) else None
        out["localizacao"] = loc
        iso = _primeiro(loc, "country_code", "isocode", "iso_code", "country_iso")
        out["pais_iso"] = iso if isinstance(iso, str) and len(iso) == 2 else None
        out["operador"] = o.get("operator")
        out["historico_ataques"], out["historico_deteccao"] = o.get("attack_history"), o.get("detection_history")
        out["atualizado_em"] = o.get("last_updated")
        out["formato_reconhecido"] = True
    elif "proxy" in o:  # ---- v2 (legado)
        proxy, tipo = _bool(o.get("proxy")), (o.get("type") or "").strip()
        tl = tipo.lower()
        usos = {"residential", "wireless", "business", "hosting"}
        det = {k: False for k in ("proxy", "vpn", "tor", "scraper", "hosting", "compromised", "anonymous")}
        if proxy:
            det["vpn"] = tl in ("vpn", "openvpn")
            det["tor"] = tl == "tor"
            det["scraper"] = tl == "scraper"
            det["compromised"] = "compromised" in tl
            det["hosting"] = tl == "hosting"
            det["proxy"] = not (det["vpn"] or det["tor"] or det["scraper"] or det["compromised"] or det["hosting"])
            det["anonymous"] = True
        out["deteccoes"] = det if proxy is not None else {k: None for k in det}
        out["rede"] = {"asn": o.get("asn"), "faixa": o.get("range"), "hostname": o.get("hostname"), "provedor": o.get("provider"),
                       "organizacao": o.get("organisation"), "tipo": tipo if tl in usos else None,
                       "tipo_proxy_v2": tipo if proxy and tl not in usos else None}
        out["risco"] = _int(o.get("risk"))
        out["ultima_vez"] = o.get("last seen human")
        iso = o.get("isocode")
        out["pais_iso"] = iso if isinstance(iso, str) and len(iso) == 2 else None
        out["localizacao"] = {k: o.get(k) for k in ("continent", "country", "isocode", "region", "city", "latitude", "longitude") if o.get(k) is not None} or None
        out["formato_reconhecido"] = proxy is not None
    return out


def consultar_proxycheck(ip, r, ctx):
    """Consulta o proxycheck.io para UM IP PÚBLICO. Controla a cota local, preserva a resposta bruta (SHA-256) e nunca grava a chave."""
    pc = ctx.get("proxycheck")
    if not pc or not pc.get("ativo"):
        return
    if not C.classificar(ipaddress.ip_address(ip))[1]:  # defesa em profundidade: IP não público NUNCA sai da máquina
        r["proxycheck"] = {"consultado": False, "motivo": "IP não público: não enviado"}
        return
    url = url_proxycheck(pc, ip)
    em_cache = bool(ctx.get("em_cache") and ctx["em_cache"](url))
    if not em_cache and not pc["ignorar_cota"] and (pc["esgotada"] or pc["usadas"] >= pc["limite"]):
        pc["esgotada"] = True
        pc["nao_consultados"] += 1
        r["proxycheck"] = {"consultado": False, "motivo": f"cota diária local atingida ({pc['usadas']}/{pc['limite']})"}
        r["lacunas"].append(f"proxycheck.io não consultado: cota diária local atingida ({pc['usadas']}/{pc['limite']}); "
                            "repita amanhã (UTC), use chave gratuita (PROXYCHECK_KEY) ou --proxycheck-ignorar-cota")
        return
    j, _ = _buscar(ctx, r, url, ip, "proxycheck.io")
    reg = r["fontes"][-1]
    if not reg.get("cache") and reg.get("status") is not None:  # só consulta de REDE gasta cota
        pc["usadas"] += 1
        _cota_gravar(pc)
        if not pc["avisou_80"] and pc["usadas"] >= 0.8 * pc["limite"]:
            pc["avisou_80"] = True
            pc["avisos"].append(f"proxycheck.io: {pc['usadas']}/{pc['limite']} consultas locais usadas hoje (≥ 80% da cota).")
    pr = parse_proxycheck(j, ip, pc["versao"])
    pr["consultado"] = reg.get("status") is not None
    pr["aviso"] = PROXYCHECK_AVISO
    pr["janela_dias"] = pc.get("dias")
    st, msg = pr.get("status"), pr.get("mensagem")
    if st == "denied":
        if re.search(r"quer|exhaust|daily|limit|second|request", str(msg), re.I):
            pc["esgotada"] = True
        r["lacunas"].append(f"proxycheck.io negou a consulta: {msg or 'sem mensagem'}")
    elif st == "error":
        r["lacunas"].append(f"proxycheck.io retornou erro: {msg or 'sem mensagem'}")
    elif st == "warning" and msg:
        pc["avisos"].append(f"proxycheck.io (aviso): {msg}")
    elif pr["consultado"] and not pr["formato_reconhecido"] and not reg.get("erro"):
        r["lacunas"].append("proxycheck.io: formato de resposta NÃO reconhecido — resposta bruta preservada, nada foi inferido; "
                            "confira o JSON e, se a API mudou, ajuste parse_proxycheck()")
    if pr["formato_reconhecido"] and pr["campos_ausentes"]:
        r["lacunas"].append("proxycheck.io: campos ausentes na resposta: " + ", ".join(pr["campos_ausentes"]))
    r["proxycheck"] = pr


def resumo_proxycheck(ctx):
    pc = ctx.get("proxycheck")
    if not pc or not pc.get("ativo"):
        return []
    gastas = pc["usadas"] - pc["usadas_inicio"]
    L = [f"proxycheck.io: {gastas} consulta(s) de rede nesta execução; contador local de hoje (UTC): {pc['usadas']}/{pc['limite']} "
         f"({'com chave' if pc['chave'] else 'sem chave, sem cadastro'})."]
    if pc["nao_consultados"]:
        L.append(f"proxycheck.io: {pc['nao_consultados']} IP(s) NÃO consultado(s) por cota local — declarado como lacuna.")
    return L + pc["avisos"]


def finalizar(ip, r, ctx):
    """Passo final (sempre executado): ressalvas ligadas à data do evento e divergências entre fontes."""
    if ctx.get("evento_utc"):
        ev = ctx["evento_utc"]
        if ctx.get("perfil_completo"):
            recurso = r.get("prefixo") or ip
            ini, fim = (ev - dt.timedelta(days=1)).strftime("%Y-%m-%dT%H:%M"), (ev + dt.timedelta(days=1)).strftime("%Y-%m-%dT%H:%M")
            j, _ = _buscar(ctx, r, f"https://stat.ripe.net/data/routing-history/data.json?resource={recurso}&starttime={ini}&endtime={fim}",
                           ip, "RIPEstat routing-history")
            if j is not None:
                r["historico_roteamento"] = {"recurso": recurso, "evento_utc": ctx["evento_utc_txt"],
                                             "origens_na_data": origens_na_data(j, ev)}
        r["verificacao_manual"] = r.get("verificacao_manual", []) + [{
            "item": "Tor na data do evento",
            "como": f"https://metrics.torproject.org/exonerator.html?ip={ip}&timestamp={ev.strftime('%Y-%m-%d')}&lang=en",
            "motivo": "a lista de saídas Tor consultada é a ATUAL; ExoneraTor responde se havia relay nesse IP na data (em UTC — "
                      "se o horário do fato estiver perto da meia-noite UTC, consultar também o dia anterior/seguinte). "
                      "Registrar o resultado em 'confirmacoes_manuais' do JSON para o 'tipologia' usar."}]
        r["alertas_temporais"] = alertas_temporais(r, ev, ctx["agora_utc"])
    r["divergencias"] = divergencias(r)


def _vcard_nome(ent):
    try:
        for item in ent.get("vcardArray", [None, []])[1]:
            if item[0] == "fn":
                return item[3]
    except Exception:  # noqa
        pass
    return None


# ----------------------------------------------------------------------------- alertas e divergências
def alertas_temporais(r, ev, agora_utc):
    out = []
    for fonte in (r.get("rdap"), r.get("rdap_nir")):
        for e in (fonte or {}).get("eventos") or []:
            d = _dt(e.get("data"))
            if d and d > ev and (e.get("acao") or "").lower() in ("registration", "last changed", "reallocation",
                                                                  "reassignment", "transfer", "allocation"):
                out.append(f"RDAP: '{e['acao']}' em {e['data'][:10]}, DEPOIS do evento ({ev.strftime('%Y-%m-%d')}): "
                           "o titular/alocação do bloco na data do fato pode ser outro.")
    hr = r.get("historico_roteamento")
    if hr is not None:
        atuais = {a.upper() for a in (r.get("asn") or [])}
        na_data = {x["asn"].upper() for x in hr["origens_na_data"]}
        if not hr["origens_na_data"]:
            out.append("Histórico de roteamento: nenhum anúncio visível cobrindo o instante do evento nas fontes consultadas "
                       "(lacuna; não equivale a 'IP não anunciado').")
        elif atuais and na_data != atuais:
            out.append(f"ASN de origem na data do evento ({', '.join(sorted(na_data))}) DIFERE do atual "
                       f"({', '.join(sorted(atuais))}): usar o ASN da data do evento.")
    if (agora_utc - ev).days > 30:
        out.append("Geolocalização, reputação, serviços expostos, listas de cloud/CDN e lista Tor refletem o estado ATUAL, "
                   f"não o de {ev.strftime('%Y-%m-%d')}. Declarar a limitação em qualquer conclusão.")
    return out


_GENERICAS = {"TELECOM", "TELECOMUNICACOES", "TELECOMUNICACAO", "BRASIL", "BRAZIL", "SERVICOS", "SERVICE", "SERVICES",
              "INTERNET", "COMUNICACAO", "COMUNICACOES", "COMUNICACOES", "NETWORKS", "NETWORK", "REDES", "DE", "DA", "DO",
              "DOS", "DAS", "AND", "THE", "OF", "AS", "ASN", "SA", "LTDA", "LTD", "INC", "LLC", "CORP", "CO", "ME", "EPP"}


def _tokens(nome):
    if not nome:
        return set()
    t = unicodedata.normalize("NFKD", str(nome)).encode("ascii", "ignore").decode().upper()
    t = re.sub(r"\bAS\s?\d+\b", " ", t)
    t = re.sub(r"[^A-Z0-9]+", " ", t)
    return {x for x in t.split() if len(x) >= 3 and x not in _GENERICAS}


def divergencias(r):
    """Conflitos e diferenças ENTRE fontes — para declarar, nunca para escolher uma delas (regra 3)."""
    out = []
    pais = {}
    if (r.get("rdap") or {}).get("pais"):
        pais["RDAP"] = r["rdap"]["pais"].upper()
    geo = {(g.get("country") or "").upper() for g in (r.get("geolocalizacao") or []) if g.get("country")}
    if geo:
        pais["RIPEstat maxmind-geo-lite"] = "/".join(sorted(geo))
    if (r.get("geolocalizacao_ipinfo") or {}).get("country"):
        pais["ipinfo"] = r["geolocalizacao_ipinfo"]["country"].upper()
    if (r.get("geolocalizacao_dbip") or {}).get("countryCode"):
        pais["DB-IP"] = r["geolocalizacao_dbip"]["countryCode"].upper()
    pcl = r.get("proxycheck") or {}
    if pcl.get("formato_reconhecido") and pcl.get("pais_iso"):
        pais["proxycheck.io"] = pcl["pais_iso"].upper()
    distintos = {x for v in pais.values() for x in v.split("/")}
    if len(distintos) > 1:
        out.append({"campo": "país", "valores": pais, "gravidade": "conflito",
                    "leitura": "As fontes divergem; a informação NÃO é conclusiva. Geolocalização é estimativa de baixa confiança "
                               "(esperada em CDN/anycast/móvel). Não escolher uma fonte arbitrariamente."})
    # ASN: RIPEstat × ipinfo.org
    org = (r.get("geolocalizacao_ipinfo") or {}).get("org") or ""
    m = re.match(r"AS(\d+)", org)
    if m and r.get("asn") and f"AS{m.group(1)}" not in {a.upper() for a in r["asn"]}:
        out.append({"campo": "ASN", "valores": {"RIPEstat prefix-overview": r["asn"], "ipinfo": f"AS{m.group(1)}"},
                    "gravidade": "conflito", "leitura": "ASN de origem diferente entre fontes (possível MOAS, mudança recente ou base defasada)."})
    asn_pc = ((pcl.get("rede") or {}).get("asn") or "")
    if pcl.get("formato_reconhecido") and asn_pc and r.get("asn"):
        n = asn_pc.upper() if str(asn_pc).upper().startswith("AS") else f"AS{asn_pc}"
        if n not in {a.upper() for a in r["asn"]}:
            out.append({"campo": "ASN", "valores": {"RIPEstat prefix-overview": r["asn"], "proxycheck.io": n}, "gravidade": "conflito",
                        "leitura": "ASN divergente entre RIPEstat e proxycheck.io (base defasada, MOAS ou mudança recente)."})
    tor_pc = (pcl.get("deteccoes") or {}).get("tor") if pcl.get("formato_reconhecido") else None
    if tor_pc is not None and r.get("tor_saida_atual") is not None and tor_pc != r["tor_saida_atual"]:
        out.append({"campo": "Tor", "valores": {"lista oficial de saídas Tor (atual)": r["tor_saida_atual"], "proxycheck.io": tor_pc},
                    "gravidade": "informativa",
                    "leitura": "As fontes divergem sobre saída Tor. A lista oficial do Tor Project é a fonte primária para o estado ATUAL; "
                               "para a data do fato, ExoneraTor. Base comercial não confirma Tor."})
    if r.get("alerta_moas"):
        out.append({"campo": "ASN", "valores": {"RIPEstat prefix-overview": r.get("asn")}, "gravidade": "informativa",
                    "leitura": r["alerta_moas"] + " — compatível com anycast ou anomalia BGP; tratar como possível, não confirmado."})
    # titular do bloco × titular do ASN
    t_blk = _tokens(r.get("organizacao"))
    t_asn = set().union(*[_tokens(n) for n in (r.get("as_nome") or []) if n]) if r.get("as_nome") else set()
    if t_blk and t_asn and not (t_blk & t_asn):
        out.append({"campo": "titular", "valores": {"RDAP (bloco)": r.get("organizacao"), "ASN (anunciante)": r.get("as_nome")},
                    "gravidade": "informativa",
                    "leitura": "O titular do bloco difere do titular do ASN que o anuncia (comum: bloco de cliente anunciado pelo provedor, "
                               "ou bloco repassado). A atribuição ao assinante deve partir de quem opera o ASN/bloco na data do fato."})
    nir = r.get("rdap_nir")
    if nir and (r.get("rdap") or {}).get("handle") and nir.get("handle") and nir["handle"] != r["rdap"]["handle"]:
        out.append({"campo": "bloco RDAP", "valores": {"RDAP (rdap.org)": r["rdap"]["handle"], "Registro.br": nir["handle"]},
                    "gravidade": "informativa",
                    "leitura": "O bloco alocado ao provedor (LACNIC) e o sub-bloco registrado no Registro.br podem diferir; o mais específico é o relevante."})
    return out
