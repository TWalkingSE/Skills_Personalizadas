#!/usr/bin/env python3
"""
Funções e dados compartilhados pelos módulos da skill analise_ip_intelligence (somente stdlib).

Conteúdo: faixas especiais IANA, classificação, extração de IPs de linhas de log (com papel
origem/destino e porta rotulada), IPv4 embutido em endereços de transição, interpretação de
timestamps com fuso/UTC, tabela de "onde o IP apareceu" (origem do dado) e utilidades de E/S.

Nada aqui faz consulta de rede.
"""
import datetime as dt
import ipaddress
import json
import os
import re

try:  # tzdata pode não existir em alguns Windows; o fuso fixo (-03:00) continua funcionando
    from zoneinfo import ZoneInfo
except Exception:  # noqa
    ZoneInfo = None

# ----------------------------------------------------------------------------- faixas especiais
ESPECIAIS = [
    ("0.0.0.0/8", "Esta rede (RFC 791)"), ("10.0.0.0/8", "Privado (RFC 1918)"),
    ("100.64.0.0/10", "CGNAT — espaço compartilhado (RFC 6598)"), ("127.0.0.0/8", "Loopback"),
    ("169.254.0.0/16", "Link-local"), ("172.16.0.0/12", "Privado (RFC 1918)"),
    ("192.0.0.0/24", "Atribuições de protocolo IETF"), ("192.0.2.0/24", "Documentação (TEST-NET-1)"),
    ("192.88.99.0/24", "6to4 relay anycast (obsoleto)"), ("192.168.0.0/16", "Privado (RFC 1918)"),
    ("198.18.0.0/15", "Benchmarking (RFC 2544)"), ("198.51.100.0/24", "Documentação (TEST-NET-2)"),
    ("203.0.113.0/24", "Documentação (TEST-NET-3)"), ("224.0.0.0/4", "Multicast"),
    ("240.0.0.0/4", "Reservado (uso futuro)"), ("255.255.255.255/32", "Broadcast limitado"),
    ("::/128", "Não especificado"), ("::1/128", "Loopback"), ("::ffff:0:0/96", "IPv4 mapeado em IPv6"),
    ("64:ff9b::/96", "Tradução IPv4/IPv6 (NAT64)"), ("100::/64", "Descarte (discard-only)"),
    ("2001::/32", "Teredo"), ("2001:db8::/32", "Documentação"), ("2002::/16", "6to4"),
    ("fc00::/7", "Unique Local (ULA — privado)"), ("fe80::/10", "Link-local"), ("ff00::/8", "Multicast"),
]
ESPECIAIS = [(ipaddress.ip_network(n), d) for n, d in ESPECIAIS]


_RE_SEGREDO = re.compile(r"([?&](?:key|api_?key|token|access_token)=)[^&#\s]+", re.I)


def redigir(txt):
    """Remove segredos (chave de API em query string) de qualquer texto que será REGISTRADO: URL, erro, nome de
    arquivo, trilha de auditoria, JSON de saída (§157). A requisição real usa a URL original; o registro, nunca."""
    return _RE_SEGREDO.sub(r"\1***", txt) if isinstance(txt, str) else txt


def agora():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def classificar(ip):
    for rede, desc in ESPECIAIS:
        if ip.version == rede.version and ip in rede:
            return desc, False
    if ip.version == 6 and ip.ipv4_mapped:
        return "IPv4 mapeado em IPv6", False
    return ("Público (global)" if ip.is_global else "Não global (verificar registro IANA)"), ip.is_global


def tipo_nao_publico(descricao):
    """Mapeia a descrição da faixa para o tipo usado na tipologia (seção 6 da skill)."""
    d = (descricao or "")
    if "Privado" in d or "ULA" in d:
        return "IP privado"
    if "CGNAT" in d:
        return "CGNAT"
    return "Não público (outros)"


def escrever(caminho, obj):
    if not caminho:
        return
    os.makedirs(os.path.dirname(os.path.abspath(caminho)), exist_ok=True)
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def json_ou_none(corpo):
    try:
        return json.loads(corpo) if corpo else None
    except Exception:  # noqa
        return None


# ----------------------------------------------------------------------------- extração de IPs
RE_V4 = r"(?<![\d.])(?:\d{1,3}(?:\[\.\]|\(\.\)|\{\.\}|\.)){3}\d{1,3}(?![\d])"
RE_V6 = r"(?<![0-9A-Fa-f:])(?:[0-9A-Fa-f]{0,4}:){2,7}[0-9A-Fa-f]{0,4}(?:%\w+)?(?![0-9A-Fa-f:]|\.\d)"

# Rótulos que antecedem o IP e indicam seu papel na conexão (origem × destino).
_R_SRC = (r"src(?:[_ -]?(?:ip|addr(?:ess)?))?|source(?:[_ -]?(?:ip|addr(?:ess)?))?|saddr|sip|"
          r"client(?:[_ -]?ip)?|cliente|remote[_ -]?addr|remote[_ -]?host|origem|from|orig(?:in)?(?:[_ -]?ip)?")
_R_DST = (r"dst(?:[_ -]?(?:ip|addr(?:ess)?))?|dest(?:ination)?(?:[_ -]?(?:ip|addr(?:ess)?))?|daddr|dip|"
          r"server(?:[_ -]?ip)?|servidor|destino|to")
RE_ROT_SRC = re.compile(r"(?<![A-Za-z])(?:%s)\s*[=:]?\s*\[?$" % _R_SRC, re.I)
RE_ROT_DST = re.compile(r"(?<![A-Za-z])(?:%s)\s*[=:]?\s*\[?$" % _R_DST, re.I)
RE_SPT = re.compile(r"(?<![A-Za-z])(?:SPT|sport|src[_-]?port|srcport|source[_ -]?port|porta[_ -]?(?:de[_ -]?)?origem)\s*[=:]\s*(\d{1,5})\b", re.I)
RE_DPT = re.compile(r"(?<![A-Za-z])(?:DPT|dport|dst[_-]?port|dstport|dest(?:ination)?[_ -]?port|porta[_ -]?(?:de[_ -]?)?destino)\s*[=:]\s*(\d{1,5})\b", re.I)

PORTAS_SERVICO = {20, 21, 22, 23, 25, 53, 80, 110, 123, 143, 389, 443, 465, 587, 636, 993, 995, 1433, 3306,
                  3389, 5432, 5900, 8080, 8443}


def dica_porta(p, papel=None):
    if papel == "origem":
        return (f"porta {p} rotulada como ORIGEM, mas é porta de serviço conhecida: conferir o campo do log "
                "(possível inversão origem/destino)") if p in PORTAS_SERVICO else None
    if p in PORTAS_SERVICO:
        return f"porta de serviço conhecida ({p}): provavelmente DESTINO — não usar como porta de origem"
    if p >= 32768:
        return f"porta efêmera ({p}): compatível com porta de ORIGEM, mas confirmar o campo do log"
    return "sem indício sobre origem/destino"


def papel_do_ip(linha, ini):
    """origem | destino | indefinido, a partir do rótulo que precede o IP na linha."""
    antes = linha[max(0, ini - 28):ini]
    if RE_ROT_SRC.search(antes):
        return "origem"
    if RE_ROT_DST.search(antes):
        return "destino"
    return "indefinido"


def portas_rotuladas(linha):
    s, d = RE_SPT.search(linha), RE_DPT.search(linha)
    return (int(s.group(1)) if s else None), (int(d.group(1)) if d else None)


def extrair_linha(linha):
    """Lista de dicts {bruto, limpo, porta, ini, fim} com todos os IPv4/IPv6 da linha."""
    achados = []
    for m in re.finditer(RE_V4, linha):
        bruto = m.group(0)
        limpo = re.sub(r"\[\.\]|\(\.\)|\{\.\}", ".", bruto)
        porta = None
        mp = re.match(r":(\d{1,5})\b", linha[m.end():m.end() + 7])
        if mp:
            porta = int(mp.group(1))
        ini = m.start()
        if linha[max(0, ini - 7):ini].lower() == "::ffff:":  # IPv4 mapeado: preserva a forma original
            ini -= 7
            bruto = linha[ini:m.end()]
        achados.append({"bruto": bruto, "limpo": limpo, "porta": porta, "ini": ini, "fim": m.end()})
    for m in re.finditer(RE_V6, linha):
        bruto = m.group(0)
        if bruto.count(":") < 2:
            continue
        if re.fullmatch(r"[\d:]+", bruto) and "::" not in bruto and bruto.count(":") < 7:
            continue  # evita horários/datas como "14:32:15" ou "2026:14:33:01"
        porta = None
        if linha[max(0, m.start() - 1):m.start()] == "[":
            mp = re.match(r"\]:(\d{1,5})\b", linha[m.end():m.end() + 7])
            if mp:
                porta = int(mp.group(1))
        achados.append({"bruto": bruto, "limpo": bruto.split("%")[0], "porta": porta, "ini": m.start(), "fim": m.end()})
    return achados


# ----------------------------------------------------------------------------- IPv4 embutido
def embutido(ip):
    """IPv4 embutido em endereços de transição (mapeado, 6to4, Teredo, NAT64).

    Retorna lista de dicts {endereco, metodo, papel, analisar, nota}. `analisar=False` marca
    endereços que são infraestrutura (ex.: servidor Teredo) e não devem ir para consulta.
    O IPv4 embutido é INDÍCIO (seção 6.1 da skill); registre sempre de onde veio.
    """
    res = []
    if ip.version != 6:
        return res
    if ip.ipv4_mapped:
        res.append({"endereco": str(ip.ipv4_mapped), "metodo": "IPv4 mapeado (::ffff:0:0/96)",
                    "papel": "par IPv4 visto por soquete dual-stack", "analisar": True,
                    "nota": "É o endereço IPv4 real do par; analisar como IPv4."})
    elif ip.sixtofour is not None:
        res.append({"endereco": str(ip.sixtofour), "metodo": "6to4 (2002::/16)",
                    "papel": "IPv4 público do gateway/host 6to4", "analisar": True,
                    "nota": "O prefixo 6to4 deriva do IPv4 do próprio host/roteador; pode estar atrás de NAT na prática."})
    elif ip.teredo is not None:
        servidor, cliente = ip.teredo
        res.append({"endereco": str(cliente), "metodo": "Teredo (2001::/32) — cliente",
                    "papel": "IPv4 (externo, mapeado pelo NAT) do cliente Teredo", "analisar": True,
                    "nota": "Indício do IPv4 do cliente; confirmar com outras fontes."})
        res.append({"endereco": str(servidor), "metodo": "Teredo (2001::/32) — servidor",
                    "papel": "servidor Teredo (infraestrutura)", "analisar": False,
                    "nota": "Infraestrutura do serviço Teredo; não é o usuário."})
    elif ip in ipaddress.ip_network("64:ff9b::/96"):
        v4 = ipaddress.IPv4Address(int(ip) & 0xFFFFFFFF)
        res.append({"endereco": str(v4), "metodo": "NAT64 (64:ff9b::/96)",
                    "papel": "IPv4 do DESTINO traduzido (host IPv4 alcançado)", "analisar": True,
                    "nota": "Em NAT64 o IPv4 embutido costuma ser o servidor alcançado, não o cliente: "
                            "verificar se o campo do log é origem ou destino."})
    return res


# ----------------------------------------------------------------------------- timestamps e fuso
MESES_EN = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}
RE_TS = [
    (re.compile(r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?: ?(?:Z|UTC|GMT|[+-]\d{2}:?\d{2}))?"), "iso"),
    (re.compile(r"\d{2}/[A-Za-z]{3}/\d{4}:\d{2}:\d{2}:\d{2} [+-]\d{4}"), "clf"),
    (re.compile(r"\d{2}/\d{2}/\d{4}[ ,]+\d{2}:\d{2}(?::\d{2})?"), "br"),
]
_RE_ISO = re.compile(r"(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2})(\.\d+)?)?\s*(Z|UTC|GMT|[+-]\d{2}:?\d{2})?$", re.I)
_RE_CLF = re.compile(r"(\d{2})/([A-Za-z]{3})/(\d{4}):(\d{2}):(\d{2}):(\d{2}) ([+-]\d{4})")
_RE_BR = re.compile(r"(\d{2})/(\d{2})/(\d{4})[ ,]+(\d{2}):(\d{2})(?::(\d{2}))?")


def precisao_ts(ts):
    if not ts:
        return None
    if re.search(r"\d{2}:\d{2}:\d{2}\.\d+", ts):
        return "ALTA (frações de segundo)"
    if re.search(r"\d{2}:\d{2}:\d{2}", ts):
        return "ALTA (segundos)"
    if re.search(r"\d{2}:\d{2}", ts):
        return "MÉDIA (minutos)"
    return "BAIXA (somente data)"


def _offset_de(txt):
    """'Z'/'UTC'/'GMT'/'+0300'/'-03:00' → timezone fixo."""
    t = txt.strip().upper()
    if t in ("Z", "UTC", "GMT"):
        return dt.timezone.utc
    m = re.fullmatch(r"([+-])(\d{2}):?(\d{2})", t)
    if not m:
        return None
    mins = int(m.group(2)) * 60 + int(m.group(3))
    return dt.timezone(dt.timedelta(minutes=mins if m.group(1) == "+" else -mins))


def resolver_fuso(spec):
    """Valor de --fuso → tzinfo. Aceita UTC, ±hh:mm ou nome IANA (ex.: America/Maceio)."""
    if not spec:
        return None
    fixo = _offset_de(spec)
    if fixo is not None:
        return fixo
    if ZoneInfo is None:
        raise ValueError("Nomes IANA exigem o pacote tzdata; use um deslocamento fixo (ex.: -03:00).")
    try:
        return ZoneInfo(spec)
    except Exception as e:  # noqa
        raise ValueError(f"Fuso desconhecido: {spec!r} ({type(e).__name__}). Use UTC, -03:00 ou um nome IANA "
                         "(ex.: America/Maceio — Sergipe; America/Sao_Paulo — Brasília).")


def interpretar_ts(ts, fmt, fuso_padrao=None):
    """Interpreta um timestamp preservando o original e SEM alterá-lo.

    Retorna: timestamp_original, timezone_original, fuso_status (explicito | assumido_pelo_usuario |
    AUSENTE), utc (ISO-8601 com Z, ou None), precisao e alertas. Sem fuso e sem --fuso, não há
    conversão para UTC (nunca presumir).
    """
    r = {"timestamp_original": ts, "formato": fmt, "timezone_original": None, "fuso_status": "AUSENTE",
         "utc": None, "precisao": precisao_ts(ts), "alertas": []}
    naive, tz_txt, frac = None, None, ""
    try:
        if fmt == "iso":
            m = _RE_ISO.match(ts.strip())
            if m:
                y, mo, d, h, mi, s, fr, tz_txt = m.groups()
                naive = dt.datetime(int(y), int(mo), int(d), int(h), int(mi), int(s or 0))
                frac = fr or ""
        elif fmt == "clf":
            m = _RE_CLF.match(ts.strip())
            if m:
                d, mon, y, h, mi, s, tz_txt = m.groups()
                naive = dt.datetime(int(y), MESES_EN[mon.lower()], int(d), int(h), int(mi), int(s))
        elif fmt == "br":
            m = _RE_BR.match(ts.strip())
            if m:
                d, mo, y, h, mi, s = m.groups()
                naive = dt.datetime(int(y), int(mo), int(d), int(h), int(mi), int(s or 0))
                r["alertas"].append("formato dd/mm/aaaa assumido (padrão brasileiro); confirmar se o log não usa mm/dd")
    except (ValueError, KeyError):
        naive = None
    if naive is None:
        r["alertas"].append("timestamp não interpretável; usar o texto original")
        return r
    if r["precisao"] and r["precisao"].startswith("MÉDIA"):
        r["alertas"].append("sem segundos: insuficiente para individualizar conexão em CGNAT")
    if tz_txt:
        tz = _offset_de(tz_txt)
        r["timezone_original"], r["fuso_status"] = tz_txt, "explicito"
        aware = naive.replace(tzinfo=tz)
    elif fuso_padrao is not None:
        r["fuso_status"] = "assumido_pelo_usuario"
        r["timezone_original"] = getattr(fuso_padrao, "key", None) or str(fuso_padrao)
        aware = naive.replace(tzinfo=fuso_padrao)
        if ZoneInfo is not None and isinstance(fuso_padrao, ZoneInfo):
            ida = naive.replace(tzinfo=fuso_padrao, fold=0)
            volta = naive.replace(tzinfo=fuso_padrao, fold=1)
            if ida.astimezone(dt.timezone.utc).astimezone(fuso_padrao).replace(tzinfo=None) != naive:
                r["alertas"].append("horário INEXISTENTE no fuso informado (salto do horário de verão): verificar o relógio do sistema")
            elif ida.utcoffset() != volta.utcoffset():
                r["alertas"].append("horário AMBÍGUO no fuso informado (fim do horário de verão): duas conversões possíveis; "
                                    f"UTC calculado com a primeira ocorrência (fold=0), alternativa {volta.astimezone(dt.timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')}")
    else:
        r["alertas"].append("SEM FUSO HORÁRIO: não é possível converter para UTC; perguntar ao responsável pelo log "
                            "(UTC ou horário local?) e informar --fuso")
        return r
    utc = aware.astimezone(dt.timezone.utc)
    r["utc"] = utc.strftime("%Y-%m-%dT%H:%M:%S") + (frac if frac else "") + "Z"
    return r


# ----------------------------------------------------------------------------- origem do dado
ORIGENS = {
    "print-wifi": ("Print de 'meu IP'/configurações de Wi-Fi do celular ou computador",
                   "Endereço local do dispositivo na rede; NÃO é o IP de internet.",
                   "Obter o IP público visto pelo serviço: logs da aplicação, e-mail/plataforma ou provedor, com data, hora e fuso."),
    "email": ("Cabeçalho de e-mail (Received, X-Originating-IP)",
              "Máquina de origem atrás de NAT ou servidor interno. Só os trechos inseridos por servidores confiáveis são confiáveis.",
              "Localizar o primeiro Received com IP público inserido por servidor confiável (subcomando 'cabecalho') e analisá-lo como público."),
    "log-web": ("Log de servidor/aplicação",
                "Proxy reverso, balanceador, CDN, WAF ou NAT na frente da aplicação.",
                "Procurar o IP do cliente em X-Forwarded-For/Forwarded/X-Real-IP/CF-Connecting-IP (vale o inserido por proxy confiável)."),
    "log-interno": ("Log interno de organização (firewall, proxy, DHCP, AD)",
                    "Host interno da própria organização.",
                    "A organização identifica o equipamento por concessão DHCP/ARP (MAC, hostname), autenticação e inventário, na hora exata."),
    "camera-iot": ("Painel de câmera, DVR, roteador, IoT",
                   "Dispositivo na rede local.",
                   "Se estiver acessível pela internet há IP público, redirecionamento de porta/UPnP ou nuvem do fabricante: esse é o elo público."),
    "dns": ("Registro DNS (A/AAAA) apontando para IP privado/loopback",
            "Configuração interna (split-horizon), erro, ambiente de teste, bloqueio/sinkhole ou rebinding.",
            "Consultar DNS histórico; não atribuir a titular algum."),
    "vpn": ("Interface de VPN/túnel (concentrador, cliente)",
            "Endereço virtual do túnel, não da pessoa.",
            "O IP público do cliente está nos logs do concentrador VPN."),
    "malware": ("Relatório de malware/IOC",
                "Configuração de rede da vítima ou do laboratório; C2/movimento lateral interno; ou ofuscação.",
                "Tratar como indicador interno COM o contexto da rede."),
    "bo": ("Boletim de ocorrência/denúncia",
           "A vítima leu um endereço local ou informou o IP que viu.",
           "Orientar a obter o IP público do evento (logs da plataforma/provedor), com data, hora e fuso."),
    "hotspot": ("Wi-Fi público/hotspot (café, hotel, transporte, evento)",
                "Muitos usuários na mesma rede; DHCP local.",
                "Operador do local: logs de DHCP/portal cativo/autenticação, se existirem."),
    "firewall": ("Log de firewall/IDS/NAT",
                 "Os campos origem/destino dependem da regra e do sentido do tráfego (entrada × saída).",
                 "Confirmar o sentido do tráfego e o campo antes de tratar qualquer IP como 'atacante'."),
    "outro": ("Origem não especificada", "Contexto desconhecido.", "Reconstituir o contexto de rede (seção 6.3 da skill)."),
}
