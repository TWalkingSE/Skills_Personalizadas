#!/usr/bin/env python3
"""
Motor de TIPOLOGIA do IP (seção 5 da skill) — tabela de decisão explícita e reprodutível. Somente stdlib.

Como decide (resumo; detalhes em references/tabela_decisao_tipologia.md):
  1. Cada indício vira uma EVIDÊNCIA com tipo, força (0–1), FAMÍLIA de fonte e se é "confirmatória"
     (lista oficial do provedor, ExoneraTor/confirmação manual com SHA-256).
  2. Dentro de uma família vale só a evidência mais forte (RDAP, nome do ASN e ipinfo são o MESMO registro).
     Entre famílias independentes combina-se por "ou-ruidoso": score = 1 − Π(1 − força).
  3. Escala: ≥0,30 Possível · ≥0,60 Provável · "Confirmado" SÓ com evidência confirmatória preservada
     (com SHA-256). Base comercial de VPN/proxy (InternetDB, proxycheck.io…) nunca passa de Provável.
  4. Papéis múltiplos são registrados (VPN sobre datacenter). Tipos incompatíveis ≥ Possível geram CONFLITO e
     hipóteses alternativas com indícios favoráveis e contrários — nunca se escolhe em silêncio.
  5. Tipos voláteis (Tor/VPN/proxy) com fato anterior à consulta: não passam de Provável sem confirmação histórica.

Tipo de IP é INDÍCIO, nunca prova de autoria. Parâmetros editáveis em references/*.json.
"""
import datetime as dt
import ipaddress
import json
import os
import re
import unicodedata

import ipa_comum as C
import ipa_prazos

AQUI = os.path.dirname(os.path.abspath(__file__))
REF = os.path.join(os.path.dirname(AQUI), "references")
ESCALA = ["Não identificado", "Possível", "Provável", "Confirmado"]
ACESSO = "Acesso (ISP, fixo/móvel indeterminado)"
VOLATEIS = {"Tor", "VPN", "Proxy (PUB/WEB)", "Proxy residencial"}


def carregar(caminho, padrao):
    with open(caminho or os.path.join(REF, padrao), encoding="utf-8") as f:
        return json.load(f)


def carregar_operadoras(caminho=None):
    """Tabelas ASN → tipo de rede. Aceita um arquivo ou uma PASTA (todos os *.json, menos os que começam com '_').
    Padrão: references/operadoras/*.json. A tabela é OPCIONAL e regional: o motor funciona sem ela (RDAP, nomes,
    PeeringDB, PTR, proxycheck.io e listas oficiais valem em qualquer país). ASN é único no mundo: pacotes se somam."""
    alvo = caminho or os.path.join(REF, "operadoras")
    arquivos = [alvo] if os.path.isfile(alvo) else sorted(
        os.path.join(alvo, n) for n in os.listdir(alvo) if n.endswith(".json") and not n.startswith("_")) if os.path.isdir(alvo) else []
    oper = {}
    for arq in arquivos:
        with open(arq, encoding="utf-8") as f:
            for o in json.load(f).get("operadoras", []):
                oper[o["asn"].upper()] = {**o, "pacote": os.path.basename(arq)}
    return oper


def norm(txt):
    t = unicodedata.normalize("NFKD", str(txt)).encode("ascii", "ignore").decode().upper()
    return re.sub(r"[^A-Z0-9]+", " ", t).strip()


def contem(nome_norm, kw):
    return re.search(r"(?<![A-Z0-9])" + re.escape(norm(kw)) + r"(?![A-Z0-9])", nome_norm) is not None


def _sha(r, prefixo):
    for f in r.get("fontes", []):
        if (f.get("fonte") or "").startswith(prefixo):
            return f.get("sha256_resposta")
    return None


def ev(tipo, forca, familia, fonte, descricao, confirma=False, atual=True, sha=None):
    return {"tipo": tipo, "forca": forca, "familia": familia, "fonte": fonte, "descricao": descricao,
            "confirma": confirma, "atual": atual, "preservada": bool(sha), "sha256": sha}


# ----------------------------------------------------------------------------- evidências
def coletar_evidencias(r, regras, oper):
    F, evs, flags = regras["forcas"], [], {"cgnat_ptr": False, "ambiguo_fixo_movel": False, "anycast": bool(r.get("alerta_moas")),
                                           "reputacao": []}
    # Tor — lista oficial (ATUAL) e confirmações manuais (ExoneraTor etc.)
    if r.get("tor_saida_atual"):
        evs.append(ev("Tor", F["tor_lista_atual"], "lista_oficial", "Tor bulk exit list (atual)",
                      "IP consta na lista ATUAL de saídas Tor", True, True, _sha(r, "Tor bulk exit list")))
    for c in r.get("confirmacoes_manuais") or []:
        if c.get("resultado") in ("positivo", True) and c.get("tipo"):
            evs.append(ev(c["tipo"], F["confirmacao_manual"], "confirmacao_manual", c.get("fonte", "confirmação manual"),
                          f"{c.get('fonte', 'confirmação')}: positivo em {c.get('data', 'data não informada')}", True, False,
                          c.get("sha256") or c.get("arquivo_bruto")))
    # listas oficiais de cloud/CDN/crawlers/Private Relay
    for m in r.get("cloud_match") or []:
        det = " ".join(x for x in (m.get("servico"), m.get("regiao")) if x)
        evs.append(ev(m["categoria"], F["lista_oficial"], "lista_oficial", f"Lista oficial {m['provedor']}",
                      f"{m['prefixo']} publicado por {m['provedor']}" + (f" ({det})" if det else ""), True, True, m.get("sha256_resposta")))
    # nomes (ASN/RDAP/ipinfo/PeeringDB) — mesma família "registro": vale o mais forte
    nomes = [("nome do ASN", n) for n in r.get("as_nome") or [] if n]
    if r.get("organizacao"):
        nomes.append(("organização (RDAP)", r["organizacao"]))
    for chave, rot in (("rdap", "nome do bloco (RDAP)"), ("rdap_nir", "nome do bloco (Registro.br)")):
        if (r.get(chave) or {}).get("nome"):
            nomes.append((rot, r[chave]["nome"]))
    for e in (r.get("rdap_nir") or {}).get("entidades") or []:
        if e.get("nome"):
            nomes.append(("titular (Registro.br)", e["nome"]))
    org = (r.get("geolocalizacao_ipinfo") or {}).get("org")
    if org:
        nomes.append(("org (ipinfo)", re.sub(r"^AS\d+\s*", "", org)))
    for a in (r.get("as_info") or {}).values():
        if a.get("titular"):
            nomes.append(("titular do ASN (RIPEstat)", a["titular"]))
    for a in (r.get("peeringdb") or {}).values():
        if a.get("encontrado") and a.get("nome"):
            nomes.append(("nome (PeeringDB)", a["nome"]))
    for rot, nome in nomes:
        nn = norm(nome)
        for tipo, grupos in regras["palavras_chave"].items():
            for nivel, kws in (("forte", grupos.get("forte", [])), ("generico", grupos.get("generico", []))):
                for kw in kws:
                    if contem(nn, kw):
                        if tipo == "Satélite":
                            forca = F["satelite"]
                        elif tipo == "Corporativo/institucional":
                            forca = F["institucional"]
                        else:
                            forca = F["nome_forte"] if nivel == "forte" else F["nome_generico"]
                        evs.append(ev(tipo, forca, "registro", "ASN/RDAP (nome)", f"{rot}: '{nome}' contém '{kw}'"))
    # PeeringDB (tipo de rede declarado pelo operador do ASN)
    for asn, a in (r.get("peeringdb") or {}).items():
        if a.get("encontrado"):
            for t in a.get("info_types") or ([a["info_type"]] if a.get("info_type") else []):
                m = regras["peeringdb_info_type"].get(t)
                if m:
                    tipo = ACESSO if m[0] == "Acesso" else m[0]
                    evs.append(ev(tipo, m[1], "peeringdb", "PeeringDB", f"{asn} declarado no PeeringDB como '{t}'"))
    # tabela de operadoras conhecidas (por ASN; pacotes regionais opcionais)
    for asn in r.get("asn") or []:
        op = oper.get(asn.upper())
        if not op:
            continue
        tr = op.get("tipo_rede")
        base = f"{asn} consta na tabela de operadoras ({op['nome']}; pacote {op.get('pacote')}; verificado={op.get('verificado')})"
        if tr == "satelite":
            evs.append(ev("Satélite", F["satelite"], "operadora_conhecida", "tabela de operadoras", base))
        else:
            evs.append(ev(ACESSO, F["operadora_conhecida"], "operadora_conhecida", "tabela de operadoras", base))
            if tr == "fixo":
                evs.append(ev("Residencial", F["operadora_conhecida_especifico"], "operadora_conhecida", "tabela de operadoras", base + " — fixo (predominante)"))
            elif tr == "movel":
                evs.append(ev("Móvel", F["operadora_conhecida_especifico"], "operadora_conhecida", "tabela de operadoras", base + " — móvel (predominante)"))
            else:
                flags["ambiguo_fixo_movel"] = True
    # proxycheck.io — base comercial (família própria). Nunca confirma: no máximo Provável.
    pc = r.get("proxycheck") or {}
    if pc.get("consultado") and pc.get("formato_reconhecido"):
        cfg = regras.get("proxycheck", {})
        sha = _sha(r, "proxycheck.io")
        det, rede = pc.get("deteccoes") or {}, pc.get("rede") or {}
        fator = 1.0
        if pc.get("confianca") is not None and pc["confianca"] < cfg.get("confianca_baixa_abaixo_de", 50):
            fator = cfg.get("fator_confianca_baixa", 0.7)

        def add_pc(tipo, base, desc):
            evs.append(ev(tipo, round(base * fator, 3), "proxycheck", "proxycheck.io", desc + (f" [confiança {pc['confianca']}/100 → peso reduzido]" if fator != 1.0 else ""), sha=sha))
        if det.get("vpn"):
            add_pc("VPN", F["proxycheck_vpn"], "proxycheck.io: detecção de VPN (base comercial)")
        if det.get("proxy"):
            if str(rede.get("tipo") or "").lower() == "residential":
                add_pc("Proxy residencial", F["proxycheck_proxy_residencial"], "proxycheck.io: proxy sobre IP classificado como residencial (o assinante pode ser vítima)")
            else:
                add_pc("Proxy (PUB/WEB)", F["proxycheck_proxy"], "proxycheck.io: detecção de proxy (base comercial)")
        if det.get("tor"):
            add_pc("Tor", F["proxycheck_tor"], "proxycheck.io: detecção de Tor (base comercial; só lista oficial/ExoneraTor confirmam)")
        if det.get("hosting"):
            add_pc("Datacenter/nuvem", F["proxycheck_hosting"], "proxycheck.io: IP de hospedagem")
        m = (cfg.get("tipo_rede") or {}).get(rede.get("tipo") or "")
        if m:
            evs.append(ev(m[0], m[1], "proxycheck", "proxycheck.io", f"proxycheck.io: tipo de rede '{rede['tipo']}' (estimativa de terceiros)", sha=sha))
        for k, rot in (("compromised", "servidor comprometido"), ("scraper", "scraper")):
            if det.get(k):
                flags["reputacao"].append(f"{rot} (proxycheck.io)")
        if pc.get("risco") is not None and pc["risco"] >= cfg.get("risco_alto_a_partir_de", 76):
            flags["reputacao"].append(f"risco {pc['risco']}/100 (proxycheck.io)")
    # PTR
    ptr = (r.get("ptr") or "").lower()
    if ptr:
        for rg in regras["ptr"]:
            if re.search(rg["regex"], ptr):
                if rg["tipo"] == "_cgnat":
                    flags["cgnat_ptr"] = True
                    continue
                evs.append(ev(rg["tipo"], rg.get("forca", F["ptr"]), "ptr", "DNS reverso (PTR)", f"{rg['descricao']}: {ptr}"))
    # InternetDB: tags e portas
    idb = r.get("internetdb") or {}
    for tag in idb.get("tags") or []:
        m = regras["tags_internetdb"].get(tag)
        if m:
            evs.append(ev(m[0], m[1], "base_comercial", "Shodan InternetDB", f"tag '{tag}' (terceiro; data de observação incerta)"))
        if tag in regras["tags_reputacao"]:
            flags["reputacao"].append(tag)
    portas = set(idb.get("ports") or [])
    for tipo, lista in regras["portas_indicio"].items():
        hit = sorted(portas & set(lista))
        if hit:
            evs.append(ev(tipo, F["portas"], "portas", "Shodan InternetDB (portas)", f"portas típicas abertas: {hit} (indício fraco)"))
    return evs, flags


def pontuar(evs):
    """ou-ruidoso entre famílias independentes; máximo dentro da família."""
    por_tipo = {}
    for e in evs:
        por_tipo.setdefault(e["tipo"], {}).setdefault(e["familia"], []).append(e)
    scores = {}
    for tipo, fams in por_tipo.items():
        prod, usados = 1.0, []
        for lst in fams.values():
            m = max(lst, key=lambda x: x["forca"])
            prod *= 1 - m["forca"]
            usados.append(m)
        scores[tipo] = {"score": round(1 - prod, 3), "evidencias": usados}
    return scores


def resolver_acesso(evs):
    """O 'Acesso (ISP)' abstrato apoia Residencial/Móvel SÓ quando há evidência específica para eles."""
    espec = {e["tipo"] for e in evs if e["tipo"] in ("Residencial", "Móvel")}
    if not espec:
        return evs
    out = [e for e in evs if e["tipo"] != ACESSO]
    for e in evs:
        if e["tipo"] == ACESSO:
            for t in espec:
                out.append({**e, "tipo": t, "descricao": e["descricao"] + " (apoio genérico de rede de acesso)"})
    return out


def escala_de(score, usados, tipo, regras, evento_antigo):
    L = regras["limiares"]
    nota, qual = None, None
    confirmatorias = [e for e in usados if e.get("confirma")]
    if score >= L["confirmado"] and any(e["preservada"] for e in confirmatorias):
        esc = "Confirmado"
        atuais = all(e["atual"] for e in confirmatorias if e["preservada"])
        qual = "na data da consulta" if atuais else "confirmação histórica (data do evento)"
        if atuais and evento_antigo and tipo in VOLATEIS:
            esc, nota = "Provável", ("tipo volátil: a evidência é do estado ATUAL e o fato é anterior; "
                                      "confirmar na data do evento (ex.: ExoneraTor para Tor) e registrar em 'confirmacoes_manuais'")
            qual = None
    elif score >= L["confirmado"] and confirmatorias:
        esc, nota = "Provável", "evidência confirmatória SEM preservação bruta (sem SHA-256): rebaixada para Provável"
    elif score >= L["provavel"]:
        esc = "Provável"
    elif score >= L["possivel"]:
        esc = "Possível"
    else:
        esc = "Não identificado"
    return esc, qual, nota


def grupo_de(tipo, regras):
    for g, lista in regras["grupos"].items():
        if tipo in lista:
            return g
    return None


# ----------------------------------------------------------------------------- decisão por IP
def decidir(r, regras, oper, evento_antigo):
    evs, flags = coletar_evidencias(r, regras, oper)
    evs = resolver_acesso(evs)
    scores = pontuar(evs)
    L = regras["limiares"]
    info = {}
    for t, s in scores.items():
        esc, qual, nota = escala_de(s["score"], s["evidencias"], t, regras, evento_antigo)
        info[t] = {"tipo": t, "score": s["score"], "escala": esc, "qualificador": qual, "nota": nota,
                   "evidencias": s["evidencias"], "grupo": grupo_de(t, regras)}
    relevantes = {t: i for t, i in info.items() if i["score"] >= L["possivel"]}
    base = {t: i for t, i in relevantes.items() if i["grupo"] != "anonimizacao"}
    anon = {t: i for t, i in relevantes.items() if i["grupo"] == "anonimizacao"}
    melhor_base = max(base.values(), key=lambda i: i["score"], default=None)
    melhor_anon = max(anon.values(), key=lambda i: i["score"], default=None)
    if melhor_anon and (melhor_anon["score"] >= L["provavel"] or not melhor_base or melhor_anon["score"] >= melhor_base["score"]):
        primario = melhor_anon
    else:
        primario = melhor_base
    # conflitos entre tipos de base incompatíveis
    conflitos, excl = [], set(regras["exclusivos_no_grupo_acesso"])
    bl = sorted(base.values(), key=lambda i: -i["score"])
    for k in range(len(bl)):
        for j in range(k + 1, len(bl)):
            a, b = bl[k], bl[j]
            if a["grupo"] != b["grupo"] or (a["tipo"] in excl and b["tipo"] in excl):
                conflitos.append({"tipos": [a["tipo"], b["tipo"]],
                                  "descricao": f"Indícios apontam para '{a['tipo']}' ({a['escala']}, {a['score']}) e para '{b['tipo']}' "
                                               f"({b['escala']}, {b['score']}), que normalmente não coexistem. Fontes em conflito: "
                                               "a classificação não deve ser considerada conclusiva."})
    papeis = [{"tipo": i["tipo"], "escala": i["escala"], "score": i["score"], "qualificador": i["qualificador"]}
              for i in relevantes.values() if primario and i["tipo"] != primario["tipo"]]
    if flags["anycast"]:
        papeis.append({"tipo": "Anycast (possível)", "escala": "Possível", "score": None})
    # hipóteses alternativas: só para tipos em CONFLITO (papéis compatíveis, ex.: Tor sobre datacenter, não são alternativas)
    alternativas = []
    envolvidos = []
    for c in conflitos:
        for t in c["tipos"]:
            if t not in envolvidos:
                envolvidos.append(t)
    for t in envolvidos:
        oponentes = [o for c in conflitos if t in c["tipos"] for o in c["tipos"] if o != t]
        alternativas.append({"tipo": t, "escala": info[t]["escala"], "score": info[t]["score"],
                             "a_favor": [e["descricao"] for e in info[t]["evidencias"]],
                             "contra": [e["descricao"] for o in dict.fromkeys(oponentes) for e in info[o]["evidencias"]]})
    # anonimização
    anon_txt = "Nenhum indicador (nas fontes consultadas)"
    if melhor_anon:
        anon_txt = {"Confirmado": "Confirmada", "Provável": "Provável", "Possível": "Possível"}[melhor_anon["escala"]] + f" ({melhor_anon['tipo']})"
    return {"info": info, "primario": primario, "papeis": papeis, "conflitos": conflitos, "alternativas": alternativas,
            "anonimizacao": anon_txt, "flags": flags, "evidencias": evs}


def completude(r, evento, listas_pedidas):
    itens = []
    def add(nome, estado, det=""):
        itens.append({"item": nome, "estado": estado, "detalhe": det})
    add("Registro (RDAP)", "✓" if r.get("rdap") else "✗")
    add("Roteamento/ASN (RIPEstat)", "✓" if r.get("asn") else "✗")
    if evento:
        add("Histórico de roteamento na data do evento", "✓" if r.get("historico_roteamento") is not None else "✗")
    add("DNS reverso (PTR)", "✓" if r.get("ptr") else ("△" if "ptr" in r else "✗"), "" if r.get("ptr") else "sem PTR/indisponível")
    bases = sum(1 for k in ("geolocalizacao", "geolocalizacao_ipinfo", "geolocalizacao_dbip") if r.get(k))
    add("Geolocalização (≥ 2 bases)", "✓" if bases >= 2 else ("△" if bases == 1 else "✗"), f"{bases} base(s)")
    tor = "tor_saida_atual" in r and r["tor_saida_atual"] is not None
    add("Anonimização (Tor + serviços/tags)", "✓" if tor and "internetdb" in r else ("△" if tor or "internetdb" in r else "✗"))
    pcr = r.get("proxycheck") or {}
    pc_ok = bool(pcr.get("consultado") and pcr.get("formato_reconhecido"))
    add("VPN/proxy/Tor (proxycheck.io)", "✓" if pc_ok else ("△" if pcr.get("consultado") else "✗"),
        "" if pc_ok else (pcr.get("motivo") or ("resposta não utilizável" if pcr.get("consultado") else "não consultado")))
    ok = r.get("cloud_listas_consultadas")
    falha = r.get("cloud_listas_falhas")
    add("Listas oficiais cloud/CDN", "✗" if not ok else ("✓" if not falha else "△"),
        f"consultadas: {', '.join(ok or []) or 'nenhuma'}" + (f"; indisponíveis: {', '.join(falha)}" if falha else ""))
    add("Serviços expostos (InternetDB)", "✓" if "internetdb" in r else "✗")
    pdb = any(v.get("encontrado") for v in (r.get("peeringdb") or {}).values())
    add("Tipo de rede do ASN (PeeringDB/operadora)", "✓" if pdb else "△" if r.get("peeringdb") else "✗")
    pesos = {"✓": 1.0, "△": 0.5, "✗": 0.0}
    pct = round(100 * sum(pesos[i["estado"]] for i in itens) / len(itens))
    return {"itens": itens, "percentual": pct, "aviso": "Completude de coleta ≠ certeza da conclusão (§94)."}


def dados_atribuicao(ip, rec_norm, a, evento_utc_txt, fuso_status):
    """Marca o que EXISTE e o que FALTA para individualizar a conexão (seção 5.5)."""
    ts = (rec_norm or {}).get("timestamps") or []
    prec = (ts[0].get("precisao") or "") if ts else ""
    porta = a.porta_origem or ((rec_norm or {}).get("portas_origem") or [None])[0]
    tem = [
        ("IP público", True, ip),
        ("Data", bool(ts or evento_utc_txt), (ts[0]["timestamp_original"] if ts else evento_utc_txt) or ""),
        ("Hora com segundos", ("segundos" in prec or "frações" in prec) if ts else bool(evento_utc_txt), prec or ("do --data-evento" if evento_utc_txt else "")),
        ("Fuso horário", (fuso_status in ("explicito", "assumido_pelo_usuario")) if ts else bool(evento_utc_txt), fuso_status or ""),
        ("Porta lógica de ORIGEM", bool(porta), str(porta) if porta else
         ("há porta no log, mas com semântica indefinida" if (rec_norm or {}).get("portas_detalhe") else "")),
        ("Protocolo (TCP/UDP)", bool(a.protocolo), a.protocolo or ""),
        ("IP/porta de destino", bool(a.destino), a.destino or ""),
        ("Identificador da conta/sessão", False, "não informado"),
    ]
    return [{"campo": c, "tem": t, "detalhe": d} for c, t, d in tem]


def _listar_lacunas(dados):
    return [d["campo"] for d in dados if not d["tem"]]


# ----------------------------------------------------------------------------- orquestração
def classificar_nao_publico(rec, regras, a):
    faixa = rec.get("classificacao") or C.classificar(ipaddress.ip_address(rec["ip"]))[0]
    tipo = C.tipo_nao_publico(faixa)
    rot = regras["roteiro"][tipo]
    ctx_rede = rec.get("leitura_contexto")
    return {
        "ip": rec["ip"], "publico": False, "tipo": tipo, "escala": "Confirmado", "qualificador": "faixa IANA (fato objetivo)",
        "faixa": faixa, "triagem": "⚪ indeterminado (contexto de rede necessário)",
        "indicios": [f"Faixa especial: {faixa}"],
        "papeis": [], "anonimizacao": "Não se aplica (IP não público)", "conflitos": [], "alternativas": [],
        "detentor": rot["detentor"], "caminho": rot["solicitar"], "obstaculos": rot["obstaculos"],
        "viabilidade": {"titular": rot["titular"], "usuario": rot["usuario"]},
        "dados_atribuicao": [{"campo": "IP PÚBLICO do gateway no mesmo instante", "tem": False, "detalhe": "não obtido"},
                             {"campo": "Rede/equipamento NAT-DHCP (local, data, hora, fuso)", "tem": bool(ctx_rede), "detalhe": ""}],
        "prazo_guarda": "DHCP/NAT locais: retenção curta ou inexistente — PRESERVAR JÁ.",
        "contexto_rede": ctx_rede or "DESCONHECIDO: reconstituir (equipamento, local, data, hora com segundos e fuso)",
        "consulta_externa": "NÃO realizada (IP não público) — não consultar RDAP/BGP/geolocalização/reputação",
        "limitacoes": ["Sem titular, ASN, geolocalização ou reputação: o mesmo endereço existe em milhões de redes.",
                       "Nunca vincular casos ou pessoas por IP privado isolado (⚠ possível falso positivo de correlação)."],
        "alertas": rec.get("alertas", []),
    }


def classificar_publico(r, rec_norm, regras, oper, a, evento_utc, evento_txt, agora_utc, evento_rot=None):
    ip = r["ip"]
    evento_antigo = bool(evento_utc and (agora_utc - evento_utc).days >= 2)
    d = decidir(r, regras, oper, evento_antigo)
    p = d["primario"]
    if p:
        tipo, esc, qual, nota = p["tipo"], p["escala"], p["qualificador"], p["nota"]
        indicios = [f"[{e['fonte']}] {e['descricao']} (força {e['forca']})" for e in sorted(p["evidencias"], key=lambda x: -x["forca"])]
    else:
        tipo, esc, qual, nota, indicios = "Não identificado", "Não identificado", None, None, ["Nenhum indício suficiente nas fontes consultadas."]
    rot = regras["roteiro"].get(tipo, regras["roteiro"]["Não identificado"])
    cg = d["flags"]["cgnat_ptr"]
    cg_alto = tipo in ("Móvel", "Satélite")
    dados = dados_atribuicao(ip, rec_norm, a, evento_txt, ((rec_norm or {}).get("timestamps") or [{}])[0].get("fuso_status"))
    falta_porta = any(x["campo"].startswith("Porta") and not x["tem"] for x in dados)
    lim = []
    if evento_antigo:
        lim.append(f"Classificação feita com dados ATUAIS (consulta); o fato é de {evento_rot or evento_txt}. Geolocalização, reputação, serviços, "
                   "listas de cloud/CDN e lista Tor podem não refletir a data do fato.")
    lim.append("Classificação comercial/heurística é estimativa de terceiros ou indício, não fato; tipo de IP nunca prova autoria.")
    if cg_alto or cg or (tipo in ("Residencial", ACESSO) and d["flags"]["ambiguo_fixo_movel"]):
        motivo = "rede móvel/satélite (CGNAT massivo)" if cg_alto else "PTR/ASN sugerem CGNAT ou rede de acesso compartilhada"
        lim.append(f"Possível CGNAT — {motivo}." + (" Sem porta de origem, o IP isoladamente pode não ser suficiente para "
                                                      "individualização da conexão." if falta_porta else ""))
    if d["flags"]["ambiguo_fixo_movel"]:
        lim.append("O ASN é de operadora que atende fixo e móvel: não declarar 'residencial' ou 'móvel' só pelo ASN; "
                   "distinguir por PTR/faixa ou perguntar ao provedor.")
    if ":" in ip:
        lim.append("IPv6: analisar o prefixo (/56 ou /64), não o endereço completo.")
    if rec_norm and rec_norm.get("derivado_de"):
        lim.append("IP derivado de endereço de transição (6to4/Teredo/NAT64/mapeado): indício, não observação direta.")
    if tipo in ("Proxy residencial",) or (tipo == "Residencial" and d["anonimizacao"].startswith(("Possível", "Provável"))):
        lim.append("Registrar a hipótese de proxy ANTES de qualquer conclusão sobre o assinante: atribuição direta pode apontar um inocente.")
    if tipo == "CDN":
        lim.append("Relação domínio → IP é fraca em CDN; nunca atribuir ao dono do IP o conteúdo do site.")
    if tipo == "Datacenter/nuvem":
        lim.append("IP de nuvem no log da vítima pode ser serviço legítimo (ferramenta de segurança que abre links).")
    if d["flags"]["reputacao"]:
        lim.append(f"Tags de reputação de terceiros ({', '.join(d['flags']['reputacao'])}): indício de abuso, não prova de autoria.")
    falhas = r.get("cloud_listas_falhas")
    if falhas:
        lim.append(f"Listas de cloud/CDN não consultadas ({', '.join(falhas)}): a ausência de correspondência não prova que o IP não seja de hospedagem.")
    sem_sha = [f["fonte"] for f in r.get("fontes", []) if not f.get("sha256_resposta") and not f.get("erro") and f.get("origem_dado") == "transcrito_web"]
    if sem_sha:
        lim.append("Fontes TRANSCRITAS pela ferramenta web (sem resposta bruta/SHA-256): " + ", ".join(sem_sha) +
                   ". Conferir na fonte; evidência não preservada.")
    jur = getattr(a, "jurisdicao", "BR")
    pais_rdap = ((r.get("rdap") or {}).get("pais") or "").upper()
    if jur == "BR" and pais_rdap and pais_rdap != "BR":
        lim.append(f"IP registrado em {pais_rdap} (RDAP): o prazo de guarda do Marco Civil (art. 13) pode NÃO se aplicar a provedor de conexão "
                   "estrangeiro; para provedor de aplicação que ofereça serviço ao público brasileiro o art. 15 pode se aplicar (art. 11). "
                   "Confirmar a lei local e a política do provedor, preservar cedo e usar cooperação internacional (references/base_legal.md §B). "
                   "O país do IP não define, sozinho, a lei aplicável.")
    prazo = None
    if evento_utc:
        prazo = ipa_prazos.calcular_prazos(evento_utc, agora_utc, retencoes=ipa_prazos.parse_retencoes(getattr(a, "retencao", None)), jurisdicao=jur)
    veredito = (f"{tipo} ({esc}{', ' + qual if qual else ''}); anonimização: {d['anonimizacao']}; "
                + ("para individualizar a conexão faltam: " + ", ".join(_listar_lacunas(dados)) if _listar_lacunas(dados) else "dados de atribuição completos")
                + ("; CONFLITO entre fontes" if d["conflitos"] else "") + ".")
    return {
        "ip": ip, "publico": True, "veredito": veredito, "tipo": tipo, "escala": esc, "qualificador": qual, "nota_escala": nota,
        "score": p["score"] if p else 0.0, "indicios": indicios,
        "papeis": d["papeis"], "anonimizacao": d["anonimizacao"], "conflitos": d["conflitos"],
        "alternativas": d["alternativas"], "detentor": rot["detentor"], "caminho": rot["solicitar"], "obstaculos": rot["obstaculos"],
        "viabilidade": {"titular": rot["titular"], "usuario": rot["usuario"]},
        "dados_atribuicao": dados, "lacunas_atribuicao": _listar_lacunas(dados),
        "prazo_guarda": prazo, "contexto_rede": ("Possível CGNAT — contexto de rede/porta necessários" if (cg_alto or cg) else "Não se aplica"),
        "consulta_externa": "Realizada (fontes em r.fontes)" if r.get("fontes") else "NÃO realizada (rode 'consultar')",
        "limitacoes": lim, "completude": completude(r, evento_utc, None),
        "contrarios": [c["descricao"] for c in d["conflitos"]],
        "divergencias": r.get("divergencias", []), "alertas_temporais": r.get("alertas_temporais", []),
        "evidencias_todas": [{k: e[k] for k in ("tipo", "forca", "familia", "fonte", "descricao", "confirma", "preservada")} for e in d["evidencias"]],
    }


def _esc(s):
    return str(s).replace("|", "\\|").replace("\n", " ")


def renderizar(itens, meta):
    L = ["# Tipologia dos IPs e caminho investigativo", "",
         f"_Gerado em {meta['gerado_em']} (UTC). Tipo de IP é **indício**, nunca prova de autoria. "
         f"Parâmetros em references/regras_tipologia.json._", ""]
    L += ["| IP | Tipo | Confiança | Anonimização | Prazo de guarda | Alertas |", "|---|---|---|---|---|---|"]
    for i in itens:
        pz = i.get("prazo_guarda")
        if isinstance(pz, dict) and pz.get("retencao_desconhecida"):
            pz_txt = "desconhecido (fora do BR) — preservar cedo"
        elif isinstance(pz, dict):
            pz_txt = " · ".join(f"{n}: {pz[k]['dias_restantes']} d" for k, n in (("conexao", "conexão"), ("aplicacao", "aplicação")) if k in pz) or "—"
        else:
            pz_txt = "informar data do fato"
        al = []
        if i["conflitos"]:
            al.append("🟡 conflito entre fontes")
        if str(i["anonimizacao"]).startswith(("Provável", "Confirmada")):
            al.append("🔴 anonimização")
        elif str(i["anonimizacao"]).startswith("Possível"):
            al.append("🟠 anonimização possível")
        if not i["publico"]:
            al.append("⚪ não público")
        L.append(f"| {i['ip']} | {_esc(i['tipo'])} | {i['escala']}" + (f" ({_esc(i['qualificador'])})" if i.get("qualificador") else "") +
                 f" | {_esc(i['anonimizacao'])} | {pz_txt if i['publico'] else 'preservar já'} | {' · '.join(al) or '—'} |")
    for i in itens:
        L += ["", f"## {i['ip']} — {i['tipo']} ({i['escala']})", ""]
        if i.get("veredito"):
            L += [f"> **Veredito técnico:** {_esc(i['veredito'])} _(indício; não é conclusão sobre autoria)_", ""]
        L += ["| Campo | Conteúdo |", "|---|---|"]
        conf = f"{i['escala']}" + (f" — {i['qualificador']}" if i.get("qualificador") else "")
        L.append(f"| Tipo provável (confiança) | **{_esc(i['tipo'])}** — {_esc(conf)} |")
        L.append("| Indícios que sustentam | " + "<br>".join(_esc(x) for x in i["indicios"]) + " |")
        L.append("| Outros papéis possíveis | " + (_esc("; ".join(f"{p['tipo']} ({p['escala']}" + (f", {p['qualificador']}" if p.get('qualificador') else "") + ")" for p in i["papeis"])) or "nenhum identificado") + " |")
        L.append(f"| Anonimização | {_esc(i['anonimizacao'])} |")
        L.append(f"| Quem detém o dado | {_esc(i['detentor'])} |")
        L.append(f"| Caminho investigativo | {_esc(i['caminho'])} |")
        L.append(f"| Obstáculos | {_esc(i['obstaculos'])} |")
        L.append(f"| Viabilidade (orientativa) | Titular da conexão/conta: {_esc(i['viabilidade']['titular'])} · Usuário: {_esc(i['viabilidade']['usuario'])} |")
        L.append("| Dados para atribuição | " + "<br>".join(f"{'✓' if d['tem'] else '✗'} {_esc(d['campo'])}" + (f" ({_esc(d['detalhe'])})" if d['detalhe'] else "")
                                                         for d in i["dados_atribuicao"]) + " |")
        pz = i.get("prazo_guarda")
        if isinstance(pz, dict):
            if pz.get("retencao_desconhecida"):
                txt = _esc(pz["aviso"])
            else:
                txt = "<br>".join(f"{rot} ({pz[k]['meses']} meses): vence {pz[k]['vence_em_utc'][:10]} — {pz[k]['status']}"
                                  for k, rot in (("conexao", "Conexão"), ("aplicacao", "Aplicação")) if k in pz)
            if pz.get("alerta_preservacao"):
                txt += "<br>⚠ " + _esc(pz["alerta_preservacao"])
        else:
            txt = _esc(pz) if pz else "Informar a data/hora do fato (--data-evento) para calcular; preservação cautelar se próximo do limite do prazo de guarda aplicável."
        L.append(f"| Prazo de guarda | {txt} |")
        L.append(f"| Contexto de rede (IP privado/CGNAT) | {_esc(i['contexto_rede'])} |")
        L.append(f"| Consulta externa | {_esc(i['consulta_externa'])} |")
        L.append("| Limitações | " + "<br>".join(_esc(x) for x in i["limitacoes"]) + " |")
        if i.get("nota_escala"):
            L += ["", f"> Nota sobre a confiança: {i['nota_escala']}"]
        if i["conflitos"] or i["alternativas"]:
            L += ["", "**Conflitos e hipóteses alternativas** (declarar; não escolher em silêncio):"]
            for c in i["conflitos"]:
                L.append(f"- 🟡 {c['descricao']}")
            for h in i["alternativas"]:
                L.append(f"- Hipótese **{h['tipo']}** ({h['escala']}, {h['score']}). Indícios a favor: {_esc('; '.join(h['a_favor']))}. "
                         f"Indícios contrários (a favor da(s) hipótese(s) rival(is)): {_esc('; '.join(h['contra']))}.")
        for dv in i.get("divergencias", []):
            L.append(f"- {'🟡' if dv['gravidade'] == 'conflito' else 'ℹ️'} Divergência em **{dv['campo']}**: {_esc(json.dumps(dv['valores'], ensure_ascii=False))} — {_esc(dv['leitura'])}")
        for t in i.get("alertas_temporais", []):
            L.append(f"- ⚠ {_esc(t)}")
        for t in i.get("alertas", []):
            L.append(f"- ⚠ {_esc(t)}")
        if i.get("completude"):
            c = i["completude"]
            L += ["", f"Completude da coleta: **{c['percentual']}%** — " + " · ".join(f"{x['estado']} {x['item']}" for x in c["itens"]) + f". _{c['aviso']}_"]
    return "\n".join(L) + "\n"


def cmd_tipologia(a):
    regras = carregar(a.regras, "regras_tipologia.json")
    oper = carregar_operadoras(a.operadoras)
    try:
        ipa_prazos.parse_retencoes(getattr(a, "retencao", None))
    except ValueError as e:
        print(f"ERRO: {e}")
        raise SystemExit(2)
    dados = json.load(open(a.entrada, encoding="utf-8"))
    norm_j = json.load(open(a.normalizado, encoding="utf-8")) if a.normalizado else None
    if "ips" in dados and "resultados" not in dados:
        norm_j, consultas = norm_j or dados, []
    else:
        consultas = dados.get("resultados", dados if isinstance(dados, list) else [])
    norm_idx = {r["ip"]: r for r in (norm_j or {}).get("ips", [])}
    agora_utc = dt.datetime.now(dt.timezone.utc)
    evento_utc, evento_txt = None, None
    parametros = dados.get("parametros") if isinstance(dados, dict) else None
    try:
        if a.data_evento:
            evento_utc, _ = ipa_prazos.interpretar_evento(a.data_evento, a.fuso)
        elif parametros and parametros.get("data_evento_utc"):
            evento_utc = dt.datetime.strptime(parametros["data_evento_utc"], "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=dt.timezone.utc)
    except ValueError as e:
        print(f"ERRO: {e}")
        raise SystemExit(2)
    evento_txt = evento_utc.strftime("%Y-%m-%dT%H:%M:%SZ") if evento_utc else None
    original = a.data_evento or (parametros or {}).get("data_evento_original")
    evento_rot = f"{original} → {evento_txt} UTC" if (original and evento_txt) else evento_txt
    itens, vistos = [], set()
    for r in consultas:
        ip = r["ip"]
        vistos.add(ip)
        publico = r["publico"] if "publico" in r else C.classificar(ipaddress.ip_address(ip))[1]
        rec = norm_idx.get(ip)
        if not publico:
            itens.append(classificar_nao_publico(rec or {"ip": ip, "classificacao": C.classificar(ipaddress.ip_address(ip))[0]}, regras, a))
            continue
        itens.append(classificar_publico(r, rec, regras, oper, a, evento_utc, evento_txt, agora_utc, evento_rot))
    for ip, rec in norm_idx.items():
        if ip in vistos:
            continue
        if not rec.get("publico"):
            itens.append(classificar_nao_publico(rec, regras, a))
        else:  # público mas sem consulta
            itens.append(classificar_publico({"ip": ip, "fontes": [], "lacunas": ["sem consulta externa (rode 'consultar')"]},
                                             rec, regras, oper, a, evento_utc, evento_txt, agora_utc, evento_rot))
    meta = {"gerado_em": C.agora()}
    saida = {"gerado_em_utc": meta["gerado_em"], "aviso": "Tipo de IP é indício, nunca prova de autoria. Hierarquia: evidência > correlação > hipótese.",
             "regras": os.path.basename(a.regras or "regras_tipologia.json"), "evento_utc": evento_txt, "itens": itens}
    C.escrever(a.saida, saida)
    md = renderizar(itens, meta)
    if a.md:
        os.makedirs(os.path.dirname(os.path.abspath(a.md)), exist_ok=True)
        open(a.md, "w", encoding="utf-8").write(md)
    print(md)
