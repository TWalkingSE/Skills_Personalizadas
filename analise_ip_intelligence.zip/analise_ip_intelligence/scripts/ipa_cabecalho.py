#!/usr/bin/env python3
"""
Cabeçalho de e-mail e X-Forwarded-For com FRONTEIRA DE CONFIANÇA (seções 4.5 e 6.2 da skill) — somente stdlib.

Regra de ouro: cada linha `Received:` é escrita pelo servidor que a RECEBEU (campo `by`). Só vale o que foi
escrito por servidores em que você confia (o seu provedor de destino e quem ele operou). Linhas mais antigas
(abaixo da fronteira) foram escritas por terceiros e podem ser forjadas: são indícios, não observação.

  • `Received` mais recente = topo do cabeçalho.
  • O IP candidato é o do `from` da linha MAIS ANTIGA escrita por servidor confiável.
  • IP privado/loopback na fronteira = cliente interno/webmail: não é identificável por esse elo.

Não faz consulta de rede.
"""
import email.utils
import ipaddress
import json
import re

import ipa_comum as C


def desdobrar(texto):
    """Cabeçalho → lista de (nome, valor) na ordem original (desdobra linhas de continuação)."""
    campos, atual = [], None
    for linha in texto.splitlines():
        if not linha.strip():
            if campos:
                break  # fim do cabeçalho
            continue
        if linha[0] in " \t" and atual is not None:
            atual[1] += " " + linha.strip()
            continue
        m = re.match(r"([!-9;-~]+):[ \t]*(.*)", linha)
        if m:
            atual = [m.group(1), m.group(2).strip()]
            campos.append(atual)
    return [(n, v) for n, v in campos]


def _ips(txt):
    out, vistos = [], set()
    for ach in C.extrair_linha(txt):
        try:
            ip = ipaddress.ip_address(ach["limpo"])
        except ValueError:
            continue
        if ip.compressed in vistos:
            continue
        vistos.add(ip.compressed)
        desc, pub = C.classificar(ip)
        out.append({"ip": ip.compressed, "classificacao": desc, "publico": pub})
    return out


def confiavel(host, sufixos):
    h = (host or "").lower().strip("[]()<>")
    return any(h == s or h.endswith("." + s) for s in sufixos)


def parse_received(valor):
    corpo, _, data = valor.rpartition(";") if ";" in valor else (valor, "", "")
    m_from = re.search(r"\bfrom\s+(.*?)(?=\s+by\s+|\s+with\s+|\s+id\s+|\s+for\s+|$)", corpo, re.I | re.S)
    m_by = re.search(r"\bby\s+([^\s;()]+)", corpo, re.I)
    from_txt = m_from.group(1).strip() if m_from else ""
    r = {"from": from_txt, "from_host": (from_txt.split() or [""])[0], "by": m_by.group(1).strip() if m_by else None,
         "ips": _ips(from_txt), "data_texto": data.strip() or None, "data_utc": None, "aviso_data": None}
    if data.strip():
        try:
            d = email.utils.parsedate_to_datetime(data.strip())
            if d.tzinfo is None:
                r["aviso_data"] = "data do Received sem fuso"
            else:
                r["data_utc"] = d.astimezone(__import__("datetime").timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        except Exception:  # noqa
            r["aviso_data"] = "data do Received não interpretável"
    return r


def analisar_cabecalho(texto, confiaveis):
    campos = desdobrar(texto)
    hops = []
    for nome, valor in campos:
        if nome.lower() == "received":
            hops.append(parse_received(valor))
    modo = "informado (--confiaveis)" if confiaveis else "PRESUMIDO: só o Received mais recente (escrito pelo seu servidor de destino)"
    for i, h in enumerate(hops):
        h["posicao"] = i + 1  # 1 = mais recente
    # confiança contígua a partir do topo. Um 'by' que NÃO é nome de host (ex.: identificador interno do mesmo
    # provedor, como '2002:a05:...' no Gmail) herda a confiança da linha acima.
    limite = len(hops)
    for i, h in enumerate(hops):
        eh_fqdn = bool(re.fullmatch(r"[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+", h["by"] or ""))
        if confiaveis:  # o topo é sempre o SEU servidor de destino; os demais exigem domínio confiável (ou herdam do interno)
            ok = (i == 0) or confiavel(h["by"], confiaveis) or (not eh_fqdn and hops[i - 1].get("confiavel"))
        else:
            ok = (i == 0) or (i == 1 and not eh_fqdn and hops[0].get("confiavel"))
        if not ok:
            limite = i
            break
        h["confiavel"] = True
    for i, h in enumerate(hops):
        h.setdefault("confiavel", False)
    candidato, nota = None, None
    for h in reversed(hops[:limite]):  # da mais antiga confiável para a mais recente
        pub = [x for x in h["ips"] if x["publico"]]
        if pub:
            candidato = {"ip": pub[0]["ip"], "hop": h["posicao"], "by": h["by"], "data_utc": h["data_utc"]}
            break
    if candidato is None and limite:
        deepest = hops[limite - 1]
        nota = ("A linha confiável mais antiga não traz IP público" +
                (f" (apenas {', '.join(x['ip'] + ' [' + x['classificacao'] + ']' for x in deepest['ips'])})" if deepest["ips"] else "") +
                ": cliente interno/webmail/NAT. Esse elo não identifica rede nem pessoa; o IP público está nos logs do provedor/serviço na data e hora do Received.")
    nao_verif = [{"hop": h["posicao"], "by": h["by"], "ips": [x["ip"] for x in h["ips"] if x["publico"]]}
                 for h in hops[limite:] if any(x["publico"] for x in h["ips"])]
    extras = {}
    for nome, valor in campos:
        ln = nome.lower()
        if ln in ("x-originating-ip", "x-forwarded-for", "x-real-ip", "x-sender-ip", "x-client-ip"):
            extras.setdefault(nome, []).append({"valor": valor, "ips": _ips(valor)})
        elif ln == "received-spf":
            m = re.search(r"client-ip=([0-9a-fA-F:.]+)", valor)
            extras.setdefault("Received-SPF", []).append({"valor": valor[:200], "client-ip": m.group(1) if m else None, "ips": _ips(m.group(1)) if m else []})
        elif ln == "authentication-results":
            res = {k: v for k, v in re.findall(r"\b(spf|dkim|dmarc|arc)=(\w+)", valor)}
            m = re.search(r"smtp\.(?:client-ip|remote-ip)=([0-9a-fA-F:.]+)", valor)
            extras.setdefault("Authentication-Results", []).append({"resultados": res, "ip_cliente": m.group(1) if m else None,
                                                                   "servidor": valor.split(";")[0].strip()[:80]})
    ident = {}
    for chave in ("From", "Reply-To", "Return-Path", "Message-ID", "Date", "Subject"):
        v = next((v for n, v in campos if n.lower() == chave.lower()), None)
        if v:
            ident[chave] = v[:200]
    doms = {}
    for k in ("From", "Reply-To", "Return-Path"):
        m = re.search(r"@([A-Za-z0-9.-]+)", ident.get(k, ""))
        if m:
            doms[k] = m.group(1).lower()
    divergencia = len(set(doms.values())) > 1
    return {"modo_confianca": modo, "hops": hops, "hops_confiaveis": limite, "ip_candidato": candidato, "nota_fronteira": nota,
            "ips_em_linhas_nao_verificadas": nao_verif, "campos_ip": extras, "identificacao": ident, "dominios": doms,
            "divergencia_de_dominios": divergencia,
            "avisos": ["Linhas abaixo da fronteira de confiança podem ser forjadas: tratar como indício e corroborar.",
                       "X-Originating-IP/X-Forwarded-For e similares são cabeçalhos opcionais: valem só se inseridos por servidor confiável.",
                       "IP encontrado em cabeçalho de e-mail NÃO prova quem escreveu a mensagem; indica o cliente/servidor que se conectou ao servidor confiável."]
            + (["From, Reply-To e Return-Path apontam domínios diferentes: sinal comum em fraude, mas não é prova por si só."] if divergencia else [])}


def analisar_xff(valor, n_proxies):
    entradas = [x.strip() for x in valor.split(",") if x.strip()]
    itens = []
    for x in entradas:
        ips = _ips(x)
        itens.append({"entrada": x, "ip": ips[0] if ips else None})
    n = max(1, n_proxies)
    if len(entradas) >= n:
        idx = len(entradas) - n
        aviso = None
    else:
        idx, aviso = 0, f"A lista tem menos entradas ({len(entradas)}) que proxies confiáveis informados ({n}): conferir a topologia."
    cliente = itens[idx] if itens else None
    return {"n_proxies_confiaveis": n, "entradas": itens, "cliente_provavel": cliente, "aviso": aviso,
            "nao_confiaveis_a_esquerda": [i["entrada"] for i in itens[:idx]],
            "leitura": ("O IP do par imediato (remote_addr) não aparece na lista: é o último proxy confiável. "
                        "Entradas à ESQUERDA do cliente provável foram enviadas pelo próprio cliente e podem ser forjadas.")}


def cmd_cabecalho(a):
    saida = {}
    if a.entrada:
        texto = open(a.entrada, encoding="utf-8", errors="replace").read()
        suf = [s.strip().lower() for s in (a.confiaveis or "").split(",") if s.strip()]
        saida["email"] = analisar_cabecalho(texto, suf)
    if a.xff:
        saida["xff"] = analisar_xff(a.xff, a.n_proxies)
    if not saida:
        print("Informe o arquivo do cabeçalho e/ou --xff.")
        raise SystemExit(2)
    C.escrever(a.saida, saida)
    if "email" in saida:
        e = saida["email"]
        print(f"Cadeia Received ({len(e['hops'])} linha(s)); confiança: {e['modo_confianca']}\n")
        print("| # | Escrito por (by) | Conectou de (from) | IPs | Data (UTC) | Confiável |")
        print("|---:|---|---|---|---|---|")
        for h in e["hops"]:
            ips = ", ".join(f"{x['ip']} [{x['classificacao']}]" for x in h["ips"]) or "—"
            print(f"| {h['posicao']} | {h['by'] or '—'} | {h['from_host'] or '—'} | {ips} | {h['data_utc'] or h['data_texto'] or '—'} | "
                  f"{'✓' if h['confiavel'] else '✗ (indício)'} |")
        c = e["ip_candidato"]
        print("\nIP candidato (linha confiável mais antiga com IP público): " +
              (f"**{c['ip']}** (Received #{c['hop']}, escrito por {c['by']}, {c['data_utc'] or 'sem data UTC'})" if c else "nenhum"))
        if e["nota_fronteira"]:
            print("⚠ " + e["nota_fronteira"])
        for n in e["ips_em_linhas_nao_verificadas"]:
            print(f"⚠ IP(s) {', '.join(n['ips'])} em linha NÃO confiável (#{n['hop']}, by {n['by']}): possível forjado; tratar como indício.")
        for k, v in e["campos_ip"].items():
            print(f"- {k}: {json.dumps(v, ensure_ascii=False)[:300]}")
        for av in e["avisos"]:
            print("ℹ " + av)
    if "xff" in saida:
        x = saida["xff"]
        c = x["cliente_provavel"]
        print(f"\nX-Forwarded-For ({len(x['entradas'])} entrada(s); {x['n_proxies_confiaveis']} proxy(ies) confiável(is)): "
              f"cliente provável = {c['entrada'] if c else '—'}")
        if x["nao_confiaveis_a_esquerda"]:
            print("⚠ Não confiáveis (enviadas pelo cliente): " + ", ".join(x["nao_confiaveis_a_esquerda"]))
        if x["aviso"]:
            print("⚠ " + x["aviso"])
        print("ℹ " + x["leitura"])
