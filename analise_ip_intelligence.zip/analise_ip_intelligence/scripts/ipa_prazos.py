#!/usr/bin/env python3
"""
Prazos de guarda e janelas de preservação — somente stdlib.

REFERÊNCIA BRASILEIRA (padrão, --jurisdicao BR) — Marco Civil da Internet, Lei 12.965/2014:
  • Provedor de CONEXÃO guarda registros de conexão por 1 ano (art. 13).
  • Provedor de APLICAÇÃO guarda registros de acesso a aplicações por 6 meses (art. 15).
  • A autoridade policial/administrativa ou o MP pode requerer a guarda cautelar por prazo superior
    (art. 13 §2º; art. 15 §2º); tem 60 dias, contados do requerimento, para pedir a autorização
    judicial de acesso (art. 13 §3º).

OUTRAS JURISDIÇÕES (--jurisdicao OUTRA): a skill NÃO presume prazo de guarda — ele depende da lei do país do provedor e
da política dele. Informe o que souber com --retencao conexao=MESES / aplicacao=MESES. As janelas de PRESERVAÇÃO de
alguns regimes (EUA, UE, Budapeste) estão em REGIMES_PRESERVACAO (orientativas; ver references/base_legal.md §B).

O cálculo é ORIENTATIVO: parte da data do evento (geração do registro), não considera preservação
cautelar já feita, nem prazos maiores previstos em contrato ou norma específica. Confirme o texto
vigente antes de usar em peça.
"""
import calendar
import datetime as dt
import math

import ipa_comum as C

RETENCAO_BR = {"conexao": (12, "Provedor de conexão — registros de conexão (MCI art. 13)"),
               "aplicacao": (6, "Provedor de aplicação — registros de acesso (MCI art. 15)")}
ROTULO = {"conexao": "Conexão", "aplicacao": "Aplicação"}

REGIMES_PRESERVACAO = {
    "BR": {"rotulo": "Brasil — MCI art. 13 §§2º–4º", "dias": 60, "prorroga": None,
           "natureza": "prazo para a autoridade protocolar o pedido judicial de acesso (a preservação perde a eficácia se não protocolado)",
           "base": "MCI art. 13 §3º — 60 dias do requerimento; art. 13 §4º — perde a eficácia se o pedido judicial não for protocolado no prazo"},
    "US": {"rotulo": "EUA — 18 U.S.C. § 2703(f)", "dias": 90, "prorroga": "mais 90 dias mediante novo pedido da entidade governamental",
           "natureza": "duração da preservação a pedido de entidade governamental, à espera de processo legal",
           "base": "18 U.S.C. § 2703(f): 90 dias, prorrogável por mais 90 (texto conferido no Cornell LII em 2026-10-24)"},
    "UE": {"rotulo": "UE — Regulamento (UE) 2023/1543 (EPOC-PR)", "dias": 60, "prorroga": "uma única vez (duração da prorrogação: conferir o art. 11 do Regulamento)",
           "natureza": "duração da preservação até surgir o pedido de produção; instrumento das autoridades dos Estados-Membros",
           "base": "Reg. (UE) 2023/1543, aplicável desde 18/08/2026 (fonte secundária; conferir o texto oficial). NÃO está disponível a autoridade de país terceiro"},
    "BUDAPESTE": {"rotulo": "Convenção de Budapeste — art. 29", "dias": 60, "prorroga": None,
                  "natureza": "preservação expedita entre Estados Partes (prazo MÍNIMO de 60 dias, art. 29(7))",
                  "base": "Convenção sobre o Crime Cibernético, arts. 16, 17, 29 e 35 (o prazo mínimo de 60 dias do art. 29(7) não foi reconfirmado nesta sessão: conferir o texto)"},
}


def somar_meses(d, n):
    m = d.month - 1 + n
    ano, mes = d.year + m // 12, m % 12 + 1
    dia = min(d.day, calendar.monthrange(ano, mes)[1])
    return d.replace(year=ano, month=mes, day=dia)


def _status(dias):
    if dias < 0:
        return "VENCIDO (presumível; verificar se houve preservação cautelar anterior)"
    if dias <= 30:
        return "URGENTE — preservar já (vence em até 30 dias)"
    if dias <= 90:
        return "ATENÇÃO — preparar preservação (vence em até 90 dias)"
    return "OK (dentro do prazo)"


def parse_retencoes(itens):
    """['conexao=24', 'aplicacao=12'] → {'conexao': (24, base), ...}. None/[] → None. Erro de formato → ValueError."""
    if not itens:
        return None
    out = {}
    for it in itens:
        nat, _, val = str(it).partition("=")
        nat = nat.strip().lower()
        if nat not in ROTULO or not val.strip().replace(",", ".").replace(".", "", 1).isdigit():
            raise ValueError(f"--retencao inválido: {it!r} (use conexao=MESES ou aplicacao=MESES, ex.: conexao=24)")
        meses = float(val.replace(",", "."))
        if meses <= 0 or meses != int(meses):
            raise ValueError(f"--retencao: informe meses inteiros e positivos ({it!r})")
        out[nat] = (int(meses), f"{ROTULO[nat]} — prazo INFORMADO pelo usuário ({int(meses)} meses); confirmar a base legal/política do provedor")
    return out


def calcular_prazos(evento_utc, agora_utc=None, retencoes=None, jurisdicao="BR"):
    """evento_utc / agora_utc: datetime com tzinfo UTC. Retorna dict com os prazos de guarda.

    BR (padrão): conexão 12 meses e aplicação 6 meses. OUTRA sem `retencoes`: devolve `retencao_desconhecida=True` e NENHUM
    vencimento (nunca presume). Com `retencoes`, calcula só as naturezas informadas.
    """
    agora_utc = agora_utc or dt.datetime.now(dt.timezone.utc)
    saida = {"jurisdicao": jurisdicao, "evento_utc": evento_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
             "calculado_em_utc": agora_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
             "aviso": "Cálculo orientativo a partir da data do evento; não considera preservação cautelar anterior "
                      "nem prazos diferentes do provedor. Conferir o texto vigente da norma aplicável.",
             "alerta_preservacao": None}
    if retencoes is None and jurisdicao != "BR":
        saida["retencao_desconhecida"] = True
        saida["aviso"] = ("Jurisdição diferente da brasileira: o prazo de guarda depende da lei do país do provedor e da política dele "
                          "(não há prazo universal). Informe --retencao conexao=MESES / aplicacao=MESES se souber (guia de atendimento a "
                          "autoridades do provedor), ou PRESERVE CEDO — ver references/base_legal.md §B.")
        saida["alerta_preservacao"] = ("Prazo de guarda do provedor DESCONHECIDO (jurisdição fora do BR): peça a preservação o quanto antes "
                                       "(subcomando 'oficio --jurisdicao OUTRA --tipo preservacao').")
        return saida
    regime = retencoes if retencoes is not None else RETENCAO_BR
    for chave, (meses, base) in regime.items():
        vence = somar_meses(evento_utc, meses)
        dias = math.floor((vence - agora_utc).total_seconds() / 86400)
        saida[chave] = {"base": base, "meses": meses, "vence_em_utc": vence.strftime("%Y-%m-%dT%H:%M:%SZ"),
                        "dias_restantes": dias, "status": _status(dias)}
    chaves = [k for k in ("conexao", "aplicacao") if k in saida]
    # prioridade operacional: o prazo mais curto ainda aberto
    abertos = [(saida[k]["dias_restantes"], k) for k in chaves if saida[k]["dias_restantes"] >= 0]
    if abertos:
        d, k = min(abertos)
        if d <= 90:
            saida["alerta_preservacao"] = (f"PRESERVAÇÃO: o prazo de guarda do provedor de {'conexão' if k == 'conexao' else 'aplicação'} "
                                           f"vence em {d} dia(s) ({saida[k]['vence_em_utc'][:10]}). "
                                           "Avaliar pedido de preservação cautelar imediato (subcomando 'oficio --tipo preservacao').")
    elif chaves and all(saida[k]["dias_restantes"] < 0 for k in chaves):
        saida["alerta_preservacao"] = ("Os prazos de guarda parecem VENCIDOS na data do cálculo. Verificar com o provedor se há "
                                       "preservação cautelar anterior, retenção maior por contrato/norma ou cópia já obtida.")
    return saida


def janela_preservacao(regime, pedido_em, agora_utc):
    """Janela do regime escolhido a partir da data (UTC) do requerimento de preservação."""
    g = REGIMES_PRESERVACAO[regime]
    fim = pedido_em + dt.timedelta(days=g["dias"])
    out = {"regime": regime, "rotulo": g["rotulo"], "preservacao_requerida_em": pedido_em.strftime("%Y-%m-%d"),
           "natureza": g["natureza"], "dias": g["dias"], "prorrogacao": g["prorroga"], "fim_do_prazo": fim.strftime("%Y-%m-%d"),
           "dias_restantes": (fim - agora_utc).days, "base": g["base"]}
    if regime == "US":
        out["fim_com_prorrogacao"] = (pedido_em + dt.timedelta(days=g["dias"] * 2)).strftime("%Y-%m-%d")
    return out


def interpretar_evento(texto, fuso_spec):
    """Texto de data/hora do evento + --fuso → (datetime UTC, dict do interpretar_ts).

    Exige fuso (explícito no texto ou via --fuso): nunca presume horário.
    """
    fuso = C.resolver_fuso(fuso_spec) if fuso_spec else None
    for rx, fmt in C.RE_TS:
        m = rx.search(texto)
        if m:
            info = C.interpretar_ts(m.group(0), fmt, fuso)
            break
    else:
        # só data (AAAA-MM-DD): precisão BAIXA; considera 00:00 no fuso informado
        try:
            d = dt.datetime.strptime(texto.strip(), "%Y-%m-%d")
            info = C.interpretar_ts(d.strftime("%Y-%m-%d 00:00:00"), "iso", fuso)
            info["alertas"].append("somente data informada: considerado 00:00 do dia (precisão BAIXA)")
        except ValueError:
            raise ValueError(f"Data/hora do evento não reconhecida: {texto!r} (use AAAA-MM-DD HH:MM:SS, "
                             "DD/MM/AAAA HH:MM:SS ou ISO-8601 com fuso).")
    if not info.get("utc"):
        raise ValueError("Data/hora do evento sem fuso horário. Informe --fuso (UTC, -03:00 ou um nome IANA, ex.: America/Maceio, "
                         "Europe/London) ou inclua o deslocamento no texto. O fuso não é presumido.")
    return dt.datetime.strptime(info["utc"][:19], "%Y-%m-%dT%H:%M:%S").replace(tzinfo=dt.timezone.utc), info


def cmd_prazos(a):
    try:
        evento, info = interpretar_evento(a.evento, a.fuso)
        ret = parse_retencoes(getattr(a, "retencao", None))
    except ValueError as e:
        print(f"ERRO: {e}")
        raise SystemExit(2)
    jur = getattr(a, "jurisdicao", "BR")
    agora = dt.datetime.now(dt.timezone.utc)
    if a.hoje:
        agora = dt.datetime.strptime(a.hoje, "%Y-%m-%d").replace(tzinfo=dt.timezone.utc)
    p = calcular_prazos(evento, agora, ret, jur)
    p["entrada"] = {"data_hora_original": a.evento, "fuso": a.fuso, "alertas": info.get("alertas", [])}
    if a.preservacao_em:
        pe = dt.datetime.strptime(a.preservacao_em, "%Y-%m-%d").replace(tzinfo=dt.timezone.utc)
        regime = getattr(a, "regime", "BR")
        w = janela_preservacao(regime, pe, agora)
        p["preservacao"] = w
        if regime == "BR":  # compatibilidade com o formato anterior
            p["pedido_judicial"] = {"preservacao_requerida_em": w["preservacao_requerida_em"], "prazo_para_pedido_judicial": w["fim_do_prazo"],
                                    "dias_restantes": w["dias_restantes"], "base": w["base"]}
    if a.saida:
        C.escrever(a.saida, p)
    print(f"Evento (UTC): {p['evento_utc']}  |  cálculo em: {p['calculado_em_utc']}  |  jurisdição de referência: {jur}")
    for k in ("conexao", "aplicacao"):
        if k in p:
            x = p[k]
            meses = (ret or RETENCAO_BR)[k][0]
            print(f"- {ROTULO[k]} ({meses} meses): vence em {x['vence_em_utc'][:10]} — {x['dias_restantes']} dia(s) — {x['status']}")
    if p.get("retencao_desconhecida"):
        print("- Prazo de guarda: DESCONHECIDO (jurisdição fora do BR; não presumido).")
    if "preservacao" in p:
        w = p["preservacao"]
        print(f"- Preservação — {w['rotulo']}: {w['dias']} dia(s) a partir de {w['preservacao_requerida_em']} → até {w['fim_do_prazo']} "
              f"({w['dias_restantes']} dia(s)); {w['natureza']}."
              + (f" Prorrogação: {w['prorrogacao']}." if w["prorrogacao"] else "")
              + (f" Com prorrogação: até {w['fim_com_prorrogacao']}." if w.get("fim_com_prorrogacao") else ""))
    for al in info.get("alertas", []):
        print(f"⚠ {al}")
    if p["alerta_preservacao"]:
        print("\n⚠ " + p["alerta_preservacao"])
    print("\n" + p["aviso"])
