#!/usr/bin/env python3
"""
Análise de Endereços IP — ferramenta de apoio da skill (Python 3.9+, somente stdlib).

Subcomandos:
  normalizar    Extrai IPs de texto/log (defang, porta, colchetes IPv6), valida, deduplica, classifica
                faixas especiais (IANA), identifica o PAPEL do IP (origem × destino) e a semântica da
                porta, interpreta timestamps com fuso/UTC (sem alterar o original), extrai IPv4 embutido
                em 6to4/Teredo/NAT64/mapeado e agrupa por /24, /48 e /64.
  consultar     Consulta PASSIVA de fontes públicas para IPs públicos: RIPEstat (prefixo/ASN, geolocalização,
                histórico de roteamento), RDAP (rdap.org → RIR/NIR e Registro.br), PTR, lista Tor, listas
                oficiais de cloud/CDN, InternetDB, PeeringDB, proxycheck.io (VPN/proxy/Tor; API pública sem
                cadastro, 100 consultas/dia) e 2ª/3ª geolocalização. Cada resposta bruta é
                guardada com URL (sem chaves de API), data/hora UTC e SHA-256. Com --data-evento compara registro, roteamento e
                prazos de guarda com a data do fato.
  tipologia     Classifica o tipo do IP (residencial, móvel, datacenter, VPN, Tor, CDN, privado…) com tabela
                de decisão explícita, conflitos, hipóteses alternativas e o bloco "Classificação do IP e
                caminho investigativo".
  correlacionar Agrupa por ASN/prefixo/organização/domínio do PTR, similaridade técnica explicável,
                clusters, hubs, outliers; exporta o caso (CASE/ENTITY/…) e o grafo.
  prazos        Vencimento da guarda do provedor a partir do evento (referência BR: conexão 1 ano, aplicação 6 meses;
                outra jurisdição: --jurisdicao OUTRA --retencao conexao=N) e janelas de preservação (BR, EUA, UE, Budapeste).
  cabecalho     Lê cabeçalho de e-mail (cadeia Received com fronteira de confiança) e/ou cadeia X-Forwarded-For.
  oficio        Gera MINUTA de ofício (BR: preservação cautelar, requisição cadastral, roteiro de representação;
                provedor no exterior: --jurisdicao OUTRA → solicitação de preservação expedita).
  validar       Verifica um relatório: linguagem proibida (IP = pessoa) e blocos obrigatórios.

Modelo de dados exportado (§124–130): CASE · ENTITY · RELATIONSHIP · OBSERVATION · EVIDENCE,
com observed_at separado de valid_from/valid_until. Cache, retry e trilha de auditoria (§152–155).

Nada aqui é intrusivo: não há varredura de portas, autenticação ou contato com o alvo além de
consultas DNS reversas (PTR) e APIs/listas públicas.
"""
import argparse, csv, datetime as dt, hashlib, ipaddress, json, os, re, socket, sys, time
import urllib.request, urllib.error
from collections import Counter, defaultdict
from xml.sax.saxutils import escape

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))  # módulos irmãos (funciona também com python -I)
import ipa_comum as C
from ipa_comum import ESPECIAIS, agora, classificar, precisao_ts, extrair_linha, RE_TS  # noqa: F401

UA = "analise-ip-skill/2.0 (investigacao; consulta passiva)"

RE_URL = re.compile(r"\b(?:https?|hxxps?|ftp)(?:://|\[://\])[^\s\"'<>]+", re.I)
RE_EMAIL = re.compile(r"\b[A-Za-z0-9._%+-]+(?:@|\[@\])[A-Za-z0-9.-]+(?:\.|\[\.\])[A-Za-z]{2,24}\b")
RE_DOM = re.compile(r"\b(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.|\[\.\]))+[A-Za-z]{2,24}\b")
NAO_TLD = {"php", "html", "htm", "js", "json", "txt", "log", "csv", "exe", "py", "jpg", "jpeg", "png", "gif",
           "xml", "asp", "aspx", "jsp", "cgi", "css", "pdf", "doc", "docx", "xls", "xlsx", "dll", "sh", "bak"}


def desfang(v):
    return re.sub(r"\[\.\]|\(\.\)|\{\.\}", ".", v).replace("[@]", "@").replace("[://]", "://").replace("hxxp", "http")


def extrair_outros(linha, n, acc):
    for tipo, rx in (("url", RE_URL), ("email", RE_EMAIL), ("dominio", RE_DOM)):
        for m in rx.finditer(linha):
            v = desfang(m.group(0)).rstrip(".,;)")
            if tipo == "dominio":
                v = v.lower()
                if v.rsplit(".", 1)[-1] in NAO_TLD or re.fullmatch(r"[\d.]+", v):
                    continue
            item = acc[tipo].setdefault(v, {"valor": v, "ocorrencias": 0, "linhas": []})
            item["ocorrencias"] += 1
            if len(item["linhas"]) < 20:
                item["linhas"].append(n)


def _novo_registro(chave, versao):
    return {"ip": chave, "versao": versao, "ocorrencias": 0, "formas_originais": [], "linhas": [],
            "portas": [], "portas_detalhe": [], "papeis": {"origem": 0, "destino": 0, "indefinido": 0},
            "timestamps": []}


def cmd_normalizar(a):
    texto = open(a.entrada, encoding="utf-8", errors="replace").read() if a.entrada != "-" else sys.stdin.read()
    try:
        fuso = C.resolver_fuso(a.fuso) if a.fuso else None
    except ValueError as e:
        print(f"ERRO: {e}")
        raise SystemExit(2)
    registros, invalidos = {}, Counter()
    outros = {"url": {}, "email": {}, "dominio": {}}
    qual_tempo = Counter()
    for n, linha in enumerate(texto.splitlines(), 1):
        extrair_outros(linha, n, outros)
        ts_info = None
        for rx, f in RE_TS:
            mt = rx.search(linha)
            if mt:
                ts_info = C.interpretar_ts(mt.group(0), f, fuso)
                ts_info["linha"] = n
                qual_tempo[ts_info["fuso_status"]] += 1
                if ts_info["utc"] is None and ts_info["fuso_status"] == "AUSENTE":
                    qual_tempo["sem_utc"] += 1
                break
        spt, dpt = C.portas_rotuladas(linha)
        for ach in extrair_linha(linha):
            try:
                ip = ipaddress.ip_address(ach["limpo"])
            except ValueError:
                invalidos[ach["bruto"]] += 1
                continue
            chave = ip.compressed
            r = registros.setdefault(chave, _novo_registro(chave, f"IPv{ip.version}"))
            r["ocorrencias"] += 1
            if ach["bruto"] not in r["formas_originais"]:
                r["formas_originais"].append(ach["bruto"])
            if len(r["linhas"]) < 50:
                r["linhas"].append(n)
            papel = C.papel_do_ip(linha, ach["ini"])
            r["papeis"][papel] += 1
            # porta: papel herdado do rótulo do IP; senão o declarado pelo usuário; senão INDEFINIDO
            porta, papel_porta, metodo = None, "indefinida", None
            if ach["porta"] is not None:
                porta = ach["porta"]
                if papel in ("origem", "destino"):
                    papel_porta, metodo = papel, "rótulo do IP no log"
                elif a.porta_semantica in ("origem", "destino"):
                    papel_porta, metodo = a.porta_semantica, "declarado pelo usuário (--porta-semantica)"
            elif papel == "origem" and spt is not None:
                porta, papel_porta, metodo = spt, "origem", "SPT/sport rotulado na linha"
            elif papel == "destino" and dpt is not None:
                porta, papel_porta, metodo = dpt, "destino", "DPT/dport rotulado na linha"
            if porta is not None:
                if porta not in r["portas"]:
                    r["portas"].append(porta)
                if not any(d["porta"] == porta and d["papel"] == papel_porta for d in r["portas_detalhe"]):
                    r["portas_detalhe"].append({"porta": porta, "papel": papel_porta, "metodo": metodo or "não determinado",
                                                "linha": n,
                                                "dica": C.dica_porta(porta, papel_porta) if papel_porta in ("indefinida", "origem") else None})
            if ts_info:
                r["timestamps"].append(dict(ts_info))
    # IPv4 embutido em endereços de transição → registros derivados (indício, rastreáveis)
    for chave in list(registros):
        r = registros[chave]
        ip = ipaddress.ip_address(chave)
        r["ipv4_embutido"] = C.embutido(ip)
        for e in r["ipv4_embutido"]:
            if not e["analisar"]:
                continue
            d = registros.setdefault(e["endereco"], _novo_registro(e["endereco"], "IPv4"))
            d.setdefault("derivado_de", []).append({"ip": chave, "metodo": e["metodo"], "papel": e["papel"], "nota": e["nota"]})
            d["linhas"] = sorted(set(d["linhas"]) | set(r["linhas"]))[:50]
            if not d["timestamps"]:
                d["timestamps"] = [dict(t) for t in r["timestamps"]]
    for r in registros.values():
        ip = ipaddress.ip_address(r["ip"])
        r["classificacao"], r["publico"] = classificar(ip)
        r["portas_origem"] = [d["porta"] for d in r["portas_detalhe"] if d["papel"] == "origem"]
        if ip.version == 4:
            r["bloco_24"] = str(ipaddress.ip_network(f"{ip}/24", strict=False))
        else:
            r["prefixo_48"] = str(ipaddress.ip_network(f"{ip}/48", strict=False))
            r["prefixo_64"] = str(ipaddress.ip_network(f"{ip}/64", strict=False))
        if r["timestamps"]:
            ords = [t["timestamp_original"] for t in r["timestamps"]]
            r["primeira_ocorrencia_texto"], r["ultima_ocorrencia_texto"] = ords[0], ords[-1]
        al = []
        for d in r["portas_detalhe"]:
            if d["papel"] == "origem" and d.get("dica"):
                al.append(d["dica"][0].upper() + d["dica"][1:] + ".")
        if any(d["papel"] == "indefinida" for d in r["portas_detalhe"]):
            al.append("PORTA com semântica indeterminada (origem × destino não identificada no log): NÃO usar como "
                      "'porta lógica de origem' em ofício sem confirmar o campo com quem gerou o log.")
        if any(t["fuso_status"] == "AUSENTE" for t in r["timestamps"]):
            al.append("HORÁRIO sem fuso: perguntar se o log está em UTC ou horário local e informar --fuso.")
        p = r["papeis"]
        if r["ocorrencias"] and p["destino"] and not p["origem"] and not p["indefinido"]:
            al.append("IP aparece só como DESTINO: provável servidor/infraestrutura acessada (possivelmente da própria vítima), "
                      "não a origem do acesso.")
        elif p["origem"] and p["destino"]:
            al.append("IP aparece como origem e como destino em linhas diferentes: separar os eventos antes de qualquer conclusão.")
        if r.get("derivado_de"):
            al.append("IP DERIVADO de endereço de transição (" + "; ".join(x["metodo"] for x in r["derivado_de"]) +
                      "): indício, não observação direta.")
        if a.origem and C.tipo_nao_publico(r["classificacao"]) in ("IP privado", "CGNAT") and not r["publico"]:
            desc, leitura, passo = C.ORIGENS[a.origem]
            r["leitura_contexto"] = {"origem_do_dado": desc, "leitura": leitura, "proximo_passo": passo}
        if al:
            r["alertas"] = al
    lista = sorted(registros.values(), key=lambda x: (-x["ocorrencias"], x["ip"]))
    blocos = defaultdict(list)
    for r in lista:
        blocos[r.get("bloco_24") or r.get("prefixo_64")].append(r["ip"])
    todos_ts = [t for r in lista if not r.get("derivado_de") or r["ocorrencias"] for t in r["timestamps"]]
    qualidade = {
        "fuso_informado": a.fuso,
        "linhas_com_timestamp": sum(v for k, v in qual_tempo.items() if k != "sem_utc"),
        "fuso_explicito": qual_tempo.get("explicito", 0),
        "fuso_assumido_pelo_usuario": qual_tempo.get("assumido_pelo_usuario", 0),
        "sem_fuso_sem_utc": qual_tempo.get("AUSENTE", 0),
        "portas_origem_identificadas": sum(len(r["portas_origem"]) for r in lista),
        "portas_semantica_indefinida": sum(1 for r in lista for d in r["portas_detalhe"] if d["papel"] == "indefinida"),
        "observacao": "Atribuição em CGNAT exige IP + PORTA DE ORIGEM + hora com segundos + fuso (seção 5.5 da skill)."}
    saida = {"gerado_em_utc": agora(), "entrada": a.entrada,
             "sha256_entrada": hashlib.sha256(texto.encode("utf-8")).hexdigest(),
             "contexto_origem": ({"origem": a.origem, **dict(zip(("descricao", "leitura", "proximo_passo"), C.ORIGENS[a.origem]))}
                                 if a.origem else None),
             "total_ips_unicos": len(lista), "total_ocorrencias": sum(r["ocorrencias"] for r in lista),
             "publicos": sum(1 for r in lista if r["publico"]), "nao_publicos": sum(1 for r in lista if not r["publico"]),
             "invalidos": dict(invalidos), "qualidade_dados_atribuicao": qualidade,
             "agrupamento_bloco": {k: v for k, v in blocos.items() if len(v) > 1},
             "ips": lista,
             "outros_indicadores": {
                 "status": "PENDENTE DE APROVAÇÃO HUMANA (§150) — apresentar ao usuário antes de incorporar ao caso",
                 **{k: sorted(v.values(), key=lambda x: -x["ocorrencias"]) for k, v in outros.items()}}}
    escrever(a.saida, saida)
    print("| IP | Versão | Ocorrências | Classificação | Papel | Portas | 1ª/última (texto) |")
    print("|---|---|---:|---|---|---|---|")
    for r in lista[: a.limite]:
        papel = "/".join(k for k in ("origem", "destino", "indefinido") if r["papeis"][k]) or ("derivado" if r.get("derivado_de") else "—")
        portas = ", ".join(f"{d['porta']} [{d['papel']}]" for d in r["portas_detalhe"]) or "—"
        print(f"| {r['ip']} | {r['versao']} | {r['ocorrencias']} | {r['classificacao']} | {papel} | {portas} | "
              f"{r.get('primeira_ocorrencia_texto', '—')} / {r.get('ultima_ocorrencia_texto', '—')} |")
    if len(lista) > a.limite:
        print(f"\n… {len(lista) - a.limite} IPs adicionais no JSON.")
    if invalidos:
        print(f"\nEntradas inválidas descartadas: {dict(invalidos)}")
    if qualidade["linhas_com_timestamp"]:
        print(f"\nTempo: {qualidade['fuso_explicito']} linha(s) com fuso explícito, {qualidade['fuso_assumido_pelo_usuario']} com fuso "
              f"assumido (--fuso {a.fuso}), {qualidade['sem_fuso_sem_utc']} SEM fuso (sem conversão para UTC).")
    if qualidade["portas_semantica_indefinida"]:
        print(f"⚠ {qualidade['portas_semantica_indefinida']} porta(s) com semântica indefinida (origem × destino não identificada). "
              "Confirme o campo do log antes de usar como porta lógica de origem.")
    for r in lista:
        for al in r.get("alertas", []):
            if r["ocorrencias"] or r.get("derivado_de"):
                print(f"⚠ {r['ip']}: {al}")
    for k, rot in (("dominio", "Domínios"), ("url", "URLs"), ("email", "E-mails")):
        if outros[k]:
            vals = sorted(outros[k].values(), key=lambda x: -x["ocorrencias"])
            print(f"\n{rot} extraídos (pendentes de aprovação): " + ", ".join(
                f"{x['valor']} ({x['ocorrencias']})" for x in vals[:20]) + (" …" if len(vals) > 20 else ""))


# ----------------------------------------------------------------------------- consultas passivas
CFG = {"cache": None, "ttl_h": 24.0, "atualizar": False, "auditoria": None, "tentativas": 3, "timeout": 20}


def auditar(acao, indicador, fonte, resultado, extra=None):
    """Trilha de auditoria JSONL (§152). Nunca registra segredos, tokens ou chaves (§157)."""
    if not CFG["auditoria"]:
        return
    linha = {"data_hora_utc": agora(), "acao": acao, "indicador": indicador, "fonte": fonte, "resultado": resultado}
    if extra:
        linha.update(extra)
    with open(CFG["auditoria"], "a", encoding="utf-8") as f:
        f.write(json.dumps(linha, ensure_ascii=False) + "\n")


def em_cache(url):
    """True se baixar(url) seria atendido pelo cache local (não gasta cota de API de terceiros)."""
    if not CFG["cache"] or CFG["atualizar"]:
        return False
    cpath = os.path.join(CFG["cache"], hashlib.sha256(C.redigir(url).encode()).hexdigest() + ".json")
    return os.path.exists(cpath) and time.time() - os.path.getmtime(cpath) < CFG["ttl_h"] * 3600


def baixar(url, pasta, indicador=None, fonte=None):
    url_reg = C.redigir(url)  # a requisição usa `url`; TUDO o que é registrado (reg, auditoria, cache, nome do arquivo) usa `url_reg`
    chave = hashlib.sha256(url_reg.encode()).hexdigest()
    cpath = os.path.join(CFG["cache"], chave + ".json") if CFG["cache"] else None
    if cpath and os.path.exists(cpath) and not CFG["atualizar"]:
        if time.time() - os.path.getmtime(cpath) < CFG["ttl_h"] * 3600:
            c = json.load(open(cpath, encoding="utf-8"))
            corpo = bytes.fromhex(c["corpo_hex"]) if c.get("corpo_hex") else None
            reg = dict(c["reg"], cache=True)
            auditar("consulta (cache)", indicador, fonte, "ok" if corpo else "erro", {"url": url_reg})
            return reg, corpo
    reg, corpo = {"url": url_reg, "consultado_em_utc": agora()}, None
    for tentativa in range(1, CFG["tentativas"] + 1):
        reg = {"url": url_reg, "consultado_em_utc": agora(), "tentativas": tentativa}
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json, application/rdap+json, */*"})
            with urllib.request.urlopen(req, timeout=CFG["timeout"]) as resp:
                corpo = resp.read()
                reg.update(status=resp.status, url_final=C.redigir(resp.geturl()))
            break
        except urllib.error.HTTPError as e:
            corpo = e.read() if hasattr(e, "read") else b""
            reg.update(status=e.code, erro=f"HTTP {e.code}")
            if e.code not in (429, 500, 502, 503, 504):
                break
        except Exception as e:  # noqa
            corpo = None
            reg.update(status=None, erro=C.redigir(f"{type(e).__name__}: {e}"))
            if "Tunnel connection failed" in str(e) or "Name or service not known" in str(e):
                break  # bloqueio de rede/DNS: repetir não adianta
        time.sleep(2 ** tentativa)
    auditar("consulta", indicador, fonte, "erro" if reg.get("erro") else "ok", {"url": url_reg, "status": reg.get("status")})
    if corpo is None:
        return reg, None
    reg["sha256_resposta"] = hashlib.sha256(corpo).hexdigest()
    st = reg.get("status") or 0
    if cpath and st not in (401, 403, 429) and st < 500:  # negação/limite/erro de servidor é transitório: não cachear
        with open(cpath, "w", encoding="utf-8") as f:
            json.dump({"reg": reg, "corpo_hex": corpo.hex()}, f)
    if pasta:
        nome = re.sub(r"[^A-Za-z0-9._-]+", "_", url_reg)[:150] + ".raw"
        with open(os.path.join(pasta, nome), "wb") as f:
            f.write(corpo)
        reg["arquivo_bruto"] = nome
    return reg, corpo


def json_ou_none(corpo):
    try:
        return json.loads(corpo) if corpo else None
    except Exception:  # noqa
        return None


def vcard_nome(ent):
    try:
        for item in ent.get("vcardArray", [None, []])[1]:
            if item[0] == "fn":
                return item[3]
    except Exception:  # noqa
        pass
    return None


def emails_abuso(ents, acc=None):
    acc = acc if acc is not None else []
    for e in ents or []:
        if "abuse" in (e.get("roles") or []):
            for item in (e.get("vcardArray") or [None, []])[1]:
                if item[0] == "email" and item[3] not in acc:
                    acc.append(item[3])
        emails_abuso(e.get("entities"), acc)
    return acc


def cmd_consultar(a):
    import ipa_fontes
    import ipa_prazos
    base = json.load(open(a.entrada, encoding="utf-8"))
    ips = [r["ip"] for r in base.get("ips", []) if r.get("publico")] if "ips" in base else base
    pasta = a.brutos
    if pasta:
        os.makedirs(pasta, exist_ok=True)
    CFG.update(ttl_h=a.ttl_cache, atualizar=a.atualizar, timeout=a.timeout,
               auditoria=a.auditoria or (os.path.join(pasta, "auditoria.jsonl") if pasta else None))
    if a.cache:
        os.makedirs(a.cache, exist_ok=True)
        CFG["cache"] = a.cache
    completo = a.perfil == "completo"
    evento_utc, info_evento, prazos = None, None, None
    if a.data_evento:
        try:
            evento_utc, info_evento = ipa_prazos.interpretar_evento(a.data_evento, a.fuso)
        except ValueError as e:
            print(f"ERRO: {e}")
            raise SystemExit(2)
        prazos = ipa_prazos.calcular_prazos(evento_utc, retencoes=ipa_prazos.parse_retencoes(a.retencao),
                                            jurisdicao=a.jurisdicao)
    chaves = [x.strip() for x in (a.listas or "").split(",") if x.strip()] if completo else []
    # Regra 11: consulta externa registra o interesse no indicador (OPSEC) — avisar e enviar SÓ o indicador
    hosts = ["stat.ripe.net", "rdap.org (→ RIR/NIR)"] + ([] if a.sem_tor else ["check.torproject.org"])
    if completo:
        hosts += ["internetdb.shodan.io", "www.peeringdb.com (só ASN)", "rdap.registro.br (IPs do Brasil)"]
        hosts += [] if a.sem_geo2 else ["ipinfo.io", "api.db-ip.com"]
        hosts += [u.split("/")[2] for k in chaves for u in (ipa_fontes.LISTAS.get(k) or {"urls": []})["urls"]]
    pc_ativo = (completo and not a.sem_proxycheck) or a.proxycheck
    if pc_ativo:
        hosts.append("proxycheck.io (API pública" + (", com chave do ambiente" if os.environ.get("PROXYCHECK_KEY") else ", sem chave/cadastro") + ")")
    print("Esta etapa requer consulta externa. Serão enviados SOMENTE os indicadores (IPs/ASNs, nunca contexto do caso) a: "
          + ", ".join(sorted(set(hosts))) + ".")
    print("Cada serviço de terceiros pode registrar o interesse nesses indicadores (OPSEC).\n")
    ctx = {"baixar": baixar, "pasta": pasta, "indice": None, "listas_status": {}, "listas_ok": [], "listas_falha": [],
           "peeringdb": {}, "asinfo": {}, "sem_geo2": a.sem_geo2, "sem_ptr": a.sem_ptr, "perfil_completo": completo,
           "evento_utc": evento_utc, "evento_utc_txt": evento_utc.strftime("%Y-%m-%dT%H:%M:%SZ") if evento_utc else None,
           "agora_utc": dt.datetime.now(dt.timezone.utc), "em_cache": em_cache}
    ctx["proxycheck"] = ipa_fontes.preparar_proxycheck(
        ativo=pc_ativo, versao=a.proxycheck_versao, dias=a.proxycheck_dias, limite=a.proxycheck_limite,
        ignorar_cota=a.proxycheck_ignorar_cota, chave=os.environ.get("PROXYCHECK_KEY"),
        cota_arquivo=os.path.join(a.cache, "proxycheck_cota.json") if a.cache else None, agora_utc=ctx["agora_utc"])
    if chaves:
        ctx["indice"], ctx["listas_status"] = ipa_fontes.carregar_listas(baixar, pasta, chaves)
        ctx["listas_ok"] = [k for k, v in ctx["listas_status"].items() if v.get("ok")]
        ctx["listas_falha"] = [k for k, v in ctx["listas_status"].items() if not v.get("ok")]
    tor_set, tor_reg = set(), None
    if not a.sem_tor:
        tor_reg, corpo = baixar("https://check.torproject.org/torbulkexitlist", pasta, "*", "Tor bulk exit list")
        if corpo:
            tor_set = {l.strip() for l in corpo.decode(errors="replace").splitlines() if l.strip()}
    resultados = []
    for ip in ips:
        r = {"ip": ip, "fontes": [], "lacunas": []}
        # RIPEstat — prefixo/ASN anunciados
        reg, corpo = baixar(f"https://stat.ripe.net/data/prefix-overview/data.json?resource={ip}", pasta, ip, "RIPEstat prefix-overview")
        r["fontes"].append({"fonte": "RIPEstat prefix-overview", **reg})
        d = (json_ou_none(corpo) or {}).get("data") or {}
        if d:
            r["prefixo"] = d.get("resource")
            r["anunciado"] = d.get("announced")
            asns = d.get("asns") or []
            r["asn"] = [f"AS{x.get('asn')}" for x in asns]
            r["as_nome"] = [x.get("holder") for x in asns]
            if len(asns) > 1:
                r["alerta_moas"] = "Prefixo com múltiplas origens (MOAS) — verificar"
            r["bloco_iana"] = (d.get("block") or {}).get("desc")
        else:
            r["lacunas"].append("prefixo/ASN (RIPEstat indisponível)")
        # RIPEstat — geolocalização (MaxMind GeoLite via RIPEstat) — fonte de BAIXA confiabilidade
        if not a.sem_geo:
            reg, corpo = baixar(f"https://stat.ripe.net/data/maxmind-geo-lite/data.json?resource={ip}", pasta, ip, "RIPEstat maxmind-geo-lite")
            r["fontes"].append({"fonte": "RIPEstat maxmind-geo-lite", **reg})
            locs = ((json_ou_none(corpo) or {}).get("data") or {}).get("located_resources") or []
            geo = []
            for lr in locs:
                for loc in lr.get("locations") or []:
                    geo.append({k: loc.get(k) for k in ("country", "city", "latitude", "longitude", "covered_percentage")})
            r["geolocalizacao"] = geo or None
        # RDAP (bootstrap rdap.org → RIR/NIR responsável)
        reg, corpo = baixar(f"https://rdap.org/ip/{ip}", pasta, ip, "RDAP")
        r["fontes"].append({"fonte": "RDAP (rdap.org bootstrap)", **reg})
        j = json_ou_none(corpo)
        if j and j.get("objectClassName") == "ip network":
            r["rdap"] = {
                "handle": j.get("handle"), "nome": j.get("name"), "tipo": j.get("type"),
                "inicio": j.get("startAddress"), "fim": j.get("endAddress"), "pais": j.get("country"),
                "parent": j.get("parentHandle"), "servidor_rdap": reg.get("url_final"),
                "entidades": [{"handle": e.get("handle"), "papeis": e.get("roles"), "nome": vcard_nome(e)}
                              for e in j.get("entities") or []],
                "eventos": [{"acao": e.get("eventAction"), "data": e.get("eventDate")} for e in j.get("events") or []],
                "abuso": emails_abuso(j.get("entities")),
            }
            r["organizacao"] = next((e["nome"] for e in r["rdap"]["entidades"]
                                     if e.get("nome") and "registrant" in (e.get("papeis") or [])), None) or j.get("name")
        else:
            r["lacunas"].append("RDAP (sem resposta válida)")
        # PTR
        if not a.sem_ptr:
            try:
                ptr = socket.gethostbyaddr(ip)[0]
                r["ptr"] = ptr
            except Exception as e:  # noqa
                r["ptr"] = None
                r["lacunas"].append(f"PTR ({type(e).__name__})")
            r["fontes"].append({"fonte": "DNS reverso (resolvedor local)", "consultado_em_utc": agora(),
                                **({"erro": "sem PTR/erro de resolução"} if not r.get("ptr") else {})})
            auditar("consulta PTR", ip, "DNS reverso", "ok" if r.get("ptr") else "sem resultado")
        # Tor (lista ATUAL — para data do evento use ExoneraTor)
        if tor_reg:
            r["tor_saida_atual"] = (ip in tor_set) if tor_set else None
            r["fontes"].append({"fonte": "Tor bulk exit list (atual)", **tor_reg})
        if completo:
            ipa_fontes.consultar_extras(ip, r, ctx)
        ipa_fontes.consultar_proxycheck(ip, r, ctx)  # no-op se desativado; IP não público nunca chega aqui
        ipa_fontes.finalizar(ip, r, ctx)
        resultados.append(r)
        time.sleep(a.pausa)
    saida = {"gerado_em_utc": agora(),
             "aviso": "Dados atuais na data da consulta; para eventos passados, usar fontes históricas e declarar a limitação.",
             "parametros": {"perfil": a.perfil, "listas": chaves, "geo_extra": completo and not a.sem_geo2,
                            "proxycheck": ({"versao": ctx["proxycheck"]["versao"], "janela_dias": ctx["proxycheck"]["dias"],
                                            "com_chave": bool(ctx["proxycheck"]["chave"]), "limite_local": ctx["proxycheck"]["limite"],
                                            "usadas_hoje_utc": ctx["proxycheck"]["usadas"]} if pc_ativo else {"ativo": False}),
                            "jurisdicao": a.jurisdicao, "data_evento_original": a.data_evento, "data_evento_utc": ctx["evento_utc_txt"], "fuso": a.fuso,
                            "alertas_evento": (info_evento or {}).get("alertas", [])},
             "fontes_globais": {"tor": tor_reg, "listas_oficiais": ctx["listas_status"]},
             "prazos_guarda": prazos, "resultados": resultados}
    escrever(a.saida, saida)
    status = defaultdict(lambda: [0, 0])
    for r in resultados:
        for f in r["fontes"]:
            nome = f["fonte"].split(" (")[0] if f["fonte"].startswith("RDAP") else f["fonte"]
            status[nome][0 if not f.get("erro") else 1] += 1
    print("Status das fontes (§155):")
    for fonte, (ok, falha) in status.items():
        print(f"  {'✓' if ok and not falha else ('⚠' if ok else '✗')} {fonte}: {ok} ok, {falha} falha(s)")
    for k, v in ctx["listas_status"].items():
        print(f"  {'✓' if v.get('ok') else '✗'} Lista oficial {v.get('nome', k)}: {v.get('prefixos', 0)} prefixos"
              + (f" — {v['erro']}" if v.get("erro") else ""))
    if any(f for _, f in status.values()) or ctx["listas_falha"]:
        print("  ⚠ Resultados ausentes NÃO devem ser preenchidos por inferência; complete pela ferramenta web ou registre a lacuna. "
              "Ausência nas listas de cloud/CDN que não puderam ser baixadas NÃO prova que o IP não é de hospedagem.")
    for linha in ipa_fontes.resumo_proxycheck(ctx):
        print(("⚠ " if linha.startswith("proxycheck.io (aviso)") else "  ") + linha)
    if prazos and prazos.get("alerta_preservacao"):
        print("\n⚠ " + prazos["alerta_preservacao"])
    for r in resultados:
        for al in r.get("alertas_temporais", []):
            print(f"⚠ {r['ip']}: {al}")
        for dv in r.get("divergencias", []):
            if dv["gravidade"] == "conflito":
                print(f"⚠ {r['ip']}: divergência em {dv['campo']}: {dv['valores']}")
    print(json.dumps({"ips_consultados": len(resultados),
                      "com_lacunas": sum(1 for r in resultados if r["lacunas"]),
                      "saida": a.saida, "auditoria": CFG["auditoria"]}, ensure_ascii=False))


# ----------------------------------------------------------------------------- correlação
PESOS_PADRAO = {"asn": 20, "prefixo": 20, "organizacao": 15, "ptr_dominio": 10,
                "certificado": 15, "dominio": 10, "hospedagem": 5, "temporal": 5}


def dominio_base(host):
    if not host:
        return None
    partes = host.rstrip(".").lower().split(".")
    if len(partes) >= 3 and len(partes[-1]) == 2 and partes[-2] in {"com", "net", "org", "gov", "edu", "co", "ind", "srv", "jus", "mp", "leg"}:
        return ".".join(partes[-3:])
    return ".".join(partes[-2:]) if len(partes) >= 2 else host


SUFIXOS_ORG = r"\b(S\.?\s?A\.?|LTDA\.?|LTD\.?|INC\.?|LLC|EIRELI|ME|EPP|CORP\.?|CORPORATION|GMBH|B\.?V\.?|PLC|LIMITED|CO\.?)\b"


def canonico(nome):
    """Nome canônico para comparação; o valor original é sempre preservado."""
    if not nome:
        return None
    v = re.sub(SUFIXOS_ORG, " ", str(nome).upper())
    v = re.sub(r"[^A-Z0-9À-Ü ]+", " ", v)
    return re.sub(r"\s+", " ", v).strip() or str(nome).upper()


def conj(v):
    if v is None:
        return set()
    return set(v) if isinstance(v, (list, tuple, set)) else {v}


def cmd_correlacionar(a):
    dados = json.load(open(a.entrada, encoding="utf-8"))
    regs = dados.get("resultados", dados)
    pesos = dict(PESOS_PADRAO)
    if a.pesos:
        pesos.update(json.loads(a.pesos))
    total = sum(pesos.values())
    for r in regs:
        r["_f"] = {
            "asn": conj(r.get("asn")), "prefixo": conj(r.get("prefixo")), "organizacao": conj(canonico(r.get("organizacao"))),
            "ptr_dominio": conj(dominio_base(r.get("ptr"))), "certificado": conj(r.get("certificados")),
            "dominio": conj(r.get("dominios")), "hospedagem": conj(r.get("hospedagem")),
            "temporal": conj(r.get("janela_temporal")),
        }
    n = len(regs)
    matriz, pares = [[None] * n for _ in range(n)], []
    for i in range(n):
        for j in range(i + 1, n):
            fatores = [(k, pesos[k]) for k in pesos if regs[i]["_f"][k] & regs[j]["_f"][k]]
            score = round(100 * sum(p for _, p in fatores) / total) if total else 0
            matriz[i][j] = matriz[j][i] = score
            pares.append({"a": regs[i]["ip"], "b": regs[j]["ip"], "similaridade": score,
                          "fatores": [f"+{p} {k}" for k, p in fatores]})
    # clusters: componentes conexos com score >= limiar
    pai = list(range(n))
    def raiz(x):
        while pai[x] != x:
            pai[x] = pai[pai[x]]
            x = pai[x]
        return x
    for i in range(n):
        for j in range(i + 1, n):
            if matriz[i][j] is not None and matriz[i][j] >= a.limiar:
                pai[raiz(i)] = raiz(j)
    grupos = defaultdict(list)
    for i in range(n):
        grupos[raiz(i)].append(regs[i]["ip"])
    clusters = sorted(grupos.values(), key=len, reverse=True)
    # hubs e outliers
    entidade_ips = defaultdict(set)
    for r in regs:
        for k in ("asn", "prefixo", "organizacao", "ptr_dominio", "certificado", "dominio"):
            for v in r["_f"][k]:
                entidade_ips[(k, v)].add(r["ip"])
    hubs = sorted(((k, v, len(s)) for (k, v), s in entidade_ips.items() if len(s) >= 2), key=lambda x: -x[2])
    outliers = []
    for campo in ("pais", "asn"):
        cont = Counter()
        for r in regs:
            for v in conj(r.get(campo)) or {"(não identificado)"}:
                cont[v] += 1
        if n >= 5:
            for v, c in cont.items():
                if c / n <= 0.1:
                    outliers.append({"campo": campo, "valor": v, "ips": c})
    # modelo de dados do caso (§124–130) e grafo (§107)
    caso = construir_caso(regs, a)
    for r in regs:
        r.pop("_f", None)
    os.makedirs(a.saida_dir, exist_ok=True)
    exportar_caso(caso, a.saida_dir)
    rel = {"gerado_em_utc": agora(), "pesos": pesos, "limiar_cluster": a.limiar,
           "aviso": "Similaridade técnica ≠ probabilidade de autoria, identidade ou participação em crime.",
           "pares": sorted(pares, key=lambda p: -p["similaridade"]), "clusters": clusters,
           "hubs": [{"tipo": k, "valor": v, "ips_conectados": c} for k, v, c in hubs], "outliers": outliers}
    escrever(os.path.join(a.saida_dir, "correlacao.json"), rel)
    # saída legível
    ips = [r["ip"] for r in regs]
    if n <= 25:
        print("| | " + " | ".join(ips) + " |")
        print("|---|" + "---:|" * n)
        for i in range(n):
            print(f"| {ips[i]} | " + " | ".join("—" if i == j else str(matriz[i][j]) for j in range(n)) + " |")
    print("\nPares mais similares:")
    for p in rel["pares"][:10]:
        print(f"- {p['a']} ↔ {p['b']}: {p['similaridade']}/100 ({', '.join(p['fatores']) or 'sem fatores comuns'})")
    print("\nClusters (limiar ≥ %d):" % a.limiar)
    for k, c in enumerate(clusters, 1):
        print(f"- Cluster {k}: {len(c)} IP(s) — {', '.join(c[:15])}{' …' if len(c) > 15 else ''}")
    if hubs:
        print("\nHubs:")
        for k, v, c in hubs[:10]:
            print(f"- {k} {v}: conecta {c} de {n} IPs")
    if outliers:
        print("\nOutliers:", json.dumps(outliers, ensure_ascii=False))
    print(f"\nArquivos em {a.saida_dir}/: correlacao.json, case.json, graph.json, graph.graphml, "
          "entities.csv, relationships.csv, observations.csv, evidence.csv")


CONF_FONTE = {"proxycheck.io": 0.5, "RDAP": 1.0, "Registro.br RDAP": 1.0, "Lista oficial": 1.0, "RIPEstat prefix-overview": 0.95,
              "Tor bulk exit list": 0.95, "DNS reverso": 0.9, "RIPEstat routing-history": 0.9, "RIPEstat as-overview": 0.9,
              "RIPEstat reverse-dns-ip": 0.9, "PeeringDB": 0.6, "Shodan InternetDB": 0.5,
              "RIPEstat maxmind-geo-lite": 0.3, "ipinfo": 0.3, "DB-IP": 0.3}


def conf_de(fonte):
    for k, v in CONF_FONTE.items():
        if fonte and fonte.startswith(k):
            return v
    return None


def construir_caso(regs, a):
    ents, rels, obs, evid = {}, [], [], []
    def ent(tipo, valor, label=None, **extra):
        eid = f"{tipo}:{valor}"
        if eid not in ents:  # nunca duplicar o mesmo identificador normalizado (§125)
            ents[eid] = {"id": eid, "type": tipo, "value": valor, "label": label or str(valor), **extra}
        return eid
    def relacionar(src, dst, tipo, valor, fonte, url=None, observed_at=None, extra=None):
        rid = f"rel:{len(rels) + 1:04d}"
        rels.append({"id": rid, "source": src, "target": dst, "type": tipo, **(extra or {})})
        obs.append({"id": f"obs:{len(obs) + 1:04d}", "relationship_id": rid, "value": valor, "source": fonte,
                    "source_url": url, "observed_at": observed_at, "valid_from": None, "valid_until": None,
                    "confidence": conf_de(fonte)})
        return rid
    for r in regs:
        fontes = {f.get("fonte"): f for f in r.get("fontes", [])}
        def ref(nome):
            for k, f in fontes.items():
                if k and k.startswith(nome):
                    return k, f.get("url_final") or f.get("url"), f.get("consultado_em_utc")
            return "informado/importado", None, None
        ip = ent("ipv6" if ":" in r["ip"] else "ipv4", r["ip"])
        for asn, nome in zip(r.get("asn") or [], (r.get("as_nome") or []) + [None] * 10):
            a_id = ent("asn", asn, f"{asn} {nome or ''}".strip())
            relacionar(ip, a_id, "originated_by", asn, *ref("RIPEstat prefix-overview"))
            if r.get("prefixo"):
                relacionar(ent("prefix", r["prefixo"]), a_id, "announced_by", asn, *ref("RIPEstat prefix-overview"))
            nome_org = re.sub(r"^AS\d+\s*-?\s*", "", nome) if nome else None
            if nome_org:
                relacionar(a_id, ent("organization", canonico(nome_org), canonical_name=canonico(nome_org), original_name=nome),
                           "operated_by", nome, *ref("RIPEstat prefix-overview"))
        if r.get("prefixo"):
            relacionar(ip, ent("prefix", r["prefixo"]), "belongs_to", r["prefixo"], *ref("RIPEstat prefix-overview"))
        if r.get("organizacao"):
            o = ent("organization", canonico(r["organizacao"]), canonical_name=canonico(r["organizacao"]),
                    original_name=r["organizacao"])
            relacionar(ip, o, "owned_by", r["organizacao"], *ref("RDAP"),
                       extra={"nota": "registrante do bloco ≠ usuário final"})
        if r.get("ptr"):
            h = ent("hostname", r["ptr"].rstrip(".").lower())
            relacionar(ip, h, "reverse_resolves_to", r["ptr"], *ref("DNS reverso"))
            d = dominio_base(r["ptr"])
            if d:
                relacionar(h, ent("domain", d), "belongs_to", d, "derivado do PTR")
        for c in conj(r.get("certificados")):
            relacionar(ip, ent("certificate", c), "uses_certificate", c, *ref("certificados"))
        for d in conj(r.get("dominios")):
            relacionar(ent("domain", str(d).lower()), ip, "resolves_to", d, *ref("dominios"))
        for h in conj(r.get("hospedagem")):
            relacionar(ip, ent("datacenter", h), "hosted_on", h, *ref("hospedagem"))
        for m in r.get("cloud_match") or []:
            relacionar(ip, ent("datacenter", m["provedor"]), "hosted_on", f"{m['provedor']} {m.get('servico') or ''} {m['prefixo']}".strip(),
                       f"Lista oficial {m['provedor']}", m.get("fonte_url"), m.get("consultado_em_utc"),
                       extra={"nota": "pertinência à faixa publicada pelo provedor, na data da consulta"})
        if r.get("tor_saida_atual"):
            relacionar(ip, ent("tor", "tor-exit"), "associated_with", "saída Tor (lista atual)", *ref("Tor bulk exit list"))
        for f in r.get("fontes", []):
            evid.append({"id": f"evidence:{len(evid) + 1:04d}", "type": "web_source", "title": f.get("fonte"),
                         "indicator": r["ip"], "source": f.get("fonte"), "url": f.get("url_final") or f.get("url"),
                         "collected_at": f.get("consultado_em_utc"), "content_hash": f.get("sha256_resposta"),
                         "raw_file": f.get("arquivo_bruto"), "status": "erro" if f.get("erro") else "ok",
                         "reliability": {1.0: "high", 0.95: "high", 0.9: "high", 0.6: "medium", 0.5: "medium", 0.3: "low"}.get(conf_de(f.get("fonte")), "unknown"),
                         "notes": f.get("erro") or ("cache" if f.get("cache") else "")})
    return {"id": a.caso, "name": a.caso, "description": "", "created_at": agora(), "updated_at": agora(),
            "sensitivity": a.sensibilidade,
            "entities": list(ents.values()), "relationships": rels, "observations": obs, "events": [],
            "evidence": evid, "hypotheses": [], "snapshots": []}


def exportar_caso(caso, pasta):
    escrever(os.path.join(pasta, "case.json"), caso)
    grafo = {"nodes": [{"id": e["id"], "type": e["type"], "label": e["label"]} for e in caso["entities"]],
             "edges": [{"source": r["source"], "target": r["target"], "relationship": r["type"],
                        "confidence": next((o["confidence"] for o in caso["observations"] if o["relationship_id"] == r["id"]), None),
                        "source_reference": next((o["source"] for o in caso["observations"] if o["relationship_id"] == r["id"]), None)}
                       for r in caso["relationships"]]}
    escrever(os.path.join(pasta, "graph.json"), grafo)
    for nome, linhas in (("entities", caso["entities"]), ("relationships", caso["relationships"]),
                         ("observations", caso["observations"]), ("evidence", caso["evidence"])):
        campos = sorted({k for l in linhas for k in l}) or ["id"]
        with open(os.path.join(pasta, f"{nome}.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=campos); w.writeheader(); w.writerows(linhas)
    with open(os.path.join(pasta, "graph.graphml"), "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<graphml xmlns="http://graphml.graphdrawing.org/xmlns">\n'
                '<key id="type" for="node" attr.name="type" attr.type="string"/>\n'
                '<key id="label" for="node" attr.name="label" attr.type="string"/>\n'
                '<key id="rel" for="edge" attr.name="relationship" attr.type="string"/>\n'
                '<key id="conf" for="edge" attr.name="confidence" attr.type="double"/>\n<graph edgedefault="directed">\n')
        for nd in grafo["nodes"]:
            f.write(f'<node id="{escape(nd["id"])}"><data key="type">{escape(nd["type"])}</data>'
                    f'<data key="label">{escape(nd["label"])}</data></node>\n')
        for k, e in enumerate(grafo["edges"]):
            conf = f'<data key="conf">{e["confidence"]}</data>' if e["confidence"] is not None else ""
            f.write(f'<edge id="e{k}" source="{escape(e["source"])}" target="{escape(e["target"])}">'
                    f'<data key="rel">{e["relationship"]}</data>{conf}</edge>\n')
        f.write("</graph>\n</graphml>\n")


def escrever(caminho, obj):
    if not caminho:
        return
    os.makedirs(os.path.dirname(os.path.abspath(caminho)), exist_ok=True)
    with open(caminho, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def _arg_jurisdicao(p):
    p.add_argument("--jurisdicao", choices=["BR", "OUTRA"], default="BR",
                   help="BR: prazos de guarda do Marco Civil como referência; OUTRA: não presume prazo (use --retencao conexao=N aplicacao=N, "
                        "em meses, conforme a lei local ou o guia do provedor)")
    p.add_argument("--retencao", action="append", metavar="NATUREZA=MESES",
                   help="prazo de guarda conhecido (repetível): conexao=24, aplicacao=12 (obrigatório p/ calcular prazo fora do BR)")


def _lazy(modulo, funcao):
    def f(a):
        import importlib
        return getattr(importlib.import_module(modulo), funcao)(a)
    return f


def main():
    ap = argparse.ArgumentParser(description="Análise de Endereços IP — apoio à skill")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("normalizar", help="extrai e classifica IPs, papéis, portas e horários de um log/texto")
    p.add_argument("entrada", help="arquivo de texto/log ou '-' (stdin)")
    p.add_argument("--saida", default="normalizado.json"); p.add_argument("--limite", type=int, default=100)
    p.add_argument("--fuso", help="fuso dos horários SEM fuso no log: UTC, -03:00 ou nome IANA (ex.: America/Maceio). "
                                  "Nunca é presumido: sem isto, esses horários não são convertidos para UTC.")
    p.add_argument("--porta-semantica", choices=["origem", "destino", "indefinida"], default="indefinida",
                   help="o que significa 'IP:porta' neste log, quando NÃO há rótulo (src/dst/SPT/DPT). Padrão: indefinida.")
    p.add_argument("--origem", choices=sorted(C.ORIGENS), help="de onde veio o dado (muda a leitura de IPs privados; seção 6.2)")
    p.set_defaults(f=cmd_normalizar)

    p = sub.add_parser("consultar", help="coleta passiva em fontes públicas (IPs públicos)")
    p.add_argument("entrada", help="saída do 'normalizar' ou lista JSON de IPs")
    p.add_argument("--saida", default="consulta.json"); p.add_argument("--brutos", default="respostas_brutas")
    p.add_argument("--pausa", type=float, default=1.0); p.add_argument("--sem-geo", action="store_true")
    p.add_argument("--sem-ptr", action="store_true"); p.add_argument("--sem-tor", action="store_true")
    p.add_argument("--perfil", choices=["basico", "completo"], default="completo",
                   help="basico = RIPEstat+RDAP+PTR+Tor; completo (padrão) acrescenta listas oficiais de cloud/CDN, InternetDB, "
                        "PeeringDB, 2ª/3ª geolocalização, Registro.br e (com --data-evento) histórico de roteamento")
    p.add_argument("--listas", default="aws,gcp,oracle,cloudflare,fastly,googlebot,bingbot,icloud",
                   help="listas oficiais de faixas a baixar (aws,gcp,oracle,cloudflare,fastly,googlebot,bingbot,gptbot,icloud); '' desativa")
    p.add_argument("--sem-geo2", action="store_true", help="não consulta ipinfo/DB-IP (2ª e 3ª geolocalização)")
    p.add_argument("--sem-proxycheck", action="store_true", help="não consulta o proxycheck.io (no perfil completo)")
    p.add_argument("--proxycheck", action="store_true", help="consulta o proxycheck.io também no perfil básico")
    p.add_argument("--proxycheck-versao", choices=["v3", "v2"], default="v3", help="API do proxycheck.io (v3 = atual; v2 = legado)")
    p.add_argument("--proxycheck-dias", type=float, help="janela de detecção em dias (0,01–60); omitido = padrão da API. "
                                                         "Para fato antigo, use 60")
    p.add_argument("--proxycheck-limite", type=int, help="cota diária LOCAL (padrão: 100 sem chave; 1000 com PROXYCHECK_KEY)")
    p.add_argument("--proxycheck-ignorar-cota", action="store_true", help="não bloqueia pelo contador local (a API ainda pode negar)")
    _arg_jurisdicao(p)
    p.add_argument("--data-evento", help="data/hora do FATO (ex.: '2026-03-14 21:45:10'): ativa histórico de roteamento, "
                                         "comparação com datas do RDAP e prazos de guarda")
    p.add_argument("--fuso", help="fuso de --data-evento quando o texto não trouxer deslocamento (UTC, -03:00, America/Maceio)")
    p.add_argument("--cache", default=".cache_ip", help="pasta de cache (§153); '' desativa")
    p.add_argument("--ttl-cache", type=float, default=24.0, help="validade do cache em horas")
    p.add_argument("--atualizar", action="store_true", help="ignora o cache e consulta de novo")
    p.add_argument("--timeout", type=float, default=20.0)
    p.add_argument("--auditoria", help="arquivo JSONL da trilha de auditoria (padrão: <brutos>/auditoria.jsonl)")
    p.set_defaults(f=cmd_consultar)

    p = sub.add_parser("tipologia", help="classifica o tipo do IP e gera o bloco 'Classificação e caminho investigativo'")
    p.add_argument("entrada", help="saída do 'consultar' (ou do 'normalizar', para IPs não públicos)")
    p.add_argument("--normalizado", help="saída do 'normalizar' (traz portas, horários e IPs não públicos)")
    p.add_argument("--saida", default="tipologia.json"); p.add_argument("--md", help="grava também o relatório em Markdown")
    p.add_argument("--regras", help="JSON de regras (padrão: references/regras_tipologia.json)")
    p.add_argument("--operadoras", help="arquivo JSON ou PASTA de tabelas ASN→tipo de rede (padrão: references/operadoras/*.json)")
    _arg_jurisdicao(p)
    p.add_argument("--data-evento", help="data/hora do fato (para prazos e ressalvas de classificação atual × histórica)")
    p.add_argument("--fuso", help="fuso de --data-evento se o texto não trouxer deslocamento")
    p.add_argument("--porta-origem", type=int, help="porta lógica de ORIGEM do evento, se conhecida")
    p.add_argument("--protocolo", help="TCP/UDP"); p.add_argument("--destino", help="IP:porta de destino")
    p.set_defaults(f=_lazy("ipa_tipologia", "cmd_tipologia"))

    p = sub.add_parser("correlacionar"); p.add_argument("entrada", help="saída do 'consultar' (ou JSON no mesmo formato)")
    p.add_argument("--saida-dir", default="correlacao"); p.add_argument("--limiar", type=int, default=40)
    p.add_argument("--caso", default="CASO-SEM-ID", help="identificador do caso (§77)")
    p.add_argument("--sensibilidade", default="SENSITIVE", choices=["PUBLIC", "INTERNAL", "SENSITIVE", "RESTRICTED"],
                   help="classificação de sensibilidade do caso (§167)")
    p.add_argument("--pesos", help='JSON para ajustar pesos, ex.: \'{"asn":10,"certificado":25}\'')
    p.set_defaults(f=cmd_correlacionar)

    p = sub.add_parser("prazos", help="vencimento da guarda do provedor a partir da data do evento")
    p.add_argument("evento", help="data/hora do fato, ex.: '2026-03-14 21:45:10'")
    p.add_argument("--fuso", help="UTC, -03:00 ou nome IANA (obrigatório se o texto não trouxer deslocamento)")
    p.add_argument("--hoje", help="(testes) data de referência AAAA-MM-DD"); p.add_argument("--saida")
    p.add_argument("--preservacao-em", help="AAAA-MM-DD em que a preservação foi requerida (calcula a janela do regime escolhido)")
    p.add_argument("--regime", choices=sorted(["BR", "US", "UE", "BUDAPESTE"]), default="BR",
                   help="regime da janela de preservação de --preservacao-em (BR: 60 dias p/ pedido judicial; US: 18 USC 2703(f); "
                        "UE: EPOC-PR; BUDAPESTE: art. 29)")
    _arg_jurisdicao(p)
    p.set_defaults(f=_lazy("ipa_prazos", "cmd_prazos"))

    p = sub.add_parser("cabecalho", help="cadeia Received de e-mail e/ou X-Forwarded-For, com fronteira de confiança")
    p.add_argument("entrada", nargs="?", help="arquivo com o cabeçalho completo do e-mail (opcional se usar --xff)")
    p.add_argument("--confiaveis", help="sufixos de domínio dos servidores cujos 'Received' são confiáveis "
                                        "(ex.: google.com,outlook.com). Sem isto, só o Received mais recente é presumido confiável.")
    p.add_argument("--xff", help="valor do X-Forwarded-For (lista separada por vírgula)")
    p.add_argument("--n-proxies", type=int, default=1, help="quantos proxies CONFIÁVEIS há à direita da lista XFF (padrão 1)")
    p.add_argument("--saida", default="cabecalho.json")
    p.set_defaults(f=_lazy("ipa_cabecalho", "cmd_cabecalho"))

    p = sub.add_parser("oficio", help="gera MINUTA de ofício (preservação, requisição cadastral, roteiro de representação)")
    p.add_argument("--tipo", required=True, choices=["preservacao", "cadastral", "representacao"])
    p.add_argument("--ip", required=True); p.add_argument("--data-hora", help="data/hora do evento"); p.add_argument("--fuso")
    p.add_argument("--porta", type=int, help="porta lógica de ORIGEM (indispensável em CGNAT)")
    p.add_argument("--protocolo"); p.add_argument("--destino", help="IP:porta de destino")
    p.add_argument("--consulta", help="saída do 'consultar' (preenche titular do bloco, ASN, contato de abuso)")
    p.add_argument("--provedor", help="nome do provedor destinatário (se já confirmado)")
    p.add_argument("--natureza", choices=["conexao", "aplicacao"], default="conexao", help="natureza do provedor destinatário")
    p.add_argument("--procedimento", help="nº do inquérito/procedimento"); p.add_argument("--autoridade", help="nome e cargo")
    p.add_argument("--unidade", help="unidade policial"); p.add_argument("--fato", help="descrição sucinta do fato (sem dados da vítima)")
    p.add_argument("--org-criminosa", action="store_true", help="(BR) investigação de organização criminosa (Lei 12.850/2013, art. 15)")
    p.add_argument("--jurisdicao", choices=["BR", "OUTRA"], default="BR",
                   help="BR: minutas do Marco Civil; OUTRA: provedor no exterior → só 'preservacao' (solicitação expedita bilíngue)")
    p.add_argument("--saida", default="minuta_oficio.md")
    p.set_defaults(f=_lazy("ipa_oficio", "cmd_oficio"))

    p = sub.add_parser("validar", help="verifica linguagem proibida e blocos obrigatórios de um relatório")
    p.add_argument("entrada", help="relatório (.md/.txt)")
    p.add_argument("--perfil", choices=["analise", "forense", "rapido"], default="analise")
    p.add_argument("--json", help="grava o resultado em JSON")
    p.set_defaults(f=_lazy("ipa_validar", "cmd_validar"))

    a = ap.parse_args()
    a.f(a)


if __name__ == "__main__":
    main()
