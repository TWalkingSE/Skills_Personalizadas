#!/usr/bin/env python3
"""
MINUTAS de ofício ao provedor (preservação cautelar, requisição de dados cadastrais, roteiro de representação).
Somente stdlib. Apoio à redação: NÃO é peça final.

  • A minuta traz [PREENCHER] onde faltam dados e lista as PENDÊNCIAS no topo (porta de origem, segundos, fuso…).
  • Nunca inclui nome de vítima/investigado; usa só o indicador técnico e o fato em termos genéricos.
  • Dispositivos legais são citados de forma orientativa: CONFERIR vigência e inteiro teor; a fundamentação
    jurídica é da autoridade requisitante/MP. A skill não substitui a análise jurídica do caso.
  • IP não público (privado/CGNAT/etc.) não gera ofício ao provedor: busque primeiro o IP público do mesmo instante.
  • --jurisdicao BR (padrão): minutas do Marco Civil. --jurisdicao OUTRA (provedor no exterior): só `preservacao`, em
    versão bilíngue (PT/EN), apoiada em Budapeste arts. 16/29/35 e, se o provedor for dos EUA, 18 U.S.C. § 2703(f).
    A requisição de dados ao provedor estrangeiro segue por cooperação internacional/processo legal local (base_legal.md §B).
"""
import datetime as dt
import ipaddress
import json
import re

import ipa_comum as C
import ipa_prazos

VIGENCIA_DEC_12975 = dt.datetime(2026, 7, 20, tzinfo=dt.timezone.utc)  # 60 dias após a publicação de 21/05/2026 (art. 2º)


def _achar(consulta, ip):
    if not consulta:
        return None
    d = json.load(open(consulta, encoding="utf-8"))
    for r in d.get("resultados", d if isinstance(d, list) else []):
        if r.get("ip") == ip:
            return r
    return None


def _minuta_exterior(a, pend, alertas, dest, org, tab, P):
    """Solicitação de preservação expedita a provedor no EXTERIOR (rascunho bilíngue). Não é peça final."""
    pend = list(pend) + [
        "Confirme o CANAL: provedores dos EUA costumam ter portal/e-mail de atendimento a autoridades; nos demais países, use o ponto de contato "
        "24/7 (Convenção de Budapeste, art. 35) da sua instituição ou a autoridade central. A solicitação NÃO obriga, por si só, provedor estrangeiro.",
        "Confirme o regime aplicável ao provedor (Budapeste × lei local × § 2703(f) × Reg. (UE) 2023/1543, esse último só para autoridades da UE) "
        "e REMOVA do texto o que não se aplicar.",
        "Planeje o passo seguinte (pedido de cooperação/MLAT ou processo legal local) dentro da janela de preservação."]
    L = ["# MINUTA — Solicitação de PRESERVAÇÃO expedita a provedor no exterior (rascunho bilíngue)", "",
         "> **Documento de apoio gerado pela skill `analise_ip_intelligence` em " + C.agora() + " (UTC). NÃO é peça final.** Conferir a base legal "
         "(`references/base_legal.md` §B), o canal e o idioma exigidos pelo provedor; revisão e assinatura da autoridade. Sem dados de vítima/investigado.", ""]
    L += ["## Pendências antes de enviar", ""] + [f"- [ ] {p}" for p in pend] + [""]
    if alertas:
        L += ["## Alertas técnicos", ""] + [f"- ⚠ {x}" for x in alertas] + [""]
    L += ["---", "", f"**[AUTHORITY / {P(a.unidade, 'UNIT')}]**  |  Ref.: {P(a.procedimento, 'case/procedure no.')}  |  Contact: {P(a.autoridade, 'name, title, e-mail, phone')}", "",
          f"**To:** {P(dest, 'PROVIDER — law enforcement / legal compliance team')}"]
    if org and org != dest:
        L.append(f"_(block holder according to RDAP: {org})_")
    L += ["", f"**Subject:** Request for preservation of records — IP address {a.ip}", "",
          f"In connection with the criminal investigation referenced above, concerning {P(a.fato, 'offence, in generic terms')}, "
          f"we request that {P(dest, 'PROVIDER')} **preserve**, pending the issuance of formal legal process (mutual legal assistance request, production order or "
          "equivalent), all records associated with the IP address and timestamp below, keeping them intact:", "", *tab, "",
          "**Records to preserve:** subscriber/account identification and registration data; connection/session and authentication logs; IP address assignment "
          "logs, **including carrier-grade NAT mappings with the source port**; related account creation and access logs for the surrounding period "
          "([PREENCHER: window, e.g. ±24 h]).", "",
          "**Legal basis (confirm the applicable framework and delete the rest):**",
          "- Convention on Cybercrime (Budapest), Arts. 16 and 29 (expedited preservation) — contact via the 24/7 network, Art. 35;",
          "- if the provider is subject to US law: 18 U.S.C. § 2703(f) — preservation for 90 days, extendable by a further 90 days upon renewed request;",
          "- other: [PREENCHER: domestic law of the provider's country].", "",
          "**Confidentiality:** we respectfully ask that this request not be disclosed to the account holder, to the extent permitted by applicable law.", "",
          "**Reply:** please confirm receipt and that the records have been preserved, and indicate the preservation period applied and the channel for the "
          "follow-up legal process, within [PREENCHER] days.", "",
          "---", "",
          "**Resumo (PT):** solicitação de preservação expedita de registros associados ao IP e ao horário acima, à espera de processo legal "
          "(cooperação internacional/ordem local). Registro de conexão e dados de assinante exigem o instrumento adequado ao país do provedor.", "",
          "_Minuta orientativa. Não substitui a análise jurídica do caso nem o canal formal de cooperação internacional._", ""]
    open(a.saida, "w", encoding="utf-8").write("\n".join(L))
    print(f"Minuta gravada em {a.saida} (preservação — provedor no exterior; IP {a.ip}).")
    if pend:
        print(f"\n{len(pend)} pendência(s) antes de enviar:")
        for p in pend:
            print(f"  - {p}")
    for x in alertas:
        print(f"⚠ {x}")


def cmd_oficio(a):
    try:
        ipo = ipaddress.ip_address(a.ip)
    except ValueError:
        print(f"ERRO: IP inválido: {a.ip!r}")
        raise SystemExit(2)
    jur = getattr(a, "jurisdicao", "BR")
    if jur == "OUTRA" and a.tipo != "preservacao":
        print("ERRO: para provedor no exterior a skill só gera a minuta de PRESERVAÇÃO (--tipo preservacao). Dados cadastrais e de conexão "
              "dependem de cooperação internacional (MLAT/carta rogatória/ponto de contato 24/7) ou do processo legal do país do provedor "
              "(references/base_legal.md §B).")
        raise SystemExit(2)
    desc, publico = C.classificar(ipo)
    if not publico:
        print(f"ERRO: {a.ip} é {desc}. Não se requisita a provedor com IP não público: ele não tem titular em RDAP/BGP e o mesmo "
              "endereço existe em milhões de redes. Obtenha o IP PÚBLICO do mesmo instante (logs de NAT/proxy/firewall ou da aplicação) "
              "e gere o ofício com ele (seção 6 da skill).")
        raise SystemExit(2)
    r = _achar(a.consulta, a.ip)
    pend, alertas = [], []
    evento = None
    if a.data_hora:
        try:
            evento, info = ipa_prazos.interpretar_evento(a.data_hora, a.fuso)
            if not re.search(r":\d{2}:\d{2}", a.data_hora):
                pend.append("Hora SEM segundos: informe a hora com segundos (indispensável para individualizar a conexão em CGNAT).")
        except ValueError as e:
            pend.append(f"Data/hora inválida ou sem fuso: {e}")
    else:
        pend.append("Informe a data e a hora do evento, com SEGUNDOS e FUSO (ex.: --data-hora '2026-03-14 21:45:10' --fuso America/Maceio).")
    if not a.porta:
        pend.append("Porta lógica de ORIGEM não informada: com CGNAT a resposta pode listar vários assinantes. Se o log tem porta, "
                    "CONFIRME com quem o gerou se é a de origem (não a de destino) antes de usar.")
    if not a.protocolo:
        pend.append("Protocolo (TCP/UDP) não informado.")
    if not a.procedimento:
        pend.append("Número do procedimento/inquérito não informado.")
    if not a.autoridade:
        pend.append("Autoridade requisitante (nome/cargo) não informada.")
    # destinatário e contexto técnico
    org = (r or {}).get("organizacao") or ((r or {}).get("rdap") or {}).get("nome")
    dest = a.provedor or org
    ctx_tec = []
    if r:
        if r.get("asn"):
            ctx_tec.append(f"ASN de origem (RIPEstat, consulta de {((r.get('fontes') or [{}])[0]).get('consultado_em_utc', 'data não registrada')}): "
                           f"{', '.join(r['asn'])} ({', '.join(x for x in (r.get('as_nome') or []) if x)})")
        if r.get("organizacao"):
            ctx_tec.append(f"Titular do bloco (RDAP): {r['organizacao']} — registrante do bloco ≠ necessariamente quem atribuiu o IP ao usuário final")
        abuso = ((r.get("rdap") or {}).get("abuso") or [])
        if abuso:
            ctx_tec.append(f"Contato de abuso no RDAP (NÃO é o canal para requisição legal): {', '.join(abuso)}")
        for e in (r.get("rdap_nir") or {}).get("entidades") or []:
            docs = ", ".join(f"{d['tipo']}: {d['id']}" for d in e.get("documentos") or [])
            if docs:
                ctx_tec.append(f"Registro.br — {e.get('nome')}: {docs}")
        for al in r.get("alertas_temporais") or []:
            alertas.append(al)
        if r.get("tor_saida_atual"):
            alertas.append("O IP consta como saída Tor na lista ATUAL: requisição ao titular do bloco NÃO identifica usuário. "
                           "Confirme na data do fato (ExoneraTor) antes de requisitar.")
        for m in r.get("cloud_match") or []:
            if m["categoria"] == "CDN":
                alertas.append(f"IP de CDN ({m['provedor']}): o destinatário correto é o provedor da CDN (cliente/dono do site e IP real do "
                               "visitante nos logs), não o titular do bloco.")
            elif m["categoria"] == "Datacenter/nuvem":
                alertas.append(f"IP de nuvem/hospedagem ({m['provedor']}): solicitar cliente/conta no instante (e-mail, pagamento, IPs de "
                               "acesso ao painel, logs) e PRESERVAÇÃO; provedor possivelmente estrangeiro (preservação expedita, Convenção de Budapeste).")
    else:
        pend.append("Sem --consulta: o titular do bloco/ASN não foi preenchido. Rode 'consultar' e informe --provedor.")
    if not dest:
        pend.append("Provedor destinatário não identificado: confirme QUEM atribuiu o IP ao usuário final na data do fato (o titular do bloco pode ter repassado a outro operador).")
    prazos = None
    if evento and jur == "OUTRA":
        alertas.append("Prazo de guarda do provedor no exterior DESCONHECIDO (depende da lei local e da política do provedor): "
                       "peça a preservação sem demora.")
    elif evento:
        prazos = ipa_prazos.calcular_prazos(evento)
        if prazos["alerta_preservacao"]:
            alertas.append(prazos["alerta_preservacao"])
        chave = "conexao" if a.natureza == "conexao" else "aplicacao"
        if prazos[chave]["dias_restantes"] < 0:
            alertas.append(f"O prazo legal de guarda do provedor de {a.natureza} parece VENCIDO ({prazos[chave]['vence_em_utc'][:10]}). "
                           "Confirme se há preservação anterior ou retenção maior; o pedido ainda pode ser útil.")
    data_txt = (f"{a.data_hora} ({a.fuso})" if a.fuso and a.data_hora and not re.search(r"[+-]\d{2}:?\d{2}|Z|UTC", a.data_hora) else (a.data_hora or "[PREENCHER]"))
    utc_txt = evento.strftime("%Y-%m-%d %H:%M:%S UTC") if evento else "[PREENCHER]"
    P = lambda v, rot: v if v else f"[PREENCHER: {rot}]"  # noqa: E731

    tab = ["| Dado técnico | Valor |", "|---|---|",
           f"| Endereço IP | {a.ip} |", f"| Data e hora do evento | {data_txt} |", f"| Equivalente em UTC | {utc_txt} |",
           f"| Porta lógica de origem | {P(a.porta, 'porta de ORIGEM')} |", f"| Protocolo | {P(a.protocolo, 'TCP/UDP')} |",
           f"| IP/porta de destino | {P(a.destino, 'opcional, se conhecido')} |"]
    if jur == "OUTRA":
        return _minuta_exterior(a, pend, alertas, dest, org, tab, P)
    pos_decreto = bool(evento and evento >= VIGENCIA_DEC_12975)
    if pos_decreto:
        porta_fund = ("A guarda da porta lógica de origem decorre do art. 15-A do Decreto nº 8.771/2016 (incluído pelo Decreto nº 12.975/2026, "
                      "em vigor desde 20/07/2026), que independe de requisição prévia e recai sobre cada provedor.")
    else:
        porta_fund = ("Para fatos anteriores à vigência do Decreto nº 12.975/2026 (20/07/2026), a guarda/fornecimento da porta lógica de origem "
                      "apoia-se na jurisprudência do STJ (REsp 1.784.156/SP; REsp 2.170.872/SP) — conferir inteiro teor e avaliar com a autoridade/MP "
                      "a melhor fundamentação.")
    n_art = "13" if a.natureza == "conexao" else "15"

    L = [f"# MINUTA — {'Requerimento de PRESERVAÇÃO CAUTELAR' if a.tipo == 'preservacao' else 'Requisição de DADOS CADASTRAIS' if a.tipo == 'cadastral' else 'ROTEIRO de representação por afastamento de sigilo de registros de conexão'}",
         "", "> **Documento de apoio gerado pela skill `analise_ip_intelligence` em " + C.agora() + " (UTC). NÃO é peça final.** "
         "Conferir vigência e inteiro teor dos dispositivos, adequar ao modelo e ao sistema da instituição e submeter à autoridade/MP. "
         "Não contém dados de vítima ou investigado.", ""]
    if pend:
        L += ["## Pendências antes de enviar", ""] + [f"- [ ] {p}" for p in pend] + [""]
    if alertas:
        L += ["## Alertas técnicos", ""] + [f"- ⚠ {x}" for x in alertas] + [""]
    L += ["---", "", f"**[ÓRGÃO / {P(a.unidade, 'UNIDADE')}]**", f"Ofício nº [PREENCHER]/{dt.date.today().year} — [LOCAL], [DATA]", "",
          f"**Ao:** {P(dest, 'PROVEDOR — setor de atendimento a autoridades / jurídico (canal oficial)')}"]
    if org and org != dest:
        L.append(f"_(titular do bloco segundo o RDAP: {org})_")
    L += ["", f"**Ref.:** {P(a.procedimento, 'nº do procedimento/inquérito')}  |  **Autoridade:** {P(a.autoridade, 'nome e cargo')}", ""]
    if a.tipo == "preservacao":
        L += [f"**Assunto:** Requerimento de guarda cautelar de registros ({'conexão' if a.natureza == 'conexao' else 'acesso a aplicações'}) — IP {a.ip}", "",
              f"Ao cumprimentá-lo, no âmbito do procedimento acima, que apura {P(a.fato, 'fato investigado, em termos genéricos')}, "
              f"com fundamento no art. {n_art}, §2º, da Lei nº 12.965/2014 (Marco Civil da Internet), **REQUER-SE a guarda cautelar** dos registros "
              "abaixo, por prazo superior ao previsto em lei, mantendo-os íntegros, preservados e sob sigilo:", "", *tab, "",
              "**Registros a preservar:**",
              ("- identificação do assinante/terminal a que o IP e a porta acima foram atribuídos no instante indicado; histórico de autenticação/sessão; "
               "demais registros de conexão correspondentes ao período." if a.natureza == "conexao" else
               "- registros de acesso à aplicação associados ao IP/porta e ao instante acima; identificadores da conta/sessão e dados de criação e acesso, "
               "conforme a natureza do serviço."),
              f"- {porta_fund}", "",
              "**Ciência:** a autoridade requerente ingressará com o pedido de autorização judicial de acesso aos registros no prazo de 60 (sessenta) dias "
              "contados deste requerimento (art. 13, §3º, aplicável também por força do art. 15, §2º), ciente de que o requerimento perde a eficácia se o pedido "
              "não for protocolado no prazo ou for indeferido (art. 13, §4º), e **solicita sigilo** quanto a este requerimento.", "",
              "**Resposta:** solicita-se confirmação do recebimento e da efetiva preservação no prazo de [PREENCHER] dias, por meio do canal oficial."]
    elif a.tipo == "cadastral":
        L += [f"**Assunto:** Requisição de dados cadastrais vinculados ao IP {a.ip}", "",
              f"Ao cumprimentá-lo, no âmbito do procedimento acima, que apura {P(a.fato, 'fato investigado, em termos genéricos')}, "
              "**REQUISITA-SE** o fornecimento dos dados cadastrais (qualificação pessoal, filiação e endereço) do assinante/usuário a quem foi atribuído o "
              "endereço IP abaixo no instante indicado:", "", *tab, "",
              "**Fundamento (conferir):** art. 10, §3º, da Lei nº 12.965/2014 e art. 11 do Decreto nº 8.771/2016"
              + ("; art. 15 da Lei nº 12.850/2013 (investigação de organização criminosa)." if a.org_criminosa else "."),
              f"- {porta_fund}", "",
              "> **ATENÇÃO (decisão da autoridade/MP):** a vinculação IP + data/hora ↔ assinante envolve **registro de conexão** (arts. 10, §1º, e 22 do MCI), "
              "para o qual muitos provedores exigem **ordem judicial**. Avalie se cabe requisição direta de dados cadastrais ou se o caminho é a representação "
              "(`--tipo representacao`). Se já houve preservação cautelar, indique a data e o número do requerimento.", "",
              "**Prazo de resposta:** [PREENCHER] dias. **Sigilo:** solicita-se que a existência desta requisição não seja informada ao titular."]
    else:
        L += ["## Estrutura sugerida (a redação e a fundamentação jurídica são da autoridade/MP)", "",
              "**I. Autoridade requerente e procedimento** — " + P(a.autoridade, "nome/cargo") + "; " + P(a.procedimento, "nº") + ".", "",
              "**II. Dos fatos (síntese)** — " + P(a.fato, "descrição sucinta, sem dados da vítima") + ".", "",
              "**III. Do cabimento (MCI, art. 22, parágrafo único)** — demonstrar: (i) fundados indícios da ocorrência do ilícito; (ii) justificativa motivada da "
              "utilidade dos registros para a investigação/instrução; (iii) período a que se referem os registros.", "",
              "**IV. Dos dados técnicos**", "", *tab, "",
              "**V. Dos pedidos**",
              f"- a) Ordem ao provedor {P(dest, 'PROVEDOR')} para fornecer os registros de conexão{' e de acesso a aplicações' if a.natureza == 'aplicacao' else ''} "
              "correspondentes ao IP, porta e instante acima, com identificação do assinante/terminal e dados cadastrais;",
              "- b) prazo de cumprimento: [PREENCHER]; c) sigilo da medida e vedação de comunicação ao titular;",
              "- d) se houver preservação cautelar prévia (art. 13, §2º): indicar data e número do requerimento e juntar comprovante.", "",
              f"**Fundamentação sobre a porta lógica:** {porta_fund}", "",
              "**VI. Anexos sugeridos** — relatório técnico da análise do IP (com hashes das respostas brutas), capturas e registros que originaram o IP, "
              "comprovante da preservação (se houver)."]
    L += ["", "---", "_Minuta orientativa. Não substitui a análise jurídica do caso nem a requisição formal pelo canal oficial do provedor._", ""]
    open(a.saida, "w", encoding="utf-8").write("\n".join(L))
    print(f"Minuta gravada em {a.saida} ({a.tipo}; IP {a.ip}).")
    if pend:
        print(f"\n{len(pend)} pendência(s) antes de enviar:")
        for p in pend:
            print(f"  - {p}")
    for x in alertas:
        print(f"⚠ {x}")
