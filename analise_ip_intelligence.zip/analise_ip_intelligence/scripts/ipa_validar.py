#!/usr/bin/env python3
"""
Verificador de relatório (controle de qualidade da seção 11 da skill) — somente stdlib.

Procura (1) linguagem que transforma IP em pessoa/autoria, (2) IP privado associado a dado externo,
(3) horário sem fuso, (4) "Confirmado" sem fonte primária declarada, (5) ausência de blocos obrigatórios.
É um APOIO: acusa o que é detectável por padrão de texto; não substitui a leitura crítica nem a análise
jurídica. Marque `validar:ignorar` na linha (ou na anterior) para suprimir um achado já justificado.
"""
import json
import re

import ipa_comum as C

NEGACAO = re.compile(r"\b(não|nao|nunca|jamais|sem|nem|evitar|vedad[oa]|incorret[oa]|erro|proibid[oa]|inadmiss[ií]vel|"
                     r"afirmar\s+que|n[ãa]o\s+se\s+pode|exemplo\s+de)\b", re.I)

PROIBIDOS = [
    ("P01", r"\bo\s+(suspeito|investigado|autor|criminoso|golpista|usu[áa]rio)\s+(utilizou|usou|acessou|operou|empregou|se\s+conectou)\b",
     "bloqueante", "Atribui o uso do IP a uma pessoa.",
     "Escrever: 'o IP X foi atribuído, em H (fuso), à conexão/conta A, segundo o provedor'. O IP não identifica pessoa."),
    ("P02", r"\b(ip|endere[çc]o\s+ip)\s+(do|da|de)\s+(suspeito|investigado|autor|criminoso|golpista)\b",
     "bloqueante", "Trata o IP como pertencente a uma pessoa.", "Escrever: 'IP de origem do acesso' ou 'IP associado à conexão X'."),
    ("P03", r"\b(comprova|prova|demonstra|confirma|atesta)\w*\s+(a\s+)?autoria\b",
     "bloqueante", "O IP/infraestrutura não prova autoria.", "Escrever: 'é compatível com' / 'constitui indício'; autoria é conclusão do conjunto probatório."),
    ("P04", r"\bautoria\s+(est[áa]\s+)?(comprovada|confirmada|demonstrada|provada)\b",
     "bloqueante", "Conclusão de autoria a partir de análise técnica de IP.", "Remover; indicar o que a análise permite afirmar."),
    ("P05", r"\b(pertence|pertencia|pertencente)\s+(ao|à|a)\s+(suspeito|investigado|autor|criminoso)\b",
     "bloqueante", "Atribui o IP a uma pessoa.", "Escrever: 'o bloco está registrado em nome de <organização>, segundo o RDAP em <data>'."),
    ("P06", r"\b(dono|titular|propriet[áa]rio)\s+do\s+ip\s+(é|foi|era)\s+(o\s+)?(autor|criminoso|golpista|respons[áa]vel)\b",
     "bloqueante", "Titular do bloco ≠ usuário ≠ autor.", "Separar infraestrutura, conexão, terminal, usuário e autoria (seção 5.4)."),
    ("P07", r"geolocaliza[çc][ãa]o\s+(comprova|prova|confirma)\b|\b(autor|suspeito|usu[áa]rio)\s+(estava|encontrava-se|residia)\s+(em|na|no)\b[^.\n]{0,60}(geolocaliza|base[s]?\s+de\s+localiza)",
     "bloqueante", "Geolocalização de IP não é localização física.", "Escrever: 'bases consultadas associam o IP à região R, com baixa confiança'."),
    ("P08", r"\b(n[ãa]o\s+existe|inexiste|inexistem)\s+(qualquer\s+)?(rela[çc][ãa]o|v[íi]nculo|conex[ãa]o)\b",
     "atenção", "Ausência de evidência ≠ evidência de ausência.", "Escrever: 'Não foi encontrada relação nas fontes consultadas'."),
    ("P09", r"\b(100\s?%\s+(certo|seguro|confirmado)|cem\s+por\s+cento|certeza\s+absoluta|sem\s+qualquer\s+d[úu]vida)\b",
     "atenção", "Certeza absoluta não é sustentável com dados de IP.", "Usar a escala Não identificado · Possível · Provável · Confirmado, com a base."),
    ("P10", r"(blacklist|lista\s+negra|lista\s+de\s+reputa[çc][ãa]o|abuseipdb)[^.\n]{0,80}(prova|comprova|confirma)[^.\n]{0,40}(crime|autoria|culpa|criminoso)",
     "bloqueante", "Reputação não prova autoria.", "Escrever: 'consta em lista de reputação L (indício de abuso)'."),
    ("P11", r"\bip\s+(privado|local|interno)\b[^.\n]{0,60}\b(falso|forjado)\b|\b(falso|forjado)\b[^.\n]{0,40}\bip\s+(privado|local|interno)\b",
     "atenção", "IP privado não é 'falso': só não tem valor fora da rede de origem.", "Explicar a faixa e buscar o IP público do mesmo instante (seção 6)."),
    ("P12", r"\b(identific(ou|amos|ado)|localiz(ou|amos|ado))\s+(o\s+)?(autor|respons[áa]vel|criminoso)\s+(pelo|por\s+meio\s+do|atrav[ée]s\s+do|a\s+partir\s+do)\s+(endere[çc]o\s+)?ip\b",
     "bloqueante", "Identificação de pessoa só pelo IP.", "Descrever a cadeia: infraestrutura → conexão → terminal → usuário → autoria, e o que falta."),
    ("P13", r"\bo\s+assinante\b[^.\n]{0,40}\s(é|foi)\s+(o\s+)?(autor|respons[áa]vel\s+pelo)\b",
     "bloqueante", "Assinante ≠ autor.", "Escrever: 'o provedor informou que o IP/porta, no horário H, foram atribuídos ao assinante A'."),
    ("P14", r"\btitular\s+do\s+(bloco|ip)\s+(praticou|cometeu|realizou)\b",
     "bloqueante", "Titular do bloco ≠ autor.", "Separar as camadas de atribuição."),
]
PROIBIDOS = [(i, re.compile(rx, re.I), sev, msg, sug) for i, rx, sev, msg, sug in PROIBIDOS]

RE_PRIV = re.compile(r"(?<![\d.])(10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})(?![\d.])")
RE_EXTERNO = re.compile(r"\b(RDAP|ASN|geolocaliza\w*|reputa\w*|AbuseIPDB|titular|provedor|cidade|operadora|pertence)\b", re.I)
RE_NEG_LINHA = re.compile(r"\b(não|nao|sem|nunca|nenhum\w*|não\s+realizad\w*)\b", re.I)

BLOCOS = {
    "analise": {
        "Resumo executivo": [[r"resumo\s+executivo"]],
        "Classificação do IP e caminho investigativo": [[r"classifica[çc][ãa]o\s+do\s+ip", r"tipo\s+prov[áa]vel"], [r"caminho\s+investigativo", r"quem\s+det[ée]m\s+o\s+dado"]],
        "O que pode e o que não pode ser atribuído": [[r"o\s+que\s+(pode|n[ãa]o\s+pode)", r"pode\s+e\s+(o\s+que\s+)?n[ãa]o\s+pode\s+ser\s+atribu"]],
        "Matriz de evidências": [[r"matriz\s+de\s+evid[êe]ncias"]],
        "O que sabemos / não sabemos": [[r"o\s+que\s+sabemos"], [r"o\s+que\s+n[ãa]o\s+sabemos"]],
        "Dados necessários para atribuição": [[r"dados\s+(necess[áa]rios\s+)?para\s+atribui[çc][ãa]o", r"dados\s+necess[áa]rios"]],
        "Próximo melhor passo": [[r"pr[óo]ximos?\s+(melhor\s+)?passos?"]],
        "Limitações": [[r"limita[çc][õo]es?"]],
        "Fontes (com data/hora da consulta)": [[r"\bfontes\b"]],
    },
    "forense": {
        "1. Identificação": [[r"identifica[çc][ãa]o"]], "2. Infraestrutura": [[r"infraestrutura"]],
        "3. Geolocalização e limitações": [[r"geolocaliza[çc][ãa]o"]], "4. DNS": [[r"\bdns\b"]],
        "5. Anonimização (inclui CGNAT)": [[r"anonimiza[çc][ãa]o"], [r"cgnat"]], "6. Reputação": [[r"reputa[çc][ãa]o"]],
        "7. Histórico": [[r"hist[óo]rico"]], "8. Correlações": [[r"correla[çc][õo]es"]],
        "9. Evidências e fontes": [[r"evid[êe]ncias"], [r"\bfontes\b"]], "10. Limitações": [[r"limita[çc][õo]es"]],
        "11. Conclusão técnica": [[r"conclus[ãa]o"]],
    },
    "rapido": {
        "Resumo executivo": [[r"resumo\s+executivo"]],
        "Classificação do IP": [[r"classifica[çc][ãa]o\s+do\s+ip", r"tipo\s+prov[áa]vel"]],
        "Limitações": [[r"limita[çc][õo]es?"]], "Próximo passo": [[r"pr[óo]ximos?\s+(melhor\s+)?passos?"]],
    },
}


def validar_texto(texto, perfil="analise"):
    linhas = texto.splitlines()
    achados = []

    def ignorada(n):
        return "validar:ignorar" in linhas[n] or (n > 0 and "validar:ignorar" in linhas[n - 1])

    for n, linha in enumerate(linhas):
        if ignorada(n):
            continue
        for ident, rx, sev, msg, sug in PROIBIDOS:
            for m in rx.finditer(linha):
                ini = max(linha.rfind(".", 0, m.start()), linha.rfind(";", 0, m.start()), linha.rfind("|", 0, m.start()),
                          linha.rfind(",", 0, m.start()), linha.rfind(":", 0, m.start())) + 1
                # só o que vem ANTES do trecho na mesma oração nega/cita-como-erro (P08/P09 já contêm "não/sem" no padrão)
                if NEGACAO.search(linha[ini:m.start()]):
                    continue
                achados.append({"id": ident, "gravidade": sev, "linha": n + 1, "trecho": linha.strip()[:200], "problema": msg, "sugestao": sug})
        mp = RE_PRIV.search(linha)
        if mp and RE_EXTERNO.search(linha) and not RE_NEG_LINHA.search(linha):
            achados.append({"id": "P20", "gravidade": "bloqueante", "linha": n + 1, "trecho": linha.strip()[:200],
                            "problema": f"IP privado ({mp.group(1)}) associado a dado externo (RDAP/ASN/titular/localização/reputação).",
                            "sugestao": "IP privado não tem titular, ASN, geolocalização nem reputação; explicar a faixa e buscar o IP público do mesmo instante."})
        if re.search(r"\b(tipo|classifica[çc][ãa]o)\b[^.\n]{0,50}\bconfirmad[oa]\b", linha, re.I) and \
                not re.search(r"lista\s+oficial|exonera|faixa|iana|rfc|oficial|sha-?256|publicad", linha, re.I):
            achados.append({"id": "P21", "gravidade": "atenção", "linha": n + 1, "trecho": linha.strip()[:200],
                            "problema": "'Confirmado' sem fonte primária declarada (lista oficial, ExoneraTor, faixa IANA).",
                            "sugestao": "Base comercial e heurísticas chegam no máximo a 'Provável'; citar a fonte que confirma."})
    if re.search(r"\b\d{1,2}:\d{2}:\d{2}\b", texto) and not re.search(r"\b(UTC|GMT|fuso|BRT|BRST|America/|Bras[ií]lia)\b|[+-]\d{2}:?\d{2}\b", texto, re.I):
        achados.append({"id": "P22", "gravidade": "atenção", "linha": None, "trecho": "",
                        "problema": "Há horários (hh:mm:ss) mas nenhuma menção a fuso horário.",
                        "sugestao": "Informar o fuso (UTC × horário local) de cada horário; sem fuso a atribuição pode apontar o assinante errado."})
    if not re.search(r"(consult\w+|coleta\w*|fontes?)[^\n]{0,80}(\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2})|(\d{2}/\d{2}/\d{4}|\d{4}-\d{2}-\d{2})[^\n]{0,80}(consult\w+|coleta\w*)", texto, re.I):
        achados.append({"id": "P23", "gravidade": "atenção", "linha": None, "trecho": "",
                        "problema": "Não há data/hora da consulta das fontes.",
                        "sugestao": "Registrar quando cada fonte foi consultada (data da consulta ≠ data do evento)."})
    ausentes = []
    for bloco, grupos in BLOCOS[perfil].items():
        if not all(any(re.search(rx, texto, re.I) for rx in g) for g in grupos):
            ausentes.append(bloco)
    return achados, ausentes


def cmd_validar(a):
    texto = open(a.entrada, encoding="utf-8", errors="replace").read()
    achados, ausentes = validar_texto(texto, a.perfil)
    bloq = [x for x in achados if x["gravidade"] == "bloqueante"]
    res = {"arquivo": a.entrada, "perfil": a.perfil, "bloqueantes": len(bloq), "atencao": len(achados) - len(bloq),
           "blocos_ausentes": ausentes, "achados": achados, "gerado_em_utc": C.agora(),
           "aviso": "Verificação por padrões de texto: apoio, não substitui a leitura crítica nem a análise jurídica."}
    if a.json:
        C.escrever(a.json, res)
    print(f"Validação ({a.perfil}) de {a.entrada}: {len(bloq)} bloqueante(s), {len(achados) - len(bloq)} de atenção, "
          f"{len(ausentes)} bloco(s) obrigatório(s) ausente(s).")
    for x in achados:
        icone = "🔴" if x["gravidade"] == "bloqueante" else "🟡"
        print(f"{icone} [{x['id']}] linha {x['linha'] or '—'}: {x['problema']}")
        if x["trecho"]:
            print(f"     trecho: {x['trecho']}")
        print(f"     sugestão: {x['sugestao']}")
    for b in ausentes:
        print(f"🟠 Bloco ausente: {b}")
    if not achados and not ausentes:
        print("✓ Nenhum problema detectável por padrão. (Isto não substitui a revisão crítica.)")
    raise SystemExit(1 if bloq else 0)
