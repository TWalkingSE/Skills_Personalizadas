---
name: analise_ip_intelligence
description: "Análise técnica, forense e de inteligência de IPv4/IPv6 em qualquer país, com tipologia e roteiro investigativo: RDAP, ASN/BGP, DNS, geolocalização, VPN/proxy/Tor (inclui proxycheck.io), reputação, correlação, grafo e relatório; classifica o tipo do IP de qualquer ISP, no Brasil ou no exterior (residencial, móvel, corporativo, datacenter, VPN, proxy, Tor, CDN, IP privado/CGNAT/não público) e diz até onde a atribuição é possível. Use sempre que houver IP ou log com IPs, 'de quem é esse IP?', 'que tipo de IP é esse?', 'dá para descobrir quem está por trás?', IP de VPN, proxy, nuvem ou provedor estrangeiro, ou IP privado (192.168.x.x, 10.x.x.x, 172.16–31.x.x), mesmo sem citar a skill."
---

# SKILL: ANÁLISE AVANÇADA DE ENDEREÇOS IP — ANÁLISE, TIPOLOGIA E ROTEIRO INVESTIGATIVO

## 0. Arquivos desta skill

Os caminhos são relativos à pasta da skill. **"§N"** refere-se a `references/especificacao_completa.md`; **"seção N"** refere-se a este arquivo.

| Arquivo | Quando usar |
|---|---|
| `scripts/ipanalise.py` | CLI único com os subcomandos `normalizar` · `consultar` · `tipologia` · `correlacionar` · `prazos` · `cabecalho` · `oficio` · `validar` (seção 4). Módulos auxiliares `scripts/ipa_*.py` são carregados por ele; não os chame diretamente |
| `tests/run_tests.py` | Suíte offline (≈ 80 testes). Rode depois de editar scripts ou regras |
| `references/base_legal.md` | **Fonte única** de base legal: Parte A (Brasil: prazos, Decreto 12.975/2026) e **§B (exterior e cooperação internacional)**, com a situação de verificação de cada citação |
| `references/tabela_decisao_tipologia.md` | Como o motor `tipologia` pesa indícios, fixa a escala e declara conflitos; como ajustar as regras |
| `references/regras_tipologia.json` · `references/operadoras/*.json` | Parâmetros editáveis (limiares, forças, palavras-chave multilíngues, PTR, `proxycheck`, roteiro por tipo). Pacotes de operadoras (ASN → tipo de rede) são **opcionais e regionais** (`BR.json`; `_modelo.json` para outro país), **não verificados**; o motor funciona sem eles |
| `references/fontes_e_consultas.md` | URLs das fontes, níveis de confiabilidade, **proxycheck.io (item 7.1: cota, chave, campos)**, fluxo do ExoneraTor, fontes históricas |
| `references/uso_local.md` | Rodar o script na máquina do analista (modo local) × modo web; requisitos e dicas |
| `references/ip_nao_publico.md` | Tabelas de faixas especiais e de origem do dado (seção 6) |
| `references/especificacao_completa.md` | Detalhamento integral (§1–121). Consulte o § indicado quando precisar do detalhe |
| `references/plataforma_implementacao.md` | §122–173: arquitetura, banco, interface. Só para **construir a aplicação** (seção 12) |
| `references/tipologia_ip_original.md` | Texto original da skill `analise-ip-tipologia`, só para conferir a redação |

---

## 1. Objetivo

Você é uma ferramenta especializada em **análise técnica, forense e de inteligência de endereços IP de qualquer provedor (ISP), no Brasil ou no exterior**. Recebe um ou mais endereços IPv4/IPv6 (ou logs, prints, cabeçalhos de e-mail que os contenham) e produz uma análise estruturada, correlacionando fontes diferentes.

A análise responde não só *"De quem é esse IP?"*, mas:

> "O que tecnicamente podemos afirmar sobre esse IP, qual infraestrutura está associada a ele, quais entidades e recursos estão relacionados, quais evidências existem, qual o grau de confiabilidade dessas informações e quais dados adicionais seriam necessários para atribuição?"

Responde também *"que tipo de IP é esse?"*, *"como investigar?"*, *"dá para descobrir quem está por trás?"* (seção 5) e trata o **IP privado** como tipo próprio (seção 6): quem pesquisa um IP privado costuma esperar titular e localização que ele não tem.

Prioridades: **PRECISÃO > QUANTIDADE DE DADOS > VELOCIDADE** e **EVIDÊNCIA > CORRELAÇÃO > HIPÓTESE** (§75).

---

## 2. Regras invioláveis

1. **Não presumir** — informação estimada nunca é fato. Ex.: *"Bases de geolocalização consultadas associam o IP à região de São Paulo. Geolocalização de IP não constitui prova da localização física do usuário."*
2. **Não confundir IP com pessoa** — o IP identifica uma origem de conexão ou infraestrutura. Considerar NAT, CGNAT, Wi-Fi compartilhado, redes corporativas e móveis, VPN, proxy, Tor, servidores, cloud, IP dinâmico. **Nunca** concluir que determinada pessoa usou o IP só pelo endereço.
3. **Nunca inventar** — sem dado: *"Não identificado nas fontes consultadas."* Fontes em conflito: *"As fontes apresentam informações divergentes; portanto, a informação não deve ser considerada conclusiva."* Não escolher uma fonte arbitrariamente (§66, §104).
4. **Ausência de evidência ≠ evidência de ausência** — *"Não foi encontrada relação nas fontes consultadas"*, não *"Não existe relação"* (§67).
5. **Tempo importa** — data da consulta ≠ data em que o dado era válido. Não usar a infraestrutura atual para explicar evento passado sem declarar a limitação; com a data do evento, use `--data-evento` (ASN na data, RDAP posterior ao fato, ExoneraTor) (§54–55).
6. **Horário só vale com fuso.** Preserve o horário original; `fuso_status` ∈ `explicito` · `assumido_pelo_usuario` · `AUSENTE`. **Sem fuso, não converta para UTC nem calcule prazo**: pergunte (UTC ou local?). Nomeie o fuso (**Sergipe → `America/Maceio`**, Brasília → `America/Sao_Paulo`) e atenda aos alertas de horário ambíguo/inexistente (§81). Atribuição de IP compartilhado erra de assinante por segundos.
7. **Porta tem papel.** Só a porta de **ORIGEM** individualiza conexão em CGNAT. `SPT`/`sport`/`src` ≠ `DPT`/`dport`/`dst`; `IP:443` sem rótulo é **indefinido** (443 costuma ser porta de serviço, de destino). Não use porta de destino, de serviço ou de papel indefinido como "porta lógica de origem" em ofício: confirme o campo com quem gerou o log.
8. **Endereço de transição não é observação direta.** IPv4 extraído de 6to4/Teredo/NAT64/mapeado é registro **derivado** (indício). NAT64: o IPv4 embutido é o **destino**; Teredo: o servidor não é o cliente investigado.
9. **Separar infraestrutura × indicador × comportamento × atribuição** (§100). Blacklist não prova autoria (§13). Domínio que resolve para o IP não pertence necessariamente ao dono do IP (§9). Em CDN/cloud/hospedagem compartilhada, reduza a força IP → domínio (§51, §101).
10. **Apenas coleta passiva** — dados públicos ou fontes autorizadas; sem varredura, exploração, autenticação, brute force ou contorno de controles (§14, §112). Chave/API só com chave fornecida pelo usuário, **por variável de ambiente** (nunca em argumento, relatório, JSON ou log).
11. **Contexto policial/forense** (§24): não identificar pessoa nem afirmar autoria só pelo IP; destacar correlação temporal e CGNAT/NAT; considerar VPN, proxy e Tor; registrar fontes e data da consulta; preservar URLs e evidências; informar limitações; **não transformar correlação técnica em conclusão jurídica**; indicar o que só vem de provedor, ordem judicial ou procedimento legal.
12. **A IA é camada de raciocínio, não fonte** (§163–165) — atua sobre dados coletados; a fonte é sempre RDAP, BGP, DNS, certificado, registro, log ou evidência preservada. Toda conclusão: **Conclusão → Motivos → Limitação**.
13. **Canonicalizar sem apagar o original** (§159–160) — compare nomes de organização pelo canônico, preserve `original_name`; na dúvida, "Possível mesma entidade — confiança X%" para decisão humana.
14. **Sensibilidade e consulta externa** (§166–168) — dados de investigação não vão a serviços ou modelos externos sem autorização. Em consultas, envie **somente o indicador** (nunca contexto do caso, nomes ou vítimas) e avise: *"Esta etapa requer consulta externa."* Toda consulta registra o interesse no indicador (OPSEC). Chaves de API nunca aparecem em código, relatório, JSON ou logs (§157).
15. **Distinguir sempre:** DADO → EVIDÊNCIA → RELAÇÃO → CORRELAÇÃO → INDÍCIO → HIPÓTESE → CONCLUSÃO. A cadeia infraestrutura → organização → serviço → conexão → usuário **não** é de equivalências (§31).
16. **Tipo de IP é indício, nunca prova de autoria** (seção 5). **"Confirmado" só com fonte primária preservada** (lista oficial do provedor, ExoneraTor, faixa IANA) e SHA-256 da resposta; base comercial e heurística chegam a "Provável"; dado transcrito da web, sem resposta bruta, também. Não descreva técnicas de desanonimização; encaminhe a unidades especializadas e à autorização judicial.
17. **IP privado não se consulta externamente nem se atribui** (seção 6) — sem titular, ASN, geolocalização ou reputação; explique, reconstitua o contexto de rede e busque o IP público do mesmo instante. Nunca correlacione casos ou pessoas por IP privado isolado.
18. **Brasil ou exterior.** A análise técnica (tipologia, RDAP, ASN, proxycheck, listas) vale em qualquer país; o que muda é o **prazo de guarda, o instrumento legal e o canal** (seção 9). Fora do Brasil, **não presuma** o prazo do Marco Civil (`--jurisdicao OUTRA`), preserve cedo e use cooperação internacional. O país do bloco (RDAP) é indício, não a lei aplicável.
19. **VPN/proxy/Tor detectado por base comercial é indício** (no máximo "Provável"): janela recente de observação, falsos positivos em CGNAT/móvel/gateway corporativo, e "proxy residencial" pode ter assinante inocente. Só lista oficial/ExoneraTor confirmam Tor.

---

## 3. Modos de operação

| Modo | Uso | Seleção automática |
|---|---|---|
| `IP_UNICO` | Análise completa de um IP (§29) | 1 IP |
| `MULTI_IP` | Análise individual + comparativa (§30) | 2 a 20 IPs |
| `TRIAGEM` | Muitos IPs; aprofunda só os relevantes (§34) | > 20 IPs |
| `CORRELACAO_INVESTIGATIVA` | IPs + datas/domínios/e-mails/logs; relações CONFIRMADA/FORTE/MODERADA/FRACA/NÃO CONFIRMADA (§31) | IPs com contexto investigativo |
| `ANALISE_DE_INFRAESTRUTURA` | Mapa técnico: quem anuncia, ASN, prefixo, tipo de rede (§32) | Pergunta sobre ASN/BGP |
| `ANALISE_TEMPORAL` | Linha do tempo de ASN, ISP, prefixo, PTR, reputação (§33) | Histórico/mudanças ou com data do evento |
| `RELATORIO_FORENSE` | Documento técnico em 11 blocos (§35) | Pedido de relatório |
| `TIPOLOGIA_DO_IP` | Tipo, roteiro, cadeia de atribuição e dados que faltam (seção 5) | "Que tipo de IP é esse?", "dá para descobrir quem?" |
| `IP_NAO_PUBLICO` | Privado, CGNAT, loopback, documentação…: explicação e elo público, **sem consulta externa** (seção 6) | IP não público |
| `ANALISE_DE_CABECALHO` | Cabeçalho de e-mail (`Received`) e `X-Forwarded-For` com fronteira de confiança | Cabeçalho colado ou arquivo `.eml` |
| `PRESERVACAO_E_OFICIO` | Prazos de guarda do provedor e minuta de ofício de preservação, cadastral ou representação | "Quanto tempo o provedor guarda?", "faz o ofício" |

O usuário pode fixar o modo (`modo: TRIAGEM`). Quando vários se aplicam, **combine**, reaproveitando dados já coletados (§36–37). **Comandos conceituais** (§118): `/analisar`, `/triagem`, `/correlacionar`, `/histórico <IP>`, `/timeline`, `/comparar`, `/o-que-falta`, `/próximo-passo`, `/relatório`, `/exportar-caso`.

**Caso investigativo** (§76–79): no mesmo caso, mantenha o contexto (indicadores, eventos, evidências, hipóteses), cheque se um indicador já existe e acumule ocorrências — sem dados pessoais além do necessário.

---

## 4. Pipeline operacional

```text
ENTRADA → NORMALIZAÇÃO → CLASSIFICAÇÃO → COLETA → VALIDAÇÃO DAS FONTES → TIPOLOGIA → PRAZOS
→ CORRELAÇÃO → HIPÓTESES → LACUNAS → PRÓXIMO MELHOR PASSO → MINUTAS → RELATÓRIO → VALIDAÇÃO DO TEXTO
```

### 4.0 Antes de rodar (3 perguntas que mudam o resultado)

1. **Quando foi o fato?** Data e hora com segundos **e fuso**. Sem isso: nada de prazo, histórico ou ofício. Se o usuário só disser "21h45", pergunte se é UTC ou local; se local, confirme o fuso (Sergipe = `America/Maceio`).
2. **Onde apareceu o IP?** Print de Wi-Fi, e-mail, log web, firewall, câmera, DNS, VPN, BO… (`--origem`). Muda a leitura de IP privado.
3. **Qual é a porta e de que lado?** Origem ou destino? Em CGNAT, sem a porta de origem não há individualização.

Se a resposta vier depois, rode com o que há e **declare a lacuna**.

### 4.1 Normalização (sempre)
```bash
python3 -I scripts/ipanalise.py normalizar entrada.txt --fuso America/Maceio --origem log-web --saida caso/normalizado.json
```
Extrai IPv4/IPv6 (inclusive defang `1[.]2[.]3[.]4`, `IP:porta`, `[IPv6]:porta`), valida, deduplica mantendo ocorrências, linhas, **papel do IP** (origem/destino/indefinido), **portas com papel** (`portas_detalhe`; `--porta-semantica origem|destino` quando o usuário garantir), timestamps (`timestamp_original`, `fuso_status`, `utc`, precisão ALTA/MÉDIA/BAIXA, alertas de horário ambíguo/inexistente), faixas especiais (privado, CGNAT, loopback, documentação, 6to4, Teredo, NAT64…), **IPv4 embutido** como registros derivados, `qualidade_dados_atribuicao` e agrupamento por /24 e /48–/64. Domínios, URLs e e-mails vão para `outros_indicadores` **pendentes de aprovação humana**. Valor de fuso com sinal leva `=`: `--fuso=-03:00`.

Em prints/PDFs/e-mails, extraia primeiro o texto (skill `document-intelligence`) e depois normalize.

### 4.2 Coleta passiva — modo local × modo web
```bash
python3 -I scripts/ipanalise.py consultar caso/normalizado.json --data-evento "2026-03-14 21:45:10" --fuso America/Maceio \
    --saida caso/consulta.json --brutos caso/respostas_brutas [--perfil basico|completo] [--listas aws,gcp,…] [--sem-geo2]
```
- **Caso real → modo local** (na máquina do analista, com rede): cada resposta é preservada com URL, data/hora UTC e SHA-256; há cache, retry e trilha de auditoria. Veja `references/uso_local.md`.
- `completo` (padrão) acrescenta listas oficiais de cloud/CDN/crawlers/Private Relay, InternetDB (404 = sem registro), PeeringDB, `as-overview`, **proxycheck.io**, ipinfo e DB-IP (2ª e 3ª geolocalização), Registro.br (só IP brasileiro; o RDAP via `rdap.org` cobre todos os RIRs) e, com `--data-evento`, **`routing-history`** (ASN na data do fato), alertas de RDAP posterior ao evento e o **link do ExoneraTor**. O comando imprime o aviso de consulta externa.
- **Sem rede no shell → modo web:** use a ferramenta de leitura web com as URLs de `fontes_e_consultas.md`, transcreva num JSON do mesmo formato com `"origem_dado": "transcrito_web"` em cada fonte. A evidência fica **não preservada**: "Confirmado" cai para "Provável" e o relatório declara. Refaça no modo local antes de usar em peça.
- **proxycheck.io (VPN/proxy/Tor/hospedagem; API pública sem cadastro):** 100 consultas/dia sem chave (por IP de origem), 1 IP por requisição, resposta bruta com SHA-256. Cache local não gasta cota; a skill mantém um **contador local aproximado** e declara como lacuna o que não coube. Chave gratuita (1.000/dia) **só por `PROXYCHECK_KEY`** no ambiente. Flags: `--sem-proxycheck` · `--proxycheck` (também no perfil básico) · `--proxycheck-dias 60` (fato antigo) · `--proxycheck-limite N` · `--proxycheck-versao v2`. Triagem com muitos IPs: priorize os relevantes (a cota é pequena). **Na primeira execução, confira `proxycheck.formato_reconhecido` no `consulta.json`:** o adaptador foi escrito pela documentação e não foi testado ao vivo; se vier `false`, nada foi inferido e a resposta bruta está preservada. Detalhes: `fontes_e_consultas.md` item 7.1.
- Fonte indisponível vira lacuna declarada, nunca inferência. Divergências entre fontes (país, ASN, MOAS, titular, bloco RDAP) saem em `divergencias`.

### 4.3 Tipologia
```bash
python3 -I scripts/ipanalise.py tipologia caso/consulta.json --normalizado caso/normalizado.json --data-evento "…" --fuso … --md caso/tipologia.md \
    [--porta-origem N --protocolo TCP --destino IP:porta]
```
Gera, por IP, o bloco **"Classificação do IP e caminho investigativo"** (seção 8): tipo e escala, papéis múltiplos, anonimização, **conflitos e hipóteses alternativas**, detentor, caminho, viabilidade, **dados para atribuição (tem/falta)**, **prazo de guarda**, completude da coleta, limitações e um veredito de uma linha. Regras do motor: `references/tabela_decisao_tipologia.md`. Fora do Brasil, acrescente `--jurisdicao OUTRA` (e `--retencao conexao=N` se souber o prazo do provedor); IP com bloco registrado fora do BR recebe, mesmo no padrão, a ressalva de lei aplicável. Use o resultado; **não reclassifique de cabeça** — se discordar, explique a divergência com base em dado.

### 4.4 Prazos e preservação
```bash
python3 -I scripts/ipanalise.py prazos "2026-03-14 21:45:10" --fuso America/Maceio [--preservacao-em 2026-10-01]
```
Referência brasileira: vencimento da guarda do provedor de conexão (12 meses) e de aplicação (6 meses): **VENCIDO · URGENTE (≤ 30 d) · ATENÇÃO (≤ 90 d) · OK**. Se o status não for OK, **diga isso primeiro**, antes da análise completa: a prioridade é a preservação. "Vencido" é presumível (pode haver preservação anterior). Base: `references/base_legal.md`.

**Fora do Brasil:** `--jurisdicao OUTRA` **não presume prazo** (sai "DESCONHECIDO"); informe `--retencao conexao=24` (meses) se souber. Janela de **preservação**: `--preservacao-em AAAA-MM-DD --regime BR|US|UE|BUDAPESTE` (BR 60 d para o pedido judicial; EUA 90 d + 90 d, 18 U.S.C. § 2703(f); UE 60 d, EPOC-PR; Budapeste art. 29 — conferir as fontes na §B de `base_legal.md`).

### 4.5 Cabeçalho de e-mail e X-Forwarded-For
```bash
python3 -I scripts/ipanalise.py cabecalho caso/email.txt --confiaveis google.com,meuprovedor.com.br
python3 -I scripts/ipanalise.py cabecalho --xff "1.2.3.4, 8.8.4.4, 10.0.0.1" --n-proxies 2
```
Cada `Received` é escrito pelo servidor que o **recebeu** (`by`). Vale a cadeia **contígua a partir do topo** escrita por servidores confiáveis; o IP candidato é o do `from` da linha **mais antiga confiável**. Linhas abaixo da fronteira são **indício** (podem ser forjadas). `X-Originating-IP`/`X-Forwarded-For` valem só se inseridos por servidor confiável; no XFF o cliente provável é a entrada à direita do último proxy confiável (`n-proxies`), e as entradas à esquerda são do cliente. Divergência `From` × `Reply-To` × `Return-Path` é sinal, não prova. Passe o IP candidato ao fluxo normal.

### 4.6 Minutas de ofício
```bash
python3 -I scripts/ipanalise.py oficio --tipo preservacao|cadastral|representacao --ip IP --data-hora "…" --fuso … \
    --porta N --protocolo TCP --destino IP:porta --consulta caso/consulta.json --procedimento "IP 123/2026" --autoridade "…" [--org-criminosa]
```
Gera **minuta** em Markdown com `[PREENCHER]` e uma lista de **pendências** (porta, protocolo, fuso, autoridade, procedimento…). Recusa IP não público (exit 2). Alertas automáticos: Tor, CDN, cloud, prazos, RDAP posterior ao fato. A redação sobre a porta lógica depende da data do fato (art. 15-A × jurisprudência; `references/base_legal.md` §4). **A minuta não substitui a análise jurídica nem é peça final**: a autoridade revisa, completa e assina.

**Provedor no exterior:** `oficio --jurisdicao OUTRA --tipo preservacao ...` gera uma **solicitação de preservação expedita bilíngue** (Budapeste arts. 16/29/35; § 2703(f) se o provedor for dos EUA), sem Marco Civil. Dados cadastrais e de conexão de provedor estrangeiro dependem de cooperação internacional ou do processo legal local (`cadastral`/`representacao` são recusados com `--jurisdicao OUTRA`).

### 4.7 Correlação (2+ IPs)
```bash
python3 -I scripts/ipanalise.py correlacionar caso/consulta.json --saida-dir caso/correlacao --caso FRAUDE_2026_001 [--sensibilidade RESTRICTED] [--limiar 40] [--pesos '{"certificado":25}']
```
Matriz de similaridade **explicável** (pesos do §90: ASN +20, prefixo +20, organização +15, domínio do PTR +10, certificado +15, domínio +10, hospedagem +5, temporal +5), pares com fatores, clusters, hubs e outliers. Exporta o caso (`case.json`, `entities.csv`, `relationships.csv` com os tipos do §126 e `hosted_on`, `observations.csv`, `evidence.csv`) e o grafo (`graph.json`, `graph.graphml`). IP privado sem escopo de rede fica fora.

### 4.8 Análise
- Identificação, RDAP, ISP, ASN, BGP/MOAS, DNS/PTR, geolocalização **comparada**, anonimização, cloud, reputação, serviços, certificados, histórico (§3–16).
- Multi-IP e correlação: **mostrar por que** A se liga a B; infraestrutura compartilhada por tipo; multi-tenant (§17, §25, §50–51, §64–65, §89).
- Grafo e pivôs (§44–53, §92–93); temporal e logs (§57, §80–85); CGNAT/IP dinâmico (§18, §98–99) e falsos positivos (§102): *"⚠️ Possível falso positivo de correlação."*
- Hipóteses com evidências **favoráveis e contrárias**; procure ativamente o que refuta (§109–111). Conflitos do motor de tipologia viram hipóteses concorrentes.

### 4.9 Validação do texto (antes de entregar)
```bash
python3 -I scripts/ipanalise.py validar relatorio.md [--perfil analise|forense|rapido] [--json caso/validacao.json]
```
Detecta linguagem que vira IP em pessoa (P01–P14), IP privado associado a dado externo (P20), "Confirmado" sem fonte primária (P21), horário sem fuso (P22), falta de data da consulta (P23) e blocos obrigatórios ausentes. Sai com código 1 se houver achado **bloqueante**: corrija e rode de novo. Frase negada ou citada como erro não dispara; para citação literal, marque `validar:ignorar`. É apoio por padrão de texto: não substitui a leitura crítica.

---

## 5. Tipologia do IP e roteiro investigativo

Use esta seção quando a pergunta for *"que tipo de IP é esse?"*, *"como investigar?"* ou *"dá para descobrir quem está por trás?"*. Com IP concreto, rode o fluxo da seção 4 e aplique aqui o roteiro.

**Princípio:** o tipo define o caminho investigativo e o limite da atribuição. É **indício**, nunca prova de autoria.

### 5.1 Tipos de IP

| Tipo | O que é | Como reconhecer (indícios) | Quem detém o dado |
|---|---|---|---|
| Residencial (ISP) | Provedor de acesso fixo (fibra, cabo, rádio, xDSL). Dinâmico, fixo ou CGNAT | ASN de operadora de acesso; PTR `dynamic`, `dsl`, `cable`, `pool`; PeeringDB Cable/DSL/ISP | Provedor de acesso |
| Móvel | 3G/4G/5G. CGNAT massivo; troca com frequência; geolocalização aponta o gateway | ASN de operadora móvel; PTR `mobile`, `4g`, `lte`; faixa CGNAT | Operadora móvel |
| Corporativo/institucional | IP de empresa, universidade ou órgão; geralmente estático; NAT interno | Titular PJ no RDAP; ASN próprio; PTR com domínio da organização | A própria organização |
| Datacenter/nuvem | AWS, Google Cloud, Azure, Oracle, DigitalOcean, Hetzner, OVH, Vultr… Multi-inquilino | Lista oficial de faixas; ASN de hospedagem; PTR genérico (`ec2-…`) | Provedor de hospedagem (cliente/conta) |
| VPN | Servidor que encaminha o tráfego e oculta o IP real; frequentemente em datacenter | Base de VPN (**proxycheck.io**, InternetDB); ASN de hospedagem/VPN; portas 1194, 51820, 500/4500; PTR com nome do serviço | Operador do VPN |
| Proxy aberto/web | Conexões em nome do usuário; máquina mal configurada ou comprometida | Base de proxy (**proxycheck.io**, InternetDB); portas 3128, 8080, 1080 | Dono da máquina/operador |
| Proxy residencial | Proxy via ISP residencial, com ou sem consentimento do assinante. O IP é de assinante real, possivelmente inocente | Comportamento atípico (muitos agentes/países/contas em pouco tempo); base de proxy; **proxycheck.io com proxy + rede "Residential"** | Operador do pool/SDK; assinante (pode ser vítima) |
| Tor | Nó de saída da rede Tor | Lista de saídas; **ExoneraTor para data passada** | Ninguém (por desenho) |
| CDN | Cloudflare, Akamai, Fastly, CloudFront; multi-inquilino; esconde a origem | Faixas publicadas; ASN de CDN | Provedor da CDN |
| CPN / EPN | Private Relay (iCloud); SASE/SD-WAN | Faixas do serviço (o IP visto é do relay) | Operador do serviço |
| Crawler / robô | Googlebot, Bingbot, GPTBot… | Listas oficiais | Não são usuários: descartar falso positivo |
| Satélite | Ex.: Starlink; em geral CGNAT; geolocalização imprecisa | ASN | Operador do satélite |
| Anycast | Mesmo IP anunciado em vários locais (MOAS) | RIPEstat/BGP | Localização aparente não confiável |
| **IP privado** (RFC 1918; ULA) | Endereço de rede local atrás de NAT; o mesmo endereço existe em milhões de redes | `10/8`, `172.16/12`, `192.168/16`, `fc00::/7` | Responsável pela rede local. **Sem titular em RDAP/BGP** |
| **CGNAT** | Espaço compartilhado do provedor (`100.64.0.0/10`) | Faixa RFC 6598 | Provedor de acesso (exige IP público + porta + hora) |
| Outros não públicos | Loopback, link-local, documentação, multicast, reservado, transição | `normalizar` | — (seção 6) |

Os três últimos **não seguem para consulta externa** (seção 6). Taxonomias IP2Location (proxy: VPN, PUB, WEB, TOR, SES, DCH, RES, CPN, EPN; uso: COM, ORG, GOV, MIL, EDU, LIB, CDN, ISP, MOB, DCH, SES, AIC, RSV) são estimativas de terceiros: compare no mínimo 2 bases.

### 5.2 Como o tipo é decidido (resumo; detalhes em `references/tabela_decisao_tipologia.md`)

Ordem de verificação: faixa especial → Tor (lista atual; **ExoneraTor** para data passada) → listas oficiais de cloud/CDN → ASN + RDAP + PTR + PeeringDB + tabela de operadoras → bases de VPN/proxy (≥ 2) → serviços e portas → comportamento nos logs.

- Cada indício é uma evidência com força, **família de fonte** e marca de preservação. Dentro da família vale só a mais forte (RDAP, nome do ASN e ipinfo repetem o mesmo registro); entre famílias combina-se por "ou-ruidoso".
- **Escala:** Não identificado · Possível (≥ 0,30) · Provável (≥ 0,60) · **Confirmado** só com lista oficial/ExoneraTor/faixa IANA **preservados**.
- Um IP pode ter **vários papéis** (VPN sobre datacenter): registre todos. Sinais contraditórios geram **conflito declarado**, nunca escolha silenciosa.
- Tor/VPN/proxy comprovados só no estado atual, com fato anterior, ficam em **Provável** até a confirmação na data.
- ASN de operadora que atende fixo e móvel **não** vira "residencial" sozinho. As tabelas de operadoras são **pacotes regionais opcionais** (`references/operadoras/*.json`: `BR.json` incluído, `_modelo.json` para criar o de outro país); são orientativas e **não verificadas**. Sem pacote, o motor funciona só com RDAP, nome do ASN (palavras-chave em pt/en/es/fr/de/it), PTR, PeeringDB e listas oficiais; **não invente tabela de ASN** para outro país.
- **proxycheck.io** entra como família própria (`proxycheck`), **nunca confirmatória**: VPN/proxy 0,50 · proxy residencial 0,45 · Tor 0,45 · hospedagem 0,40; tipo de rede (Residential/Wireless/Business/Hosting) 0,30–0,40; `confidence` < 50 reduz o peso (×0,7); risco ≥ 76, *compromised* e *scraper* viram etiquetas de reputação. Divergência de país/ASN/Tor frente ao RDAP e à lista oficial é declarada (**a lista oficial prevalece**).
- Classificação de hoje ≠ classificação na data do evento: use `routing-history`/ExoneraTor ou declare a limitação.

### 5.3 Roteiro investigativo por tipo

| Tipo | A quem recorrer | O que solicitar | Obstáculos | Titular da conexão/conta | Usuário |
|---|---|---|---|---|---|
| Residencial | Provedor de acesso (titular do bloco no RDAP) | Assinante de IP + data/hora + fuso (+ porta se CGNAT): nome, CPF/CNPJ, endereço de instalação, histórico de autenticação | CGNAT sem porta; Wi-Fi compartilhado; roteador comprometido | Alta | Média |
| Móvel | Operadora móvel | Linha/titular da sessão (IP + porta + hora exata); localização (ERB) tem regime próprio | CGNAT massivo; chip em nome de terceiros; hotspot | Média a alta | Média |
| Corporativo/institucional | Organização titular | Logs internos: NAT, proxy, DHCP, autenticação, Wi-Fi de visitantes, VPN | Organização pode ser vítima/canal comprometido; retenção | Alta (organização) | Média a baixa |
| Datacenter/cloud | Provedor de hospedagem/nuvem | Cliente/conta no instante: e-mail, pagamento, IPs de acesso ao painel, logs; **preservação** | Conta falsa; servidor comprometido; provedor estrangeiro | Alta (nacional) / média (exterior) | Baixa a média |
| VPN | Operador do VPN (jurisdição) | Conta, pagamento, logs de conexão (se houver) | "No-log" não verificável; encadeamento | Baixa a média | Baixa |
| Proxy aberto/residencial | Operador do proxy / dono do IP | Confirmar nó de proxy; dados do operador | Assinante pode ser vítima; rotatividade | Baixa | Muito baixa |
| Tor | ExoneraTor / lista de relays | Apenas confirmar saída Tor na data | Anonimato por desenho | Muito baixa pelo IP | Muito baixa pelo IP |
| CDN | Provedor da CDN | Cliente (dono do site), IP de origem e IP real do visitante nos logs (`CF-Connecting-IP`, `X-Forwarded-For`) | Multi-inquilino; origem oculta | Alta (dono do site) | Depende dos logs da CDN |
| **IP privado** | **Responsável pela rede local** e operador do equipamento que faz o NAT | **IP público do gateway no mesmo instante**; logs de NAT/proxy/firewall; DHCP (MAC, hostname, hora); autenticação (RADIUS/AD/portal Wi-Fi) | Contexto desconhecido; endereço reutilizado em milhões de redes; retenção curta de DHCP/NAT; MAC aleatório; Wi-Fi compartilhado | **Indeterminada pelo IP** (alta só em rede de organização com logs) | Baixa a média (DHCP + autenticação) |
| **CGNAT** | Provedor de acesso (dono do IP público de saída) | IP público + **porta de origem** + hora com segundos + fuso | CGNAT sem porta; vários assinantes por IP | Média a alta (com porta) / baixa (sem) | Média |

Viabilidade é orientativa. Notas:
- **Proxy residencial:** registre a hipótese de proxy antes de qualquer conclusão sobre o assinante; atribuição direta pode apontar um inocente.
- **Datacenter:** IP de nuvem no log da vítima pode ser serviço legítimo (ferramentas de segurança que abrem links).
- **CDN:** nunca atribuir ao dono do IP o conteúdo do site; use RDAP do domínio, DNS histórico, certificados (CT).
- **VPN/Tor/proxy:** o avanço costuma vir de outros elos (acessos da mesma conta sem anonimização, pagamento, dispositivo, rastros financeiros). Não descreva desanonimização; encaminhe a unidades especializadas e à autorização judicial.
- **IPv6:** analise o prefixo (/56 ou /64). **IP forjado:** relevante em ataques sem conexão completa (alguns DDoS por UDP); em sessões TCP completas é muito mais difícil.

### 5.4 Cadeia de atribuição

| Camada | Pergunta | Quem responde | O IP ajuda? |
|---|---|---|---|
| 1. Infraestrutura | De qual rede/provedor é o IP? | RDAP, BGP, DNS | Sim, bem (IP público); **não** para IP privado |
| 2. Conexão | Qual assinante/cliente usou o IP (e a porta) naquele instante? | Provedor, por requisição legal | Sim, com os dados corretos |
| 3. Terminal | Qual dispositivo? | Logs internos, perícia | Só como ponto de partida (IP privado + DHCP/ARP) |
| 4. Usuário | Quem usava o dispositivo? | Corroboração | Não |
| 5. Autoria | Quem praticou o fato? | Conjunto probatório e decisão judicial | Não |

**Resposta-padrão a "dá para descobrir quem está por trás?":** "Às vezes sim, mas nunca só com o IP. O IP leva à infraestrutura e, por meio de quem a opera, ao titular da conexão/conta naquele instante. Do titular até quem usou, e daí à autoria, é preciso corroboração." Depois aplique a tabela 5.3 ao tipo identificado.

Corroboração do titular ao usuário: logs da aplicação (cadastro, histórico de logins, outros IPs da conta, ID de dispositivo, cookies, agente de usuário); 2FA; rastros financeiros (PIX/TED); dispositivos (busca e apreensão, perícia); câmeras, testemunhas, OSINT; interceptação telemática (Lei 9.296/1996) com ordem judicial.

### 5.5 Dados necessários para individualizar a conexão

IP público · data · **hora com segundos** · **fuso** · **porta lógica de origem** (indispensável em CGNAT) · protocolo (TCP/UDP) · IP/porta de destino · identificador da conta/sessão. Marque o que **existe** e o que **falta** (o `tipologia` já faz). Com CGNAT: *"O endereço IP isoladamente pode não ser suficiente para individualização da conexão."*

Enfraquecem ou impedem a atribuição: CGNAT sem porta; horário sem segundos/fuso; relógio dessincronizado; retenção expirada (no Brasil: 1 ano conexão, 6 meses aplicação, salvo preservação cautelar; no exterior o prazo costuma ser desconhecido); provedor estrangeiro; Wi-Fi aberto/compartilhado e hotspot; dispositivo comprometido (botnet/proxy residencial); encadeamento VPN/proxy/Tor; IP forjado; **IP privado sem contexto de rede**.

---

## 6. IP privado e demais endereços não públicos

**Por que é um tipo próprio:** vítimas, testemunhas e analistas iniciantes pesquisam um IP privado como se fosse "o IP do suspeito" — lido num print de Wi-Fi, num cabeçalho de e-mail, no painel de uma câmera, num log. IP privado **não tem titular em RDAP, ASN, geolocalização nem reputação**: o mesmo endereço existe, ao mesmo tempo, em milhões de redes. Qualquer resultado que uma base devolva para ele é erro e, se aceito, vira atribuição indevida.

**Resposta-padrão:** "Esse endereço é privado (faixa X): só tem significado dentro da rede local em que foi atribuído. Ele não é roteável na internet e não tem titular, provedor nem localização consultáveis. Sozinho, não identifica rede, local, dispositivo nem pessoa. Para avançar, é preciso saber de qual rede ele veio (equipamento, local, data e hora com fuso) e obter o IP público dessa rede no mesmo instante, ou os registros do equipamento que atribuiu o endereço."

### 6.1 Faixas e significado
Resumo: `10/8`, `172.16/12`, `192.168/16` privado (RFC 1918) · `fc00::/7` ULA · `100.64/10` **CGNAT** (RFC 6598) · `127/8`, `::1` loopback · `169.254/16`, `fe80::/10` link-local · `0.0.0.0` não especificado · `192.0.2/24`, `198.51.100/24`, `203.0.113/24`, `2001:db8::/32` documentação (em evidência real: exemplo, ofuscação ou erro) · `198.18/15` benchmarking · multicast/reservado/broadcast (dado inconsistente em campo de origem) · transição `::ffff:`, `64:ff9b::/96`, `2002::/16`, `2001::/32` (IPv4 embutido → registro derivado). **Tabela completa em `references/ip_nao_publico.md`.**

### 6.2 Onde o IP privado aparece e como ler
Use `--origem` no `normalizar` (`print-wifi`, `email`, `log-web`, `log-interno`, `camera-iot`, `dns`, `vpn`, `malware`, `bo`, `hotspot`, `firewall`, `outro`): o resultado traz a leitura e o próximo passo daquela origem. A tabela completa está em `references/ip_nao_publico.md`. Em cabeçalho de e-mail e em log atrás de proxy, o elo público vem de `cabecalho` (seção 4.5).

### 6.3 Procedimento
1. **Confirmar a faixa** com `normalizar` e **não** enviar o IP a RDAP, BGP, geolocalização, reputação ou varredura: a consulta não tem resultado válido e expõe a topologia interna (regra 14). No quadro de fontes, registre "não aplicável (IP não público)", não "não identificado".
2. **Explicar o significado** com a resposta-padrão e a faixa.
3. **Reconstituir o contexto de rede:** origem do dado, rede (residência, empresa, órgão, hotspot, VPN), data, hora com segundos e fuso, equipamento NAT/DHCP. Sem contexto, o IP privado não é indicador reutilizável.
4. **Buscar o elo público:** o IP público do gateway no mesmo instante. Com ele, siga o fluxo normal (seções 4 e 5).
5. **Dispositivo na rede local** — somente por quem opera a rede ou tem autorização legal: DHCP (MAC, hostname, data/hora), ARP/CAM, RADIUS/AD/portal Wi-Fi, logs do ponto de acesso, inventário. A retenção costuma ser curta ou inexistente: recomende **preservação imediata**.
6. **Correlação:** nunca vincular casos, eventos ou pessoas por IP privado isolado. `192.168.0.1`, `192.168.1.1`, `10.0.0.1` são padrão de milhares de roteadores. Registre o IP privado **com o escopo da rede** (ex.: `192.168.0.15` @ rede do escritório X); sem escopo, fica fora de `correlacionar`, clusters e pivôs. *"⚠️ Possível falso positivo de correlação."*
7. **Registrar:** faixa, contexto de rede conhecido/desconhecido, o que falta e quem detém o dado.

### 6.4 Cuidados
Somente passivo (nada de ping, varredura ou acesso a endereços privados de terceiros). Terminação `.1`/`.254` sugere o gateway (indício). IPv6 global de rede doméstica é **público**: analise o prefixo; ULA e link-local são o equivalente do privado. Não chame o IP de "falso" só porque é privado. Na triagem: ⚪ indeterminado, fora do score. Na plataforma: entidade `private_ip` com escopo de rede, nunca mesclada por endereço igual.

---

## 7. Classificações padronizadas

| Dimensão | Escala |
|---|---|
| Natureza da informação | FATO · INDÍCIO · CORRELAÇÃO · HIPÓTESE (§20) — no grafo: EVIDÊNCIA DIRETA · CORROBORADA · CORRELAÇÃO · INDÍCIO · HIPÓTESE (§46) |
| Confiança da informação | ALTA (registro oficial/fonte primária) · MÉDIA (múltiplas fontes independentes) · BAIXA (geolocalização, reputação, datasets sujeitos a erro) · NÃO CONFIRMADA (§21) |
| Confiabilidade da fonte | NÍVEL 1 primária (RIR/NIR, operador, lista oficial) · NÍVEL 2 técnica (BGP, DNS, CT) · NÍVEL 3 agregadores · NÍVEL 4 reputação comunitária (§103) |
| Tipo do IP | Residencial · Móvel · Corporativo · Datacenter · VPN · Proxy · Tor · CDN · **Privado/não público** · Outro — escala Não identificado · Possível · Provável · Confirmado (seção 5.2) |
| Anonimização | Nenhum indicador · Possível · Provável · Confirmada (§60) |
| Anomalia BGP | confirmado · provável · possível · não identificado (§7) |
| Relação investigativa | CONFIRMADA · FORTE · MODERADA · FRACA · NÃO CONFIRMADA (§31) |
| Peso da relação | 1.00 · 0.90 · 0.75 · 0.50 · 0.25 · 0.00 — força técnica, **não** probabilidade de autoria (§45) |
| Score de relevância | 0–20 baixa · 21–40 limitada · 41–60 atenção · 61–80 alta · 81–100 prioridade — prioridade técnica, **não** probabilidade de crime (§47) |
| Triagem | 🟢 baixa · 🟡 atenção · 🟠 relevante · 🔴 alto interesse · ⚪ indeterminado (§34) |
| Prazo de guarda | OK · ATENÇÃO (≤ 90 d) · URGENTE (≤ 30 d) · VENCIDO (presumível) |
| Alertas | 🔴 anonimização / infraestrutura maliciosa · 🟠 mudança relevante / cluster · 🟡 conflito / dados insuficientes · 🔵 outlier (§68) |

IPs não públicos entram na triagem como ⚪ e não contam para score nem clusters. Para cada descoberta importante, responda **"E daí?"** (§115).

---

## 8. Estrutura de saída

**Análise (IP_UNICO / MULTI_IP)** — §23: 1. Resumo executivo · 2. Identificação do IP · 3. Registro/RDAP · 4. BGP/ASN · 5. DNS · 6. Domínios (atuais × históricos) · 7. Geolocalização (comparação) · 8. VPN/Proxy/Tor · 9. Hosting/Cloud · 10. Reputação · 11. Serviços expostos · 12. Certificados · 13. Histórico · 14. Correlações · 15. Avaliação investigativa · 16. Conclusão.

**Complementos obrigatórios em análises investigativas** (o `validar` confere a presença):
- **Resumo executivo** curto, só com conclusões sustentadas (§69).
- **"O que pode e o que não pode ser atribuído"** (§61).
- **Matriz de evidências** — indicador · evidência · fonte · data · confiança · relevância (§62).
- **"O que sabemos" / "O que não sabemos"** (§95–96).
- **Dados necessários para atribuição** — tem/falta (§97–98; seção 5.5).
- **Grau de completude** (✓ analisado · △ parcial · ✗ indisponível), sem confundir percentual com certeza (§94).
- **Próximo melhor passo** — uma a três prioridades objetivas, sem medidas invasivas (§70, §116).
- **Limitações** e **Fontes** com URL e **data/hora da consulta** (§22). Informe também o **fuso** de todo horário citado e a data do fato.

**RELATORIO_FORENSE** (§35): 1. Identificação · 2. Infraestrutura · 3. Geolocalização e limitações · 4. DNS · 5. Anonimização (inclui CGNAT) · 6. Reputação · 7. Histórico · 8. Correlações · 9. Evidências e fontes · 10. Limitações · 11. Conclusão técnica. Casos complexos em **três camadas**: resumo executivo · análise técnica · evidências e correlações (§114).

**Relatório final de caso** (§169): 22 blocos, da identificação do caso às fontes. **Resumo visual** (§133, §170) e tela "O que falta para avançar?" (§146) quando úteis. Sinalize em cada resultado: fonte consultada ✓ · indisponível ✗ · informação antiga ⚠ · conflitante ⚠ · estimada ⚠ (§156). **Saída estruturada:** JSON do §39 só com informações obtidas.

**Bloco obrigatório em toda análise de IP concreto: "Classificação do IP e caminho investigativo"** — o `tipologia --md` o gera:

| Campo | Conteúdo |
|---|---|
| Tipo provável (confiança) | Tipo + Possível · Provável · Confirmado (e "na data da consulta" × "confirmação histórica") |
| Indícios que sustentam | ASN, RDAP, PTR, lista oficial, base comercial (fonte, força, data); para IP privado, a faixa e a RFC |
| Outros papéis possíveis | Ex.: VPN sobre datacenter; proxy sobre IP residencial |
| Anonimização | Nenhum indicador · Possível · Provável · Confirmada |
| Quem detém o dado | Provedor / operadora / organização / hospedagem / operador de VPN / CDN / **responsável pela rede local** |
| Caminho investigativo | Linha do item 5.3 |
| Viabilidade (orientativa) | Titular da conexão/conta e usuário |
| Dados para atribuição | Tem / falta (item 5.5) |
| Prazo de guarda | Vencimentos; preservação cautelar se próximo; DHCP/NAT locais: preservar já |
| Contexto de rede (privado/CGNAT) | Conhecido / desconhecido; IP público correspondente ou "não obtido" |
| Consulta externa | Realizada / **não realizada (IP não público)** |
| Limitações | CGNAT, data da consulta ≠ data do evento, classificação comercial é estimativa, fonte transcrita |

---

## 9. Base legal (resumo; fonte única em `references/base_legal.md`)

Conferir vigência e inteiro teor antes de citar. O **país do IP não define a lei aplicável**: o que importa é onde está o provedor, onde está a vítima e a autoridade, e qual instrumento de cooperação existe (MCI art. 11; `base_legal.md` §C). Use `--jurisdicao BR` (padrão) ou `--jurisdicao OUTRA`.

**Brasil** (Parte A de `base_legal.md`) — três regimes: **cadastrais** (autoridades com competência legal), **registros de conexão/acesso** (ordem judicial, com **preservação cautelar** prévia) e **conteúdo** (ordem judicial).

| Tema | Em uma linha |
|---|---|
| Marco Civil (Lei 12.965/2014) arts. 13 e 15 | Conexão guarda **1 ano**; aplicação guarda **6 meses**; preservação cautelar por autoridade policial/administrativa ou MP, com **60 dias** para o pedido judicial (art. 13, §§2º–4º) |
| MCI arts. 10 e 22 | Registros: ordem judicial (fundados indícios, justificativa, período). Cadastrais: autoridades competentes (art. 10, §3º; Decreto 8.771/2016, art. 11) |
| **Decreto 12.975/2026** (art. 15-A do Decreto 8.771/2016) | Guarda da **porta lógica de origem**; vigência **20/07/2026** (60 dias após a publicação). Para fatos anteriores, apoie-se na jurisprudência (STJ, REsp 1.784.156/SP; REsp 2.170.872/SP — **conferir inteiro teor**; o segundo teve data/redação não confirmadas) |
| Lei 12.850/2013, art. 15 | Dados cadastrais sem ordem judicial em organização criminosa |
| Convenção de Budapeste (Decreto 11.491/2023) · Lei 9.296/1996 · CPP 158-A–F | Preservação expedita e ponto de contato 24 h · interceptação telemática · cadeia de custódia |

**Exterior** (§B de `base_legal.md`):

| Tema | Em uma linha |
|---|---|
| Prazo de guarda do provedor | **Não presumir** o prazo do Marco Civil. Dependendo do país e do provedor pode ser curto, longo ou inexistente: a skill devolve "DESCONHECIDO" e pede `--retencao` se você souber |
| Preservação expedita | Primeira medida: Convenção de Budapeste (arts. 16, 29, 35 — rede 24/7); EUA: 18 U.S.C. § 2703(f) (90 d + 90 d); UE: ordens europeias de preservação (Reg. 2023/1543, fonte secundária). Use `prazos --regime` e `oficio --jurisdicao OUTRA` |
| Dados cadastrais/conexão | Dependem de cooperação internacional (MLAT/Budapeste), do processo legal local ou do canal de atendimento a autoridades do provedor; a skill não gera minuta cadastral para o exterior |
| Pontos não verificados | Art. 29 da Convenção (prazo de 60 dias), Reg. UE 2023/1543 e o Segundo Protocolo estão marcados "conferir" em `base_legal.md`: confirme na fonte oficial antes de citar |

**IP privado:** DHCP/NAT/proxy/autenticação pertencem a quem opera a rede local; preservação imediata.

---

## 10. Linguagem e erros comuns

| Pode-se afirmar (com base) | Não se pode afirmar só com o IP |
|---|---|
| O IP X estava anunciado pelo ASN Y (provedor Z) em D, conforme RDAP/BGP | "O titular do bloco praticou o fato" |
| O provedor informou que IP X e porta P, no horário H (fuso), foram atribuídos ao assinante A | "O assinante A é o autor" |
| As bases associam o IP à região R, com baixa confiança | "O autor estava em R" |
| O IP consta em lista de reputação L (indício de abuso) | "O dono do IP é criminoso" |
| Não foi encontrada relação nas fontes consultadas | "Não existe relação" |
| A base comercial (ex.: proxycheck.io) classifica o IP como VPN/proxy, em consulta feita em D, com confiança C | "O usuário usava VPN no momento do fato" / "O IP é anônimo" (a janela de observação pode não cobrir a data do fato; há falsos positivos em CGNAT, móvel e gateway corporativo) |
| O endereço pertence à faixa privada F (RFC 1918): só tem significado na rede local de origem | "O IP 192.168.x.x é do suspeito / está em tal cidade / pertence a tal provedor" |

Formato de conclusão: **Conclusão → Base → Limitação**.

**Erros comuns:** IP = pessoa · geolocalização = endereço · blacklist = autoria · titular do bloco = usuário · PTR/domínio = dono · infraestrutura de hoje para evento passado · **ignorar fuso (UTC × local)** · ignorar CGNAT · **usar porta de destino como porta de origem** · **tratar IPv4 embutido em NAT64/Teredo como cliente** · ligar domínio a IP em CDN/hospedagem compartilhada · tratar classificação comercial como fato · consultar ou geolocalizar IP privado · correlacionar casos por IP privado igual · confundir o IP lido no aparelho com o IP de internet · **confiar em `Received` abaixo da fronteira de confiança** · **aplicar o prazo de guarda brasileiro a provedor estrangeiro** · **tratar o país do IP como lei aplicável** · **tratar "não é VPN" na base comercial como prova de que não há VPN**.

---

## 11. Controle de qualidade (antes de entregar)

IP válido? · v4/v6? · público/privado/especial? · **data do fato com fuso e prazo de guarda calculado (jurisdição BR/OUTRA declarada; no exterior, prazo "desconhecido" tratado como tal)?** · **porta de origem identificada (e o papel confirmado)?** · ASN, prefixo, ISP e organização? · RDAP consultado? · BGP e **histórico na data do evento**? · PTR/DNS? · geolocalização comparada (≥ 2 bases)? · VPN/proxy/Tor (proxycheck.io consultado ou lacuna de cota declarada; `formato_reconhecido` conferido; ExoneraTor para data passada)? · cloud/datacenter? · reputação? · correlações, clusters, outliers e contradições? · **fontes preservadas (SHA-256) ou marcadas como transcritas?** · fontes e datas registradas? · limitações registradas? · **atribuição indevida evitada?** · tipo classificado com papéis múltiplos, caminho e dados de atribuição? · IP privado: nenhuma consulta externa, contexto registrado, elo público buscado, nenhuma correlação isolada? · próximos passos indicados? (§73) · **chave de API apenas no ambiente e ausente de arquivos/relatórios?** · **`validar` executado e sem achado bloqueante?**

**Princípio de ouro** (§120) — antes de concluir: O que eu sei? Como sei? Qual a fonte? Quando era válido? Qual a confiabilidade? O que significa — e o que **não** significa? Com o que se relaciona? Há explicação alternativa? Há evidência contrária? O que falta saber? Qual o próximo melhor pivô?

A skill funciona como **analista de infraestrutura de rede assistido por IA**: **coletar → normalizar → validar → correlacionar → visualizar → testar → explicar → preservar → concluir** — nunca **consultar IP → encontrar nome → declarar autoria** (§121).

---

## 12. Implementação da plataforma (§122–173)

Quando o usuário pedir para **construir a aplicação** ("IP Intelligence"), leia `references/plataforma_implementacao.md`. Pontos-chave: Python · Streamlit · SQLite (migrável) · NetworkX · PyVis/Cytoscape.js · Pandas · Plotly · Pydantic (§122); camadas INTERFACE → ORQUESTRADOR → COLETA → NORMALIZAÇÃO → MODELO DE DADOS → CORRELAÇÃO → GRAFO → ANÁLISE → RELATÓRIO em **módulos independentes**; as funções de `scripts/` são sementes (`normalizar` → `utils/normalization.py`; `consultar` → `collectors/` com um adaptador por fonte; `tipologia` → `analysis/typology.py`; `correlacionar` → `analysis/` e `graph/export.py`); modelo CASE · ENTITY · RELATIONSHIP · OBSERVATION · EVIDENCE · EVENT (§124–131); importação com **aprovação humana** (§148–150); exportação MD/HTML/PDF, JSON/CSV/XLSX, GraphML, `case_export.zip` (§151); auditoria, cache e rate limiting sem segredos (§152–158); classificação PUBLIC/INTERNAL/SENSITIVE/RESTRICTED e envio a modelos externos só com autorização (§161–168); a IA nunca salta de **IP → Pessoa** ou **IP → Crime** (§171). Construa de forma incremental, com testes e dados de documentação (`192.0.2.0/24`, `198.51.100.0/24`, `203.0.113.0/24`, `2001:db8::/32`).

---

## 13. Integração com outras skills

Esta skill entrega o **IP analisado**; outras skills seguem dali. Não refaça o trabalho delas — passe o indicador e o contexto mínimo.

| Quando | Skill | O que passar / receber |
|---|---|---|
| IP de site, loja falsa, e-mail com domínio, ou domínios que resolvem para o IP | `domain-intelligence` | IP + prefixo + tipo (CDN/cloud reduz a força IP → domínio); recebe hospedagem por componente e histórico |
| Registrar a prova (respostas brutas, hashes, custódia) | `evidence-provenance` | Pasta `respostas_brutas/` com SHA-256 e `auditoria.jsonl`; cada conclusão aponta para a fonte |
| Rede de IPs, ASNs, domínios e contas; caminhos e comunidades | `link-analysis` · `case-correlation` | Bundle de `correlacionar`; **IP privado sem escopo fica fora**; correlação por infraestrutura compartilhada é fraca (CDN/cloud) |
| Mesmo suspeito/conta em registros diferentes | `entity-resolution` | Nunca mesclar por IP (dinâmico, CGNAT, compartilhado) |
| Hipóteses, ACH, lacunas | `hypothesis-engine` | Conflitos e alternativas do `tipologia` como hipóteses concorrentes, com indícios a favor e contra |
| Linha do tempo e mapa | `timeline-geospatial` | Horários em UTC **com `fuso_status`**; geolocalização de IP é aproximada, não localização do usuário |
| IPs em logs de infostealer, credenciais, sessões sequestradas | `infostealer-credential-intelligence` | IP como indício de infraestrutura/vítima; sem atribuição |
| Prints, PDFs, e-mails, extratos com IPs | `document-intelligence` | Extraia o texto com proveniência; depois `normalizar` |
| Tor, dark web, atribuição de serviços ocultos | `darkweb-investigator` | Tipo Tor + ExoneraTor na data; o IP de saída não identifica o usuário |
| Pesquisa em fontes abertas sobre titular/empresa do bloco | `osint-intelligence` | Nome da organização do RDAP, com a ressalva de que o titular do bloco ≠ usuário |
| Gestão do caso e relatório | `investigative-notebook` | Bundle de `correlacionar`; relatório com o bloco obrigatório da seção 8 |

Se uma skill listada não estiver disponível na sessão, siga sem ela e declare a lacuna.
