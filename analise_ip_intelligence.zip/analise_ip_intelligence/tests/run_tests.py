#!/usr/bin/env python3
"""
Suíte de testes OFFLINE da skill analise_ip_intelligence (unittest, somente stdlib).

  python3 tests/run_tests.py            # tudo
  python3 tests/run_tests.py -v         # detalhado
  python3 tests/run_tests.py TestPrazos # uma classe

Nenhum teste acessa a rede: as consultas externas são substituídas por respostas simuladas (mock) que
imitam o formato real de RIPEstat, RDAP, PeeringDB, InternetDB, listas oficiais de cloud/CDN e Tor.
Por isso os testes provam a LÓGICA (parsing, decisão, alertas), não a disponibilidade nem o conteúdo atual
das fontes. Os IPs usados nos cenários de consulta são públicos "de teste" e as organizações são fictícias.
"""
import contextlib
import datetime as dt
import hashlib
import io
import json
import os
import socket
import subprocess
import sys
import tempfile
import unittest
import urllib.error
import warnings
from pathlib import Path
from unittest import mock

warnings.simplefilter("ignore", ResourceWarning)  # os scripts da skill abrem JSONs sem close(); irrelevante aqui

RAIZ = Path(__file__).resolve().parent.parent
SCRIPTS = RAIZ / "scripts"
CLI = str(SCRIPTS / "ipanalise.py")
sys.path.insert(0, str(SCRIPTS))

import ipa_cabecalho  # noqa: E402
import ipa_comum as C  # noqa: E402
import ipa_fontes  # noqa: E402
import ipa_oficio  # noqa: E402
import ipa_prazos  # noqa: E402
import ipa_tipologia  # noqa: E402
import ipa_validar  # noqa: E402
import ipanalise as I  # noqa: E402

try:
    import zoneinfo
    zoneinfo.ZoneInfo("America/Sao_Paulo")
    TEM_TZDATA = True
except Exception:  # noqa
    TEM_TZDATA = False


# ───────────────────────────── utilitários ─────────────────────────────

def cli(*args, cwd=None):
    """Executa o CLI como o analista faria (python -I) e devolve (código, stdout)."""
    p = subprocess.run([sys.executable, "-I", CLI, *map(str, args)], cwd=cwd, capture_output=True, text=True, timeout=120)
    return p.returncode, p.stdout + p.stderr


def jl(caminho):
    with open(caminho, encoding="utf-8") as f:
        return json.load(f)


class Tmp(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.dir = Path(self._td.name)

    def tearDown(self):
        self._td.cleanup()

    def escrever(self, nome, conteudo):
        p = self.dir / nome
        p.write_text(conteudo, encoding="utf-8")
        return str(p)

    def normalizar(self, texto, *extra):
        ent = self.escrever("entrada.txt", texto)
        saida = str(self.dir / "n.json")
        rc, out = cli("normalizar", ent, "--saida", saida, *extra)
        self.assertEqual(rc, 0, out)
        return jl(saida), out

    @staticmethod
    def achar(n, ip):
        return next(r for r in n["ips"] if r["ip"] == ip)


# ───────────────────────────── normalizar ─────────────────────────────

class TestNormalizar(Tmp):
    def test_privado_e_origem_muda_a_leitura(self):
        n, _ = self.normalizar("2026-03-14 21:45:10 login de 192.168.0.15\n", "--fuso", "America/Maceio", "--origem", "print-wifi")
        r = self.achar(n, "192.168.0.15")
        self.assertFalse(r["publico"])
        self.assertIn("RFC 1918", r["classificacao"])
        self.assertTrue(r.get("leitura_contexto"), "IP privado deve receber leitura de contexto")
        self.assertIn("print-wifi", json.dumps(n["contexto_origem"]))

    def test_cgnat_porta_sem_papel_alerta(self):
        n, _ = self.normalizar("100.64.5.5:51000 sem rotulo\n")
        r = self.achar(n, "100.64.5.5")
        self.assertIn("CGNAT", r["classificacao"])
        self.assertEqual(r["portas_origem"], [])  # papel indefinido → NÃO vira "porta de origem"
        self.assertTrue(any("semântica indeterminada" in a for a in r["alertas"]))

    def test_documentacao_nao_recebe_leitura_de_contexto(self):
        n, _ = self.normalizar("evento de 203.0.113.9\n")
        r = self.achar(n, "203.0.113.9")
        self.assertFalse(r["publico"])
        self.assertFalse(r.get("leitura_contexto"))

    def test_papeis_src_dst_e_portas_rotuladas(self):
        n, _ = self.normalizar("IN=eth0 SRC=198.51.100.7 DST=203.0.113.9 PROTO=TCP SPT=40422 DPT=443\n")
        o, d = self.achar(n, "198.51.100.7"), self.achar(n, "203.0.113.9")
        self.assertEqual(o["papeis"]["origem"], 1)
        self.assertEqual(d["papeis"]["destino"], 1)
        self.assertEqual(o["portas_origem"], [40422])
        self.assertEqual(d["portas_origem"], [])
        self.assertTrue(any("DESTINO" in a for a in d["alertas"]))

    def test_porta_de_servico_rotulada_como_origem_gera_aviso(self):
        n, _ = self.normalizar("2026-03-14 21:45:10 login ok client=198.51.100.8:443 server=203.0.113.9\n", "--fuso=-03:00")
        r = self.achar(n, "198.51.100.8")
        self.assertTrue(any("porta de serviço" in a for a in r["alertas"]))

    def test_porta_semantica_declarada_pelo_usuario(self):
        n, _ = self.normalizar("198.51.100.8:51111 acesso\n", "--porta-semantica", "origem")
        r = self.achar(n, "198.51.100.8")
        self.assertEqual(r["portas_origem"], [51111])

    def test_ipv4_embutido_teredo_6to4_nat64_mapped(self):
        n, _ = self.normalizar("2001:0:4136:e378:8000:63bf:3fff:fdd2\n2002:c000:0204::1\n64:ff9b::c000:0201\n::ffff:192.0.2.77\n")
        ter = self.achar(n, "2001:0:4136:e378:8000:63bf:3fff:fdd2")
        enderecos = {e["endereco"]: e for e in ter["ipv4_embutido"]}
        self.assertIn("192.0.2.45", enderecos)       # cliente Teredo (des-ofuscado)
        self.assertIn("65.54.227.120", enderecos)    # servidor Teredo
        self.assertFalse(enderecos["65.54.227.120"]["analisar"], "servidor Teredo não é o cliente investigado")
        self.assertEqual(self.achar(n, "2002:c000:204::1")["ipv4_embutido"][0]["endereco"], "192.0.2.4")
        nat = self.achar(n, "64:ff9b::c000:201")["ipv4_embutido"][0]
        self.assertEqual(nat["endereco"], "192.0.2.1")
        self.assertIn("DESTINO", nat["papel"])
        derivado = self.achar(n, "192.0.2.1")
        self.assertTrue(derivado["derivado_de"], "IPv4 embutido vira registro derivado")
        self.assertTrue(any("DERIVADO" in a for a in derivado["alertas"]))
        mapeado = self.achar(n, "192.0.2.77")
        self.assertIn("::ffff:192.0.2.77", mapeado["formas_originais"])

    def test_fuso_assumido_converte_para_utc_maceio(self):
        n, _ = self.normalizar("2026-03-14 21:45:10 login 198.51.100.9\n", "--fuso", "America/Maceio")
        t = self.achar(n, "198.51.100.9")["timestamps"][0]
        self.assertEqual(t["fuso_status"], "assumido_pelo_usuario")
        self.assertEqual(t["utc"], "2026-03-15T00:45:10Z")

    def test_sem_fuso_nao_inventa_utc(self):
        n, _ = self.normalizar("2026-03-14 21:45:10 login 198.51.100.9\n")
        t = self.achar(n, "198.51.100.9")["timestamps"][0]
        self.assertEqual(t["fuso_status"], "AUSENTE")
        self.assertIsNone(t["utc"])
        self.assertTrue(any("SEM FUSO" in a for a in t["alertas"]))
        self.assertEqual(n["qualidade_dados_atribuicao"]["sem_fuso_sem_utc"], 1)

    def test_fuso_explicito_no_proprio_log(self):
        n, _ = self.normalizar("24/Oct/2026:14:32:15 -0300 GET /x from 198.51.100.7\n")
        t = self.achar(n, "198.51.100.7")["timestamps"][0]
        self.assertEqual(t["fuso_status"], "explicito")
        self.assertEqual(t["utc"], "2026-10-24T17:32:15Z")

    @unittest.skipUnless(TEM_TZDATA, "sem tzdata no sistema")
    def test_horario_ambiguo_e_inexistente_no_fim_e_inicio_do_verao(self):
        n, _ = self.normalizar("2018-02-17 23:30:00 login 198.51.100.9\n", "--fuso", "America/Sao_Paulo")
        t = self.achar(n, "198.51.100.9")["timestamps"][0]
        self.assertTrue(any("AMBÍGUO" in a for a in t["alertas"]))
        n, _ = self.normalizar("2018-11-04 00:30:00 login 198.51.100.9\n", "--fuso", "America/Sao_Paulo")
        t = self.achar(n, "198.51.100.9")["timestamps"][0]
        self.assertTrue(any("INEXISTENTE" in a for a in t["alertas"]))

    def test_sergipe_usa_maceio_e_nao_sao_paulo(self):
        tz = C.resolver_fuso("America/Maceio")
        self.assertIsNotNone(tz)
        # a regra é NOMEAR o fuso (Sergipe → America/Maceio), não presumir Brasília
        self.assertEqual(C.interpretar_ts("2026-03-14 21:45:10", "iso", tz)["utc"], "2026-03-15T00:45:10Z")
        with self.assertRaises(ValueError):
            C.resolver_fuso("Brasil/Nada")


# ───────────────────────────── prazos ─────────────────────────────

class TestPrazos(Tmp):
    def test_evento_janeiro_hoje_outubro(self):
        saida = str(self.dir / "p.json")
        rc, out = cli("prazos", "2026-01-10 21:00", "--fuso=-03:00", "--hoje", "2026-10-24", "--saida", saida)
        self.assertEqual(rc, 0, out)
        p = jl(saida)
        self.assertEqual(p["evento_utc"], "2026-01-11T00:00:00Z")
        self.assertEqual(p["conexao"]["vence_em_utc"], "2027-01-11T00:00:00Z")
        self.assertEqual(p["conexao"]["dias_restantes"], 79)
        self.assertTrue(p["conexao"]["status"].startswith("ATENÇÃO"))
        self.assertEqual(p["aplicacao"]["vence_em_utc"], "2026-07-11T00:00:00Z")
        self.assertTrue(p["aplicacao"]["status"].startswith("VENCIDO"))
        self.assertIn("PRESERVAÇÃO", p["alerta_preservacao"])

    def test_exige_fuso(self):
        rc, out = cli("prazos", "2026-01-10 21:00", "--hoje", "2026-10-24")
        self.assertNotEqual(rc, 0)
        self.assertIn("fuso", out.lower())

    def test_meses_fim_de_mes(self):
        import datetime as dt
        self.assertEqual(ipa_prazos.somar_meses(dt.datetime(2026, 8, 31, tzinfo=dt.timezone.utc), 6).strftime("%Y-%m-%d"), "2027-02-28")

    def test_preservacao_60_dias(self):
        saida = str(self.dir / "p.json")
        rc, out = cli("prazos", "2026-01-10 21:00", "--fuso=-03:00", "--hoje", "2026-10-24", "--preservacao-em", "2026-10-01", "--saida", saida)
        self.assertEqual(rc, 0, out)
        self.assertIn("2026-11-30", out)  # 01/10 + 60 dias


# ───────────────────────────── consulta simulada + tipologia ─────────────────────────────

RES, AWS, CF, TOR, CONF, MOVEL, VPN = "200.100.50.10", "52.10.20.30", "104.16.5.5", "185.220.101.5", "177.10.20.30", "189.40.1.77", "45.9.10.20"
LISTAS_OFICIAIS = {
    "https://ip-ranges.amazonaws.com/ip-ranges.json": json.dumps({"prefixes": [{"ip_prefix": "52.10.20.0/24", "region": "us-west-2", "service": "EC2"}], "ipv6_prefixes": []}).encode(),
    "https://www.cloudflare.com/ips-v4": b"104.16.0.0/13\n",
    "https://check.torproject.org/torbulkexitlist": (TOR + "\n").encode(),
}


def kit(ip, asn, holder, pais="BR", cidade="Aracaju", ptr=None, peering=None, tags=None, portas=None, rdap_nome="NET"):
    """Respostas simuladas (formato real) das fontes para UM IP."""
    pref = ".".join(ip.split(".")[:3]) + ".0/24"
    d = {
        f"https://stat.ripe.net/data/prefix-overview/data.json?resource={ip}": {"data": {"resource": pref, "announced": True, "asns": [{"asn": asn, "holder": holder}], "block": {"desc": "RIR"}}},
        f"https://stat.ripe.net/data/maxmind-geo-lite/data.json?resource={ip}": {"data": {"located_resources": [{"locations": [{"country": pais, "city": cidade, "latitude": -10.9, "longitude": -37.0, "covered_percentage": 100}]}]}},
        f"https://rdap.org/ip/{ip}": {"objectClassName": "ip network", "handle": pref, "name": rdap_nome, "country": pais, "startAddress": pref.split("/")[0], "endAddress": ip,
                                      "entities": [{"handle": "E1", "roles": ["registrant"], "vcardArray": ["vcard", [["fn", {}, "text", holder]]]}],
                                      "events": [{"eventAction": "registration", "eventDate": "2005-01-01T00:00:00Z"}]},
        f"https://stat.ripe.net/data/reverse-dns-ip/data.json?resource={ip}": {"data": {"result": [ptr] if ptr else []}},
        f"https://ipinfo.io/{ip}/json": {"ip": ip, "country": pais, "city": cidade, "org": f"AS{asn} {holder}"},
        f"https://api.db-ip.com/v2/free/{ip}": {"countryCode": pais, "city": cidade},
        f"https://stat.ripe.net/data/as-overview/data.json?resource=AS{asn}": {"data": {"holder": holder, "announced": True}},
        f"https://www.peeringdb.com/api/net?asn={asn}": {"data": [{"name": holder, "info_type": peering, "info_types": [peering]}] if peering else []},
    }
    if tags is not None or portas is not None:
        d[f"https://internetdb.shodan.io/{ip}"] = {"ip": ip, "ports": portas or [], "tags": tags or [], "hostnames": [], "cpes": [], "vulns": []}
    return {k: json.dumps(v).encode() for k, v in d.items()}


class Cenario(Tmp):
    """Roda `consultar` em-processo com as funções de rede trocadas por mocks."""

    def consultar(self, ips, respostas, *extra, historico=None, dns_local=True, http=None, cache_hit=None):
        """http={url: (status, corpo_bytes)} simula erro/negação HTTP; cache_hit={url,...} simula resposta vinda do cache local."""
        self.urls = []
        corpos = dict(LISTAS_OFICIAIS)
        corpos.update(respostas)
        ptrs = {}
        for url, c in respostas.items():
            if "reverse-dns-ip" in url:
                ptrs[url.split("resource=")[1]] = (json.loads(c)["data"]["result"] or [None])[0]

        def fake_baixar(url, pasta, indicador=None, fonte=None):
            self.urls.append(url)
            reg = {"url": url, "consultado_em_utc": I.agora()}
            if http and url in http:
                st, corpo = http[url]
                reg.update(status=st, sha256_resposta=hashlib.sha256(corpo).hexdigest())
                if st >= 400:
                    reg["erro"] = f"HTTP {st}"
                return reg, corpo
            corpo = corpos.get(url)
            if corpo is None and historico and "routing-history" in url:
                corpo = json.dumps(historico).encode()
            if corpo is None:
                if "internetdb" in url:
                    reg.update(status=404, erro="HTTP 404")
                    return reg, b'{"detail":"No information available"}'
                reg.update(status=None, erro="URLError: sem rede (mock)")
                return reg, None
            reg.update(status=200, url_final=url, sha256_resposta=hashlib.sha256(corpo).hexdigest())
            if cache_hit and url in cache_hit:
                reg["cache"] = True
            if pasta:
                os.makedirs(pasta, exist_ok=True)
                nome = "mock_" + hashlib.sha1(url.encode()).hexdigest()[:10] + ".raw"
                with open(os.path.join(pasta, nome), "wb") as f:
                    f.write(corpo)
                reg["arquivo_bruto"] = nome
            return reg, corpo

        def fake_ptr(ip):
            if dns_local and ptrs.get(ip):
                return (ptrs[ip].rstrip("."), [], [ip])
            raise socket.herror("sem PTR (mock)")

        n = self.dir / "n_mock.json"
        n.write_text(json.dumps({"ips": [{"ip": ip, "publico": True} for ip in ips]}), encoding="utf-8")
        saida = self.dir / "c.json"
        originais = (I.baixar, socket.gethostbyaddr, I.time.sleep, sys.argv, I.em_cache)
        I.baixar, socket.gethostbyaddr, I.time.sleep = fake_baixar, fake_ptr, (lambda *_: None)
        I.em_cache = lambda u: bool(cache_hit and u in cache_hit)
        sys.argv = ["ipanalise", "consultar", str(n), "--saida", str(saida), "--brutos", str(self.dir / "brutos"), "--cache", "",
                    "--listas", "aws,cloudflare", *extra]
        try:
            with contextlib.redirect_stdout(io.StringIO()) as buf:
                try:
                    I.main()
                except SystemExit as e:
                    self.assertIn(e.code, (None, 0), buf.getvalue())
        finally:
            I.baixar, socket.gethostbyaddr, I.time.sleep, sys.argv, I.em_cache = originais
        return jl(saida)

    def tipologia(self, consulta, *extra, normalizado=None):
        c = self.dir / "c.json"
        c.write_text(json.dumps(consulta), encoding="utf-8")
        saida = str(self.dir / "t.json")
        args = ["tipologia", str(c), "--saida", saida, "--md", str(self.dir / "t.md"), *extra]
        if normalizado:
            args += ["--normalizado", normalizado]
        rc, out = cli(*args)
        self.assertEqual(rc, 0, out)
        t = jl(saida)
        return {i["ip"]: i for i in t["itens"]}, out

    @staticmethod
    def res(c, ip):
        return next(r for r in c["resultados"] if r["ip"] == ip)


class TestConsultaETipologia(Cenario):
    def test_residencial_br_ptr_dinamico_e_peeringdb_provavel(self):
        r = kit(RES, 64500, "Example Telecom S.A.", ptr="200-100-50-10.dynamic.example.com.br", peering="Cable/DSL/ISP")
        c = self.consultar([RES], r)
        self.assertIn("AS64500", self.res(c, RES)["asn"])
        t, _ = self.tipologia(c)
        self.assertEqual(t[RES]["tipo"], "Residencial")
        self.assertEqual(t[RES]["escala"], "Provável")  # nunca 'Confirmado' por heurística/base comercial
        faltam = {d["campo"] for d in t[RES]["dados_atribuicao"] if not d["tem"]}
        self.assertIn("Porta lógica de ORIGEM", faltam)  # sem a porta, CGNAT impede individualizar a conexão
        self.assertTrue(t[RES]["limitacoes"])

    def test_internetdb_404_nao_quebra_e_vira_ausencia(self):
        r = kit(RES, 64500, "Example Telecom S.A.", peering="Cable/DSL/ISP")  # sem InternetDB → 404
        c = self.consultar([RES], r)
        reg = self.res(c, RES)
        self.assertTrue(any("internetdb" in (f.get("url") or "") and f.get("status") == 404 for f in reg["fontes"]))
        self.assertFalse(any("internetdb" in l.lower() and "erro" in l.lower() for l in reg["lacunas"]))

    def test_ptr_fallback_ripestat_quando_dns_local_falha(self):
        r = kit(RES, 64500, "Example Telecom S.A.", ptr="200-100-50-10.dynamic.example.com.br", peering="Cable/DSL/ISP")
        c = self.consultar([RES], r, dns_local=False)  # DNS do sistema falha → usa RIPEstat
        self.assertIn("dynamic.example.com.br", json.dumps(self.res(c, RES)["ptr"]))
        self.assertIn("ripestat", json.dumps(self.res(c, RES).get("ptr_fonte", "")).lower())

    def test_aws_lista_oficial_datacenter_confirmado_na_data_da_consulta(self):
        c = self.consultar([AWS], kit(AWS, 16509, "AMAZON-02", pais="US", cidade="Boardman"))
        self.assertTrue(self.res(c, AWS)["cloud_match"])
        t, _ = self.tipologia(c)
        self.assertEqual(t[AWS]["tipo"], "Datacenter/nuvem")
        self.assertEqual(t[AWS]["escala"], "Confirmado")
        self.assertIn("consulta", (t[AWS]["qualificador"] or ""))

    def test_cdn_cloudflare_lista_oficial(self):
        c = self.consultar([CF], kit(CF, 13335, "CLOUDFLARENET", pais="US", cidade="San Francisco"))
        t, _ = self.tipologia(c)
        self.assertEqual(t[CF]["tipo"], "CDN")
        self.assertEqual(t[CF]["escala"], "Confirmado")

    def test_tor_atual_tem_confianca_limitada_e_exige_exonerator(self):
        c = self.consultar([TOR], kit(TOR, 64501, "HOSTX Hosting LLC", pais="DE", cidade="Frankfurt"), "--data-evento", "2026-03-14 21:45:10", "--fuso", "America/Maceio")
        reg = self.res(c, TOR)
        self.assertTrue(reg["tor_saida_atual"])
        self.assertIn("exonerator", json.dumps(reg["verificacao_manual"]).lower())
        t, _ = self.tipologia(c, "--data-evento", "2026-03-14 21:45:10", "--fuso", "America/Maceio")
        self.assertEqual(t[TOR]["tipo"], "Tor")
        self.assertNotEqual(t[TOR]["escala"], "Confirmado", "lista atual não confirma o estado na data do fato")
        self.assertIn("Provável", t[TOR]["anonimizacao"])

    def test_vpn_sobre_datacenter_mostra_os_dois_papeis(self):
        r = kit(VPN, 9009, "M247 Europe SRL", pais="RO", cidade="Bucharest", tags=["vpn"], portas=[1194, 51820])
        c = self.consultar([VPN], r)
        t, _ = self.tipologia(c)
        tipos = {t[VPN]["tipo"]} | {p["tipo"] for p in t[VPN]["papeis"]}
        self.assertIn("VPN", tipos)
        self.assertIn("Datacenter/nuvem", tipos)
        self.assertNotEqual(t[VPN]["anonimizacao"], "Nenhum indicador (nas fontes consultadas)")

    def test_conflito_residencial_x_datacenter_nao_e_escondido(self):
        r = kit(CONF, 64500, "Example Telecom S.A.", ptr="177-10-20-30.dynamic.example.com.br", peering="Cable/DSL/ISP", tags=["cloud"])
        c = self.consultar([CONF], r)
        t, _ = self.tipologia(c)
        item = t[CONF]
        texto = json.dumps(item, ensure_ascii=False)
        self.assertTrue(item["conflitos"] or item["alternativas"] or "Datacenter" in texto,
                        "sinais contraditórios devem aparecer como conflito/alternativa/papel")
        self.assertNotEqual(item["escala"], "Confirmado")

    def test_movel_cgnat_por_ptr_pede_porta_de_origem(self):
        r = kit(MOVEL, 64502, "Example Mobile S.A.", ptr="cgnat-4g-189-40-1-77.mobile.example.com.br", peering="Cable/DSL/ISP")
        c = self.consultar([MOVEL], r)
        t, _ = self.tipologia(c)
        texto = json.dumps(t[MOVEL], ensure_ascii=False)
        self.assertIn("CGNAT", texto)
        self.assertIn("Porta lógica de ORIGEM", texto)
        self.assertEqual(t[MOVEL]["tipo"], "Móvel")

    def test_divergencias_e_historico_de_roteamento(self):
        r = kit(RES, 64500, "Example Telecom S.A.", pais="BR", peering="Cable/DSL/ISP")
        r[f"https://ipinfo.io/{RES}/json"] = json.dumps({"ip": RES, "country": "US", "org": "AS64999 Outra Coisa"}).encode()
        hist = {"data": {"by_origin": [{"origin": "64999", "prefixes": [{"prefix": ".".join(RES.split(".")[:3]) + ".0/24",
                                                                         "timelines": [{"starttime": "2020-01-01T00:00:00", "endtime": "2026-04-01T00:00:00"}]}]}]}}
        c = self.consultar([RES], r, "--data-evento", "2026-03-14 21:45:10", "--fuso", "America/Maceio", historico=hist)
        reg = self.res(c, RES)
        campos = json.dumps(reg["divergencias"], ensure_ascii=False)
        self.assertIn("país", campos)
        self.assertIn("ASN", campos)
        self.assertIn("AS64999", json.dumps(reg["alertas_temporais"], ensure_ascii=False))  # ASN na data difere do atual
        t, _ = self.tipologia(c, "--data-evento", "2026-03-14 21:45:10", "--fuso", "America/Maceio")
        self.assertIn("ATUAIS", json.dumps(t[RES]["limitacoes"], ensure_ascii=False))

    def test_rdap_posterior_ao_evento_gera_alerta(self):
        r = kit(RES, 64500, "Example Telecom S.A.", peering="Cable/DSL/ISP")
        corpo = json.loads(r[f"https://rdap.org/ip/{RES}"])
        corpo["events"] = [{"eventAction": "registration", "eventDate": "2026-05-01T00:00:00Z"}]
        r[f"https://rdap.org/ip/{RES}"] = json.dumps(corpo).encode()
        c = self.consultar([RES], r, "--data-evento", "2026-03-14 21:45:10", "--fuso", "America/Maceio")
        self.assertIn("DEPOIS do evento", json.dumps(self.res(c, RES)["alertas_temporais"], ensure_ascii=False))

    def test_ip_nao_publico_nao_e_consultado_e_tipologia_explica(self):
        n, _ = self.normalizar("100.64.5.5:51000 acesso\n192.168.0.15 acesso\n", "--origem", "log-interno")
        # entrada de 'tipologia' sem consulta: usa só o normalizado
        vazio = self.dir / "vazio.json"
        vazio.write_text(json.dumps({"resultados": []}), encoding="utf-8")
        t, _ = self.tipologia(jl(vazio), normalizado=str(self.dir / "n.json"))
        self.assertIn("100.64.5.5", t)
        self.assertEqual(t["192.168.0.15"]["escala"], "Confirmado")
        self.assertIn("NÃO realizada", t["192.168.0.15"]["consulta_externa"])
        self.assertIn("CGNAT", json.dumps(t["100.64.5.5"], ensure_ascii=False))

    def test_perfil_basico_nao_chama_fontes_extras(self):
        r = kit(RES, 64500, "Example Telecom S.A.")
        c = self.consultar([RES], r, "--perfil", "basico")
        urls = " ".join(f.get("url", "") for f in self.res(c, RES)["fontes"])
        self.assertNotIn("peeringdb", urls)
        self.assertNotIn("internetdb", urls)


class TestEvidenciaPreservada(Cenario):
    def test_confirmacao_exonerator_com_sha256_vira_confirmado_historico(self):
        c = self.consultar([TOR], kit(TOR, 64501, "HOSTX Hosting LLC", pais="DE", cidade="Frankfurt"))
        self.res(c, TOR)["confirmacoes_manuais"] = [{"tipo": "Tor", "fonte": "ExoneraTor", "resultado": "positivo",
                                                      "data": "2026-03-14", "sha256": "ab" * 32}]
        t, _ = self.tipologia(c, "--data-evento", "2026-03-14 21:45:10", "--fuso", "America/Maceio")
        self.assertEqual(t[TOR]["tipo"], "Tor")
        self.assertEqual(t[TOR]["escala"], "Confirmado")
        self.assertIn("histórica", t[TOR]["qualificador"])

    def test_confirmacao_sem_sha256_nao_confirma(self):
        c = self.consultar([TOR], kit(TOR, 64501, "HOSTX Hosting LLC", pais="DE", cidade="Frankfurt"))
        self.res(c, TOR)["tor_saida_atual"] = False
        self.res(c, TOR)["confirmacoes_manuais"] = [{"tipo": "Tor", "fonte": "ExoneraTor", "resultado": "positivo", "data": "2026-03-14"}]
        t, _ = self.tipologia(c, "--data-evento", "2026-03-14 21:45:10", "--fuso", "America/Maceio")
        self.assertNotEqual(t[TOR]["escala"], "Confirmado")

    def test_fonte_transcrita_da_web_sem_sha256_rebaixa_e_declara(self):
        consulta = {"resultados": [{"ip": AWS, "publico": True, "asn": ["AS16509"],
                                    "cloud_match": [{"categoria": "Datacenter/nuvem", "provedor": "AWS", "prefixo": "52.10.20.0/24"}],
                                    "fontes": [{"fonte": "Lista oficial AWS", "origem_dado": "transcrito_web"}]}]}
        t, _ = self.tipologia(consulta)
        self.assertEqual(t[AWS]["tipo"], "Datacenter/nuvem")
        self.assertEqual(t[AWS]["escala"], "Provável")
        self.assertIn("TRANSCRITAS", json.dumps(t[AWS]["limitacoes"], ensure_ascii=False))


# ───────────────────────────── cabeçalho ─────────────────────────────

HDR = """Received: by 2002:a05:6a00:1234:b0:123:456 with SMTP id x1csp123456xyz;
        Sat, 14 Mar 2026 21:46:00 -0300 (-03)
Received: from mail-lf1-f41.google.com (mail-lf1-f41.google.com. [9.9.9.9])
        by mx.google.com with ESMTPS id abc123
        for <vitima@example.org>; Sat, 14 Mar 2026 21:45:59 -0300 (-03)
Received: from [192.168.0.15] (unknown [8.8.4.4])
        by mail-lf1-f41.google.com with ESMTPSA id def456;
        Sat, 14 Mar 2026 21:45:58 -0300 (-03)
Received: from evil.example.net (evil.example.net [8.8.8.8])
        by smtp.fake.example with SMTP id zzz;
        Sat, 14 Mar 2026 21:45:50 -0300 (-03)
X-Originating-IP: [8.8.4.4]
Authentication-Results: mx.google.com; spf=pass smtp.mailfrom=a@b.example; dkim=pass; dmarc=fail
From: "Fulano" <a@alfa.example>
Reply-To: x@beta.example
Return-Path: <a@alfa.example>
Subject: teste

corpo
"""


class TestCabecalho(Tmp):
    def test_fronteira_de_confianca_google(self):
        e = ipa_cabecalho.analisar_cabecalho(HDR, ["google.com"])
        self.assertEqual(e["hops_confiaveis"], 3)
        self.assertEqual(e["ip_candidato"]["ip"], "8.8.4.4")
        self.assertEqual(e["ip_candidato"]["hop"], 3)
        self.assertFalse(e["hops"][3]["confiavel"])
        self.assertEqual(e["ips_em_linhas_nao_verificadas"][0]["ips"], ["8.8.8.8"])  # indício, não observação
        self.assertTrue(e["divergencia_de_dominios"])

    def test_sem_confiaveis_so_o_topo_vale(self):
        e = ipa_cabecalho.analisar_cabecalho(HDR, [])
        self.assertLessEqual(e["hops_confiaveis"], 1)
        self.assertIsNone(e["ip_candidato"])  # topo sem IP público → nada a afirmar
        self.assertTrue(e["nota_fronteira"])

    def test_ip_privado_na_fronteira_vira_nota(self):
        cab = "Received: from [192.168.0.15] (unknown [192.168.0.15])\n    by mx.meuprovedor.example with ESMTP; Sat, 14 Mar 2026 21:45:58 -0300\nSubject: x\n\n"
        e = ipa_cabecalho.analisar_cabecalho(cab, [])
        self.assertIsNone(e["ip_candidato"])
        self.assertIn("não identifica", e["nota_fronteira"])

    def test_xff_rightmost_n(self):
        x = ipa_cabecalho.analisar_xff("1.2.3.4, 8.8.4.4, 10.0.0.1", 2)
        self.assertEqual(x["cliente_provavel"]["entrada"], "8.8.4.4")
        self.assertEqual(x["nao_confiaveis_a_esquerda"], ["1.2.3.4"])  # enviado pelo cliente: forjável
        x = ipa_cabecalho.analisar_xff("8.8.4.4", 3)
        self.assertTrue(x["aviso"])

    def test_cli_cabecalho(self):
        arq = self.escrever("h.txt", HDR)
        rc, out = cli("cabecalho", arq, "--confiaveis", "google.com", "--saida", str(self.dir / "h.json"))
        self.assertEqual(rc, 0, out)
        self.assertIn("**8.8.4.4**", out)


# ───────────────────────────── validar ─────────────────────────────

RUIM = """# Relatório
Resumo executivo: o suspeito utilizou o IP 8.8.8.8 em 14/03/2026 21:45:58.
O IP 192.168.0.15 pertence à operadora X e o titular (RDAP) é Fulano.
A geolocalização comprova que o autor estava em Aracaju.
O IP consta na AbuseIPDB, o que prova a autoria do crime.
Não existe relação com outros casos.
Tipo do IP: Confirmado (base comercial).
Não se pode afirmar que o suspeito utilizou o IP.
"""

BOM = """# Relatório de análise de IP
## Resumo executivo
O IP 8.8.8.8 foi atribuído em 14/03/2026 21:45:58 (UTC-03:00, America/Maceio), segundo o provedor, à conexão A.
## Classificação do IP e caminho investigativo
Tipo provável: Residencial (Provável).
## O que pode e o que não pode ser atribuído
Não se pode afirmar que o suspeito utilizou o IP; o IP não identifica pessoa.
## Matriz de evidências
RDAP consultado em 2026-10-24.
## O que sabemos / não sabemos
O que sabemos: titular do bloco. O que não sabemos: usuário.
## Dados necessários para atribuição
Porta de origem, protocolo.
## Próximo melhor passo
Ofício de preservação.
## Limitações
Dados atuais, não os do fato. Não foi encontrada relação nas fontes consultadas.
## Fontes
RDAP (consulta em 2026-10-24).
"""


class TestValidar(Tmp):
    def ids(self, texto, perfil="analise"):
        a, aus = ipa_validar.validar_texto(texto, perfil)
        return {x["id"] for x in a}, aus

    def test_detecta_frases_proibidas(self):
        ids, _ = self.ids(RUIM)
        self.assertTrue({"P01", "P03", "P07", "P10", "P20", "P21", "P08"} <= ids, ids)

    def test_negacao_nao_dispara(self):
        ids, _ = self.ids("Não se pode afirmar que o suspeito utilizou o IP.\nÉ vedado escrever que o IP prova a autoria.\n")
        self.assertFalse({"P01", "P03"} & ids, ids)

    def test_certeza_absoluta_e_p09(self):
        ids, _ = self.ids("Sem qualquer dúvida o tráfego veio dali.\n")
        self.assertIn("P09", ids)

    def test_bom_relatorio_passa(self):
        a, aus = ipa_validar.validar_texto(BOM, "analise")
        self.assertEqual([x for x in a if x["gravidade"] == "bloqueante"], [])
        self.assertEqual(aus, [])
        self.assertNotIn("P22", {x["id"] for x in a})

    def test_horario_sem_fuso_e_sem_data_de_consulta(self):
        ids, _ = self.ids("Evento às 21:45:58 no IP 8.8.8.8.\n")
        self.assertIn("P22", ids)
        self.assertIn("P23", ids)

    def test_marcador_ignorar(self):
        ids, _ = self.ids("<!-- validar:ignorar -->\nO suspeito utilizou o IP (citação literal da denúncia).\n")
        self.assertNotIn("P01", ids)

    def test_blocos_ausentes_por_perfil(self):
        _, aus = self.ids("# Nada\n", "rapido")
        self.assertIn("Limitações", aus)
        self.assertTrue(len(aus) >= 3)

    def test_codigo_de_saida_do_cli(self):
        ruim = self.escrever("ruim.md", RUIM)
        bom = self.escrever("bom.md", BOM)
        rc, _ = cli("validar", ruim)
        self.assertEqual(rc, 1)
        rc, out = cli("validar", bom)
        self.assertEqual(rc, 0, out)


# ───────────────────────────── ofício ─────────────────────────────

class TestOficio(Cenario):
    def _consulta(self):
        c = self.consultar([RES], kit(RES, 64500, "Example Telecom S.A.", peering="Cable/DSL/ISP", ptr="200-100-50-10.dynamic.example.com.br"))
        p = self.dir / "c_of.json"
        p.write_text(json.dumps(c), encoding="utf-8")
        return str(p)

    def oficio(self, *args):
        saida = str(self.dir / "of.md")
        rc, out = cli("oficio", "--saida", saida, *args)
        texto = Path(saida).read_text(encoding="utf-8") if os.path.exists(saida) else ""
        return rc, out, texto

    def test_recusa_ip_nao_publico(self):
        rc, out, _ = self.oficio("--tipo", "preservacao", "--ip", "192.168.0.15", "--data-hora", "2026-03-14 21:45:58", "--fuso", "America/Maceio")
        self.assertEqual(rc, 2, out)

    def test_preservacao_lista_pendencias_e_nao_inventa_dados(self):
        rc, out, md = self.oficio("--tipo", "preservacao", "--ip", RES, "--data-hora", "2026-03-14 21:45:58", "--fuso", "America/Maceio",
                                  "--consulta", self._consulta())
        self.assertEqual(rc, 0, out)
        self.assertIn("[PREENCHER", md)
        self.assertIn("12.965", md)
        self.assertIn("pendência", (md + out).lower())
        self.assertIn("2026-03-15", md + out)  # UTC do evento

    def test_sem_fuso_nao_calcula_utc(self):
        rc, out, md = self.oficio("--tipo", "preservacao", "--ip", RES, "--data-hora", "2026-03-14 21:45:58")
        self.assertIn("fuso", (md + out).lower())

    def test_cadastral_e_representacao(self):
        for tipo in ("cadastral", "representacao"):
            rc, out, md = self.oficio("--tipo", tipo, "--ip", RES, "--data-hora", "2026-03-14 21:45:58", "--fuso", "America/Maceio",
                                      "--porta", "40422", "--protocolo", "TCP", "--procedimento", "IP 123/2026", "--autoridade", "Delegado X")
            self.assertEqual(rc, 0, out)
            self.assertIn("40422", md)
            self.assertIn("IP 123/2026", md)

    def test_alertas_tor_cdn_cloud(self):
        for ip, kitr in ((TOR, kit(TOR, 64501, "HOSTX", pais="DE")), (CF, kit(CF, 13335, "CLOUDFLARENET", pais="US")), (AWS, kit(AWS, 16509, "AMAZON-02", pais="US"))):
            c = self.consultar([ip], kitr)
            p = self.dir / f"c_{ip}.json"
            p.write_text(json.dumps(c), encoding="utf-8")
            rc, out, md = self.oficio("--tipo", "preservacao", "--ip", ip, "--data-hora", "2026-03-14 21:45:58", "--fuso", "America/Maceio", "--consulta", str(p))
            self.assertEqual(rc, 0, out)
            self.assertTrue(any(w in (md + out) for w in ("Tor", "CDN", "nuvem", "hospedagem", "Cloudflare")), (ip, out))

    def test_marco_legal_art_15a(self):
        # antes da vigência do Decreto 12.975/2026 (20/07/2026) a minuta não pode afirmar o art. 15-A como vigente
        self.assertEqual(ipa_oficio.VIGENCIA_DEC_12975.strftime("%Y-%m-%d"), "2026-07-20")


# ───────────────────────────── integração leve ─────────────────────────────

class TestIntegracao(Tmp):
    def test_ajuda_lista_todos_os_subcomandos(self):
        rc, out = cli("--help")
        self.assertEqual(rc, 0)
        for sc in ("normalizar", "consultar", "tipologia", "correlacionar", "prazos", "cabecalho", "oficio", "validar"):
            self.assertIn(sc, out)

    def test_modo_isolado_funciona_com_python_I(self):
        rc, out = cli("prazos", "2026-01-10 21:00", "--fuso=-03:00", "--hoje", "2026-10-24")
        self.assertEqual(rc, 0, out)

    def test_regras_e_pacotes_de_operadoras_sao_json_validos(self):
        regras = jl(RAIZ / "references" / "regras_tipologia.json")
        for k in ("proxycheck_vpn", "proxycheck_proxy", "proxycheck_proxy_residencial", "proxycheck_tor", "proxycheck_hosting",
                  "operadora_conhecida", "operadora_conhecida_especifico"):
            self.assertIn(k, regras["forcas"])
        self.assertNotIn("operadora_br", regras["forcas"], "a força não pode mais ter nome de país")
        pacotes = sorted((RAIZ / "references" / "operadoras").glob("*.json"))
        self.assertTrue(any(p.name == "BR.json" for p in pacotes) and any(p.name == "_modelo.json" for p in pacotes))
        for p in pacotes:
            self.assertTrue(all(o["verificado"] is False for o in jl(p)["operadoras"]), f"{p.name}: pacote deve nascer não verificado")

# ───────────────────────────── proxycheck.io ─────────────────────────────

SEGREDO = "SEGREDO-TESTE-123"


def pc_v3(ip, status="ok", tipo="Hosting", asn="AS9009", vpn=False, proxy=False, tor=False, hosting=False, compromised=False,
          scraper=False, risco=40, confianca=80, pais="RO", extra=None):
    """Resposta v3 SINTÉTICA montada com os nomes de campo da documentação do proxycheck.io (network/location/detections/…).
    A documentação não traz um exemplo completo de resposta: estes testes provam o parser e a decisão, não o formato ao vivo."""
    obj = {"network": {"asn": asn, "range": ".".join(ip.split(".")[:3]) + ".0/24", "hostname": None, "provider": "Example Hosting",
                       "organisation": "Example Hosting", "type": tipo},
           "location": {"country_code": pais},
           "detections": {"proxy": proxy, "vpn": vpn, "tor": tor, "scraper": scraper, "hosting": hosting, "compromised": compromised,
                          "anonymous": bool(vpn or proxy or tor), "risk": risco, "confidence": confianca,
                          "first_seen": "2026-10-01T00:00:00Z", "last_seen": "2026-10-23T00:00:00Z"},
           "operator": None, "last_updated": "2026-10-24T00:00:00Z", **(extra or {})}
    return {"status": status, ip: obj}


def pc_url(ip, qs=""):
    return f"https://proxycheck.io/v3/{ip}{qs}"


def pc_resp(ip, **kw):
    return {pc_url(ip): json.dumps(pc_v3(ip, **kw)).encode()}


class TestProxycheck(Cenario):
    def test_vpn_detectado_entra_como_evidencia_e_nunca_confirma(self):
        r = kit(VPN, 9009, "Example Hosting", pais="RO", cidade="Bucuresti")
        r.update(pc_resp(VPN, vpn=True, hosting=True, tipo="Hosting"))
        c = self.consultar([VPN], r)
        pc = self.res(c, VPN)["proxycheck"]
        self.assertTrue(pc["consultado"] and pc["formato_reconhecido"])
        self.assertTrue(pc["deteccoes"]["vpn"])
        self.assertEqual(pc["risco"], 40)
        fonte = next(f for f in self.res(c, VPN)["fontes"] if f["fonte"] == "proxycheck.io")
        self.assertTrue(fonte.get("sha256_resposta"), "resposta bruta do proxycheck deve ter SHA-256")
        t, _ = self.tipologia(c)
        self.assertTrue(any(e["fonte"] == "proxycheck.io" and e["tipo"] == "VPN" for e in t[VPN]["evidencias_todas"]))
        vpn_escala = ([t[VPN]["escala"]] if t[VPN]["tipo"] == "VPN" else []) + [p["escala"] for p in t[VPN]["papeis"] if p["tipo"] == "VPN"]
        self.assertTrue(vpn_escala, "VPN deve aparecer como tipo ou como papel")
        self.assertNotIn("Confirmado", vpn_escala, "base comercial NUNCA confirma VPN")
        self.assertFalse(t[VPN]["anonimizacao"].startswith("Nenhum"))

    def test_residencial_com_proxy_registra_hipotese_de_proxy_antes_do_assinante(self):
        r = kit(RES, 64500, "Example Telecom S.A.", peering="Cable/DSL/ISP", ptr="200-100-50-10.dynamic.example.com.br")
        r.update(pc_resp(RES, tipo="Residential", proxy=True, confianca=90, pais="BR"))
        c = self.consultar([RES], r)
        t, _ = self.tipologia(c)
        self.assertEqual(t[RES]["tipo"], "Residencial")
        self.assertTrue(t[RES]["anonimizacao"].startswith(("Possível", "Provável")), t[RES]["anonimizacao"])
        self.assertIn("Proxy residencial", t[RES]["anonimizacao"])
        self.assertTrue(any("hipótese de proxy" in x for x in t[RES]["limitacoes"]))

    def test_confianca_baixa_reduz_o_peso(self):
        r = kit(VPN, 9009, "Example Hosting", pais="RO")
        r.update(pc_resp(VPN, vpn=True, confianca=20))
        t, _ = self.tipologia(self.consultar([VPN], r))
        forcas = [e["forca"] for e in t[VPN]["evidencias_todas"] if e["fonte"] == "proxycheck.io" and e["tipo"] == "VPN"]
        self.assertEqual(forcas, [0.35])  # 0,50 × 0,7

    def test_formato_desconhecido_vira_lacuna_e_nao_infere(self):
        for corpo in ({"status": "ok", "algo": 1}, {"status": "ok", VPN: {"campo_novo": True}}):
            r = kit(VPN, 9009, "Example Hosting", pais="RO")
            r[pc_url(VPN)] = json.dumps(corpo).encode()
            c = self.consultar([VPN], r)
            reg = self.res(c, VPN)
            self.assertFalse(reg["proxycheck"]["formato_reconhecido"])
            self.assertTrue(any("NÃO reconhecido" in l for l in reg["lacunas"]), reg["lacunas"])
            t, _ = self.tipologia(c)
            self.assertFalse(any(e["fonte"] == "proxycheck.io" for e in t[VPN]["evidencias_todas"]))

    def test_cota_esgotada_declara_lacuna_e_nao_insiste(self):
        ips = [RES, MOVEL]
        r = {}
        for ip in ips:
            r.update(kit(ip, 64500, "Example Telecom S.A.", peering="Cable/DSL/ISP"))
        negado = json.dumps({"status": "denied", "message": "You have exhausted your 100 free queries for today."}).encode()
        c = self.consultar(ips, r, http={pc_url(RES): (429, negado)})
        a, b = self.res(c, RES), self.res(c, MOVEL)
        self.assertTrue(any("negou" in l for l in a["lacunas"]), a["lacunas"])
        self.assertFalse(a["proxycheck"].get("formato_reconhecido"))
        self.assertFalse(b["proxycheck"]["consultado"])
        self.assertIn(pc_url(RES), self.urls)
        self.assertNotIn(pc_url(MOVEL), self.urls, "depois de 'cota esgotada' não se insiste")

    def test_limite_local_e_contador_persistente_entre_execucoes(self):
        ips = [RES, MOVEL]
        r = {}
        for ip in ips:
            r.update(kit(ip, 64500, "Example Telecom S.A.", peering="Cable/DSL/ISP"))
            r.update(pc_resp(ip, tipo="Residential"))
        cache = str(self.dir / "cache")
        c = self.consultar(ips, r, "--cache", cache, "--proxycheck-limite", "1")
        self.assertTrue(self.res(c, RES)["proxycheck"]["consultado"])
        self.assertFalse(self.res(c, MOVEL)["proxycheck"]["consultado"])
        self.assertTrue(any("cota diária local" in l for l in self.res(c, MOVEL)["lacunas"]))
        self.assertEqual(c["parametros"]["proxycheck"]["usadas_hoje_utc"], 1)
        cota = jl(Path(cache) / "proxycheck_cota.json")
        self.assertEqual(cota["usadas"]["sem_chave"], 1)
        # 2ª execução no mesmo dia: o contador foi lido do disco → nada novo é consultado
        c2 = self.consultar([RES], r, "--cache", cache, "--proxycheck-limite", "1")
        self.assertFalse(self.res(c2, RES)["proxycheck"]["consultado"])
        self.assertNotIn(pc_url(RES), self.urls)
        # --proxycheck-ignorar-cota libera
        c3 = self.consultar([RES], r, "--cache", cache, "--proxycheck-limite", "1", "--proxycheck-ignorar-cota")
        self.assertTrue(self.res(c3, RES)["proxycheck"]["consultado"])

    def test_resposta_do_cache_nao_gasta_cota(self):
        ips = [RES, MOVEL]
        r = {}
        for ip in ips:
            r.update(kit(ip, 64500, "Example Telecom S.A.", peering="Cable/DSL/ISP"))
            r.update(pc_resp(ip, tipo="Residential"))
        c = self.consultar(ips, r, "--proxycheck-limite", "1", cache_hit={pc_url(RES), pc_url(MOVEL)})
        self.assertTrue(self.res(c, RES)["proxycheck"]["consultado"] and self.res(c, MOVEL)["proxycheck"]["consultado"])
        self.assertEqual(c["parametros"]["proxycheck"]["usadas_hoje_utc"], 0)

    def test_chave_so_por_ambiente_e_nunca_aparece_nos_arquivos(self):
        r = kit(VPN, 9009, "Example Hosting", pais="RO")
        r[pc_url(VPN, f"?key={SEGREDO}")] = json.dumps(pc_v3(VPN, vpn=True)).encode()
        with mock.patch.dict(os.environ, {"PROXYCHECK_KEY": SEGREDO}):
            c = self.consultar([VPN], r)
        self.assertIn(pc_url(VPN, f"?key={SEGREDO}"), self.urls, "a requisição real leva a chave")
        self.assertEqual(c["parametros"]["proxycheck"]["com_chave"], True)
        self.assertEqual(c["parametros"]["proxycheck"]["limite_local"], 1000)
        for p in self.dir.rglob("*"):
            if p.is_file():
                self.assertNotIn(SEGREDO.encode(), p.read_bytes(), f"chave vazou em {p.name}")

    def test_baixar_real_redige_chave_em_registro_cache_auditoria_e_arquivo_bruto(self):
        corpo = json.dumps(pc_v3("8.8.4.4")).encode()

        class Resp(io.BytesIO):
            status = 200
            def geturl(self_):  # noqa: N805
                return "https://proxycheck.io/v3/8.8.4.4?key=" + SEGREDO
            def __enter__(self_):  # noqa: N805
                return self_
            def __exit__(self_, *a):  # noqa: N805
                return False
        cfg0 = dict(I.CFG)
        cache, brutos = self.dir / "c", self.dir / "b"
        cache.mkdir(), brutos.mkdir()
        try:
            I.CFG.update(cache=str(cache), ttl_h=24.0, atualizar=False, auditoria=str(brutos / "auditoria.jsonl"), tentativas=1, timeout=5)
            url = "https://proxycheck.io/v3/8.8.4.4?key=" + SEGREDO
            with mock.patch.object(I.urllib.request, "urlopen", side_effect=lambda *a, **k: Resp(corpo)) as uo:
                reg, c1 = I.baixar(url, str(brutos), "8.8.4.4", "proxycheck.io")
                self.assertEqual(uo.call_args[0][0].full_url, url, "a requisição real usa a chave")
                self.assertIn("key=***", reg["url"])
                self.assertNotIn(SEGREDO, json.dumps(reg))
                self.assertTrue(I.em_cache(url))
                reg2, _ = I.baixar(url, str(brutos), "8.8.4.4", "proxycheck.io")
                self.assertTrue(reg2.get("cache"))
                self.assertEqual(uo.call_count, 1, "2ª chamada vem do cache local")
            for p in list(cache.rglob("*")) + list(brutos.rglob("*")):
                if p.is_file():
                    self.assertNotIn(SEGREDO.encode(), p.read_bytes(), f"chave vazou em {p.name}")
                self.assertNotIn(SEGREDO, p.name)
            # negação/limite (HTTP 429) é transitória: não pode ficar 24 h no cache
            url2 = "https://proxycheck.io/v3/1.1.1.1?key=" + SEGREDO
            err = urllib.error.HTTPError(url2, 429, "Too Many Requests", {}, io.BytesIO(b'{"status":"denied","message":"limit"}'))
            with mock.patch.object(I.urllib.request, "urlopen", side_effect=err):
                reg3, c3 = I.baixar(url2, str(brutos), "1.1.1.1", "proxycheck.io")
            self.assertEqual(reg3["status"], 429)
            self.assertIn(b"denied", c3)
            self.assertFalse(I.em_cache(url2), "resposta 429 não deve ser cacheada")
        finally:
            I.CFG.clear(), I.CFG.update(cfg0)

    def test_ip_nao_publico_nunca_chega_ao_proxycheck(self):
        r, ctx = {"ip": "192.168.0.15", "fontes": [], "lacunas": []}, {}
        ctx["proxycheck"] = ipa_fontes.preparar_proxycheck(True)
        ctx["baixar"] = lambda *a, **k: self.fail("IP privado não pode ser enviado a serviço externo")
        ipa_fontes.consultar_proxycheck("192.168.0.15", r, ctx)
        self.assertFalse(r["proxycheck"]["consultado"])

    def test_divergencia_com_a_lista_oficial_de_tor_e_declarada(self):
        r = kit(TOR, 64501, "HOSTX", pais="DE")
        r.update(pc_resp(TOR, tor=False, tipo="Hosting", pais="DE"))
        c = self.consultar([TOR], r)
        div = [d for d in self.res(c, TOR)["divergencias"] if d["campo"] == "Tor"]
        self.assertTrue(div, "lista oficial diz Tor e o proxycheck diz que não: divergência deve ser declarada")
        self.assertIn("fonte primária", div[0]["leitura"])
        t, _ = self.tipologia(c)
        self.assertEqual(t[TOR]["tipo"], "Tor")  # a lista oficial prevalece sobre a base comercial

    def test_basico_nao_consulta_a_menos_que_pedido(self):
        r = kit(RES, 64500, "Example Telecom S.A.")
        r.update(pc_resp(RES))
        self.consultar([RES], r, "--perfil", "basico")
        self.assertNotIn(pc_url(RES), self.urls)
        self.consultar([RES], r, "--perfil", "basico", "--proxycheck")
        self.assertIn(pc_url(RES), self.urls)
        self.consultar([RES], r, "--sem-proxycheck")
        self.assertNotIn(pc_url(RES), self.urls)

    def test_parse_v2_legado_e_montagem_de_url(self):
        v2 = {"status": "ok", "1.2.3.4": {"proxy": "yes", "type": "VPN", "risk": 73, "provider": "X", "asn": "AS1", "isocode": "NL",
                                          "last seen human": "2 hours ago"}}
        p = ipa_fontes.parse_proxycheck(v2, "1.2.3.4", "v2")
        self.assertTrue(p["formato_reconhecido"] and p["deteccoes"]["vpn"] and not p["deteccoes"]["proxy"])
        self.assertEqual((p["risco"], p["pais_iso"]), (73, "NL"))
        nao = ipa_fontes.parse_proxycheck({"status": "ok", "1.2.3.4": {"proxy": "no", "type": "Residential"}}, "1.2.3.4", "v2")
        self.assertFalse(any(nao["deteccoes"].values()))
        self.assertEqual(nao["rede"]["tipo"], "Residential")
        pc = ipa_fontes.preparar_proxycheck(True, versao="v2", dias=60, chave="a b&c")
        u = ipa_fontes.url_proxycheck(pc, "1.2.3.4")
        self.assertTrue(u.startswith("https://proxycheck.io/v2/1.2.3.4?vpn=3&asn=1"))
        self.assertIn("days=60", u)
        self.assertIn("key=a%20b%26c", u, "a chave é codificada na URL")
        self.assertEqual(ipa_fontes.url_proxycheck(ipa_fontes.preparar_proxycheck(True), "2001:db8::1"), "https://proxycheck.io/v3/2001:db8::1")

    def test_ipv6_em_notacao_diferente_ainda_e_encontrado(self):
        j = {"status": "ok", "2001:db8:0:0:0:0:0:1": pc_v3("1.1.1.1")["1.1.1.1"]}
        self.assertTrue(ipa_fontes.parse_proxycheck(j, "2001:db8::1")["formato_reconhecido"])


# ───────────────────────────── generalização (qualquer ISP / país) ─────────────────────────────

class TestGeneralizacao(Cenario):
    def test_pacotes_regionais_somam_e_o_modelo_e_ignorado(self):
        oper = ipa_tipologia.carregar_operadoras()
        self.assertEqual(oper["AS26615"]["pacote"], "BR.json")
        self.assertNotIn("AS64496", oper, "arquivos que começam com '_' são modelos e não entram")
        pasta = self.dir / "regiao"
        pasta.mkdir()
        (pasta / "DE.json").write_text(json.dumps({"operadoras": [{"asn": "AS64497", "nome": "Beispiel Telekom", "tipo_rede": "fixo", "verificado": False}]}), encoding="utf-8")
        self.assertEqual(list(ipa_tipologia.carregar_operadoras(str(pasta))), ["AS64497"])
        self.assertEqual(ipa_tipologia.carregar_operadoras(str(self.dir / "inexistente")), {})

    def test_pacote_de_outro_pais_alimenta_a_tipologia(self):
        ip = "91.200.100.77"
        c = self.consultar([ip], kit(ip, 64497, "Beispiel Telekom GmbH", pais="DE", cidade="Berlin"))
        p = self.dir / "DE.json"
        p.write_text(json.dumps({"operadoras": [{"asn": "AS64497", "nome": "Beispiel Telekom", "tipo_rede": "fixo", "verificado": False}]}), encoding="utf-8")
        t, _ = self.tipologia(c, "--operadoras", str(p))
        self.assertEqual(t[ip]["tipo"], "Residencial")
        self.assertTrue(any("tabela de operadoras" in x for x in t[ip]["indicios"]))
        self.assertTrue(any("pacote DE.json" in x for x in t[ip]["indicios"]))

    def test_funciona_sem_nenhum_pacote_e_fora_do_brasil(self):
        ip = "91.200.100.78"
        c = self.consultar([ip], kit(ip, 64497, "Beispiel Telekom GmbH", pais="DE", cidade="Berlin", peering="Cable/DSL/ISP",
                                     ptr="p5b2a1234.dip0.t-ipconnect.de"))
        vazio = self.dir / "vazio"
        vazio.mkdir()
        t, _ = self.tipologia(c, "--operadoras", str(vazio))
        self.assertEqual(t[ip]["tipo"], "Residencial")
        self.assertEqual(t[ip]["escala"], "Provável")

    def test_palavras_chave_em_outros_idiomas(self):
        for nome, tipo in (("Universidad Nacional de Ejemplo", "Corporativo/institucional"), ("Universität Beispielstadt", "Corporativo/institucional"),
                           ("Beispiel Mobilfunk GmbH", "Móvel"), ("Ejemplo Alojamiento SL", "Datacenter/nuvem")):
            regras = ipa_tipologia.carregar(None, "regras_tipologia.json")
            evs, _ = ipa_tipologia.coletar_evidencias({"ip": "198.51.100.1", "as_nome": [nome], "fontes": []}, regras, {})
            self.assertIn(tipo, {e["tipo"] for e in evs}, nome)

    def test_pais_do_ip_fora_do_br_gera_ressalva_de_lei_aplicavel(self):
        ip = "91.200.100.79"
        de = kit(ip, 64497, "Beispiel Telekom GmbH", pais="DE", cidade="Berlin", peering="Cable/DSL/ISP")
        t, _ = self.tipologia(self.consultar([ip], de), "--data-evento", "2026-06-01 10:00:00", "--fuso", "Europe/Berlin")
        self.assertTrue(any("registrado em DE" in x for x in t[ip]["limitacoes"]), t[ip]["limitacoes"])
        br = kit(RES, 64500, "Example Telecom S.A.", pais="BR", peering="Cable/DSL/ISP")
        t2, _ = self.tipologia(self.consultar([RES], br), "--data-evento", "2026-06-01 10:00:00", "--fuso=-03:00")
        self.assertFalse(any("registrado em" in x for x in t2[RES]["limitacoes"]))

    def test_tipologia_jurisdicao_outra_nao_presume_prazo_e_aceita_retencao_informada(self):
        ip = "91.200.100.80"
        c = self.consultar([ip], kit(ip, 64497, "Beispiel Telekom GmbH", pais="DE", cidade="Berlin", peering="Cable/DSL/ISP"))
        t, _ = self.tipologia(c, "--data-evento", "2026-06-01 10:00:00", "--fuso", "Europe/Berlin", "--jurisdicao", "OUTRA")
        self.assertTrue(t[ip]["prazo_guarda"]["retencao_desconhecida"])
        self.assertNotIn("conexao", t[ip]["prazo_guarda"])
        self.assertIn("desconhecido", (self.dir / "t.md").read_text(encoding="utf-8").lower())
        t2, _ = self.tipologia(c, "--data-evento", "2026-06-01 10:00:00", "--fuso", "Europe/Berlin", "--jurisdicao", "OUTRA", "--retencao", "conexao=6")
        self.assertEqual(t2[ip]["prazo_guarda"]["conexao"]["meses"], 6)
        self.assertNotIn("aplicacao", t2[ip]["prazo_guarda"])


class TestJurisdicaoPrazosEOficio(Cenario):
    def test_prazos_fora_do_br_nao_inventa_vencimento(self):
        saida = str(self.dir / "p.json")
        rc, out = cli("prazos", "2026-01-10 21:00", "--fuso", "Europe/London", "--hoje", "2026-10-24", "--jurisdicao", "OUTRA", "--saida", saida)
        self.assertEqual(rc, 0, out)
        p = jl(saida)
        self.assertTrue(p["retencao_desconhecida"])
        self.assertNotIn("conexao", p)
        self.assertIn("DESCONHECIDO", out)

    def test_prazos_com_retencao_informada(self):
        saida = str(self.dir / "p.json")
        rc, out = cli("prazos", "2026-01-10 21:00", "--fuso=-03:00", "--hoje", "2026-10-24", "--jurisdicao", "OUTRA", "--retencao", "conexao=24", "--saida", saida)
        self.assertEqual(rc, 0, out)
        p = jl(saida)
        self.assertEqual(p["conexao"]["vence_em_utc"], "2028-01-11T00:00:00Z")
        self.assertNotIn("aplicacao", p)
        for ruim in ("conexao=abc", "foo=3", "conexao=0", "conexao=1.5"):
            rc, out = cli("prazos", "2026-01-10 21:00", "--fuso=-03:00", "--retencao", ruim)
            self.assertEqual(rc, 2, (ruim, out))

    def test_janelas_de_preservacao_por_regime(self):
        base = dt.date(2026, 10, 1)
        for regime, dias in (("BR", 60), ("US", 90), ("UE", 60), ("BUDAPESTE", 60)):
            saida = str(self.dir / f"p_{regime}.json")
            rc, out = cli("prazos", "2026-01-10 21:00", "--fuso=-03:00", "--hoje", "2026-10-24", "--preservacao-em", "2026-10-01", "--regime", regime, "--saida", saida)
            self.assertEqual(rc, 0, out)
            w = jl(saida)["preservacao"]
            self.assertEqual(w["fim_do_prazo"], (base + dt.timedelta(days=dias)).isoformat(), regime)
            self.assertIn("conferir", w["base"].lower() if regime in ("UE", "BUDAPESTE") else "conferir")  # regimes de fonte secundária pedem conferência
        us = jl(self.dir / "p_US.json")["preservacao"]
        self.assertEqual(us["fim_com_prorrogacao"], (base + dt.timedelta(days=180)).isoformat())

    def test_oficio_exterior_so_preservacao_bilingue_sem_marco_civil(self):
        c = self.consultar([AWS], kit(AWS, 16509, "AMAZON-02", pais="US"))
        p = self.dir / "c_aws.json"
        p.write_text(json.dumps(c), encoding="utf-8")
        saida = str(self.dir / "of_ext.md")
        rc, out = cli("oficio", "--tipo", "preservacao", "--ip", AWS, "--data-hora", "2026-03-14 21:45:58", "--fuso", "America/Maceio",
                      "--consulta", str(p), "--jurisdicao", "OUTRA", "--saida", saida)
        self.assertEqual(rc, 0, out)
        md = Path(saida).read_text(encoding="utf-8")
        for esperado in ("Budapest", "2703(f)", "[PREENCHER", "source port", "Resumo (PT)", "2026-03-15"):
            self.assertIn(esperado, md)
        for proibido in ("12.965", "Marco Civil", "Decreto"):
            self.assertNotIn(proibido, md)
        self.assertIn("pendência", (md + out).lower())
        for tipo in ("cadastral", "representacao"):
            rc, out = cli("oficio", "--tipo", tipo, "--ip", AWS, "--data-hora", "2026-03-14 21:45:58", "--fuso", "America/Maceio",
                          "--jurisdicao", "OUTRA", "--saida", str(self.dir / "x.md"))
            self.assertEqual(rc, 2, out)
            self.assertIn("cooperação internacional", out)


class TestNomeDaSkill(unittest.TestCase):
    def test_nome_e_sem_vestigios_do_nome_antigo(self):
        sk = (RAIZ / "SKILL.md").read_text(encoding="utf-8")
        self.assertRegex(sk, r"(?m)^name: analise_ip_intelligence$")
        for p in RAIZ.rglob("*"):
            if p.is_file() and p.suffix in (".md", ".py", ".json") and p.name != "run_tests.py":
                self.assertNotIn("analise-ip-unificada", p.read_text(encoding="utf-8"), f"nome antigo em {p.relative_to(RAIZ)}")
        self.assertIn("analise_ip_intelligence", Path(__file__).read_text(encoding="utf-8"))

    def test_nenhuma_chave_de_api_no_pacote(self):
        for p in RAIZ.rglob("*"):
            if p.is_file() and p.suffix in (".md", ".py", ".json") and p.name != "run_tests.py":
                self.assertNotRegex(p.read_text(encoding="utf-8"), r"(?i)[?&]key=(?!\*\*\*|\{|<|a%20)[A-Za-z0-9_-]{8,}", p.name)



if __name__ == "__main__":
    unittest.main(verbosity=1, warnings="ignore")
