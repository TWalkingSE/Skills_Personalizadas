---
name: "investigative-notebook"
description: Caderno investigativo digital inspirado no IBM i2 Analyst's Notebook — análise de vínculos com entidades, relacionamentos, eventos, timeline, mapa, evidências, fontes, hipóteses, Smart Match, análise financeira, OSINT e relatório, separando fato, declaração, correlação, inferência e hipótese. Use sempre que o usuário quiser montar ou analisar um caso, diagrama de vínculos, grafo investigativo, link analysis, rede criminosa, fluxo de valores entre contas, extrato ou quebra de sigilo, registros de chamadas, linha do tempo de fatos, cruzamento de dados de BO, depoimentos ou planilhas, entidades duplicadas, contradições entre fontes, matriz de hipóteses ou relatório de análise — mesmo que não cite i2, grafo ou esta skill. É a camada de gestão e visualização de todas as skills de inteligência do ecossistema. Use também para projetar ou implementar a plataforma (Streamlit, NetworkX, Cytoscape, SQLite).
---

# Investigative Notebook

Um caso investigativo é um **conjunto rastreável de afirmações**, não um desenho. O grafo é só
uma das vistas; a mesma base vira timeline, mapa, tabela, matriz de hipóteses e relatório.
Esta skill dá a você (Claude) um núcleo pronto em Python e um visualizador estilo i2 para
registrar, analisar e apresentar casos sem perder a origem de nenhuma informação.

## O princípio que governa tudo

Toda informação carrega sua **natureza epistemológica**. O motivo é prático: em investigação,
uma inferência apresentada como fato contamina diligências, relatórios e decisões judiciais,
e o erro raramente é detectado depois. Por isso o sistema distingue, sempre:

| Natureza (`nature`) | Quando usar |
|---|---|
| `fato` (OFFICIAL) | documentado por fonte oficial/primária (extrato, cadastro institucional, log de provedor) |
| `observado` (OBSERVED) | verificado diretamente pelo analista ou ferramenta (hash calculado, string no arquivo, perfil público capturado) |
| `declarado` (DECLARED) | relato: BO, depoimento, declaração de vítima/testemunha |
| `correlacao` (CORRELATED) | coincidência observada nos dados (mesmo IP, mesmo endereço, mesmo horário) |
| `inferencia` (INFERRED) | conclusão do analista ou do sistema a partir de outros elementos |
| `hipotese` (HYPOTHESIS) | proposição a testar |
| `nao_verificado` (UNVERIFIED) | dado de origem não validada (OSINT, arquivo recebido sem verificação) |

Regras invariáveis (o código as reforça; você também deve):

1. Nunca promover inferência, correlação ou hipótese a fato automaticamente. A promoção exige
   fundamentação registrada (`update --reason`), e fica marcada em `promoted_from`.
2. Nunca inventar fonte, evidência, data ou identificador. Campo desconhecido fica vazio e vira lacuna.
3. Nunca mesclar entidades só por similaridade. Smart Match **sugere**; a decisão humana (com motivo) mescla.
4. Nunca escolher entre fontes contraditórias. Sinalize “CONTRADIÇÃO DETECTADA” e mostre ambas.
5. Preservar o valor original: identificadores são guardados como `{original, normalized, valid}`.
6. Confiança não substitui evidência; ausência de dado no caso não é ausência do fato.
7. Toda operação relevante entra na trilha de auditoria (feito automaticamente pela biblioteca).

## Formato obrigatório das conclusões

Ao responder qualquer pergunta analítica sobre o caso, use este bloco (uma vez por conclusão):

```
CONCLUSÃO: <afirmação objetiva>
EVIDÊNCIAS: <IDs de relações/evidências/eventos usados, ex.: R-0016, D-0001>
FUNDAMENTAÇÃO: <como se chegou à conclusão, em 1–3 frases>
TIPO: fato | declarado | correlação | inferência | hipótese
CONFIANÇA: muito baixa | baixa | média | alta | muito alta
LIMITAÇÕES: <o que a conclusão NÃO demonstra; dados ausentes; vieses>
FONTES: <IDs e títulos das fontes>
```

Exemplo de limitação bem escrita: “O compartilhamento de telefone, isoladamente, não demonstra
controle da empresa.” Sempre cite IDs — eles permitem ao leitor verificar cada passo.

## Ferramentas incluídas

Scripts em `scripts/` (Python 3.9+, requer `networkx`; `pandas`/`openpyxl` só para XLSX).
Execute sempre a partir da pasta `scripts/` ou use o caminho completo:

```bash
NB="python <skill>/scripts/nb.py"     # CLI única; `$NB <comando> -h` mostra opções
```

| Tarefa | Comando |
|---|---|
| Criar caso | `$NB init caso.json --title "..." --lead "..." --objective "..."` |
| Registrar muitos itens de uma vez (preferido) | `$NB batch caso.json ops.json` |
| Importar resultado das skills de inteligência | `$NB import-bundle caso.json a.bundle.json [b.bundle.json…] [--dry-run]` |
| Evidência com SHA-256 (e SHA-512/MD5 legado) | `$NB add-evidence caso.json --name X --type extrato --file arq.pdf --source S-0001` |
| Planilha/CSV → prévia | `$NB detect arq.csv --out map.json` → ajustar → `$NB stage-table arq.csv --mapping map.json --out stg.json` |
| Texto/PDF/DOCX/EML → prévia de identificadores | `$NB stage-text arq.pdf --out stg.json` |
| Importar o que foi aceito | `$NB commit caso.json stg.json [--accept-all] --evidence-id D-0001` |
| Validar regras epistemológicas | `$NB validate caso.json` |
| Análise completa | `$NB analyze caso.json --out analise.json` |
| Análises específicas | `metrics`, `paths A B [--all]`, `ego`, `match`, `contradictions`, `gaps`, `temporal --ref EV-…`, `spatial`, `financial`, `anomalies`, `hypotheses` |
| Mesclar (decisão humana) | `$NB merge caso.json E-0003 E-0002 --reason "mesmo CPF em D-0003"` |
| Visualizador i2 (HTML) | `$NB viewer caso.json --out caso.html [--no-tiles] [--inline-libs DIR]` |
| Relatório (17 seções) | `$NB report caso.json --out relatorio.md` |
| Exportar | `$NB export caso.json --format <fmt> --out ...` (graphml, gexf, csv, xlsx, json) |
| Pacote do caso (ZIP + SHA256SUMS) | `$NB package caso.json --out pacote.zip [--with-evidence-files] [--inline-libs DIR]` |
| Versões | `snapshot --label`, `snapshots`, `diff caso.json SN-0001`, `restore caso.json SN-0001 --reason` |
| Normalizar valor | `$NB normalize cpf "123.456.789-09"` (cpf, cnpj, telefone, email, ip, dominio, url, placa, pix, imei, mac, asn, data, valor) |

Filtros aceitos por `analyze/metrics/paths/ego/report`: `--mode oficial|declarado|inferencia`,
`--min-confidence 0.6`, `--evidence-only`, `--rel-type transferiu`, `--since/--until AAAA-MM-DD`.

## Fluxo de trabalho

### 1. Abrir ou criar o caso
Se o usuário trouxer um `caso.json`, carregue-o (`stats`, `validate`). Senão, crie com `init`.
Pergunte o objetivo da análise se não estiver claro — ele orienta o que extrair.

### 2. Fontes e evidências primeiro
Antes de qualquer entidade, registre de onde a informação vem (`source`) e o arquivo que a
sustenta (`evidence`, com hash). Assim cada item extraído já nasce vinculado. Tipo de fonte
sugere a natureza padrão (boletim/depoimento → `declarado`; documento oficial, sistema
institucional, log → `fato`; OSINT/página web → `nao_verificado`), mas ajuste caso a caso.

### 3. Extrair entidades, relações, eventos e observações
- **Material tabular** (extratos, CDR/ERB, logs, cadastros): `detect` → revise o mapeamento
  (tipos, relação, natureza, fonte) → `stage-table` → mostre o resumo ao usuário
  (“N entidades e M possíveis relações identificadas”) → `commit`. A entity resolution reaproveita
  entidades já existentes com o mesmo identificador normalizado.
- **Texto livre** (BO, depoimento, relatório): `stage-text` extrai identificadores por padrão;
  pessoas, empresas e relações exigem leitura sua. Leia o documento, monte um `ops.json` e
  aplique com `batch`. Use **observações** para afirmações contextualizadas — “Segundo o
  depoimento de 12/08/2026, a vítima informou que Pessoa A utilizava o telefone X” — além
  (ou em vez) da relação direta; elas preservam quem disse o quê, quando.
- Mostre ao usuário o que vai importar antes de importar em massa, e respeite o que ele rejeitar.

Formato do lote (referências locais com `ref` e `@ref`; detalhes em `references/data-model.md`):

```json
[
 {"op":"source","ref":"bo","type":"boletim","title":"BO 123/2026","date":"2026-08-12"},
 {"op":"entity","ref":"pa","type":"pessoa","label":"Pessoa A","identifiers":{"cpf":"..."},"nature":"declarado","confidence":"media","source_ids":["@bo"]},
 {"op":"entity","ref":"tel","type":"telefone","label":"(79) 99999-0001","identifiers":{"telefone":"(79) 99999-0001"},"source_ids":["@bo"]},
 {"op":"rel","source":"@pa","type":"utiliza","target":"@tel","start":"2026-08-12","nature":"declarado","confidence":"alta","source_ids":["@bo"]},
 {"op":"event","title":"Ligação para a vítima","type":"ligacao","start":"12/08/2026 02:40","participants":["@tel"],"source_ids":["@bo"]},
 {"op":"obs","statement":"Segundo o BO, ...","entity_id":"@pa","attribute":"telefone","value":"...","source_id":"@bo"},
 {"op":"hypothesis","title":"H1 — Pessoa A controla a conta B","supporting":["..."],"contradicting":[],"gaps":["..."],"confidence":40,"status":"aberta"}
]
```

Valores monetários de transações vão em `attributes.amount` (relação `transferiu`), o que
habilita a análise financeira. Datas aceitam ISO, `dd/mm/aaaa [hh:mm]`, `mm/aaaa`, `aaaa`,
`aprox. …` e `?` — a precisão é registrada e datas imprecisas viram lacuna.

### 4. Validar e analisar
Rode `validate` (erros de integridade, “fato sem fonte”, inferência marcada como confirmada sem
registro humano) e `analyze --out analise.json`. Leia o JSON, não só o resumo. Interprete com
`references/analysis-methods.md` — lá estão o significado e os limites de cada métrica,
dos critérios do Smart Match, dos padrões financeiros (passagem, fracionamento, circularidade)
e das anomalias.

### 5. Responder às perguntas investigativas
Mapeie a pergunta para a análise, depois responda no formato explicável:

| Pergunta | Onde buscar |
|---|---|
| Entidades mais importantes | `network.top` (intermediação, PageRank) + pontos de articulação |
| Caminho entre A e B | `paths A B` (e `--mode oficial --evidence-only` para ver se se sustenta só com fatos) |
| Múltiplas fontes / fonte única | `multi_source` |
| Conectadas a 3+ alvos | `ego` de cada alvo, ou métricas de grau filtradas por tag `alvo` |
| Antes/depois de um evento, 24h | `temporal --ref EV-…` |
| Padrões financeiros | `financial` (contas, fluxos, achados com limitações) |
| IPs relacionados | `ego` do IP / `paths` entre IPs; ver `references/osint-and-legal.md` |
| Duplicidades | `match` |
| Hipóteses sustentadas | `hypotheses` (alerta quando não há evidência contrária registrada) |
| Lacunas e contradições | `gaps`, `contradictions` |

Contraste sempre o modo `oficial` com o `todos`: se uma conclusão some quando só fatos são
considerados, ela depende de declaração ou inferência — e isso precisa estar no `TIPO`.

### 6. Visualizar e entregar
- **Visualizador** (`viewer`): HTML único, abre no navegador, sem servidor. Paleta à esquerda,
  grafo no centro, inspector à direita, timeline/mapa/evidências/filtros/achados/hipóteses/
  auditoria embaixo — seleção sincronizada entre todas as vistas. Permite criar, editar,
  mesclar (com motivo), agrupar, desfazer/refazer, layouts (force, hierárquico, radial,
  circular, por comunidade, por tempo, por localização), modos de exibição (oficial, declarado,
  inferência, destaque, visão geral, evidências, temporal, geográfico), expansão, pivô e
  caminhos. “Salvar” baixa o JSON atualizado com as edições na auditoria; para continuar na CLI,
  use esse arquivo como novo `caso.json` (compare com `diff`). Detalhes: `references/viewer-guide.md`.
- **Dados sensíveis**: o caso fica embutido no HTML e nada é enviado. Para máquinas isoladas use
  `--inline-libs DIR` (pasta com `cytoscape.min.js` e, opcional, `leaflet.js`/`leaflet.css`);
  use `--no-tiles` para que o mapa não peça tiles ao OpenStreetMap (as requisições revelariam a
  região analisada). Sem Leaflet, o mapa cai para um esquema SVG local.
- **Relatório**: `report` gera o Markdown com as 17 seções; preencha os marcadores `[ANALISTA: …]`
  (objetivo, resumo executivo, conclusões no formato explicável, limitações específicas) com o
  usuário. Para DOCX/PDF use as skills `docx`/`pdf`. **Pacote**: `package` (ZIP com caso,
  análise, visualizador, relatório, GraphML/GEXF, CSVs, manifesto de evidências e SHA256SUMS).
- Tire um `snapshot` antes de mudanças grandes (merge, importação em massa) e ao entregar.

Arquivos entregues ao usuário devem ser enviados como arquivos (não como artefato publicado):
o conteúdo de um caso real é sigiloso e não deve ganhar URL.

## Construindo a plataforma

Se o pedido for desenvolver a aplicação (Streamlit etc.), leia
`references/platform-architecture.md`: arquitetura modular por fase, como os scripts desta
skill já cobrem o núcleo (reaproveite `case_model.py`/`analyze.py` como camada de domínio em vez
de reescrever), esquema SQLite, componentes de UI e roadmap das 6 fases.

## Ecossistema de inteligência

O caderno é a **camada de visualização e gestão do caso** (grafo, timeline, mapa). As demais skills
são motores de coleta, extração e análise que convergem nele pelo contrato `intel-bundle/1.0`
(`references/intel-contract.md`) ou trabalhando diretamente sobre o `caso.json`:

| Camada | Skill | Papel no caso |
|---|---|---|
| Coleta/extração | `document-intelligence` | documentos → entidades, relações, eventos e contradições com documento, página, trecho e posição |
| | `financial-intelligence` | extratos → contas, transferências e padrões ("compatível com") |
| | `social-media-intelligence` | presença digital → perfis classificados (Confirmado/Provável/Possível) |
| | `malware-artifact-analysis` | artefatos → arquivos, hashes, IOCs e nível de suspeição |
| | `osint-intelligence` | fontes abertas → entidades com fonte, data, trecho e confiabilidade |
| Consistência | `entity-resolution` | duplicidades e homônimos: sugere, o analista decide; mescla reversível |
| Rastreabilidade | `evidence-provenance` | hashes, custódia, "de onde veio esta informação?", reconstrução de conclusões |
| Interpretação | `link-analysis` | estrutura da rede (centralidade, comunidades, caminhos com sustentação) |
| | `timeline-geospatial` | tempo e espaço (ordem, trajetória, compatibilidade, presença direta × via objeto) |
| | `case-correlation` | conexões com outras investigações |
| Raciocínio | `hypothesis-engine` | resumo, hipóteses, matriz ACH, explicabilidade, próximas verificações |

Fluxo típico: Documento → Document Intelligence → (Entity Resolution `bundle-check`) →
`import-bundle` → Evidence & Provenance (`register`, `verify`) → Link Analysis → Timeline &
Geospatial → OSINT / Financial / Social / Malware → Entity Resolution (`candidates`, decisões) →
Case Correlation → Hypothesis Engine → relatório.

`import-bundle` aplica **entity resolution** só por identificadores fortes e só entre entidades do
**mesmo tipo** (CPF/CNPJ, telefone, e-mail, IP, domínio, URL, conta completa, PIX, hashes, perfil,
username, processo, caso): a mesma conta vinda de um PDF e de uma planilha vira uma entidade, com as
duas proveniências. Nome igual nunca une sozinho; mesmo CPF com nomes incompatíveis vira
`contraditorio` + observação; valor de atributo divergente vira observação; fontes, evidências
(por SHA-256), relações e eventos repetidos são reaproveitados; análises dos produtores entram em
`analyses[]`. Rode `--dry-run` (ou `er.py bundle-check`) antes, tire um `snapshot` e rode
`validate` depois. A proveniência de cada item aparece no inspector do visualizador.

Nenhuma camada substitui a avaliação humana: o caderno nunca promove natureza sozinho, não mescla
sem decisão registrada e não oculta contradições.

## Integrações

- Endereços IP, ASN, domínios e certificados: aprofundar com a skill `analise-ip`; OSINT com
  base legal e cadeia de custódia: `osint-investigator-forense`; criptoativos:
  `crypto-investigator`. Traga os resultados para o caso como entidades/relações
  `nao_verificado` e registre cada consulta com `{"op":"osint", ...}`.
- Revisão de texto do relatório: `redator-inteligente`.

## Referências

| Arquivo | Ler quando |
|---|---|
| `references/data-model.md` | precisar dos campos completos, vocabulários controlados ou do formato de lote |
| `references/intel-contract.md` | importar ou depurar bundles das skills de inteligência |
| `references/analysis-methods.md` | for interpretar métricas, Smart Match, finanças, timeline, mapa, anomalias, hipóteses |
| `references/viewer-guide.md` | for explicar ou ajustar o visualizador (atalhos, modos, ciclo de edição) |
| `references/osint-and-legal.md` | o caso envolver IP/DNS/domínio/certificado, consultas externas ou dados sob sigilo |
| `references/platform-architecture.md` | o usuário quiser construir/evoluir a plataforma |
| `assets/example_case_ops.json` | quiser um caso fictício completo para demonstração ou teste |
