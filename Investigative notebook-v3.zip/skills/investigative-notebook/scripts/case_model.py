"""
case_model.py — Núcleo do Investigative Notebook (Fase 1 + proveniência da Fase 4).

Modelo de dados do CASO em JSON, com:
- entidades, relacionamentos, observações, eventos, fontes, evidências, hipóteses,
  consultas OSINT, snapshots e trilha de auditoria;
- natureza epistemológica obrigatória (fato / declarado / correlação / inferência /
  hipótese / não verificado);
- normalização que preserva o valor original;
- hash de evidências (SHA-256 preferencial);
- validação das regras epistemológicas.

Uso como biblioteca:
    from case_model import Case
    c = Case.load("caso.json")
    pid = c.add_entity("pessoa", "João da Silva", identifiers={"cpf": "123.456.789-09"},
                       nature="declarado", source_ids=["S-0001"])
    c.save("caso.json")

Somente biblioteca padrão. Python 3.9+.
"""
from __future__ import annotations

import copy
import datetime as _dt
import hashlib
import ipaddress
import json
import os
import re
import unicodedata
from pathlib import Path
from typing import Any, Iterable

SCHEMA_VERSION = "1.0"

# ----------------------------------------------------------------------------
# Vocabulários controlados
# ----------------------------------------------------------------------------

NATURES = {
    "fato": "Fato (fonte oficial)",
    "observado": "Observado (verificação direta)",
    "declarado": "Informação declarada",
    "correlacao": "Correlação",
    "inferencia": "Inferência",
    "hipotese": "Hipótese",
    "nao_verificado": "Não verificado",
}

# Vocabulário do contrato comum (inglês) e variantes aceitas na entrada -> chave interna
NATURE_ALIASES = {
    "official": "fato", "oficial": "fato", "fact": "fato", "fato": "fato",
    "observed": "observado", "observado": "observado", "observacao_direta": "observado",
    "declared": "declarado", "declarado": "declarado", "declaracao": "declarado",
    "correlated": "correlacao", "correlation": "correlacao", "correlacao": "correlacao", "correlacionado": "correlacao",
    "inferred": "inferencia", "inference": "inferencia", "inferencia": "inferencia", "inferido": "inferencia",
    "hypothesis": "hipotese", "hipotese": "hipotese",
    "unverified": "nao_verificado", "nao_verificado": "nao_verificado", "naoverificado": "nao_verificado",
}
NATURE_CONTRACT = {"fato": "OFFICIAL", "observado": "OBSERVED", "declarado": "DECLARED", "correlacao": "CORRELATED",
                   "inferencia": "INFERRED", "hipotese": "HYPOTHESIS", "nao_verificado": "UNVERIFIED"}
FACTUAL_NATURES = {"fato", "observado"}


def canon_nature(value) -> str:
    key = strip_accents(str(value or "")).lower().strip().replace(" ", "_").replace("-", "_")
    if key in NATURE_ALIASES:
        return NATURE_ALIASES[key]
    raise ValueError(f"natureza inválida: {value!r}. Valores aceitos: {', '.join(NATURES)} "
                     f"(ou {', '.join(NATURE_CONTRACT.values())})")


# Confiabilidade da fonte (escala Admiralty/OTAN) e credibilidade da informação
SOURCE_RELIABILITY = {"A": "completamente confiável", "B": "geralmente confiável", "C": "razoavelmente confiável",
                      "D": "geralmente não confiável", "E": "não confiável", "F": "confiabilidade não avaliável"}
INFO_CREDIBILITY = {"1": "confirmada por outras fontes", "2": "provavelmente verdadeira", "3": "possivelmente verdadeira",
                    "4": "duvidosa", "5": "improvável", "6": "veracidade não avaliável"}

# Modos de exibição do grafo -> naturezas incluídas
DISPLAY_MODES = {
    "oficial": {"fato", "observado"},
    "declarado": {"declarado"},
    "inferencia": {"correlacao", "inferencia", "hipotese"},
    "todos": set(NATURES),
}

CONFIDENCE_LEVELS = {
    "muito_baixa": 0.1,
    "baixa": 0.3,
    "media": 0.5,
    "alta": 0.7,
    "muito_alta": 0.9,
}

STATUSES = {
    "confirmado": "Confirmado",
    "nao_confirmado": "Não confirmado",
    "hipotese": "Hipótese",
    "em_analise": "Em análise",
    "rejeitado": "Rejeitado",
    "contraditorio": "Contraditório",
    "arquivado": "Arquivado",
}

HYPOTHESIS_STATUSES = {
    "aberta": "Aberta",
    "em_analise": "Em análise",
    "sustentada": "Sustentada",
    "enfraquecida": "Enfraquecida",
    "confirmada": "Confirmada",
    "rejeitada": "Rejeitada",
}

CASE_STATUSES = ["aberto", "em_analise", "suspenso", "concluido", "arquivado"]
CLASSIFICATIONS = ["OSTENSIVO", "RESERVADO", "SIGILOSO", "SECRETO"]

ENTITY_TYPES = {
    "pessoa": "Pessoa", "empresa": "Empresa", "organizacao": "Organização",
    "endereco": "Endereço", "telefone": "Telefone", "email": "E-mail",
    "cpf": "CPF", "cnpj": "CNPJ", "documento": "Documento",
    "conta_bancaria": "Conta bancária", "pix": "Chave PIX", "cartao": "Cartão",
    "veiculo": "Veículo", "ip": "IP", "dominio": "Domínio", "url": "URL",
    "usuario": "Usuário", "perfil_social": "Perfil social", "dispositivo": "Dispositivo",
    "imei": "IMEI", "mac": "MAC", "asn": "ASN", "prefixo_ip": "Prefixo IP",
    "certificado": "Certificado digital", "arquivo": "Arquivo", "evento": "Evento",
    "localizacao": "Localização", "transacao": "Transação", "processo": "Processo",
    "ocorrencia": "Ocorrência", "boletim": "Boletim", "evidencia": "Evidência",
    "imagem": "Imagem", "audio": "Áudio", "video": "Vídeo",
    "hash": "Hash", "indicador": "Indicador (IOC)", "aplicativo": "Aplicativo", "mutex": "Mutex",
    "chave_registro": "Chave de registro", "instituicao": "Instituição", "outro": "Outro",
}

RELATIONSHIP_TYPES = [
    "possui", "utiliza", "pertence a", "reside em", "trabalha em", "sócio de",
    "administrador de", "proprietário de", "transferiu", "recebeu", "telefonou",
    "enviou mensagem", "acessou", "conectado a", "associado a", "localizado em",
    "visitou", "esteve em", "controla", "representa", "conhece", "relacionado a",
    "compartilha", "originou", "recebeu de", "encaminhou para",
    # OSINT / infraestrutura
    "resolve para", "anunciado por", "hospedado em", "emitido para", "registrado por",
]

# Relações tipicamente não direcionadas
UNDIRECTED_TYPES = {"conhece", "relacionado a", "associado a", "compartilha", "conectado a"}

# Relações "exclusivas": a mesma origem com destinos diferentes no mesmo período
# é potencial contradição (ex.: residir em dois endereços ao mesmo tempo).
EXCLUSIVE_RELATIONSHIP_TYPES = {"reside em"}

# Atributos de valor único: valores diferentes vindos de fontes diferentes = contradição
SINGLE_VALUED_ATTRIBUTES = {
    "data_nascimento", "cpf", "cnpj", "nome_mae", "sexo", "rg", "placa", "chassi",
    "renavam", "endereco_residencial", "titular",
}

EVENT_TYPES = [
    "ligacao", "mensagem", "transferencia", "saque", "deposito", "login", "acesso",
    "viagem", "encontro", "criacao_conta", "abertura_empresa", "alteracao_cadastral",
    "ocorrencia", "apreensao", "busca", "evento_policial", "evento_financeiro",
    "evento_digital", "personalizado",
]

SOURCE_TYPES = [
    "documento_oficial", "boletim", "depoimento", "sistema_institucional",
    "banco_de_dados", "arquivo_fornecido", "pagina_web", "api", "consulta_osint",
    "log", "imagem", "video", "audio", "fonte_secundaria", "fonte_desconhecida",
]

# Natureza padrão sugerida por tipo de fonte (o analista pode alterar)
SOURCE_DEFAULT_NATURE = {
    "documento_oficial": "fato", "sistema_institucional": "fato", "banco_de_dados": "fato",
    "log": "fato", "boletim": "declarado", "depoimento": "declarado",
    "arquivo_fornecido": "nao_verificado", "pagina_web": "nao_verificado",
    "api": "nao_verificado", "consulta_osint": "nao_verificado",
    "imagem": "nao_verificado", "video": "nao_verificado", "audio": "nao_verificado",
    "fonte_secundaria": "nao_verificado", "fonte_desconhecida": "nao_verificado",
}

EVIDENCE_TYPES = [
    "pdf", "documento", "imagem", "screenshot", "audio", "video", "planilha", "csv",
    "json", "xml", "txt", "email", "exportacao_aplicativo", "log", "relatorio",
    "extrato", "boletim", "pagina_web", "banco_de_dados", "arquivo_digital", "outro",
]

ID_PREFIX = {
    "entities": "E", "relationships": "R", "observations": "O", "events": "EV",
    "sources": "S", "evidence": "D", "hypotheses": "H", "osint_queries": "Q", "analyses": "AN",
    "snapshots": "SN",
}


# ----------------------------------------------------------------------------
# Utilidades
# ----------------------------------------------------------------------------

def now_iso() -> str:
    return _dt.datetime.now().astimezone().isoformat(timespec="seconds")


def strip_accents(s: str) -> str:
    return "".join(ch for ch in unicodedata.normalize("NFKD", s) if not unicodedata.combining(ch))


def confidence_value(conf: Any) -> float | None:
    """Converte nível textual ou número (0-1 ou 0-100) para 0..1."""
    if conf is None or conf == "":
        return None
    if isinstance(conf, (int, float)):
        v = float(conf)
        return v / 100.0 if v > 1 else v
    key = strip_accents(str(conf)).lower().replace(" ", "_")
    if key in CONFIDENCE_LEVELS:
        return CONFIDENCE_LEVELS[key]
    try:
        return confidence_value(float(str(conf).replace("%", "").replace(",", ".")))
    except ValueError:
        return None


def confidence_label(conf: Any) -> str:
    v = confidence_value(conf)
    if v is None:
        return "não informada"
    for k, thr in [("muito_alta", 0.8), ("alta", 0.6), ("media", 0.4), ("baixa", 0.2)]:
        if v >= thr:
            return k
    return "muito_baixa"


def _canon(value: str, vocab: Iterable[str], field: str) -> str:
    key = strip_accents(str(value)).lower().strip().replace(" ", "_").replace("-", "_")
    vocab = list(vocab)
    if key in vocab:
        return key
    raise ValueError(f"{field} inválido: {value!r}. Valores aceitos: {', '.join(vocab)}")


# ----------------------------------------------------------------------------
# Normalização (valor original sempre preservado)
# ----------------------------------------------------------------------------

def _digits(s: str) -> str:
    return re.sub(r"\D", "", str(s))


def cpf_is_valid(d: str) -> bool:
    if len(d) != 11 or d == d[0] * 11:
        return False
    for n in (9, 10):
        s = sum(int(d[i]) * (n + 1 - i) for i in range(n))
        dv = (s * 10) % 11 % 10
        if dv != int(d[n]):
            return False
    return True


def cnpj_is_valid(d: str) -> bool:
    if len(d) != 14 or d == d[0] * 14:
        return False
    w1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    w2 = [6] + w1
    for w, n in ((w1, 12), (w2, 13)):
        s = sum(int(d[i]) * w[i] for i in range(n))
        dv = 0 if s % 11 < 2 else 11 - s % 11
        if dv != int(d[n]):
            return False
    return True


def normalize(kind: str, value: Any) -> dict:
    """Retorna {original, normalized, valid, note}. Nunca descarta o original."""
    orig = value
    s = "" if value is None else str(value).strip()
    out: dict[str, Any] = {"original": orig, "normalized": s, "valid": None, "note": ""}
    k = strip_accents(kind).lower()
    try:
        if k == "cpf":
            d = _digits(s)
            out["normalized"] = d
            out["valid"] = cpf_is_valid(d)
        elif k == "cnpj":
            d = _digits(s)
            out["normalized"] = d
            out["valid"] = cnpj_is_valid(d)
        elif k in ("telefone", "phone"):
            d = _digits(s)
            if d.startswith("00"):
                d = d[2:]
            if len(d) in (10, 11):          # DDD + número, sem país
                d = "55" + d
            elif len(d) in (12, 13) and d.startswith("0"):  # 0 + operadora? mantém
                out["note"] = "prefixo de operadora não removido"
            out["normalized"] = "+" + d if d else ""
            out["valid"] = 12 <= len(d) <= 13 if d.startswith("55") else 8 <= len(d) <= 15
        elif k in ("email", "e-mail"):
            n = s.lower()
            out["normalized"] = n
            out["valid"] = bool(re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", n))
        elif k == "ip":
            ip = ipaddress.ip_address(s.strip("[]"))
            out["normalized"] = ip.compressed
            out["valid"] = True
            out["note"] = "privado/reservado" if (ip.is_private or ip.is_reserved) else ""
        elif k in ("prefixo_ip", "cidr"):
            net = ipaddress.ip_network(s, strict=False)
            out["normalized"] = net.compressed
            out["valid"] = True
        elif k in ("dominio", "domain"):
            n = s.lower().rstrip(".")
            n = re.sub(r"^https?://", "", n).split("/")[0]
            n = n.replace("[.]", ".")  # refanging de valores defanged
            try:
                n = n.encode("idna").decode("ascii")
            except UnicodeError:
                pass
            out["normalized"] = n
            out["valid"] = bool(re.fullmatch(r"(?=.{1,253}$)([a-z0-9-]{1,63}\.)+[a-z0-9-]{2,63}", n))
        elif k == "url":
            n = s.replace("hxxp", "http").replace("[.]", ".")
            m = re.match(r"^([a-zA-Z][a-zA-Z0-9+.-]*)://([^/]+)(.*)$", n)
            if m:
                n = f"{m.group(1).lower()}://{m.group(2).lower()}{m.group(3)}"
            out["normalized"] = n
            out["valid"] = bool(m)
        elif k in ("placa", "veiculo"):
            n = re.sub(r"[^A-Z0-9]", "", strip_accents(s).upper())
            out["normalized"] = n
            if re.fullmatch(r"[A-Z]{3}[0-9][A-Z][0-9]{2}", n):
                out["valid"], out["note"] = True, "padrão Mercosul"
            elif re.fullmatch(r"[A-Z]{3}[0-9]{4}", n):
                out["valid"], out["note"] = True, "padrão anterior (pré-Mercosul)"
            else:
                out["valid"] = False
        elif k in ("nome", "name", "pessoa", "empresa"):
            n = strip_accents(s).upper()
            n = re.sub(r"[^A-Z0-9 ]", " ", n)
            out["normalized"] = re.sub(r"\s+", " ", n).strip()
            out["valid"] = bool(out["normalized"])
        elif k in ("endereco", "address"):
            n = strip_accents(s).upper()
            for a, b in [(r"\bR\.?\s", "RUA "), (r"\bAV\.?\s", "AVENIDA "), (r"\bTRAV\.?\s", "TRAVESSA "),
                         (r"\bN[º°O]\.?\s*", "N "), (r"\bAPTO?\.?\s", "APARTAMENTO ")]:
                n = re.sub(a, b, n)
            n = re.sub(r"[^A-Z0-9 ,\-]", " ", n)
            out["normalized"] = re.sub(r"\s+", " ", n).strip()
            out["valid"] = bool(out["normalized"])
        elif k in ("data", "date", "datetime"):
            iso, precision = parse_date(s)
            out["normalized"] = iso
            out["valid"] = iso is not None
            out["note"] = precision
        elif k in ("valor", "money", "moeda"):
            out["normalized"] = parse_money(s)
            out["valid"] = out["normalized"] is not None
        elif k in ("imei",):
            d = _digits(s)
            out["normalized"] = d
            out["valid"] = len(d) in (14, 15, 16) and (len(d) != 15 or _luhn(d))
        elif k in ("mac",):
            h = re.sub(r"[^0-9a-fA-F]", "", s).lower()
            out["normalized"] = ":".join(h[i:i + 2] for i in range(0, len(h), 2))
            out["valid"] = len(h) == 12
        elif k in ("asn",):
            d = _digits(s)
            out["normalized"] = f"AS{d}" if d else ""
            out["valid"] = bool(d)
        elif k in ("sha256", "sha1", "md5", "sha512", "hash"):
            h = re.sub(r"[^0-9a-fA-F]", "", s).lower()
            lens = {"md5": 32, "sha1": 40, "sha256": 64, "sha512": 128}
            out["normalized"] = h
            out["valid"] = len(h) == lens[k] if k in lens else len(h) in lens.values()
            if k == "hash" and out["valid"]:
                out["note"] = {32: "md5", 40: "sha1", 64: "sha256", 128: "sha512"}[len(h)]
        elif k in ("username", "usuario", "perfil_social"):
            n = s.strip().lstrip("@").lower()
            n = re.sub(r"^https?://(www\.)?[^/]+/(@)?", "", n).strip("/")
            out["normalized"] = n
            out["valid"] = bool(re.fullmatch(r"[a-z0-9._\-]{1,64}", n))
        elif k in ("conta_bancaria", "conta"):
            # chave composta banco|agência|conta(+DV); '?' marca parte desconhecida
            t = strip_accents(s).lower()
            def grab(pat):
                m = re.search(pat, t)
                return re.sub(r"\D", "", m.group(1)) if m else ""
            banco = grab(r"(?:banco|bco|compe)\s*[:#n.o]*\s*(\d{3})")
            ag = grab(r"(?:ag(?:encia)?|ag\.)\s*[:#n.o]*\s*(\d{3,5}(?:-?\d)?)")
            cc = grab(r"(?:c/?c|conta(?:\s+corrente|\s+poupanca|\s+pagamento)?|cp)\s*[:#n.o]*\s*(\d[\d.\-]{2,15}[0-9x]?)")
            if not cc:
                cc = re.sub(r"\D", "", t) if re.fullmatch(r"[\d.\- x]+", t) else ""
            out["normalized"] = f"{banco or '?'}|{ag.lstrip('0') or '?'}|{cc.lstrip('0') or '?'}"
            out["valid"] = bool(cc)
            out["note"] = "parcial" if "?" in out["normalized"] else ""
        elif k in ("processo", "cnj"):
            d = _digits(s)
            out["normalized"] = d
            out["valid"] = len(d) == 20 and int(d[:7] + d[9:] + d[7:9]) % 97 == 1
            out["note"] = "numeração única CNJ" if out["valid"] else "fora do padrão CNJ"
        elif k in ("pix",):
            # chave PIX pode ser CPF, CNPJ, telefone, e-mail ou aleatória
            if "@" in s:
                return {**normalize("email", s), "note": "chave PIX tipo e-mail"}
            d = _digits(s)
            if re.fullmatch(r"[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}", s):
                out.update(normalized=s.lower(), valid=True, note="chave PIX aleatória (EVP)")
            elif len(d) == 11 and cpf_is_valid(d):
                out.update(normalized=d, valid=True, note="chave PIX tipo CPF (ou telefone sem DDI)")
            elif len(d) == 14 and cnpj_is_valid(d):
                out.update(normalized=d, valid=True, note="chave PIX tipo CNPJ")
            elif s.startswith("+") or len(d) in (12, 13):
                return {**normalize("telefone", s), "note": "chave PIX tipo telefone"}
            else:
                out["valid"] = False
    except (ValueError, TypeError) as exc:
        out["valid"] = False
        out["note"] = f"falha na normalização: {exc}"
    return out


def _luhn(d: str) -> bool:
    total = 0
    for i, ch in enumerate(reversed(d)):
        n = int(ch)
        if i % 2:
            n *= 2
            n -= 9 if n > 9 else 0
        total += n
    return total % 10 == 0


_DATE_PATTERNS = [
    (r"^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?", "exata"),
    (r"^(\d{2})/(\d{2})/(\d{4})[ ,]+(\d{2}):(\d{2})(?::(\d{2}))?", "exata"),
    (r"^(\d{4})-(\d{2})-(\d{2})$", "dia"),
    (r"^(\d{2})/(\d{2})/(\d{4})$", "dia"),
    (r"^(\d{2})/(\d{4})$", "mes"),
    (r"^(\d{4})-(\d{2})$", "mes"),
    (r"^(\d{4})$", "ano"),
]


def parse_date(s: str) -> tuple[str | None, str]:
    """Interpreta datas BR/ISO. Retorna (ISO, precisão). Precisão: exata|dia|mes|ano|aproximada|desconhecida.
    Prefixos 'aprox.', 'c.', '~' marcam data aproximada."""
    if s is None:
        return None, "desconhecida"
    raw = str(s).strip()
    if not raw or raw.lower() in ("?", "desconhecida", "n/d", "nd", "null", "none"):
        return None, "desconhecida"
    approx = bool(re.match(r"^(aprox\.?|aproximadamente|c\.|~|circa)\s*", raw, re.I))
    raw = re.sub(r"^(aprox\.?|aproximadamente|c\.|~|circa)\s*", "", raw, flags=re.I)
    for pat, prec in _DATE_PATTERNS:
        m = re.match(pat, raw)
        if not m:
            continue
        g = m.groups()
        try:
            if pat.startswith(r"^(\d{4})-(\d{2})-(\d{2})[T"):
                dt = _dt.datetime(int(g[0]), int(g[1]), int(g[2]), int(g[3]), int(g[4]), int(g[5] or 0))
                iso = dt.isoformat()
                tz = re.search(r"(Z|[+-]\d{2}:?\d{2})$", raw)
                if tz:
                    iso += "Z" if tz.group(1) == "Z" else tz.group(1)
            elif pat.startswith(r"^(\d{2})/(\d{2})/(\d{4})[ ,]"):
                iso = _dt.datetime(int(g[2]), int(g[1]), int(g[0]), int(g[3]), int(g[4]), int(g[5] or 0)).isoformat()
            elif prec == "dia" and "-" in pat:
                iso = _dt.date(int(g[0]), int(g[1]), int(g[2])).isoformat()
            elif prec == "dia":
                iso = _dt.date(int(g[2]), int(g[1]), int(g[0])).isoformat()
            elif prec == "mes" and "/" in pat:
                iso = f"{int(g[1]):04d}-{int(g[0]):02d}"
            elif prec == "mes":
                iso = f"{int(g[0]):04d}-{int(g[1]):02d}"
            else:
                iso = f"{int(g[0]):04d}"
        except ValueError:
            return None, "desconhecida"
        return iso, ("aproximada" if approx else prec)
    return None, "desconhecida"


def to_datetime(iso: str | None) -> _dt.datetime | None:
    """Converte ISO (inclusive parcial: AAAA, AAAA-MM) para datetime ingênuo (início do período)."""
    if not iso:
        return None
    s = str(iso)
    try:
        if re.fullmatch(r"\d{4}", s):
            return _dt.datetime(int(s), 1, 1)
        if re.fullmatch(r"\d{4}-\d{2}", s):
            return _dt.datetime(int(s[:4]), int(s[5:7]), 1)
        dt = _dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
        return dt.replace(tzinfo=None) if dt.tzinfo else dt
    except ValueError:
        iso2, _ = parse_date(s)
        return to_datetime(iso2) if iso2 and iso2 != s else None


def fmt_brl(v: float | None) -> str:
    """1234.5 -> '1.234,50' (padrão brasileiro)."""
    if v is None:
        return "—"
    return f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")


def parse_money(s: Any) -> float | None:
    if isinstance(s, (int, float)):
        return float(s)
    t = re.sub(r"[^\d,.\-]", "", str(s))
    if not t:
        return None
    if "," in t and "." in t:
        t = t.replace(".", "").replace(",", ".") if t.rfind(",") > t.rfind(".") else t.replace(",", "")
    elif "," in t:
        t = t.replace(",", ".")
    elif t.count(".") > 1:
        t = t.replace(".", "")
    try:
        return float(t)
    except ValueError:
        return None


# ----------------------------------------------------------------------------
# Hash de arquivos (evidências)
# ----------------------------------------------------------------------------

def file_hashes(path: str | os.PathLike, algorithms: Iterable[str] = ("sha256",)) -> dict:
    hs = {a: hashlib.new(a) for a in algorithms}
    size = 0
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            size += len(chunk)
            for h in hs.values():
                h.update(chunk)
    out = {a: h.hexdigest() for a, h in hs.items()}
    out["size"] = size
    return out


# ----------------------------------------------------------------------------
# Case
# ----------------------------------------------------------------------------

def empty_case(title: str, **meta) -> dict:
    ts = now_iso()
    return {
        "schema_version": SCHEMA_VERSION,
        "case": {
            "id": meta.get("id") or "CASO-" + _dt.datetime.now().strftime("%Y%m%d-%H%M%S"),
            "title": title,
            "description": meta.get("description", ""),
            "objective": meta.get("objective", ""),
            "lead": meta.get("lead", ""),
            "team": meta.get("team", []),
            "created_at": ts,
            "updated_at": ts,
            "classification": meta.get("classification", "SIGILOSO"),
            "status": meta.get("status", "em_analise"),
            "tags": meta.get("tags", []),
            "notes": meta.get("notes", ""),
            "custom_entity_types": {},
            "custom_relationship_types": [],
        },
        "entities": [], "relationships": [], "observations": [], "events": [],
        "sources": [], "evidence": [], "hypotheses": [], "osint_queries": [], "analyses": [],
        "snapshots": [], "audit_log": [], "positions": {}, "groups": [],
    }


class Case:
    def __init__(self, data: dict, path: str | None = None, user: str | None = None):
        self.data = data
        self.path = path
        self.user = user or os.environ.get("NB_USER") or data.get("case", {}).get("lead") or "analista"
        for key in ("entities", "relationships", "observations", "events", "sources", "evidence",
                    "hypotheses", "osint_queries", "analyses", "snapshots", "audit_log", "groups"):
            data.setdefault(key, [])
        data.setdefault("positions", {})

    # ---------- persistência ----------
    @classmethod
    def new(cls, title: str, path: str | None = None, user: str | None = None, **meta) -> "Case":
        c = cls(empty_case(title, **meta), path, user)
        c._audit("criação", "caso", c.data["case"]["id"], after={"title": title})
        return c

    @classmethod
    def load(cls, path: str, user: str | None = None) -> "Case":
        with open(path, encoding="utf-8") as fh:
            return cls(json.load(fh), path, user)

    def save(self, path: str | None = None) -> str:
        path = path or self.path
        if not path:
            raise ValueError("Caminho do caso não definido")
        self.data["case"]["updated_at"] = now_iso()
        tmp = f"{path}.tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(self.data, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
        self.path = path
        return path

    # ---------- acesso ----------
    def coll(self, name: str) -> list:
        return self.data[name]

    def get(self, obj_id: str) -> tuple[str, dict] | tuple[None, None]:
        for name in ID_PREFIX:
            for obj in self.data.get(name, []):
                if obj.get("id") == obj_id:
                    return name, obj
        return None, None

    def entity(self, ref: str) -> dict | None:
        """Busca entidade por id, rótulo exato ou alias (sem diferenciar acentos/caixa)."""
        key = strip_accents(ref).lower().strip()
        for e in self.data["entities"]:
            if e["id"] == ref:
                return e
        for e in self.data["entities"]:
            names = [e.get("label", "")] + e.get("aliases", [])
            if any(strip_accents(n).lower().strip() == key for n in names):
                return e
        return None

    def _next_id(self, coll: str) -> str:
        prefix = ID_PREFIX[coll]
        n = 0
        for obj in self.data[coll]:
            m = re.match(rf"^{prefix}-(\d+)$", str(obj.get("id", "")))
            if m:
                n = max(n, int(m.group(1)))
        return f"{prefix}-{n + 1:04d}"

    # ---------- auditoria ----------
    def _audit(self, action: str, obj_type: str, obj_id: str | None, before=None, after=None, reason: str = ""):
        self.data["audit_log"].append({
            "ts": now_iso(), "user": self.user, "action": action, "object_type": obj_type,
            "object_id": obj_id, "before": before, "after": after, "reason": reason,
        })

    # ---------- criação ----------
    def _epistemic(self, nature, confidence, status, source_ids) -> dict:
        if nature is None:
            # Natureza não informada: sugere a partir da fonte, senão "não verificado"
            nature = "nao_verificado"
            for sid in source_ids or []:
                _, src = self.get(sid)
                if src and src.get("type") in SOURCE_DEFAULT_NATURE:
                    nature = SOURCE_DEFAULT_NATURE[src["type"]]
                    break
        nature = canon_nature(nature)
        status = _canon(status or ("hipotese" if nature == "hipotese" else "em_analise"), STATUSES, "status")
        if confidence is not None and confidence_value(confidence) is None:
            raise ValueError(f"confiança inválida: {confidence!r}")
        return {"nature": nature, "confidence": confidence, "status": status}

    def add_source(self, type: str, title: str, reference: str = "", date: str = "",
                   reliability: str = "", notes: str = "", url: str = "", credibility: str = "",
                   level: str = "", accessed_at: str = "", **extra) -> str:
        """reliability: A–F (Admiralty) ou texto; credibility: 1–6; level: primaria|secundaria."""
        sid = extra.pop("id", None) or self._next_id("sources")
        rel = str(reliability or "").strip()
        if rel.upper() in SOURCE_RELIABILITY:
            rel = rel.upper()
        cred = str(credibility or "").strip()
        if level:
            level = _canon(level, ["primaria", "secundaria"], "nível da fonte")
        obj = {"id": sid, "type": _canon(type, SOURCE_TYPES, "tipo de fonte"), "title": title,
               "reference": reference, "date": date, "reliability": rel, "credibility": cred, "level": level,
               "url": url, "accessed_at": accessed_at, "notes": notes, "created_by": self.user, "created_at": now_iso(), **extra}
        self.data["sources"].append(obj)
        self._audit("criação", "fonte", sid, after={"title": title})
        return sid

    def add_evidence(self, name: str, type: str = "outro", file_path: str | None = None,
                     source_id: str = "", origin: str = "", description: str = "",
                     acquired_at: str = "", created_at: str = "", entity_ids=None,
                     relationship_ids=None, custody=None, hash_algorithms=("sha256", "sha512"), **extra) -> str:
        did = extra.pop("id", None) or self._next_id("evidence")
        obj = {"id": did, "name": name, "type": _canon(type, EVIDENCE_TYPES, "tipo de evidência"),
               "origin": origin, "source_id": source_id, "description": description,
               "acquired_at": acquired_at or now_iso(), "created_at": created_at,
               "storage_path": file_path or "", "entity_ids": list(entity_ids or []),
               "relationship_ids": list(relationship_ids or []), "custody": list(custody or []),
               "hashes": {}, "hash_algorithm": "sha256", "size": None, "registered_by": self.user, "registered_at": now_iso(), **extra}
        if file_path and os.path.isfile(file_path):
            h = file_hashes(file_path, hash_algorithms)
            obj["size"] = h.pop("size")
            obj["hashes"] = h
            obj["custody"].append({"ts": now_iso(), "user": self.user, "action": "registro e cálculo de hash",
                                   "hashes": dict(h)})
        self.data["evidence"].append(obj)
        self._audit("criação", "evidência", did, after={"name": name, "hashes": obj["hashes"]})
        return did

    def add_entity(self, type: str, label: str, identifiers: dict | None = None, aliases=None,
                   attributes: dict | None = None, description: str = "", location: dict | None = None,
                   start: str = "", end: str = "", source_ids=None, evidence_ids=None,
                   nature: str | None = None, confidence=None, status: str | None = None,
                   tags=None, notes: str = "", **extra) -> str:
        t = strip_accents(type).lower().strip().replace(" ", "_").replace("-", "_")
        if t not in ENTITY_TYPES and t not in self.data["case"].get("custom_entity_types", {}):
            self.data["case"].setdefault("custom_entity_types", {})[t] = type
            self._audit("criação", "tipo de entidade", t, after={"label": type})
        eid = extra.pop("id", None) or self._next_id("entities")
        idents = {}
        for k, v in (identifiers or {}).items():
            idents[k] = v if isinstance(v, dict) and "original" in v else normalize(k, v)
        obj = {"id": eid, "type": t, "label": label, "label_normalized": normalize("nome", label)["normalized"],
               "identifiers": idents, "aliases": list(aliases or []), "description": description,
               "attributes": dict(attributes or {}), "location": location or {}, "start": start, "end": end,
               "source_ids": list(source_ids or []), "evidence_ids": list(evidence_ids or []),
               **self._epistemic(nature, confidence, status, source_ids),
               "tags": list(tags or []), "notes": notes, "created_by": self.user,
               "created_at": now_iso(), "updated_at": now_iso(), **extra}
        self.data["entities"].append(obj)
        self._audit("criação", "entidade", eid, after={"type": t, "label": label})
        return eid

    def add_relationship(self, source: str, type: str, target: str, directed: bool | None = None,
                         start: str = "", end: str = "", source_ids=None, evidence_ids=None,
                         nature: str | None = None, confidence=None, status: str | None = None,
                         notes: str = "", attributes: dict | None = None, origin: str = "manual",
                         **extra) -> str:
        s, t = self.entity(source), self.entity(target)
        if not s or not t:
            raise ValueError(f"Entidade não encontrada: {source if not s else target}")
        rtype = type.strip()
        if rtype not in RELATIONSHIP_TYPES and rtype not in self.data["case"].get("custom_relationship_types", []):
            self.data["case"].setdefault("custom_relationship_types", []).append(rtype)
        rid = extra.pop("id", None) or self._next_id("relationships")
        obj = {"id": rid, "type": rtype, "directed": (rtype not in UNDIRECTED_TYPES) if directed is None else directed,
               "source": s["id"], "target": t["id"], "start": start, "end": end,
               "source_ids": list(source_ids or []), "evidence_ids": list(evidence_ids or []),
               **self._epistemic(nature, confidence, status, source_ids),
               "notes": notes, "attributes": dict(attributes or {}), "origin": origin,
               "author": self.user, "created_at": now_iso(), "updated_at": now_iso(), **extra}
        self.data["relationships"].append(obj)
        self._audit("criação", "relacionamento", rid, after={"source": s["id"], "type": rtype, "target": t["id"]})
        return rid

    def add_observation(self, statement: str, entity_id: str = "", relationship_id: str = "",
                        attribute: str = "", value: Any = None, observed_at: str = "",
                        source_id: str = "", evidence_id: str = "", method: str = "",
                        confidence=None, nature: str | None = None, notes: str = "", **extra) -> str:
        oid = extra.pop("id", None) or self._next_id("observations")
        ep = self._epistemic(nature, confidence, None, [source_id] if source_id else [])
        obj = {"id": oid, "statement": statement, "entity_id": entity_id, "relationship_id": relationship_id,
               "attribute": attribute, "value": value, "observed_at": observed_at, "source_id": source_id,
               "evidence_id": evidence_id, "method": method, "nature": ep["nature"], "confidence": confidence,
               "author": self.user, "notes": notes, "created_at": now_iso(), **extra}
        self.data["observations"].append(obj)
        self._audit("criação", "observação", oid, after={"statement": statement})
        return oid

    def add_event(self, title: str, type: str = "personalizado", start: str = "", end: str = "",
                  participants=None, location: dict | None = None, relationship_ids=None,
                  source_ids=None, evidence_ids=None, description: str = "", confidence=None,
                  nature: str | None = None, status: str | None = None, attributes: dict | None = None,
                  **extra) -> str:
        evid = extra.pop("id", None) or self._next_id("events")
        s_iso, s_prec = parse_date(start) if start else (None, "desconhecida")
        e_iso, _ = parse_date(end) if end else (None, "")
        parts = []
        for p in participants or []:
            ent = self.entity(p)
            if not ent:
                raise ValueError(f"Participante não encontrado: {p}")
            parts.append(ent["id"])
        obj = {"id": evid, "title": title, "type": _canon(type, EVENT_TYPES, "tipo de evento"),
               "start": s_iso or "", "start_original": start, "end": e_iso or "", "date_precision": s_prec,
               "participants": parts, "location": location or {}, "relationship_ids": list(relationship_ids or []),
               "source_ids": list(source_ids or []), "evidence_ids": list(evidence_ids or []),
               "description": description, "attributes": dict(attributes or {}),
               **self._epistemic(nature, confidence, status, source_ids),
               "created_by": self.user, "created_at": now_iso(), **extra}
        self.data["events"].append(obj)
        self._audit("criação", "evento", evid, after={"title": title, "start": obj["start"]})
        return evid

    def add_analysis(self, type: str, method: str, result, input_entities=None, confidence=None,
                     limitations: str = "", nature: str = "inferencia", tool: str = "", tool_version: str = "",
                     parameters: dict | None = None, source_ids=None, evidence_ids=None, **extra) -> str:
        """Registro reproduzível de uma análise (contrato ANALYSIS): entrada, método, parâmetros, resultado, limitações."""
        aid = extra.pop("id", None) or self._next_id("analyses")
        obj = {"id": aid, "type": type, "method": method, "result": result, "input_entities": list(input_entities or []),
               "parameters": dict(parameters or {}), "confidence": confidence, "limitations": limitations,
               "nature": canon_nature(nature), "tool": tool, "tool_version": tool_version,
               "source_ids": list(source_ids or []), "evidence_ids": list(evidence_ids or []),
               "created_by": self.user, "created_at": now_iso(), **extra}
        self.data.setdefault("analyses", []).append(obj)
        self._audit("criação", "análise", aid, after={"type": type, "method": method})
        return aid

    def add_hypothesis(self, title: str, statement: str = "", supporting=None, contradicting=None,
                       gaps=None, confidence=None, status: str = "aberta", related_ids=None,
                       notes: str = "", **extra) -> str:
        hid = extra.pop("id", None) or self._next_id("hypotheses")
        obj = {"id": hid, "title": title, "statement": statement or title,
               "supporting": list(supporting or []), "contradicting": list(contradicting or []),
               "gaps": list(gaps or []), "confidence": confidence,
               "status": _canon(status, HYPOTHESIS_STATUSES, "status da hipótese"),
               "related_ids": list(related_ids or []), "notes": notes,
               "created_by": self.user, "created_at": now_iso(), "updated_at": now_iso(), **extra}
        self.data["hypotheses"].append(obj)
        self._audit("criação", "hipótese", hid, after={"title": title})
        return hid

    def add_osint_query(self, query: str, tool: str, result_summary: str, entity_ids=None,
                        evidence_id: str = "", limitations: str = "", date: str = "", legal_basis: str = "",
                        **extra) -> str:
        qid = extra.pop("id", None) or self._next_id("osint_queries")
        obj = {"id": qid, "query": query, "tool": tool, "date": date or now_iso(),
               "result_summary": result_summary, "entity_ids": list(entity_ids or []),
               "evidence_id": evidence_id, "limitations": limitations, "legal_basis": legal_basis,
               "user": self.user, **extra}
        self.data["osint_queries"].append(obj)
        self._audit("consulta externa", "consulta OSINT", qid, after={"query": query, "tool": tool})
        return qid

    # ---------- edição ----------
    def update(self, obj_id: str, changes: dict, reason: str = "") -> dict:
        coll, obj = self.get(obj_id)
        if not obj:
            raise ValueError(f"Objeto não encontrado: {obj_id}")
        before = {k: copy.deepcopy(obj.get(k)) for k in changes}
        if "nature" in changes:
            changes["nature"] = canon_nature(changes["nature"])
            # Promoção para "fato" exige registro explícito de quem confirmou e por quê
            if changes["nature"] in FACTUAL_NATURES and before.get("nature") in ("correlacao", "inferencia", "hipotese"):
                if not reason:
                    raise ValueError("Promover inferência/correlação/hipótese a fato exige 'reason' "
                                     "(fundamentação e evidência que a confirma).")
                obj["promoted_from"] = {"nature": before["nature"], "by": self.user, "at": now_iso(), "reason": reason}
        if "status" in changes and coll != "hypotheses":
            changes["status"] = _canon(changes["status"], STATUSES, "status")
        obj.update(changes)
        if "updated_at" in obj or coll in ("entities", "relationships", "hypotheses"):
            obj["updated_at"] = now_iso()
        self._audit("edição", coll, obj_id, before=before, after=changes, reason=reason)
        return obj

    def delete(self, obj_id: str, reason: str = "") -> None:
        coll, obj = self.get(obj_id)
        if not obj:
            raise ValueError(f"Objeto não encontrado: {obj_id}")
        self.data[coll].remove(obj)
        removed = [obj_id]
        if coll == "entities":
            for r in list(self.data["relationships"]):
                if r["source"] == obj_id or r["target"] == obj_id:
                    self.data["relationships"].remove(r)
                    removed.append(r["id"])
        self._audit("exclusão", coll, obj_id, before=obj, reason=reason,
                    after={"cascata": removed[1:]} if len(removed) > 1 else None)

    def merge_entities(self, keep_id: str, merge_id: str, reason: str, decision: dict | None = None) -> dict:
        """Mescla merge_id em keep_id. Exige motivo (decisão humana). Preserva aliases, identificadores,
        fontes e evidências; atributos divergentes viram observações de CONTRADIÇÃO (os dois valores ficam);
        registra merged_from com o snapshot e os objetos movidos — unmerge_entity desfaz exatamente."""
        if not reason:
            raise ValueError("Mesclagem exige motivo: nunca mesclar só por similaridade.")
        keep, other = self.entity(keep_id), self.entity(merge_id)
        if not keep or not other:
            raise ValueError("Entidade não encontrada para mesclagem")
        if keep["id"] == other["id"]:
            raise ValueError("Não é possível mesclar uma entidade com ela mesma")
        snapshot = copy.deepcopy(other)
        keep_before = {k: copy.deepcopy(keep.get(k)) for k in ("label", "aliases", "identifiers", "attributes", "source_ids",
                                                                "evidence_ids", "tags")}
        keep.setdefault("aliases", [])
        for name in [other["label"]] + other.get("aliases", []):
            if name != keep["label"] and name not in keep["aliases"]:
                keep["aliases"].append(name)
        conflicts = []
        for k, v in other.get("identifiers", {}).items():
            if k in keep["identifiers"] and keep["identifiers"][k].get("normalized") != v.get("normalized"):
                keep["identifiers"][f"{k}__{other['id']}"] = v  # valor conflitante preservado
                conflicts.append((k, keep["identifiers"][k].get("original"), v.get("original")))
            else:
                keep["identifiers"].setdefault(k, v)
        for fld in ("source_ids", "evidence_ids", "tags"):
            keep[fld] = list(dict.fromkeys(keep.get(fld, []) + other.get(fld, [])))
        for k, v in other.get("attributes", {}).items():
            old = keep["attributes"].get(k)
            if old in (None, "", [], {}):
                keep["attributes"][k] = v
            elif str(old).strip().lower() != str(v).strip().lower():
                conflicts.append((k, old, v))
        moved = {"rel_source": [], "rel_target": [], "events": [], "observations": [], "evidence": []}
        for r in self.data["relationships"]:
            if r["source"] == other["id"]:
                r["source"] = keep["id"]; moved["rel_source"].append(r["id"])
            if r["target"] == other["id"]:
                r["target"] = keep["id"]; moved["rel_target"].append(r["id"])
        for ev in self.data["events"]:
            if other["id"] in ev["participants"]:
                had_keep = keep["id"] in ev["participants"]
                ev["participants"] = list(dict.fromkeys(keep["id"] if p == other["id"] else p for p in ev["participants"]))
                moved["events"].append([ev["id"], had_keep])
        for o in self.data["observations"]:
            if o.get("entity_id") == other["id"]:
                o["entity_id"] = keep["id"]; moved["observations"].append(o["id"])
        for d in self.data["evidence"]:
            if other["id"] in d["entity_ids"]:
                d["entity_ids"] = list(dict.fromkeys(keep["id"] if x == other["id"] else x for x in d["entity_ids"]))
                moved["evidence"].append(d["id"])
        obs_ids = []
        for k, a_val, b_val in conflicts:
            obs_ids.append(self.add_observation(
                f"CONTRADIÇÃO após mesclagem de {other['id']} em {keep['id']}: {k} = {a_val!r} ({keep['id']}) × {b_val!r} "
                f"({other['id']}). Os dois valores foram preservados; nenhum foi escolhido automaticamente.",
                entity_id=keep["id"], attribute=k, value=b_val, method="merge_entities", nature="correlacao"))
        keep.setdefault("merged_from", []).append({"entity": snapshot, "keep_before": keep_before, "moved": moved,
                                                   "contradiction_observations": obs_ids, "by": self.user, "at": now_iso(),
                                                   "reason": reason, "decision": decision or {}})
        self.data["entities"].remove(other)
        self._audit("merge", "entidade", keep["id"], before={"merged": other["id"]},
                    after={"into": keep["id"], "moved": moved, "conflicts": len(conflicts)}, reason=reason)
        return keep

    def unmerge_entity(self, keep_id: str, merged_id: str, reason: str) -> dict:
        """Desfaz uma mesclagem registrada em merged_from: recria a entidade e devolve-lhe os objetos movidos."""
        if not reason:
            raise ValueError("Desfazer mesclagem exige motivo.")
        keep = self.entity(keep_id)
        if not keep:
            raise ValueError("Entidade não encontrada")
        idx = next((i for i, m in enumerate(keep.get("merged_from", [])) if m["entity"]["id"] == merged_id), None)
        if idx is None:
            raise ValueError(f"{merged_id} não consta como mesclada em {keep_id}")
        rec = keep["merged_from"].pop(idx)
        restored = copy.deepcopy(rec["entity"])
        if any(e["id"] == restored["id"] for e in self.data["entities"]):
            raise ValueError(f"Já existe entidade com id {restored['id']}")
        self.data["entities"].append(restored)
        mv = rec.get("moved", {})
        for r in self.data["relationships"]:
            if r["id"] in mv.get("rel_source", []):
                r["source"] = restored["id"]
            if r["id"] in mv.get("rel_target", []):
                r["target"] = restored["id"]
        evmap = {e_id: had for e_id, had in mv.get("events", [])}
        for ev in self.data["events"]:
            if ev["id"] in evmap:
                if evmap[ev["id"]]:
                    ev["participants"].append(restored["id"])
                else:
                    ev["participants"] = [restored["id"] if p == keep["id"] else p for p in ev["participants"]]
        for o in self.data["observations"]:
            if o["id"] in mv.get("observations", []):
                o["entity_id"] = restored["id"]
        for d in self.data["evidence"]:
            if d["id"] in mv.get("evidence", []) and restored["id"] not in d["entity_ids"]:
                d["entity_ids"].append(restored["id"])
        kb = rec.get("keep_before")
        if kb:
            for k, v in kb.items():
                keep[k] = v
        for oid in rec.get("contradiction_observations", []):
            _, o = self.get(oid)
            if o:
                o["status"] = "arquivado"
                o["notes"] = (o.get("notes", "") + f" Mesclagem desfeita: {reason}").strip()
        self._audit("unmerge", "entidade", keep["id"], before={"merged": merged_id}, after={"restored": restored["id"]}, reason=reason)
        return restored

    # ---------- snapshots ----------
    def snapshot(self, label: str = "", directory: str | None = None) -> str:
        directory = directory or os.path.join(os.path.dirname(os.path.abspath(self.path or ".")), "snapshots")
        os.makedirs(directory, exist_ok=True)
        sid = self._next_id("snapshots")
        payload = copy.deepcopy(self.data)
        payload["snapshots"] = []
        blob = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True).encode()
        digest = hashlib.sha256(blob).hexdigest()
        fname = os.path.join(directory, f"{sid}_{_dt.datetime.now():%Y%m%d-%H%M%S}.json")
        with open(fname, "wb") as fh:
            fh.write(blob)
        self.data["snapshots"].append({"id": sid, "label": label, "created_at": now_iso(), "sha256": digest,
                                       "path": fname, "counts": self.counts()})
        self._audit("snapshot", "caso", sid, after={"label": label, "sha256": digest})
        return sid

    def restore_snapshot(self, snapshot_id: str, reason: str = "") -> None:
        snap = next((s for s in self.data["snapshots"] if s["id"] == snapshot_id), None)
        if not snap:
            raise ValueError("Snapshot não encontrado")
        with open(snap["path"], "rb") as fh:
            blob = fh.read()
        if hashlib.sha256(blob).hexdigest() != snap["sha256"]:
            raise ValueError("Integridade do snapshot comprometida: hash divergente")
        restored = json.loads(blob)
        keep_snaps, keep_audit = self.data["snapshots"], self.data["audit_log"]
        self.data = restored
        self.data["snapshots"] = keep_snaps
        self.data["audit_log"] = keep_audit
        self._audit("restauração", "caso", snapshot_id, reason=reason)

    def counts(self) -> dict:
        return {k: len(self.data.get(k, [])) for k in ID_PREFIX if k != "snapshots"}

    # ---------- validação epistemológica ----------
    def validate(self) -> list[dict]:
        """Retorna lista de achados {nivel, objeto, mensagem}. Não altera o caso."""
        out = []
        ids = set()
        def add(level, oid, msg):
            out.append({"level": level, "object": oid, "message": msg})
        for coll in ID_PREFIX:
            for obj in self.data.get(coll, []):
                if obj.get("id") in ids:
                    add("erro", obj.get("id"), "ID duplicado")
                ids.add(obj.get("id"))
        ent_ids = {e["id"] for e in self.data["entities"]}
        src_ids = {s["id"] for s in self.data["sources"]}
        ev_ids = {d["id"] for d in self.data["evidence"]}
        for coll in ("entities", "relationships", "events"):
            for o in self.data[coll]:
                if o.get("nature") not in NATURES:
                    add("erro", o["id"], f"natureza ausente ou inválida: {o.get('nature')!r}")
                if o.get("status") not in STATUSES:
                    add("erro", o["id"], f"status inválido: {o.get('status')!r}")
                for s in o.get("source_ids", []):
                    if s not in src_ids:
                        add("erro", o["id"], f"fonte inexistente referenciada: {s}")
                for d in o.get("evidence_ids", []):
                    if d not in ev_ids:
                        add("erro", o["id"], f"evidência inexistente referenciada: {d}")
                if o.get("nature") in FACTUAL_NATURES and not o.get("source_ids") and not o.get("evidence_ids"):
                    add("alerta", o["id"], f"marcado como {NATURES[o['nature']].upper()} sem fonte nem evidência")
                if o.get("nature") in ("inferencia", "correlacao", "hipotese") and o.get("status") == "confirmado" \
                        and not o.get("promoted_from") and not o.get("confirmed_by"):
                    add("alerta", o["id"], f"{NATURES[o['nature']]} com status 'confirmado' sem registro de "
                                           "confirmação humana (confirmed_by/promoted_from)")
        for r in self.data["relationships"]:
            for end in ("source", "target"):
                if r[end] not in ent_ids:
                    add("erro", r["id"], f"{end} aponta para entidade inexistente {r[end]}")
            if not r.get("source_ids") and not r.get("evidence_ids"):
                add("lacuna", r["id"], "relação sem fonte e sem evidência")
        for ev in self.data["events"]:
            for p in ev.get("participants", []):
                if p not in ent_ids:
                    add("erro", ev["id"], f"participante inexistente {p}")
        for h in self.data["hypotheses"]:
            for ref in h.get("supporting", []) + h.get("contradicting", []):
                if self.get(ref)[1] is None:
                    add("erro", h["id"], f"hipótese referencia objeto inexistente {ref}")
            if h.get("status") == "confirmada" and not h.get("supporting"):
                add("alerta", h["id"], "hipótese confirmada sem evidências favoráveis vinculadas")
        for d in self.data["evidence"]:
            if d.get("storage_path") and not d.get("hashes"):
                add("alerta", d["id"], "evidência com arquivo sem hash registrado")
            if d.get("hashes") and "sha256" not in d["hashes"]:
                add("alerta", d["id"], "evidência sem SHA-256 (MD5 apenas como referência legada)")
        for e in self.data["entities"]:
            for k, v in e.get("identifiers", {}).items():
                if isinstance(v, dict) and v.get("valid") is False:
                    add("alerta", e["id"], f"identificador {k}={v.get('original')!r} não passou na validação")
        return out
