"""
bundle_import.py — Importa bundles `intel-bundle/1.0` das skills de inteligência para o caso.

Entity resolution entre skills:
  * entidades/indicadores: reaproveita a existente quando um IDENTIFICADOR FORTE normalizado
    coincide (CPF, CNPJ, telefone, e-mail, IP, domínio, URL, placa, PIX, conta completa,
    hash, processo, perfil...). Nomes iguais NÃO são mesclados (homônimos) — ficam para o
    Smart Match e a decisão humana;
  * fontes: mesmo (tipo, título, referência); evidências: mesmo SHA-256;
  * relações: mesma (origem, tipo, destino, início, valor, txid) → une fontes/evidências/proveniência;
  * eventos: mesmo (tipo, início, participantes, valor).
A natureza de um item existente nunca é promovida pelo bundle; divergências de atributos
viram OBSERVAÇÕES (a detecção de contradições as encontra).
"""
from __future__ import annotations

import json
import os
import re

from case_model import Case, canon_nature, normalize, now_iso, strip_accents

CONTRACT = "intel-bundle/1.0"
STRONG = {"cpf", "cnpj", "telefone", "email", "ip", "prefixo_ip", "dominio", "url", "placa", "pix", "imei", "mac",
          "asn", "sha256", "sha1", "md5", "sha512", "conta_bancaria", "processo", "perfil", "username", "e2e",
          "chassi", "renavam", "certificado_sha256", "pacote_android", "caso_ref"}
IOC_ENTITY_TYPE = {"ip": "ip", "ipv4": "ip", "ipv6": "ip", "domain": "dominio", "dominio": "dominio", "url": "url",
                   "email": "email", "hash": "hash", "sha256": "hash", "sha1": "hash", "md5": "hash",
                   "file": "arquivo", "arquivo": "arquivo", "certificate": "certificado", "certificado": "certificado",
                   "mutex": "mutex", "registry": "chave_registro", "chave_registro": "chave_registro", "asn": "asn",
                   "apk": "aplicativo", "pacote_android": "aplicativo"}


def _keys(identifiers: dict) -> list[tuple]:
    out = []
    for k, v in (identifiers or {}).items():
        kk = k.split("__")[0]
        if kk not in STRONG:
            continue
        n = v.get("normalized") if isinstance(v, dict) else normalize(kk, v)["normalized"]
        if n and "?" not in str(n):
            out.append((kk, str(n)))
    return out


_STOP = {"DA", "DE", "DO", "DAS", "DOS", "E"}


def _names_compatible(a: str, b: str) -> bool:
    """Contenção de tokens (João Silva ⊂ João da Silva Ferreira); abreviações de 1 letra aceitas."""
    def toks(s):
        return [t for t in re.sub(r"[^A-Z0-9 ]", " ", strip_accents(s or "").upper()).split() if t not in _STOP]
    ta, tb = toks(a), toks(b)
    if not ta or not tb:
        return True
    short, long_ = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
    hit = sum(any(y == x or (len(x) == 1 and y.startswith(x)) or (len(y) == 1 and x.startswith(y)) for y in long_) for x in short)
    return hit / len(short) >= 0.75 and ta[0][0] == tb[0][0]


def _index(case: Case) -> dict:
    idx = {}
    for e in case.data["entities"]:
        for key in _keys(e.get("identifiers", {})):
            idx.setdefault(key, [])
            if e["id"] not in idx[key]:
                idx[key].append(e["id"])
    return idx


def _union(obj: dict, field: str, values) -> None:
    if values:
        obj[field] = list(dict.fromkeys(list(obj.get(field) or []) + [v for v in values if v]))


def import_bundle(case: Case, bundle: dict, dry_run: bool = False) -> dict:
    if bundle.get("contract") != CONTRACT:
        raise ValueError(f"Contrato não suportado: {bundle.get('contract')!r}")
    producer = bundle.get("producer", "?")
    refs: dict[str, str] = {}
    stats = {"criados": {}, "reaproveitados": {}, "observacoes_de_divergencia": 0, "ignorados": []}
    def bump(kind, what):
        stats[kind][what] = stats[kind].get(what, 0) + 1

    REF_FIELDS = ("source", "target", "entity_id", "source_id", "evidence_id", "relationship_id")
    REF_LISTS = ("source_ids", "evidence_ids", "participants", "supporting", "contradicting", "entity_ids", "input_entities",
                 "relationship_ids")

    def _r(v):
        if isinstance(v, str) and v.startswith("@"):
            if v[1:] not in refs:
                raise ValueError(f"referência não resolvida {v}")
            return refs[v[1:]]
        return v

    def R(item):
        # só campos de referência são resolvidos: rótulos como "@usuario" ficam intactos
        for f in REF_FIELDS:
            if f in item:
                item[f] = _r(item[f])
        for f in REF_LISTS:
            if isinstance(item.get(f), list):
                item[f] = [_r(x) for x in item[f]]
        return item

    idx = _index(case)
    src_idx = {(s["type"], s["title"], s.get("reference", "")): s["id"] for s in case.data["sources"]}
    ev_idx = {d.get("hashes", {}).get("sha256"): d["id"] for d in case.data["evidence"] if d.get("hashes", {}).get("sha256")}
    rel_idx = {(r["source"], r["type"], r["target"], r.get("start", ""), str((r.get("attributes") or {}).get("amount", "")),
                str((r.get("attributes") or {}).get("txid", ""))): r for r in case.data["relationships"]}
    evt_idx = {(e["type"], e.get("start", ""), tuple(sorted(e.get("participants", []))),
                str((e.get("attributes") or {}).get("amount", ""))): e for e in case.data["events"]}
    meta_note = {"bundle_producer": producer, "bundle_generated_at": bundle.get("generated_at"),
                 "bundle_case_ref": bundle.get("case_ref")}

    for it in bundle.get("items", []):
        it = dict(it)
        op, ref = it.pop("op"), it.pop("ref", None)
        it = R(it)
        if it.get("nature") not in (None, ""):
            it["nature"] = canon_nature(it["nature"])  # aceita OFFICIAL/OBSERVED/… do contrato
        new_id = None
        if op == "source":
            key = (it["type"], it["title"], it.get("reference", ""))
            if key in src_idx:
                new_id = src_idx[key]; bump("reaproveitados", "fontes")
            else:
                if bundle.get("legal_basis") and "legal_basis" not in it:
                    it["legal_basis"] = bundle["legal_basis"]
                new_id = case.add_source(producer_meta=meta_note, **it); src_idx[key] = new_id; bump("criados", "fontes")
        elif op == "evidence":
            sha = it.pop("sha256", "")
            fp = it.pop("file_path", None)
            if sha and sha in ev_idx:
                new_id = ev_idx[sha]; bump("reaproveitados", "evidências")
            else:
                new_id = case.add_evidence(file_path=fp, **it)
                d = case.get(new_id)[1]
                if sha and not d.get("hashes"):
                    d["hashes"] = {"sha256": sha}
                    d["custody"].append({"ts": now_iso(), "user": case.user, "action": f"hash informado por {producer}"})
                elif sha and d["hashes"].get("sha256") and d["hashes"]["sha256"] != sha:
                    d.setdefault("integrity_alerts", []).append(f"SHA-256 do arquivo difere do informado por {producer}: {sha}")
                h = d.get("hashes", {}).get("sha256")
                if h:
                    ev_idx[h] = new_id
                bump("criados", "evidências")
        elif op in ("entity", "indicator"):
            prov = it.pop("provenance", [])
            if op == "indicator":
                it.setdefault("tags", [])
                if "IOC" not in it["tags"]:
                    it["tags"].append("IOC")
                if it.get("type") in (None, "", "indicador"):
                    it["type"] = IOC_ENTITY_TYPE.get((it.get("attributes") or {}).get("ioc_type", ""), "indicador")
            existing_id = it.pop("existing_id", None)
            match = existing_id if existing_id and case.get(existing_id)[1] is not None else None
            if match and case.get(match)[1]["type"] != it.get("type"):
                stats["ignorados"].append(f"existing_id {existing_id} é {case.get(match)[1]['type']}, não {it.get('type')} "
                                          f"({it.get('label')}) — vínculo ignorado")
                match = None
            if not match:
                cands = [c for k in _keys(it.get("identifiers", {})) for c in idx.get(k, [])]
                cands = list(dict.fromkeys(c for c in cands if case.get(c)[1] is not None))
                # só unifica com entidade do MESMO tipo (uma empresa não vira o nó "CNPJ" nem o nó "telefone")
                cands = [c for c in cands if case.get(c)[1]["type"] == it.get("type")]
                if it.get("type") in ("pessoa", "empresa"):
                    # identificador disputado (ex.: mesmo CPF em duas pessoas): prefere o candidato com nome compatível
                    ok = [c for c in cands if case.get(c)[1]["type"] not in ("pessoa", "empresa")
                          or _names_compatible(case.get(c)[1]["label"], it.get("label", ""))]
                    match = ok[0] if ok else (cands[0] if cands else None)
                else:
                    match = cands[0] if cands else None
            if not match and it.get("type") == "conta_bancaria" and (it.get("identifiers") or {}).get("conta_bancaria"):
                # conta com banco ausente em uma das fontes: unifica por agência + conta se houver candidato único compatível
                b_, a_, c_ = normalize("conta_bancaria", it["identifiers"]["conta_bancaria"])["normalized"].split("|")
                if a_ != "?" and c_ != "?":
                    cands = []
                    for e in case.data["entities"]:
                        v = (e.get("identifiers") or {}).get("conta_bancaria")
                        if e["type"] == "conta_bancaria" and v:
                            b2, a2, c2 = (v.get("normalized") if isinstance(v, dict) else normalize("conta_bancaria", v)["normalized"]).split("|")
                            if a2 == a_ and c2 == c_ and (b_ == "?" or b2 == "?" or b_ == b2):
                                cands.append(e["id"])
                    if len(cands) == 1:
                        match = cands[0]
                        it.setdefault("notes", "")
                        case.add_observation(f"Conta unificada por agência+conta ({a_}/{c_}) com banco ausente em uma das fontes "
                                             f"({producer}). Confirmar instituição.", entity_id=match, attribute="unificacao_conta",
                                             value=it["identifiers"]["conta_bancaria"], method=f"import-bundle {producer}", nature="correlacao")
            conflict = None
            if match and it.get("type") in ("pessoa", "empresa"):
                ex = case.get(match)[1]
                if ex["type"] in ("pessoa", "empresa") and not _names_compatible(ex["label"], it.get("label", "")):
                    conflict, match = ex, None   # mesmo CPF/CNPJ, nomes incompatíveis: NÃO unifica
            if match:
                e = case.get(match)[1]
                _union(e, "source_ids", it.get("source_ids")); _union(e, "evidence_ids", it.get("evidence_ids"))
                _union(e, "tags", it.get("tags")); e.setdefault("provenance", []).extend(prov)
                for name in [it.get("label")] + list(it.get("aliases") or []):
                    if name and name != e["label"] and name not in e.get("aliases", []):
                        e.setdefault("aliases", []).append(name)
                for k, v in (it.get("identifiers") or {}).items():
                    if k not in e["identifiers"]:
                        e["identifiers"][k] = v if isinstance(v, dict) and "original" in v else normalize(k.split("__")[0], v)
                for k, v in (it.get("attributes") or {}).items():
                    old = e.setdefault("attributes", {}).get(k)
                    if old in (None, ""):
                        e["attributes"][k] = v
                    elif str(old).strip().lower() != str(v).strip().lower() and k not in ("context", "tlp", "ioc_type"):
                        case.add_observation(f"{producer} registrou {k} = {v!r} para {e['label']} (valor existente: {old!r})",
                                             entity_id=e["id"], attribute=k, value=v,
                                             source_id=(it.get("source_ids") or [""])[0], method=f"import-bundle {producer}",
                                             nature=it.get("nature"), provenance=prov)
                        stats["observacoes_de_divergencia"] += 1
                if it.get("location") and not e.get("location"):
                    e["location"] = it["location"]
                case._audit("importação (bundle)", "entidade", e["id"], after={"reaproveitada_por": producer})
                new_id = match; bump("reaproveitados", "entidades")
            else:
                it.pop("identifiers_normalized", None)
                if conflict:
                    it["status"] = "contraditorio"
                new_id = case.add_entity(provenance=prov, origin_bundle=meta_note, **it)
                for k in _keys(case.get(new_id)[1]["identifiers"]):
                    idx.setdefault(k, []).append(new_id)
                if conflict:
                    case.update(conflict["id"], {"status": "contraditorio"}, reason=f"identificador compartilhado com {new_id} ({producer})")
                    case.add_observation(f"CONTRADIÇÃO: {it.get('label')} ({new_id}, via {producer}) e {conflict['label']} ({conflict['id']}) "
                                         f"compartilham identificador {', '.join(k[0].upper() + ' ' + k[1] for k in _keys(it.get('identifiers', {})))} "
                                         f"com nomes incompatíveis — entidades mantidas separadas.", entity_id=new_id,
                                         attribute="identificador_compartilhado", value=conflict["id"], method=f"import-bundle {producer}",
                                         nature="correlacao", provenance=prov)
                    stats["observacoes_de_divergencia"] += 1
                bump("criados", "indicadores" if op == "indicator" else "entidades")
        elif op in ("rel", "relationship"):
            prov = it.pop("provenance", [])
            key = (it["source"], it["type"], it["target"], it.get("start", ""),
                   str((it.get("attributes") or {}).get("amount", "")), str((it.get("attributes") or {}).get("txid", "")))
            if key in rel_idx:
                r = rel_idx[key]
                _union(r, "source_ids", it.get("source_ids")); _union(r, "evidence_ids", it.get("evidence_ids"))
                r.setdefault("provenance", []).extend(prov)
                new_id = r["id"]; bump("reaproveitados", "relações")
            else:
                src, tgt, rtype = it.pop("source"), it.pop("target"), it.pop("type")
                new_id = case.add_relationship(src, rtype, tgt, provenance=prov, origin=f"bundle:{producer}", **it)
                rel_idx[key] = case.get(new_id)[1]; bump("criados", "relações")
        elif op == "event":
            prov = it.pop("provenance", [])
            key = (it.get("type", "personalizado"), it.get("start", ""), tuple(sorted(it.get("participants", []))),
                   str((it.get("attributes") or {}).get("amount", "")))
            e_start = it.get("start", "")
            existing = next((e for k, e in evt_idx.items() if k[0] == key[0] and k[2] == key[2] and k[3] == key[3]
                             and (k[1] == e_start or (k[1] or "")[:16] == (e_start or "")[:16])), None)
            if existing:
                _union(existing, "source_ids", it.get("source_ids")); _union(existing, "evidence_ids", it.get("evidence_ids"))
                existing.setdefault("provenance", []).extend(prov)
                new_id = existing["id"]; bump("reaproveitados", "eventos")
            else:
                title = it.pop("title")
                new_id = case.add_event(title, provenance=prov, **it)
                e = case.get(new_id)[1]
                evt_idx[(e["type"], e.get("start", ""), tuple(sorted(e.get("participants", []))),
                         str((e.get("attributes") or {}).get("amount", "")))] = e
                bump("criados", "eventos")
        elif op in ("obs", "observation"):
            new_id = case.add_observation(**it); bump("criados", "observações")
        elif op == "hypothesis":
            new_id = case.add_hypothesis(**it); bump("criados", "hipóteses")
        elif op == "osint":
            new_id = case.add_osint_query(**it); bump("criados", "consultas")
        elif op == "analysis":
            t, m, res = it.pop("type", "analise"), it.pop("method", producer), it.pop("result", "")
            it.pop("provenance", None)
            new_id = case.add_analysis(t, m, res, tool=it.pop("tool", producer), **it); bump("criados", "análises")
        else:
            stats["ignorados"].append(op)
            continue
        if ref:
            refs[ref] = new_id
    case._audit("importação", "bundle", bundle.get("producer"),
                after={"contrato": CONTRACT, "gerado_em": bundle.get("generated_at"), "case_ref": bundle.get("case_ref"),
                       "legal_basis": bundle.get("legal_basis"), "resumo": {k: v for k, v in stats.items() if k != "ignorados"}})
    stats["refs"] = refs
    return stats
