"""
report.py — Relatório automático (Fase 6.9/6.10) em Markdown.

Gera as seções a partir dos DADOS e da ANÁLISE. Partes que exigem juízo
(objetivo, resumo executivo, conclusões) recebem marcadores [ANALISTA: ...]
para serem redigidas pelo analista ou pela IA seguindo o formato explicável
(conclusão / evidências / tipo / confiança / limitações / fontes).
Converter para DOCX/PDF com as skills docx/pdf ou com pandoc.
"""
from __future__ import annotations

import json
from case_model import fmt_brl, CONFIDENCE_LEVELS, ENTITY_TYPES, NATURES, STATUSES, confidence_label, now_iso

NATURE_ICON = {"fato": "■", "observado": "●", "declarado": "◆", "correlacao": "◇", "inferencia": "△", "hipotese": "?", "nao_verificado": "○"}


def _lbl(case, oid):
    for coll in ("entities", "events", "sources", "evidence", "relationships", "hypotheses"):
        for o in case.get(coll, []):
            if o["id"] == oid:
                return o.get("label") or o.get("title") or o.get("name") or o.get("type") or oid
    return oid


def _ent(case, oid):
    return f"{_lbl(case, oid)} ({oid})"


def _tbl(header, rows):
    out = ["| " + " | ".join(header) + " |", "|" + "---|" * len(header)]
    for r in rows:
        out.append("| " + " | ".join(str(c).replace("|", "/").replace("\n", " ") for c in r) + " |")
    return "\n".join(out) if rows else "_Nenhum registro._"


def build_report(case: dict, analysis: dict, top_n: int = 15) -> str:
    c = case["case"]
    net = analysis["network"]
    L = []
    L.append(f"# Relatório de Análise Investigativa — {c['title']}\n")
    L.append(f"**Classificação:** {c.get('classification', '')}  \n**Caso:** {c['id']}  \n"
             f"**Gerado em:** {now_iso()}  \n**Versão dos dados:** última atualização {c.get('updated_at')}"
             + (f"; snapshot {case['snapshots'][-1]['id']} (SHA-256 {case['snapshots'][-1]['sha256'][:16]}…)"
                if case.get("snapshots") else "") + "\n")
    L.append("> **Legenda de natureza:** " + " · ".join(f"{NATURE_ICON[k]} {v}" for k, v in NATURES.items()) +
             "\n> Os resultados computacionais deste relatório são correlações ou inferências sobre os dados "
             "registrados; não substituem a valoração do analista nem da autoridade competente.\n")

    L.append("## 1. Identificação do caso\n")
    L.append(_tbl(["Campo", "Valor"], [
        ["Título", c["title"]], ["Identificador", c["id"]], ["Responsável", c.get("lead", "")],
        ["Equipe", ", ".join(c.get("team", [])) or "—"], ["Status", {"aberto": "Aberto", "em_analise": "Em análise", "suspenso": "Suspenso", "concluido": "Concluído", "arquivado": "Arquivado"}.get(c.get("status"), c.get("status", ""))],
        ["Classificação", c.get("classification", "")], ["Criado em", c.get("created_at", "")],
        ["Tags", ", ".join(c.get("tags", []))]]))
    L.append("\n## 2. Objetivo\n")
    L.append(c.get("objective") or "[ANALISTA: delimitar o objetivo da análise e as perguntas a responder]")
    L.append("\n## 3. Resumo executivo\n")
    s = net["summary"]
    L.append(f"Base analisada: {len(case['entities'])} entidades, {len(case['relationships'])} relações, "
             f"{len(case['events'])} eventos, {len(case['sources'])} fontes, {len(case['evidence'])} evidências e "
             f"{len(case['hypotheses'])} hipóteses. A rede possui {s.get('components', 0)} componente(s) conectado(s), "
             f"{s.get('communities', 0)} comunidade(s) detectada(s) e densidade {s.get('density', 0)}. "
             f"Foram sinalizadas {len(analysis['contradictions'])} contradição(ões), "
             f"{len(analysis['smart_match'])} possível(is) duplicidade(s) e {len(analysis['anomalies'])} anomalia(s).\n")
    L.append("[ANALISTA: síntese dos achados relevantes em 5–10 linhas, cada afirmação com sua natureza "
             "(fato/declarado/correlação/inferência/hipótese)]\n")

    L.append("## 4. Entidades principais\n")
    rows = []
    for nid, d in sorted(net["nodes"].items(), key=lambda x: (-x[1]["betweenness"], -x[1]["degree"]))[:top_n]:
        e = next((x for x in case["entities"] if x["id"] == nid), {})
        rows.append([nid, d["label"], ENTITY_TYPES.get(d["type"], d["type"]), d["degree"], d["betweenness"],
                     d["pagerank"], d["community"], NATURES.get(e.get("nature"), ""), len(e.get("source_ids", []))])
    L.append(_tbl(["ID", "Entidade", "Tipo", "Grau", "Intermediação", "PageRank", "Comunidade", "Natureza", "Fontes"], rows))
    L.append("\n_Critério de ordenação: intermediação (betweenness) e grau. " + net["interpretation"]["aviso"] + "_\n")
    if net.get("articulation_points"):
        L.append("**Pontos de articulação** (sua remoção fragmenta a rede): " +
                 ", ".join(_ent(case, x) for x in net["articulation_points"]) + "\n")

    L.append("## 5. Relacionamentos principais\n")
    rels = sorted(case["relationships"], key=lambda r: (-(len(r.get("evidence_ids", [])) + len(r.get("source_ids", []))), r["id"]))
    L.append(_tbl(["ID", "Origem", "Relação", "Destino", "Período", "Natureza", "Confiança", "Status", "Fontes", "Evidências"],
                  [[r["id"], _lbl(case, r["source"]), r["type"], _lbl(case, r["target"]),
                    f"{r.get('start') or '?'} → {r.get('end') or '…'}", f"{NATURE_ICON.get(r.get('nature'), '')} {NATURES.get(r.get('nature'), '')}",
                    confidence_label(r.get("confidence")), STATUSES.get(r.get("status"), ""),
                    ", ".join(r.get("source_ids", [])) or "—", ", ".join(r.get("evidence_ids", [])) or "—"] for r in rels[:top_n * 2]]))

    L.append("\n## 6. Linha do tempo\n")
    from analyze import timeline
    tl = timeline(case)
    L.append(_tbl(["Data", "Precisão", "Tipo", "Descrição", "Envolvidos", "Natureza", "ID"],
                  [[i.get("start") or "desconhecida", i.get("precision") or "—", i["type"],
                    i["title"] if i["kind"] == "evento" else f"{_lbl(case, i['entities'][0])} {i['type']} {_lbl(case, i['entities'][1])}",
                    ", ".join(_lbl(case, e) for e in i["entities"]), NATURES.get(i.get("nature"), ""), i["id"]] for i in tl]))
    t = analysis["temporal"]
    if t.get("simultaneous"):
        L.append("\n**Eventos simultâneos/próximos:** " + "; ".join(
            f"{a['events'][0]} e {a['events'][1]} ({a['minutes_apart']} min)" for a in t["simultaneous"]))
    L.append(f"\n_{t['caveat']}_\n")

    sp = analysis["spatial"]
    L.append("## 7. Análise geográfica\n")
    if sp["points"]:
        L.append(f"{len(sp['points'])} elemento(s) georreferenciado(s).\n")
        if sp["shared_addresses"]:
            L.append("**Endereços compartilhados:**\n")
            for a in sp["shared_addresses"]:
                L.append(f"- {a['label']} ({a['address']}): " + ", ".join(_ent(case, x) for x in a["entities"]))
        if sp["near_pairs"]:
            L.append("\n**Proximidade (≤ raio configurado):** " + "; ".join(
                f"{_lbl(case, p['a'])} ↔ {_lbl(case, p['b'])} ({p['km']} km)" for p in sp["near_pairs"][:20]))
        for e, legs in sp["trajectories"].items():
            flagged = [l for l in legs if l["flag"]]
            if flagged:
                L.append(f"\n**Trajetória de {_lbl(case, e)}:** " + "; ".join(f"{l['from']}→{l['to']} {l['flag']}" for l in flagged))
        L.append(f"\n_{sp['caveat']}_\n")
    else:
        L.append("_Sem dados georreferenciados._\n")

    fin = analysis["financial"]
    L.append("## 8. Análise financeira\n")
    if fin["transactions"]:
        L.append(_tbl(["Conta/entidade", "Entradas", "Saídas", "Saldo", "Nº entr.", "Nº saídas", "Primeira", "Última", "Concentração saída"],
                      [[v["label"], f"R$ {fmt_brl(v['in'])}", f"R$ {fmt_brl(v['out'])}", f"R$ {fmt_brl(v['balance'])}", v["n_in"], v["n_out"],
                        v["first"] or "—", v["last"] or "—", v["concentration_out"] if v["concentration_out"] is not None else "—"]
                       for v in sorted(fin["accounts"].values(), key=lambda x: -(x["in"] + x["out"]))]))
        for f in fin["findings"]:
            L.append(f"\n- **{f['kind']}** ({NATURES[f['nature']]}): {f['reason']}. _Limitação: {f['limitations']}_")
        for fl in fin["flows"][:10]:
            L.append(f"- Fluxo: " + " → ".join(_lbl(case, n) for n in fl["path"]) + " | valores: " +
                     ", ".join(f"R$ {fmt_brl(a)}" for a in fl["amounts"]))
        L.append(f"\n_{fin['caveat']}_\n")
    else:
        L.append("_Sem transações registradas._\n")

    L.append("## 9. Análise de infraestrutura digital\n")
    infra = [e for e in case["entities"] if e["type"] in ("ip", "dominio", "url", "asn", "prefixo_ip", "certificado", "dispositivo", "imei", "mac")]
    if infra:
        L.append(_tbl(["ID", "Tipo", "Valor", "Normalizado/observação", "Natureza"],
                      [[e["id"], ENTITY_TYPES.get(e["type"], e["type"]), e["label"],
                        "; ".join(f"{v.get('normalized')} {v.get('note', '')}".strip() for v in e.get("identifiers", {}).values()),
                        NATURES.get(e.get("nature"), "")] for e in infra]))
        if case.get("osint_queries"):
            L.append("\n**Consultas externas registradas:**\n")
            L.append(_tbl(["ID", "Data", "Ferramenta", "Consulta", "Resultado", "Limitações"],
                          [[q["id"], q["date"], q["tool"], q["query"], q["result_summary"], q.get("limitations", "")] for q in case["osint_queries"]]))
    else:
        L.append("_Sem elementos de infraestrutura digital._\n")

    L.append("\n## 10. Evidências\n")
    L.append(_tbl(["ID", "Nome", "Tipo", "SHA-256", "Tamanho", "Fonte", "Adquirida em"],
                  [[d["id"], d["name"], d["type"], (d.get("hashes", {}).get("sha256") or "—"), d.get("size") or "—",
                    d.get("source_id") or "—", d.get("acquired_at") or "—"] for d in case["evidence"]]))
    L.append("\n## 11. Fontes\n")
    ms = analysis["multi_source"]
    L.append(_tbl(["ID", "Tipo", "Título", "Referência", "Data", "Confiabilidade", "Nível"],
                  [[s["id"], s["type"], s["title"], s.get("reference", ""), s.get("date", ""),
                    (s.get("reliability", "") + str(s.get("credibility", ""))).strip() or "—", s.get("level") or "—"] for s in case["sources"]]))
    L.append(f"\nObjetos com múltiplas fontes: {len(ms['multiple_sources'])}; com fonte única: {len(ms['single_source'])}; "
             f"sem fonte: {len(ms['no_source'])}.\n")
    if case.get("analyses"):
        L.append("\n**Análises registradas (reproduzíveis):**\n")
        L.append(_tbl(["ID", "Tipo", "Método", "Ferramenta", "Natureza", "Confiança", "Resultado", "Limitações"],
                      [[a["id"], a["type"], a["method"], f"{a.get('tool', '')} {a.get('tool_version', '')}".strip(),
                        NATURES.get(a.get("nature"), ""), a.get("confidence") or "—",
                        (a["result"] if isinstance(a["result"], str) else json.dumps(a["result"], ensure_ascii=False))[:200],
                        a.get("limitations", "")[:160]] for a in case["analyses"]]))

    L.append("## 12. Hipóteses\n")
    L.append(_tbl(["ID", "Hipótese", "Favoráveis", "Contrárias", "Lacunas", "Confiança", "Status", "Alertas"],
                  [[h["id"], h["title"], ", ".join(h["supporting"]) or "—", ", ".join(h["contradicting"]) or "—",
                    "; ".join(h["gaps"]) or "—", h["confidence"] if h["confidence"] is not None else "—", h["status"],
                    "; ".join(h["flags"]) or "—"] for h in analysis["hypotheses"]]))
    L.append("\n## 13. Contradições\n")
    if analysis["contradictions"]:
        for x in analysis["contradictions"]:
            if x["kind"] == "atributo divergente":
                L.append(f"- **CONTRADIÇÃO DETECTADA** — {x['subject_label']}: atributo `{x['attribute']}` com valores " +
                         "; ".join(f"{v['value']} (fontes {', '.join(v['sources'])})" for v in x["values"]) + ". " + x["note"])
            elif x["kind"] == "relação exclusiva simultânea":
                L.append(f"- **CONTRADIÇÃO DETECTADA** — {x['subject_label']}: {x['statement_a']} × {x['statement_b']}. {x['note']}")
            else:
                L.append(f"- **{x['kind']}** — {x.get('subject_label') or x['subject']} ({x['subject']}). {x.get('note', '')}".rstrip())
                L.extend(f"  - {d}" for d in x.get("details", []))
        L.append("\n_Nenhuma versão foi escolhida automaticamente._\n")
    else:
        L.append("_Nenhuma contradição sinalizada nos dados registrados._\n")
    if analysis["smart_match"]:
        L.append("**Possíveis duplicidades (Smart Match — pendentes de decisão humana):**\n")
        for m in analysis["smart_match"][:20]:
            L.append(f"- {m['labels'][0]} ({m['pair'][0]}) ≈ {m['labels'][1]} ({m['pair'][1]}) — {m['score']:.0%}: " +
                     "; ".join(cr["detail"] for cr in m["criteria"]) + (f" | conflitos: {'; '.join(m['conflicts'])}" if m["conflicts"] else ""))
    L.append("\n## 14. Lacunas\n")
    gaps = analysis["gaps"]
    by = {}
    for g in gaps:
        by.setdefault(g["kind"], []).append(g)
    for k, items in by.items():
        L.append(f"- **{k}** ({len(items)}): " + "; ".join(f"{g['object']} {g['label']}" for g in items[:12]) +
                 (" …" if len(items) > 12 else "") + f" → {items[0]['suggestion']}")
    if analysis["anomalies"]:
        L.append("\n**Anomalias sinalizadas (com motivo):**\n")
        for a in analysis["anomalies"]:
            L.append(f"- {a['kind']}: {', '.join(map(str, a['objects'] or []))} — {a['reason']}")
    L.append("\n## 15. Conclusões\n")
    L.append("[ANALISTA/IA: cada conclusão no formato]\n\n"
             "```\nCONCLUSÃO:\nEVIDÊNCIAS: (IDs)\nTIPO: fato | declarado | correlação | inferência | hipótese\n"
             "CONFIANÇA:\nLIMITAÇÕES:\nFONTES: (IDs)\n```\n")
    L.append("## 16. Limitações\n")
    L.append("- A análise se restringe aos dados registrados no caso; ausência de registro não equivale à inexistência do fato.\n"
             "- Métricas de rede refletem o que foi coletado (viés de coleta) e não demonstram, por si, hierarquia ou autoria.\n"
             "- Correspondências de entidades (Smart Match) são sugestões e só produzem efeito após decisão humana registrada.\n"
             "- Datas imprecisas e fusos horários distintos podem alterar a ordem dos eventos.\n"
             "- [ANALISTA: limitações específicas do caso — fontes indisponíveis, dados pendentes de requisição, etc.]\n")
    L.append("## 17. Anexos\n")
    L.append("- Visualizador interativo do grafo (`visualizador.html`)\n- Dados em CSV/GraphML/GEXF\n"
             "- Manifesto de evidências com SHA-256\n- Trilha de auditoria (`dados/auditoria.csv`)\n")
    L.append("\n---\n### Relatório do grafo\n")
    L.append(f"Data da análise: {analysis['generated_at']} · Filtros aplicados: {analysis.get('filters') or 'nenhum'} · "
             f"Nós: {s.get('nodes')} · Arestas: {s.get('edges')}  \n"
             "Legenda de arestas: linha contínua = fato; tracejada = declarado; pontilhada = correlação/inferência; "
             "vermelha tracejada = hipótese; cinza = não verificado. Espessura proporcional à confiança.\n")
    return "\n".join(L) + "\n"
