"""
build_viewer.py — Gera o visualizador/editor HTML autocontido (Fases 2 e 3).

O HTML embute o caso e a análise; nenhum dado sai da máquina. Bibliotecas:
- padrão: Cytoscape.js e Leaflet via CDN (somente código; nenhum dado enviado);
- --inline-libs DIR: embute cytoscape.min.js / leaflet.js / leaflet.css locais (uso offline);
- --no-tiles: mapa sem tiles do OpenStreetMap (as requisições de tiles revelariam a região
  visualizada ao provedor) — usa Leaflet sem camada base ou esquema SVG.
"""
from __future__ import annotations

import json
import os

from case_model import (CONFIDENCE_LEVELS, ENTITY_TYPES, EVENT_TYPES, EVIDENCE_TYPES, HYPOTHESIS_STATUSES,
                        NATURES, RELATIONSHIP_TYPES, STATUSES)

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "..", "assets", "viewer_template.html")

CDN = """<script src="https://cdn.jsdelivr.net/npm/cytoscape@3.30.2/dist/cytoscape.min.js"
  onerror="var s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.30.2/cytoscape.min.js';document.head.appendChild(s)"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/cytoscape-svg@0.4.0/cytoscape-svg.js" onerror="void 0"></script>"""

EVENT_LABELS = {
    "ligacao": "Ligação", "mensagem": "Mensagem", "transferencia": "Transferência", "saque": "Saque",
    "deposito": "Depósito", "login": "Login", "acesso": "Acesso", "viagem": "Viagem", "encontro": "Encontro",
    "criacao_conta": "Criação de conta", "abertura_empresa": "Abertura de empresa",
    "alteracao_cadastral": "Alteração cadastral", "ocorrencia": "Ocorrência", "apreensao": "Apreensão",
    "busca": "Busca", "evento_policial": "Evento policial", "evento_financeiro": "Evento financeiro",
    "evento_digital": "Evento digital", "personalizado": "Personalizado",
}


def _inline(lib_dir: str) -> str:
    parts = []
    for name, tag in (("leaflet.css", "style"), ("leaflet.min.css", "style"), ("cytoscape.min.js", "script"),
                      ("leaflet.js", "script"), ("leaflet.min.js", "script"), ("cytoscape-svg.js", "script")):
        p = os.path.join(lib_dir, name)
        if os.path.isfile(p):
            with open(p, encoding="utf-8") as fh:
                code = fh.read().replace("</script", "<\\/script")
            parts.append(f"<{tag}>/* {name} */\n{code}\n</{tag}>")
    if not any("cytoscape.min.js" in x for x in parts):
        raise FileNotFoundError(f"cytoscape.min.js não encontrado em {lib_dir}")
    return "\n".join(parts)


def _slim_analysis(an: dict) -> dict:
    keep = {k: an.get(k) for k in ("generated_at", "contradictions", "smart_match", "anomalies", "gaps",
                                   "hypotheses", "financial", "epistemic_note")}
    net = an.get("network", {})
    keep["network"] = {k: net.get(k) for k in ("summary", "nodes", "top", "articulation_points", "interpretation")}
    fin = keep.get("financial") or {}
    keep["financial"] = {k: fin.get(k) for k in ("accounts", "findings", "flows", "cycles", "caveat")}
    return keep


def build(case: dict, analysis: dict | None = None, no_tiles: bool = False, inline_libs: str | None = None) -> str:
    with open(TEMPLATE, encoding="utf-8") as fh:
        html = fh.read()
    an = _slim_analysis(analysis) if analysis else {}
    comm = {nid: d.get("community") for nid, d in (analysis or {}).get("network", {}).get("nodes", {}).items()}
    boot = {
        "case": case, "analysis": an, "network_metrics_communities": comm,
        "config": {"no_tiles": no_tiles},
        "vocab": {"entity_types": ENTITY_TYPES, "natures": NATURES, "statuses": STATUSES,
                  "confidence": CONFIDENCE_LEVELS, "relationship_types": RELATIONSHIP_TYPES,
                  "event_types": EVENT_TYPES, "event_labels": EVENT_LABELS, "evidence_types": EVIDENCE_TYPES,
                  "hypothesis_statuses": HYPOTHESIS_STATUSES},
    }
    payload = json.dumps(boot, ensure_ascii=False, default=str).replace("</", "<\\/").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
    libs = _inline(inline_libs) if inline_libs else CDN
    if no_tiles and not inline_libs:
        libs += "\n<!-- no-tiles: mapa sem camada base externa -->"
    html = html.replace("<!--__NB_LIBS__-->", libs, 1).replace("/*__NB_DATA__*/null", payload, 1)
    title = case.get("case", {}).get("title", "Caso")
    return html.replace("<title>Investigative Notebook</title>",
                        f"<title>{title.replace('<', '&lt;')} — Investigative Notebook</title>", 1)
