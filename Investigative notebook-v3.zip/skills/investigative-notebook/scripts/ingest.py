"""
ingest.py — Importação com prévia (Fase 4).

Fluxo: arquivo → detecção → identificação de colunas → normalização → mapeamento →
entity resolution → validação → PRÉVIA (staging) → decisão humana → importação.

Nada entra no caso sem passar pelo arquivo de staging, onde cada proposta tem
"decision": "pendente" | "aceito" | "rejeitado".

Formatos tabulares: CSV, TSV, XLSX/XLS (pandas+openpyxl), JSON (lista de objetos), SQLite (tabela).
Texto livre (TXT, PDF, DOCX, e-mail .eml): extração por padrões de identificadores.
"""
from __future__ import annotations

import csv
import json
import os
import re
import sqlite3
import subprocess
from collections import Counter, defaultdict

from case_model import Case, file_hashes, normalize, now_iso, parse_date, parse_money

# ----------------------------------------------------------------------------
# Leitura
# ----------------------------------------------------------------------------

def read_table(path: str, sheet: str | int | None = None, table: str | None = None) -> list[dict]:
    ext = os.path.splitext(path)[1].lower()
    if ext in (".csv", ".tsv", ".txt"):
        with open(path, encoding="utf-8-sig", errors="replace", newline="") as fh:
            sample = fh.read(65536)
            fh.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=",;\t|")
            except csv.Error:
                dialect = csv.excel_tab if ext == ".tsv" else csv.excel
            return [dict(r) for r in csv.DictReader(fh, dialect=dialect)]
    if ext in (".xlsx", ".xlsm", ".xls"):
        import pandas as pd
        df = pd.read_excel(path, sheet_name=sheet if sheet is not None else 0, dtype=str)
        return df.fillna("").to_dict(orient="records")
    if ext == ".json":
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict):
            for v in data.values():
                if isinstance(v, list):
                    data = v
                    break
        return [r for r in data if isinstance(r, dict)]
    if ext in (".db", ".sqlite", ".sqlite3"):
        con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        con.row_factory = sqlite3.Row
        if not table:
            tables = [r[0] for r in con.execute("select name from sqlite_master where type='table'")]
            raise ValueError(f"Informe --table. Tabelas: {', '.join(tables)}")
        rows = [dict(r) for r in con.execute(f'select * from "{table}"')]
        con.close()
        return rows
    raise ValueError(f"Formato tabular não suportado: {ext}")


def read_text(path: str) -> str:
    ext = os.path.splitext(path)[1].lower()
    if ext == ".pdf":
        try:
            return subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True, text=True, check=True).stdout
        except (FileNotFoundError, subprocess.CalledProcessError):
            from pypdf import PdfReader
            return "\n".join(p.extract_text() or "" for p in PdfReader(path).pages)
    if ext == ".docx":
        import docx  # python-docx
        d = docx.Document(path)
        parts = [p.text for p in d.paragraphs]
        for t in d.tables:
            for row in t.rows:
                parts.append(" | ".join(c.text for c in row.cells))
        return "\n".join(parts)
    if ext == ".eml":
        import email
        from email import policy
        with open(path, "rb") as fh:
            msg = email.message_from_binary_file(fh, policy=policy.default)
        hdr = "\n".join(f"{k}: {v}" for k, v in msg.items())
        body = msg.get_body(preferencelist=("plain", "html"))
        return hdr + "\n\n" + (body.get_content() if body else "")
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


# ----------------------------------------------------------------------------
# Detecção de colunas
# ----------------------------------------------------------------------------

HEADER_HINTS = [  # ordem importa: o primeiro padrão que casar com o cabeçalho vence
    ("cpf", r"\bcpf\b"), ("cnpj", r"\bcnpj\b"), ("email", r"e-?mail"), ("imei", r"imei"), ("mac", r"\bmac\b"),
    ("ip", r"\bip\b|endere[cç]o.?ip|ip_?(orig|dest|src|dst)"), ("placa", r"placa"), ("pix", r"pix|chave"),
    ("valor", r"valor|amount|quantia|montante|r\$"), ("data", r"data|date|hora|time|timestamp|dt_"),
    ("nome", r"nome|name|titular|favorecido|pagador|benefici"), ("endereco", r"endere[cç]o|logradouro|address|\brua\b"),
    ("conta_bancaria", r"conta|ag[eê]ncia|account"), ("dominio", r"dom[ií]nio|domain|\bhost"), ("url", r"\burl\b|link"),
    ("telefone", r"tel|fone|celular|msisdn|n[uú]mero|^origem$|^destino$|a_?number|b_?number"),
]

VALUE_PATTERNS = {
    "cpf": r"^\d{3}\.?\d{3}\.?\d{3}-?\d{2}$",
    "cnpj": r"^\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}$",
    "email": r"^[^@\s]+@[^@\s]+\.[^@\s]+$",
    "ip": r"^(\d{1,3}\.){3}\d{1,3}$|^[0-9a-fA-F:]{3,39}$",
    "data": r"^\d{2}/\d{2}/\d{4}|^\d{4}-\d{2}-\d{2}",
    "valor": r"^-?R?\$?\s?[\d.]+,\d{2}$",
    "telefone": r"^\+?\(?\d{2,3}\)?\s?9?\d{4}-?\d{4}$",
    "placa": r"^[A-Za-z]{3}-?\d[A-Za-z0-9]\d{2}$",
}


def detect_columns(rows: list[dict], sample: int = 200) -> dict:
    if not rows:
        return {}
    cols = list(rows[0].keys())
    out = {}
    for c in cols:
        values = [str(r.get(c, "")).strip() for r in rows[:sample] if str(r.get(c, "")).strip()]
        votes = Counter()
        for kind, pat in VALUE_PATTERNS.items():
            hits = sum(1 for v in values if re.match(pat, v))
            if values and hits / len(values) >= 0.6:
                votes[kind] += hits / len(values)
        for kind, pat in HEADER_HINTS:
            if re.search(pat, c, re.I):
                votes[kind] += 0.8
                break
        if "cpf" in votes and "telefone" in votes:  # 11 dígitos é ambíguo
            votes["cpf" if re.search("cpf", c, re.I) else "telefone"] += 1
        guess = votes.most_common(1)[0][0] if votes else "texto"
        out[c] = {"guess": guess, "confidence": round(min(1.0, votes[guess] / 1.5), 2) if votes else 0,
                  "sample": values[:3], "filled": f"{len(values)}/{min(len(rows), sample)}"}
    return out


ENTITY_FOR_KIND = {"cpf": "cpf", "cnpj": "cnpj", "telefone": "telefone", "email": "email", "ip": "ip",
                   "dominio": "dominio", "url": "url", "placa": "veiculo", "pix": "pix",
                   "conta_bancaria": "conta_bancaria", "endereco": "endereco", "nome": "pessoa", "imei": "imei", "mac": "mac"}


def suggest_mapping(rows: list[dict], source_id: str = "") -> dict:
    det = detect_columns(rows)
    ents, keys = [], {}
    for col, d in det.items():
        k = d["guess"]
        if k in ENTITY_FOR_KIND:
            key = re.sub(r"\W+", "_", col.lower()).strip("_") or "col"
            et = ENTITY_FOR_KIND[k]
            ent = {"key": key, "type": et, "label": "{" + col + "}"}
            if k not in ("nome", "endereco"):
                ent["identifiers"] = {("placa" if k == "placa" else k): "{" + col + "}"}
            ents.append(ent)
            keys[col] = key
    dates = [c for c, d in det.items() if d["guess"] == "data"]
    amounts = [c for c, d in det.items() if d["guess"] == "valor"]
    rels = []
    if len(ents) >= 2:
        rel = {"source": ents[0]["key"], "target": ents[1]["key"], "type": "relacionado a"}
        if dates:
            rel["start"] = "{" + dates[0] + "}"
        if amounts:
            rel["attributes"] = {"amount": "{" + amounts[0] + "}"}
        rels.append(rel)
    return {
        "_instructions": "Revise antes de importar: ajuste tipos, rótulos, relação (type/source/target), "
                         "natureza e fonte. Placeholders {coluna} são substituídos pelo valor da linha.",
        "detected_columns": det,
        "defaults": {"nature": "nao_verificado", "confidence": "media", "source_ids": [source_id] if source_id else []},
        "entities": ents, "relationships": rels, "events": [],
    }


# ----------------------------------------------------------------------------
# Aplicação do mapeamento -> staging
# ----------------------------------------------------------------------------

_PH = re.compile(r"\{([^{}]+)\}")


def _fill(tpl, row: dict):
    if isinstance(tpl, str):
        if tpl.startswith("{") and tpl.endswith("}") and tpl.count("{") == 1:
            return row.get(tpl[1:-1], "")
        return _PH.sub(lambda m: str(row.get(m.group(1), "")), tpl)
    if isinstance(tpl, dict):
        return {k: _fill(v, row) for k, v in tpl.items()}
    if isinstance(tpl, list):
        return [_fill(v, row) for v in tpl]
    return tpl


def _ent_key(e: dict) -> tuple:
    for k, v in (e.get("identifiers") or {}).items():
        n = normalize(k, v)["normalized"]
        if n:
            return (e["type"], k, n)
    return (e["type"], "label", normalize("nome", e.get("label", ""))["normalized"])


def stage_from_table(path: str, mapping: dict, sheet=None, table=None) -> dict:
    rows = read_table(path, sheet, table)
    h = file_hashes(path)
    defaults = mapping.get("defaults", {})
    ents: dict[tuple, dict] = {}
    rels, events, problems = [], [], []
    for i, row in enumerate(rows, start=1):
        row = {k: ("" if v is None else str(v).strip()) for k, v in row.items()}
        local = {}
        for spec in mapping.get("entities", []):
            e = _fill({k: v for k, v in spec.items() if k != "key"}, row)
            if not str(e.get("label", "")).strip():
                continue
            e["identifiers"] = {k: v for k, v in (e.get("identifiers") or {}).items() if str(v).strip()}
            key = _ent_key(e)
            if key not in ents:
                ents[key] = {"tmp_id": f"T-{len(ents) + 1:04d}", **e, "rows": [i], "decision": "pendente"}
                for k, v in e["identifiers"].items():
                    n = normalize(k, v)
                    if n["valid"] is False:
                        problems.append({"row": i, "issue": f"{k} inválido: {v!r}", "tmp_id": ents[key]["tmp_id"]})
            else:
                ents[key]["rows"].append(i)
            local[spec["key"]] = ents[key]["tmp_id"]
        for spec in mapping.get("relationships", []):
            if spec["source"] in local and spec["target"] in local:
                r = _fill({k: v for k, v in spec.items() if k not in ("source", "target")}, row)
                if "start" in r:
                    r["start"] = parse_date(r["start"])[0] or r["start"]
                if "attributes" in r and "amount" in r["attributes"]:
                    r["attributes"]["amount"] = parse_money(r["attributes"]["amount"])
                rels.append({"tmp_id": f"TR-{len(rels) + 1:05d}", "source": local[spec["source"]],
                             "target": local[spec["target"]], **r, "row": i, "decision": "pendente"})
        for spec in mapping.get("events", []):
            ev = _fill({k: v for k, v in spec.items() if k != "participants"}, row)
            ev["participants"] = [local[k] for k in spec.get("participants", []) if k in local]
            if "attributes" in ev and "amount" in ev["attributes"]:
                ev["attributes"]["amount"] = parse_money(ev["attributes"]["amount"])
            events.append({"tmp_id": f"TE-{len(events) + 1:05d}", **ev, "row": i, "decision": "pendente"})
    return {
        "staging_version": "1.0", "created_at": now_iso(), "kind": "tabela",
        "file": os.path.abspath(path), "file_hashes": {"sha256": h["sha256"]}, "file_size": h["size"],
        "rows": len(rows), "defaults": defaults,
        "summary": f"{len(ents)} entidades, {len(rels)} possíveis relações e {len(events)} eventos identificados "
                   f"em {len(rows)} linhas. Revise e marque 'decision' antes de importar.",
        "problems": problems,
        "entities": list(ents.values()), "relationships": rels, "events": events,
    }


# ----------------------------------------------------------------------------
# Extração de texto livre -> staging (somente entidades; relações exigem leitura)
# ----------------------------------------------------------------------------

TEXT_PATTERNS = [
    ("cpf", "cpf", r"(?<!\d)\d{3}\.\d{3}\.\d{3}-\d{2}(?!\d)"),
    ("cnpj", "cnpj", r"(?<!\d)\d{2}\.\d{3}\.\d{3}/\d{4}-\d{2}(?!\d)"),
    ("email", "email", r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
    ("telefone", "telefone", r"(?<!\d)(?:\+55\s?)?\(?\d{2}\)?\s?9?\d{4}[-\s]?\d{4}(?!\d)"),
    ("ip", "ip", r"(?<![\d.])(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)(?![\d.])"),
    ("url", "url", r"\b(?:https?|hxxps?)://[^\s<>\"')]+"),
    ("dominio", "dominio", r"\b(?:[a-z0-9-]+(?:\.|\[\.\]))+(?:com|net|org|br|io|info|xyz|online|site|app|me|co|gov|edu)(?:\.br)?\b"),
    ("veiculo", "placa", r"\b[A-Z]{3}-?\d[A-Z0-9]\d{2}\b"),
    ("pix", "pix", r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b"),
]


def stage_from_text(path: str, text: str | None = None) -> dict:
    text = text if text is not None else read_text(path)
    h = file_hashes(path) if path and os.path.isfile(path) else {"sha256": None, "size": len(text or "")}
    found: dict[tuple, dict] = {}
    covered = []  # evita que CPF vire telefone, URL vire domínio etc.
    for etype, ikind, pat in TEXT_PATTERNS:
        for m in re.finditer(pat, text, flags=0 if etype == "veiculo" else re.I):
            if any(a <= m.start() < b for a, b in covered):
                continue
            raw = m.group(0).rstrip(".,;")
            n = normalize(ikind, raw)
            if n["valid"] is False and etype in ("cpf", "cnpj", "ip"):
                continue
            key = (etype, n["normalized"])
            line = text.count("\n", 0, m.start()) + 1
            ctx = text[max(0, m.start() - 80): m.end() + 80].replace("\n", " ")
            if key not in found:
                found[key] = {"tmp_id": f"T-{len(found) + 1:04d}", "type": etype, "label": raw,
                              "identifiers": {ikind: raw}, "occurrences": [], "decision": "pendente",
                              "validation": n}
            found[key]["occurrences"].append({"line": line, "context": ctx.strip()})
            covered.append((m.start(), m.end()))
    money = [{"value": parse_money(m.group(0)), "raw": m.group(0), "line": text.count("\n", 0, m.start()) + 1}
             for m in re.finditer(r"R\$\s?[\d.]+,\d{2}", text)]
    dates = [{"raw": m.group(0), "iso": parse_date(m.group(0))[0], "line": text.count("\n", 0, m.start()) + 1}
             for m in re.finditer(r"\b\d{2}/\d{2}/\d{4}(?:[ ,]+(?:às\s)?\d{2}[:h]\d{2}(?::\d{2})?)?", text)]
    return {
        "staging_version": "1.0", "created_at": now_iso(), "kind": "texto",
        "file": os.path.abspath(path) if path else "", "file_hashes": {"sha256": h["sha256"]}, "file_size": h["size"],
        "defaults": {"nature": "nao_verificado", "confidence": "media", "source_ids": []},
        "summary": f"{len(found)} identificadores extraídos por padrão. Pessoas, empresas e RELAÇÕES "
                   "precisam de leitura contextual (feita pelo analista ou pela IA) e devem ser adicionadas "
                   "ao staging antes da importação.",
        "entities": list(found.values()), "relationships": [], "events": [],
        "monetary_values": money, "dates": dates, "problems": [],
    }


# ----------------------------------------------------------------------------
# Commit do staging -> caso (com entity resolution)
# ----------------------------------------------------------------------------

def commit_staging(case: Case, staging: dict, accept_all: bool = False, evidence_id: str = "") -> dict:
    defaults = staging.get("defaults", {})
    def ok(x):
        return x.get("decision") == "aceito" or (accept_all and x.get("decision") != "rejeitado")
    # índice de identificadores existentes
    existing = {}
    for e in case.data["entities"]:
        for k, v in e.get("identifiers", {}).items():
            if v.get("normalized"):
                existing[(e["type"], k.split("__")[0], v["normalized"])] = e["id"]
        existing[(e["type"], "label", e.get("label_normalized") or normalize("nome", e["label"])["normalized"])] = e["id"]
    tmp2id, created, reused = {}, [], []
    src_ids = defaults.get("source_ids", [])
    ev_ids = [evidence_id] if evidence_id else []
    for e in staging.get("entities", []):
        if not ok(e):
            continue
        key = _ent_key(e)
        if key in existing:
            tmp2id[e["tmp_id"]] = existing[key]
            reused.append(existing[key])
            ent = case.entity(existing[key])
            ent["source_ids"] = list(dict.fromkeys(ent.get("source_ids", []) + src_ids))
            ent["evidence_ids"] = list(dict.fromkeys(ent.get("evidence_ids", []) + ev_ids))
            continue
        eid = case.add_entity(e["type"], e["label"], identifiers=e.get("identifiers"),
                              attributes=e.get("attributes"), aliases=e.get("aliases"),
                              location=e.get("location"), source_ids=e.get("source_ids", src_ids),
                              evidence_ids=e.get("evidence_ids", ev_ids),
                              nature=e.get("nature", defaults.get("nature")),
                              confidence=e.get("confidence", defaults.get("confidence")),
                              provenance={"staging_file": staging.get("file"), "file_sha256": staging["file_hashes"]["sha256"],
                                          "rows": e.get("rows"), "occurrences": e.get("occurrences", [])[:5],
                                          "method": "importação " + staging.get("kind", "")})
        tmp2id[e["tmp_id"]] = eid
        existing[key] = eid
        created.append(eid)
    rel_ids = []
    for r in staging.get("relationships", []):
        if not ok(r) or r["source"] not in tmp2id or r["target"] not in tmp2id:
            continue
        rid = case.add_relationship(tmp2id[r["source"]], r.get("type", "relacionado a"), tmp2id[r["target"]],
                                    start=r.get("start", ""), end=r.get("end", ""),
                                    source_ids=r.get("source_ids", src_ids), evidence_ids=r.get("evidence_ids", ev_ids),
                                    nature=r.get("nature", defaults.get("nature")),
                                    confidence=r.get("confidence", defaults.get("confidence")),
                                    attributes=r.get("attributes"), origin="importação",
                                    provenance={"file_sha256": staging["file_hashes"]["sha256"], "row": r.get("row")})
        rel_ids.append(rid)
    ev_created = []
    for ev in staging.get("events", []):
        if not ok(ev):
            continue
        evid = case.add_event(ev.get("title", "evento importado"), ev.get("type", "personalizado"),
                              start=ev.get("start", ""), end=ev.get("end", ""),
                              participants=[tmp2id[p] for p in ev.get("participants", []) if p in tmp2id],
                              source_ids=ev.get("source_ids", src_ids), evidence_ids=ev.get("evidence_ids", ev_ids),
                              nature=ev.get("nature", defaults.get("nature")),
                              confidence=ev.get("confidence", defaults.get("confidence")),
                              attributes=ev.get("attributes"), location=ev.get("location"),
                              provenance={"file_sha256": staging["file_hashes"]["sha256"], "row": ev.get("row")})
        ev_created.append(evid)
    case._audit("importação", "arquivo", staging.get("file"),
                after={"sha256": staging["file_hashes"]["sha256"], "entidades_criadas": len(created),
                       "entidades_reaproveitadas": len(set(reused)), "relacoes": len(rel_ids), "eventos": len(ev_created)})
    return {"created_entities": created, "reused_entities": sorted(set(reused)), "relationships": rel_ids,
            "events": ev_created}
