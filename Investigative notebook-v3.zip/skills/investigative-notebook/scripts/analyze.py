"""
analyze.py — Motor analítico do Investigative Notebook (Fases 3 e 5).

Todas as funções recebem o dicionário do caso (Case.data) e devolvem estruturas
explicáveis: cada achado traz o MOTIVO, os objetos envolvidos e a natureza
epistemológica do resultado (sempre correlação/inferência — nunca fato).

Requer: networkx (>= 3.0). Restante: biblioteca padrão.
"""
from __future__ import annotations

import itertools
import math
import re
import statistics
from collections import Counter, defaultdict
from datetime import timedelta
from difflib import SequenceMatcher

import networkx as nx

from case_model import (fmt_brl, CONFIDENCE_LEVELS, DISPLAY_MODES, EXCLUSIVE_RELATIONSHIP_TYPES, NATURES,
                        SINGLE_VALUED_ATTRIBUTES, confidence_value, strip_accents, to_datetime)

FINANCIAL_TYPES = {"transferiu", "recebeu", "recebeu de", "depositou", "sacou", "pagou"}
ACCOUNT_TYPES = {"conta_bancaria", "pix", "cartao", "carteira_cripto"}
IDENTIFIER_NODE_TYPES = {"telefone", "email", "cpf", "cnpj", "endereco", "ip", "dispositivo",
                         "imei", "mac", "conta_bancaria", "pix", "veiculo", "dominio", "usuario", "perfil_social"}


# ============================================================================
# Construção e filtragem do grafo
# ============================================================================

def build_graph(case: dict, mode: str = "todos", min_confidence: float | None = None,
                include_rejected: bool = False, only_with_evidence: bool = False,
                rel_types: set | None = None, period: tuple | None = None,
                entity_types: set | None = None) -> nx.MultiDiGraph:
    """MultiDiGraph com entidades (nós) e relações (arestas). Relações não direcionadas
    são marcadas com directed=False (as métricas usam a versão não direcionada)."""
    natures = DISPLAY_MODES.get(mode, set(NATURES))
    G = nx.MultiDiGraph()
    for e in case["entities"]:
        if not include_rejected and e.get("status") == "rejeitado":
            continue
        if entity_types and e["type"] not in entity_types:
            continue
        G.add_node(e["id"], **{k: e.get(k) for k in ("type", "label", "nature", "status", "confidence")})
    p0 = to_datetime(period[0]) if period and period[0] else None
    p1 = to_datetime(period[1]) if period and period[1] else None
    for r in case["relationships"]:
        if r["source"] not in G or r["target"] not in G:
            continue
        if r.get("nature") not in natures:
            continue
        if not include_rejected and r.get("status") == "rejeitado":
            continue
        cv = confidence_value(r.get("confidence"))
        if min_confidence is not None and (cv is None or cv < min_confidence):
            continue
        if only_with_evidence and not r.get("evidence_ids"):
            continue
        if rel_types and r["type"] not in rel_types:
            continue
        if p0 or p1:
            rs, re_ = to_datetime(r.get("start")), to_datetime(r.get("end")) or to_datetime(r.get("start"))
            if rs is None:
                continue
            if p1 and rs > p1:
                continue
            if p0 and re_ and re_ < p0:
                continue
        G.add_edge(r["source"], r["target"], key=r["id"], id=r["id"], type=r["type"],
                   directed=r.get("directed", True), nature=r.get("nature"), status=r.get("status"),
                   confidence=cv if cv is not None else 0.5, evidence=len(r.get("evidence_ids", [])),
                   sources=len(r.get("source_ids", [])), start=r.get("start"),
                   amount=(r.get("attributes") or {}).get("amount"))
    if mode != "todos":
        G.remove_nodes_from([n for n in list(G) if G.degree(n) == 0])
    return G


def simple_undirected(G: nx.MultiDiGraph) -> nx.Graph:
    """Colapsa multiarestas; peso = soma das confianças; 'distance' = 1/peso (para caminhos)."""
    H = nx.Graph()
    H.add_nodes_from(G.nodes(data=True))
    for u, v, d in G.edges(data=True):
        if H.has_edge(u, v):
            H[u][v]["weight"] += d["confidence"]
            H[u][v]["ids"].append(d["id"])
        else:
            H.add_edge(u, v, weight=d["confidence"], ids=[d["id"]])
    for u, v, d in H.edges(data=True):
        d["distance"] = 1.0 / max(d["weight"], 0.05)
    return H


# ============================================================================
# 5.1–5.3 Métricas de rede e comunidades
# ============================================================================

def network_metrics(case: dict, **filters) -> dict:
    G = build_graph(case, **filters)
    H = simple_undirected(G)
    n = H.number_of_nodes()
    if n == 0:
        return {"summary": {"nodes": 0, "edges": 0}, "nodes": {}, "communities": [], "notes": ["grafo vazio"]}
    deg = dict(H.degree())
    wdeg = dict(H.degree(weight="weight"))
    btw = nx.betweenness_centrality(H, normalized=True)
    clo = nx.closeness_centrality(H)
    try:
        eig = nx.eigenvector_centrality(H, max_iter=2000, weight="weight")
    except (nx.PowerIterationFailedConvergence, nx.NetworkXException):
        eig = {k: None for k in H}
    pr = nx.pagerank(H, weight="weight") if H.number_of_edges() else {k: 1 / n for k in H}
    comms = []
    if H.number_of_edges():
        try:
            comms = nx.community.louvain_communities(H, weight="weight", seed=42)
        except Exception:  # noqa: BLE001
            comms = list(nx.community.greedy_modularity_communities(H, weight="weight"))
    comm_of = {}
    for i, c in enumerate(sorted(comms, key=len, reverse=True)):
        for node in c:
            comm_of[node] = i
    for node in H:
        comm_of.setdefault(node, -1)
    comps = sorted(nx.connected_components(H), key=len, reverse=True)
    bridges = [{"between": [u, v], "relationship_ids": H[u][v]["ids"]} for u, v in nx.bridges(H)]
    arts = list(nx.articulation_points(H))
    isolates = list(nx.isolates(H))
    nodes = {}
    for node in H:
        nodes[node] = {
            "label": H.nodes[node].get("label"), "type": H.nodes[node].get("type"),
            "degree": deg[node], "weighted_degree": round(wdeg[node], 3),
            "betweenness": round(btw[node], 4), "closeness": round(clo[node], 4),
            "eigenvector": None if eig[node] is None else round(eig[node], 4),
            "pagerank": round(pr[node], 4), "community": comm_of[node],
            "articulation_point": node in arts,
        }
    def top(metric, k=10):
        return sorted(((nid, d[metric]) for nid, d in nodes.items() if d[metric] is not None),
                      key=lambda x: -x[1])[:k]
    modularity = None
    if comms and H.number_of_edges():
        try:
            modularity = round(nx.community.modularity(H, comms, weight="weight"), 4)
        except Exception:  # noqa: BLE001
            pass
    return {
        "summary": {"nodes": n, "edges": G.number_of_edges(), "unique_links": H.number_of_edges(),
                    "density": round(nx.density(H), 4), "components": len(comps),
                    "largest_component": len(comps[0]) if comps else 0, "communities": len(comms),
                    "modularity": modularity, "isolates": len(isolates), "bridges": len(bridges),
                    "articulation_points": len(arts)},
        "nodes": nodes,
        "top": {m: top(m) for m in ("degree", "weighted_degree", "betweenness", "closeness", "eigenvector", "pagerank")},
        "communities": [{"id": i, "size": len(c), "members": sorted(c)} for i, c in
                        enumerate(sorted(comms, key=len, reverse=True))],
        "components": [sorted(c) for c in comps],
        "bridges": bridges, "articulation_points": arts, "isolates": isolates,
        "interpretation": {
            "degree": "quantidade de conexões diretas (exposição/atividade)",
            "betweenness": "posição de intermediário — remove-lo desconecta partes da rede",
            "closeness": "proximidade média em relação ao restante da rede",
            "eigenvector/pagerank": "importância derivada da importância das conexões",
            "articulation_point": "nó cuja remoção separa a rede em partes",
            "aviso": "Métricas descrevem a ESTRUTURA DO GRAFO REGISTRADO, não a realidade: dependem "
                     "do que foi coletado (viés de coleta). São indicadores para priorizar diligências, "
                     "não prova de liderança ou participação.",
        },
    }


def ego_network(case: dict, entity_id: str, radius: int = 1, **filters) -> dict:
    G = build_graph(case, **filters)
    H = simple_undirected(G)
    if entity_id not in H:
        return {"center": entity_id, "nodes": [], "edges": []}
    E = nx.ego_graph(H, entity_id, radius=radius)
    return {"center": entity_id, "radius": radius, "nodes": list(E.nodes),
            "relationship_ids": sorted({i for _, _, d in E.edges(data=True) for i in d["ids"]})}


# ============================================================================
# 2.11 Caminhos
# ============================================================================

def paths(case: dict, a: str, b: str, kind: str = "shortest", cutoff: int = 5, max_paths: int = 50,
          weighted: bool = True, **filters) -> dict:
    """kind: shortest | all. Filtros aceitos: rel_types, period, only_with_evidence, min_confidence, mode de exibição."""
    G = build_graph(case, **filters)
    H = simple_undirected(G)
    res = {"from": a, "to": b, "filters": {k: (sorted(v) if isinstance(v, set) else v) for k, v in filters.items()},
           "paths": []}
    if a not in H or b not in H:
        res["note"] = "origem ou destino ausente no grafo filtrado"
        return res
    try:
        if kind == "shortest":
            node_paths = [nx.shortest_path(H, a, b, weight="distance" if weighted else None)]
        else:
            node_paths = list(itertools.islice(nx.all_simple_paths(H, a, b, cutoff=cutoff), max_paths))
    except nx.NetworkXNoPath:
        res["note"] = "não há caminho com os filtros aplicados"
        return res
    if not node_paths:
        res["note"] = "não há caminho com os filtros aplicados"
        return res
    for p in node_paths:
        hops = []
        weakest = 1.0
        for u, v in zip(p, p[1:]):
            rels = [d for x, y, d in G.edges(data=True) if {x, y} == {u, v}]
            best = max(rels, key=lambda d: d["confidence"])
            weakest = min(weakest, best["confidence"])
            hops.append({"from": u, "to": v, "relationship_ids": [d["id"] for d in rels],
                         "types": sorted({d["type"] for d in rels}), "best_confidence": best["confidence"],
                         "natures": sorted({d["nature"] for d in rels}),
                         "with_evidence": any(d["evidence"] for d in rels)})
        res["paths"].append({"nodes": p, "length": len(p) - 1, "hops": hops, "weakest_link_confidence": weakest,
                             "fully_evidenced": all(h["with_evidence"] for h in hops),
                             "contains_inference": any(n in ("inferencia", "correlacao", "hipotese", "nao_verificado")
                                                       for h in hops for n in h["natures"])})
    res["paths"].sort(key=lambda x: (x["length"], -x["weakest_link_confidence"]))
    res["caveat"] = ("Um caminho no grafo indica conexão registrada, não vínculo causal ou conhecimento "
                     "mútuo. A força do caminho é limitada pelo seu elo mais fraco.")
    return res


# ============================================================================
# 5.4–5.5 Smart Match (resolução de entidades) — só SUGERE
# ============================================================================

_STOP = {"DA", "DE", "DO", "DAS", "DOS", "E", "LTDA", "ME", "EPP", "SA", "S", "A", "EIRELI"}


def _tokens(name: str) -> list[str]:
    n = strip_accents(name or "").upper()
    return [t for t in "".join(ch if ch.isalnum() else " " for ch in n).split() if t not in _STOP]


def name_similarity(a: str, b: str) -> tuple[float, str]:
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0, "nome ausente"
    sa, sb = " ".join(ta), " ".join(tb)
    seq = SequenceMatcher(None, sa, sb).ratio()
    set_a, set_b = set(ta), set(tb)
    jacc = len(set_a & set_b) / len(set_a | set_b)
    # tolera abreviações: "S." casa com "SILVA"; tokens contidos (João Silva ⊂ João S. da Silva)
    def tok_match(x, ys):
        return any(y == x or (len(x) == 1 and y.startswith(x)) or (len(y) == 1 and x.startswith(y)) for y in ys)
    short, long_ = (ta, tb) if len(ta) <= len(tb) else (tb, ta)
    containment = sum(tok_match(t, long_) for t in short) / len(short)
    first_last = 1.0 if (ta[0] == tb[0] and ta[-1] == tb[-1]) else 0.0
    score = max(seq, 0.45 * containment + 0.25 * first_last + 0.30 * jacc)
    why = (f"sequência={seq:.2f}, tokens em comum={jacc:.2f}, contenção={containment:.2f}, "
           f"primeiro/último iguais={'sim' if first_last else 'não'}")
    return round(score, 3), why


def _neighbors_by_type(case: dict) -> dict:
    idx = {e["id"]: e for e in case["entities"]}
    out = defaultdict(lambda: defaultdict(set))
    for r in case["relationships"]:
        if r.get("status") == "rejeitado":
            continue
        s, t = idx.get(r["source"]), idx.get(r["target"])
        if not s or not t:
            continue
        if t["type"] in IDENTIFIER_NODE_TYPES:
            out[s["id"]][t["type"]].add(t["id"])
        if s["type"] in IDENTIFIER_NODE_TYPES:
            out[t["id"]][s["type"]].add(s["id"])
    return out


# Identificador que DEFINE a entidade: se ambos o têm com valores diferentes, são entidades distintas
DEFINING_ID = {"conta_bancaria": ("conta_bancaria",), "arquivo": ("sha256", "sha1", "md5"), "hash": ("sha256", "sha1", "md5", "hash"),
               "ip": ("ip",), "dominio": ("dominio",), "url": ("url",), "email": ("email",), "telefone": ("telefone",),
               "certificado": ("certificado_sha256",), "perfil_social": ("perfil",), "usuario": ("username",),
               "veiculo": ("placa", "chassi"), "cpf": ("cpf",), "cnpj": ("cnpj",), "pix": ("pix",), "aplicativo": ("pacote_android",),
               "processo": ("processo",), "imei": ("imei",), "mac": ("mac",), "asn": ("asn",)}


def _defining_conflict(a: dict, b: dict) -> bool:
    for k in DEFINING_ID.get(a["type"], ()):
        va = ((a.get("identifiers") or {}).get(k) or {}).get("normalized")
        vb = ((b.get("identifiers") or {}).get(k) or {}).get("normalized")
        if va and vb and va != vb:
            if k == "conta_bancaria" and "|" in va and "|" in vb:
                pa, pb = va.split("|"), vb.split("|")
                if len(pa) == len(pb) and all(x == y or "?" in (x, y) for x, y in zip(pa, pb)):
                    continue
            return True
    return False


def smart_match(case: dict, threshold: float = 0.75, types: set | None = None) -> list[dict]:
    """Sugere pares possivelmente equivalentes com explicação multicritério.
    NUNCA mescla: a decisão (confirmar / rejeitar / manter como hipótese) é humana."""
    ents = [e for e in case["entities"] if e.get("status") != "rejeitado" and (not types or e["type"] in types)
            and not (e.get("attributes") or {}).get("placeholder")]
    rejected = {tuple(sorted(p)) for p in case.get("case", {}).get("rejected_matches", [])}
    nbr = _neighbors_by_type(case)
    by_type = defaultdict(list)
    for e in ents:
        by_type[e["type"]].append(e)
    out = []
    for t, group in by_type.items():
        for a, b in itertools.combinations(group, 2):
            if tuple(sorted((a["id"], b["id"]))) in rejected or _defining_conflict(a, b):
                continue
            criteria, conflicts = [], []
            names_a = [a["label"]] + a.get("aliases", [])
            names_b = [b["label"]] + b.get("aliases", [])
            ns, why = max((name_similarity(x, y) for x in names_a for y in names_b), key=lambda z: z[0])
            if ns >= 0.6:
                criteria.append({"criterion": "nome", "score": ns, "detail": why})
            ia, ib = a.get("identifiers", {}), b.get("identifiers", {})
            for k in set(ia) & set(ib):
                va, vb = ia[k].get("normalized"), ib[k].get("normalized")
                if va and vb:
                    if va == vb:
                        criteria.append({"criterion": f"identificador {k}", "score": 1.0, "detail": f"{k} idêntico ({va})"})
                    elif k in SINGLE_VALUED_ATTRIBUTES or k in ("cpf", "cnpj", "data_nascimento"):
                        conflicts.append(f"{k} divergente: {va} × {vb}")
            for k in set(a.get("attributes", {})) & set(b.get("attributes", {})):
                va, vb = str(a["attributes"][k]).strip().lower(), str(b["attributes"][k]).strip().lower()
                if va and va == vb:
                    criteria.append({"criterion": f"atributo {k}", "score": 0.6, "detail": f"{k} igual ({va})"})
                elif k in SINGLE_VALUED_ATTRIBUTES and va and vb:
                    conflicts.append(f"{k} divergente: {va} × {vb}")
            for nt in set(nbr[a["id"]]) & set(nbr[b["id"]]):
                shared = nbr[a["id"]][nt] & nbr[b["id"]][nt]
                if shared:
                    criteria.append({"criterion": f"{nt} compartilhado", "score": 0.7,
                                     "detail": f"vinculados ao(s) mesmo(s) {nt}: {', '.join(sorted(shared))}"})
            if not criteria:
                continue
            strong = any(c["score"] == 1.0 for c in criteria)
            if strong and t in ("pessoa", "empresa") and ns < 0.6:
                conflicts.append(f"identificador idêntico, mas nomes incompatíveis ({a['label']} × {b['label']}) — "
                                 "possível uso de documento de terceiro ou erro cadastral")
            # combinação: 1 - Π(1 - s_i*w) — evidências independentes reforçam-se
            prod = 1.0
            for c in criteria:
                w = 0.95 if c["score"] == 1.0 else (0.85 if c["criterion"] == "nome" else 0.5)
                prod *= 1 - c["score"] * w
            score = 1 - prod
            if conflicts:
                score *= 0.4
            if score < threshold and not strong:
                continue
            out.append({
                "pair": [a["id"], b["id"]], "labels": [a["label"], b["label"]], "type": t,
                "score": round(score, 3), "criteria": criteria, "conflicts": conflicts,
                "nature": "correlacao",
                "recommendation": ("NÃO mesclar sem verificação: há atributos conflitantes" if conflicts else
                                   "Verificar documentação antes de confirmar" if not strong else
                                   "Forte indício de mesma entidade — confirmar com documento"),
                "actions": ["confirmar (merge com motivo)", "rejeitar", "manter como hipótese"],
            })
    return sorted(out, key=lambda x: -x["score"])


# ============================================================================
# 4.9–4.10 Fontes múltiplas e contradições — sinaliza, nunca escolhe
# ============================================================================

def _overlap(a_start, a_end, b_start, b_end) -> bool:
    a0, b0 = to_datetime(a_start), to_datetime(b_start)
    a1, b1 = to_datetime(a_end), to_datetime(b_end)
    if a0 is None or b0 is None:
        return True  # período desconhecido: não é possível descartar sobreposição
    return (a1 is None or a1 >= b0) and (b1 is None or b1 >= a0)


def contradictions(case: dict) -> list[dict]:
    out = []
    idx = {e["id"]: e for e in case["entities"]}
    # (a) relações exclusivas simultâneas (ex.: reside em X e Y)
    groups = defaultdict(list)
    for r in case["relationships"]:
        if r["type"] in EXCLUSIVE_RELATIONSHIP_TYPES and r.get("status") != "rejeitado":
            groups[(r["source"], r["type"])].append(r)
    for (src, rtype), rels in groups.items():
        for r1, r2 in itertools.combinations(rels, 2):
            if r1["target"] != r2["target"] and _overlap(r1.get("start"), r1.get("end"), r2.get("start"), r2.get("end")):
                out.append({
                    "kind": "relação exclusiva simultânea", "subject": src,
                    "subject_label": idx.get(src, {}).get("label"),
                    "statement_a": f"{rtype} {idx.get(r1['target'], {}).get('label')} ({r1['id']}; fontes {r1.get('source_ids')})",
                    "statement_b": f"{rtype} {idx.get(r2['target'], {}).get('label')} ({r2['id']}; fontes {r2.get('source_ids')})",
                    "objects": [r1["id"], r2["id"]],
                    "note": "Períodos se sobrepõem ou são desconhecidos. Pode ser mudança de endereço não datada, "
                            "duplo domicílio ou erro de uma das fontes — não há escolha automática.",
                })
    # (b) atributos de valor único divergentes (entidades e observações)
    vals = defaultdict(lambda: defaultdict(list))
    for e in case["entities"]:
        for k, v in e.get("attributes", {}).items():
            if k in SINGLE_VALUED_ATTRIBUTES and v not in (None, ""):
                vals[e["id"]][k].append((str(v).strip(), e.get("source_ids") or ["?"], e["id"]))
    for o in case["observations"]:
        if o.get("entity_id") and o.get("attribute") in SINGLE_VALUED_ATTRIBUTES and o.get("value") not in (None, ""):
            vals[o["entity_id"]][o["attribute"]].append((str(o["value"]).strip(), [o.get("source_id") or "?"], o["id"]))
    for eid, attrs in vals.items():
        for attr, items in attrs.items():
            distinct = {strip_accents(v).lower() for v, _, _ in items}
            if len(distinct) > 1:
                out.append({
                    "kind": "atributo divergente", "subject": eid, "subject_label": idx.get(eid, {}).get("label"),
                    "attribute": attr,
                    "values": [{"value": v, "sources": s, "object": oid} for v, s, oid in items],
                    "objects": [oid for _, _, oid in items],
                    "note": "Fontes atribuem valores diferentes a um atributo de valor único.",
                })
    # (c) objetos marcados manualmente como contraditórios
    for coll in ("entities", "relationships", "events"):
        for o in case[coll]:
            if o.get("status") == "contraditorio":
                mention = re.compile(r"\b" + re.escape(o["id"]) + r"\b")
                obs = [x for x in case.get("observations", []) if "CONTRADI" in str(x.get("statement", "")).upper()
                       and (o["id"] in (x.get("entity_id"), x.get("relationship_id")) or mention.search(str(x.get("statement", ""))))]
                out.append({"kind": "marcado como contraditório", "subject": o["id"],
                            "subject_label": o.get("label") or o.get("title") or o.get("type"),
                            "objects": [o["id"]] + [x["id"] for x in obs],
                            "details": [f'{x["id"]}: {x["statement"]}' for x in obs],
                            "note": o.get("notes", "") or ("" if obs else "Status definido manualmente; registre a observação que descreve a contradição.")})
    return out


def multi_source(case: dict) -> dict:
    """Quais objetos têm múltiplas fontes, quais dependem de uma única fonte."""
    single, multiple, none_ = [], [], []
    for coll in ("entities", "relationships", "events"):
        for o in case[coll]:
            n = len(set(o.get("source_ids", [])))
            (none_ if n == 0 else single if n == 1 else multiple).append(o["id"])
    # entidades citadas por mais fontes (fontes próprias + fontes das relações que as tocam)
    per_entity = defaultdict(set)
    for e in case["entities"]:
        per_entity[e["id"]].update(e.get("source_ids", []))
    for r in case["relationships"]:
        for end in ("source", "target"):
            per_entity[r[end]].update(r.get("source_ids", []))
    ranked = sorted(((k, len(v)) for k, v in per_entity.items()), key=lambda x: -x[1])
    return {"multiple_sources": multiple, "single_source": single, "no_source": none_,
            "entities_by_source_count": ranked}


# ============================================================================
# 3.3 / 3.5 Análise temporal e espacial
# ============================================================================

def timeline(case: dict) -> list[dict]:
    """Eventos + relações datadas ordenados. Datas desconhecidas vão para o final."""
    items = []
    for ev in case["events"]:
        items.append({"id": ev["id"], "kind": "evento", "type": ev["type"], "title": ev["title"],
                      "start": ev.get("start"), "end": ev.get("end"), "precision": ev.get("date_precision"),
                      "entities": ev.get("participants", []), "nature": ev.get("nature")})
    for r in case["relationships"]:
        if r.get("start"):
            items.append({"id": r["id"], "kind": "relação", "type": r["type"], "title": f"{r['source']} {r['type']} {r['target']}",
                          "start": r["start"], "end": r.get("end"), "precision": "", "entities": [r["source"], r["target"]],
                          "nature": r.get("nature")})
    known = sorted([i for i in items if to_datetime(i["start"])], key=lambda i: to_datetime(i["start"]))
    unknown = [i for i in items if not to_datetime(i["start"])]
    return known + unknown


def temporal_analysis(case: dict, reference_event: str | None = None, window_hours: float = 24,
                      simultaneous_minutes: float = 10) -> dict:
    tl = [i for i in timeline(case) if to_datetime(i["start"])]
    res: dict = {"first": tl[0] if tl else None, "last": tl[-1] if tl else None,
                 "undated": [i["id"] for i in timeline(case) if not to_datetime(i["start"])]}
    # recorrência de entidades nos eventos
    cnt = Counter(e for i in tl if i["kind"] == "evento" for e in i["entities"])
    res["recurring_entities"] = [{"entity": k, "events": v} for k, v in cnt.most_common() if v > 1]
    # simultaneidade
    sims = []
    evs = [i for i in tl if i["kind"] == "evento" and i.get("precision") in ("exata", None, "")]
    for a, b in zip(evs, evs[1:]):
        delta = (to_datetime(b["start"]) - to_datetime(a["start"])).total_seconds() / 60
        if delta <= simultaneous_minutes:
            sims.append({"events": [a["id"], b["id"]], "minutes_apart": round(delta, 1),
                         "shared_entities": sorted(set(a["entities"]) & set(b["entities"]))})
    res["simultaneous"] = sims
    # duração das relações
    durs = []
    for r in case["relationships"]:
        s, e = to_datetime(r.get("start")), to_datetime(r.get("end"))
        if s and e:
            durs.append({"relationship": r["id"], "type": r["type"], "days": (e - s).days})
    res["relationship_durations"] = durs
    if reference_event:
        ref = next((i for i in tl if i["id"] == reference_event), None)
        if ref:
            t0 = to_datetime(ref["start"])
            w = timedelta(hours=window_hours)
            res["reference"] = ref
            res["before"] = [i for i in tl if to_datetime(i["start"]) < t0]
            res["after"] = [i for i in tl if to_datetime(i["start"]) > t0]
            res["window_before"] = [i for i in res["before"] if t0 - to_datetime(i["start"]) <= w]
            res["window_after"] = [i for i in res["after"] if to_datetime(i["start"]) - t0 <= w]
            res["involved_entities"] = ref["entities"]
    res["caveat"] = ("Ordem temporal não implica causalidade. Datas com precisão 'dia', 'mês', 'ano' ou "
                     "'aproximada' podem alterar a sequência; verifique fuso horário das fontes (logs em UTC × "
                     "horário local).")
    return res


def haversine_km(lat1, lon1, lat2, lon2) -> float:
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def _located(case: dict) -> list[dict]:
    pts = []
    for coll, kind in (("entities", "entidade"), ("events", "evento")):
        for o in case[coll]:
            loc = o.get("location") or {}
            if loc.get("lat") is not None and loc.get("lon") is not None:
                pts.append({"id": o["id"], "kind": kind, "label": o.get("label") or o.get("title"),
                            "lat": float(loc["lat"]), "lon": float(loc["lon"]), "start": o.get("start"),
                            "participants": o.get("participants", []), "precision_m": loc.get("precision_m")})
    return pts


def spatial_analysis(case: dict, radius_km: float = 0.5) -> dict:
    pts = _located(case)
    near = []
    for a, b in itertools.combinations(pts, 2):
        d = haversine_km(a["lat"], a["lon"], b["lat"], b["lon"])
        if d <= radius_km:
            near.append({"a": a["id"], "b": b["id"], "km": round(d, 3)})
    # endereços compartilhados (entidades ligadas ao mesmo endereço)
    idx = {e["id"]: e for e in case["entities"]}
    by_addr = defaultdict(set)
    for r in case["relationships"]:
        if r.get("status") == "rejeitado":
            continue
        for x, y in ((r["source"], r["target"]), (r["target"], r["source"])):
            if idx.get(y, {}).get("type") == "endereco" and idx.get(x, {}).get("type") != "endereco":
                by_addr[y].add(x)
    shared = [{"address": k, "label": idx[k]["label"], "entities": sorted(v)} for k, v in by_addr.items() if len(v) > 1]
    # trajetória por entidade (eventos localizados e datados)
    traj = defaultdict(list)
    for p in pts:
        if p["kind"] == "evento" and to_datetime(p["start"]):
            for e in p["participants"]:
                traj[e].append(p)
    trajectories = {}
    for e, seq in traj.items():
        seq.sort(key=lambda p: to_datetime(p["start"]))
        legs = []
        for a, b in zip(seq, seq[1:]):
            km = haversine_km(a["lat"], a["lon"], b["lat"], b["lon"])
            hrs = (to_datetime(b["start"]) - to_datetime(a["start"])).total_seconds() / 3600
            speed = km / hrs if hrs > 0 else None
            legs.append({"from": a["id"], "to": b["id"], "km": round(km, 2), "hours": round(hrs, 2),
                         "kmh": None if speed is None else round(speed, 1),
                         "flag": ("deslocamento implausível (>900 km/h) — verificar dados/geolocalização"
                                  if speed and speed > 900 else "")})
        trajectories[e] = legs
    # concentração: grade de ~1 km
    grid = Counter((round(p["lat"], 2), round(p["lon"], 2)) for p in pts)
    hotspots = [{"lat": k[0], "lon": k[1], "count": v} for k, v in grid.most_common(10) if v > 1]
    return {"points": pts, "near_pairs": near, "shared_addresses": shared, "trajectories": trajectories,
            "hotspots": hotspots,
            "caveat": "Geolocalização por IP é aproximada (cidade/região) e não indica localização física "
                      "de pessoa. Coordenadas de ERB indicam área de cobertura, não ponto exato."}


# ============================================================================
# 5.6–5.7 Análise financeira e de fluxo
# ============================================================================

def _transactions(case: dict) -> list[dict]:
    tx = []
    for r in case["relationships"]:
        amt = (r.get("attributes") or {}).get("amount")
        if r["type"] in FINANCIAL_TYPES and amt is not None and r.get("status") != "rejeitado":
            src, dst = (r["target"], r["source"]) if r["type"] in ("recebeu", "recebeu de") else (r["source"], r["target"])
            tx.append({"id": r["id"], "from": src, "to": dst, "amount": float(amt), "date": r.get("start"),
                       "evidence": r.get("evidence_ids", []), "nature": r.get("nature")})
    for ev in case["events"]:
        a = ev.get("attributes") or {}
        if ev["type"] in ("transferencia", "deposito", "saque", "evento_financeiro") and a.get("amount") is not None:
            frm, to = a.get("from"), a.get("to")
            if not (frm and to) and len(ev.get("participants", [])) >= 2:
                frm, to = ev["participants"][0], ev["participants"][1]
            if frm and to:
                d = to_datetime(ev.get("start"))
                # evita contar duas vezes a mesma transação registrada como relação E como evento
                dup = any(t["from"] == frm and t["to"] == to and abs(t["amount"] - float(a["amount"])) < 0.01 and
                          (d is None or to_datetime(t["date"]) is None or abs((to_datetime(t["date"]) - d).total_seconds()) <= 300)
                          for t in tx) or any(rid in {t["id"] for t in tx} for rid in ev.get("relationship_ids", []))
                if dup:
                    continue
                tx.append({"id": ev["id"], "from": frm, "to": to, "amount": float(a["amount"]),
                           "date": ev.get("start"), "evidence": ev.get("evidence_ids", []), "nature": ev.get("nature")})
    return tx


def financial_analysis(case: dict, structuring_threshold: float = 10000.0, structuring_margin: float = 0.15,
                       passthrough_tolerance: float = 0.1, passthrough_hours: float = 72) -> dict:
    tx = _transactions(case)
    idx = {e["id"]: e for e in case["entities"]}
    acc = defaultdict(lambda: {"in": 0.0, "out": 0.0, "n_in": 0, "n_out": 0, "first": None, "last": None,
                               "counterparties_in": Counter(), "counterparties_out": Counter(), "in_tx": [], "out_tx": []})
    for t in tx:
        d = to_datetime(t["date"])
        for side, node, other in (("out", t["from"], t["to"]), ("in", t["to"], t["from"])):
            a = acc[node]
            a[side] += t["amount"]
            a[f"n_{side}"] += 1
            a[f"counterparties_{side}"][other] += t["amount"]
            a[f"{side}_tx"].append(t)
            if d:
                a["first"] = d if not a["first"] or d < a["first"] else a["first"]
                a["last"] = d if not a["last"] or d > a["last"] else a["last"]
    accounts = {}
    findings = []
    for node, a in acc.items():
        total_in = a["in"]
        top_in = a["counterparties_in"].most_common(1)
        top_out = a["counterparties_out"].most_common(1)
        accounts[node] = {
            "label": idx.get(node, {}).get("label", node), "type": idx.get(node, {}).get("type"),
            "in": round(a["in"], 2), "out": round(a["out"], 2), "balance": round(a["in"] - a["out"], 2),
            "n_in": a["n_in"], "n_out": a["n_out"],
            "first": a["first"].isoformat() if a["first"] else None, "last": a["last"].isoformat() if a["last"] else None,
            "concentration_in": round(top_in[0][1] / total_in, 3) if top_in and total_in else None,
            "concentration_out": round(top_out[0][1] / a["out"], 3) if top_out and a["out"] else None,
        }
        # conta de passagem
        if a["in"] > 0 and a["out"] > 0 and abs(a["in"] - a["out"]) <= passthrough_tolerance * a["in"]:
            ins = [to_datetime(t["date"]) for t in a["in_tx"] if to_datetime(t["date"])]
            outs = [to_datetime(t["date"]) for t in a["out_tx"] if to_datetime(t["date"])]
            quick = bool(ins and outs and (max(outs) - min(ins)).total_seconds() / 3600 <= passthrough_hours)
            findings.append({"kind": "possível conta de passagem", "account": node, "nature": "inferencia",
                             "reason": f"entradas R$ {fmt_brl(a['in'])} ≈ saídas R$ {fmt_brl(a['out'])} "
                                       f"(diferença ≤ {passthrough_tolerance:.0%})"
                                       + (f", repasse em até {passthrough_hours:.0f}h" if quick else ""),
                             "limitations": "Só considera transações registradas no caso; saldo prévio e "
                                            "movimentações não importadas podem explicar o padrão."})
        # fracionamento
        lo = structuring_threshold * (1 - structuring_margin)
        near = [t for t in a["out_tx"] + a["in_tx"] if lo <= t["amount"] < structuring_threshold]
        if len(near) >= 3:
            findings.append({"kind": "possível fracionamento", "account": node, "nature": "inferencia",
                             "transactions": [t["id"] for t in near],
                             "reason": f"{len(near)} transações entre R$ {fmt_brl(lo)} e R$ {fmt_brl(structuring_threshold)} "
                                       f"(logo abaixo do limiar configurado)",
                             "limitations": "Limiar configurável; valores próximos podem ter explicação comercial."})
    # circularidade
    F = nx.DiGraph()
    for t in tx:
        if F.has_edge(t["from"], t["to"]):
            F[t["from"]][t["to"]]["amount"] += t["amount"]
            F[t["from"]][t["to"]]["ids"].append(t["id"])
        else:
            F.add_edge(t["from"], t["to"], amount=t["amount"], ids=[t["id"]])
    cycles = list(itertools.islice(nx.simple_cycles(F, length_bound=6), 50)) if F.number_of_edges() else []
    for c in cycles:
        if len(c) >= 2:
            findings.append({"kind": "fluxo circular", "accounts": c, "nature": "correlacao",
                             "reason": "recursos retornam à origem por " + " → ".join(c + [c[0]]),
                             "limitations": "Ciclos podem refletir estornos, empréstimos ou operações legítimas."})
    # intermediários (in e out, betweenness no grafo financeiro)
    inter = []
    if F.number_of_nodes() > 2:
        btw = nx.betweenness_centrality(F)
        inter = [{"account": k, "betweenness": round(v, 3)} for k, v in sorted(btw.items(), key=lambda x: -x[1]) if v > 0][:10]
    # anomalias de valor (IQR)
    amounts = [t["amount"] for t in tx]
    outliers = []
    if len(amounts) >= 5:
        q = statistics.quantiles(amounts, n=4)
        iqr = q[2] - q[0]
        hi = q[2] + 1.5 * iqr
        outliers = [{"transaction": t["id"], "amount": t["amount"],
                     "reason": f"valor acima de Q3 + 1,5×IQR (R$ {fmt_brl(hi)}) na amostra do caso"}
                    for t in tx if t["amount"] > hi]
    origins = [n for n in F if F.in_degree(n) == 0]
    sinks = [n for n in F if F.out_degree(n) == 0]
    flows = []
    # caminhos maximais a partir das origens (param quando não há sucessor não visitado)
    def walk(path):
        if len(flows) >= 30:
            return
        nxt = [v for v in F.successors(path[-1]) if v not in path]
        if not nxt or len(path) > 7:
            if len(path) > 1:
                flows.append({"path": list(path), "amounts": [round(F[u][v]["amount"], 2) for u, v in zip(path, path[1:])],
                              "transactions": [F[u][v]["ids"] for u, v in zip(path, path[1:])],
                              "ends_in": "destino final" if path[-1] in sinks else "retorno/ciclo ou limite"})
            return
        for v in nxt:
            walk(path + [v])
    for o in origins:
        walk([o])
    return {"transactions": tx, "accounts": accounts, "findings": findings, "cycles": cycles,
            "intermediaries": inter, "value_outliers": outliers, "origins": origins, "sinks": sinks,
            "flows": flows,
            "caveat": "Análise restrita às transações registradas no caso. Ausência de dado não é ausência de fato."}


# ============================================================================
# 5.12 Anomalias (sempre com motivo)
# ============================================================================

def anomalies(case: dict, night_hours=(0, 5), burst_window_min: float = 60, burst_count: int = 5) -> list[dict]:
    out = []
    fin = financial_analysis(case)
    for o in fin["value_outliers"]:
        out.append({"kind": "valor fora do padrão", "objects": [o["transaction"]], "reason": o["reason"]})
    for f in fin["findings"]:
        if f["kind"] in ("possível fracionamento", "fluxo circular"):
            out.append({"kind": f["kind"], "objects": f.get("transactions") or f.get("accounts"), "reason": f["reason"]})
    evs = [e for e in case["events"] if to_datetime(e.get("start")) and e.get("date_precision") == "exata"]
    for e in evs:
        h = to_datetime(e["start"]).hour
        if night_hours[0] <= h <= night_hours[1]:
            out.append({"kind": "horário incomum", "objects": [e["id"]],
                        "reason": f"evento às {h:02d}h (faixa {night_hours[0]:02d}h–{night_hours[1]:02d}h). "
                                  "Confirme fuso horário da fonte."})
    # rajadas de frequência por entidade
    per = defaultdict(list)
    for e in evs:
        for p in e.get("participants", []):
            per[p].append(to_datetime(e["start"]))
    for ent, ts in per.items():
        ts.sort()
        j = 0
        for i in range(len(ts)):
            while ts[i] - ts[j] > timedelta(minutes=burst_window_min):
                j += 1
            if i - j + 1 >= burst_count:
                out.append({"kind": "frequência anormal", "objects": [ent],
                            "reason": f"{i - j + 1} eventos em {burst_window_min:.0f} min a partir de {ts[j].isoformat()}"})
                break
    # novos IPs/dispositivos após o primeiro registro da entidade
    idx = {x["id"]: x for x in case["entities"]}
    seen = defaultdict(list)
    for r in sorted(case["relationships"], key=lambda r: to_datetime(r.get("start")) or to_datetime("9999")):
        t = idx.get(r["target"], {})
        if t.get("type") in ("ip", "dispositivo", "imei") and r["type"] in ("utiliza", "acessou", "conectado a"):
            prev = seen[(r["source"], t["type"])]
            if prev and r.get("start"):
                out.append({"kind": f"novo {t['type']}", "objects": [r["id"]],
                            "reason": f"{idx.get(r['source'], {}).get('label')} passou a usar {t.get('label')} em {r['start']} "
                                      f"(anteriores: {', '.join(prev)})"})
            prev.append(t.get("label"))
    for a in out:
        a["nature"] = "inferencia"
    return out


# ============================================================================
# 5.8–5.9 Hipóteses e 5.13 lacunas
# ============================================================================

def hypothesis_matrix(case: dict) -> list[dict]:
    rows = []
    for h in case["hypotheses"]:
        sup, con = h.get("supporting", []), h.get("contradicting", [])
        flags = []
        if not con:
            flags.append("nenhuma evidência contrária registrada — buscar ativamente (viés de confirmação)")
        if not sup:
            flags.append("sem evidência favorável vinculada")
        cv = confidence_value(h.get("confidence"))
        if cv is not None and cv >= 0.7 and len(sup) < 2:
            flags.append("confiança alta apoiada em menos de duas evidências")
        weak = []
        for ref in sup:
            for coll in ("relationships", "entities", "events", "observations"):
                o = next((x for x in case[coll] if x["id"] == ref), None)
                if o and o.get("nature") in ("inferencia", "correlacao", "hipotese", "nao_verificado"):
                    weak.append(f"{ref} ({NATURES[o['nature']]})")
        if weak:
            flags.append("apoio inclui itens não factuais: " + ", ".join(weak))
        rows.append({"id": h["id"], "title": h["title"], "supporting": sup, "contradicting": con,
                     "gaps": h.get("gaps", []), "confidence": h.get("confidence"), "status": h.get("status"),
                     "balance": len(sup) - len(con), "flags": flags})
    return rows


def gaps(case: dict) -> list[dict]:
    out = []
    for e in case["entities"]:
        if e["type"] in ("pessoa", "empresa") and not e.get("identifiers"):
            out.append({"kind": "entidade sem identificação", "object": e["id"], "label": e["label"],
                        "suggestion": "obter CPF/CNPJ ou documento que individualize a entidade"})
        if not e.get("source_ids") and not e.get("evidence_ids"):
            out.append({"kind": "entidade sem fonte", "object": e["id"], "label": e["label"],
                        "suggestion": "vincular a fonte de onde a entidade foi extraída"})
    for r in case["relationships"]:
        if not r.get("evidence_ids"):
            out.append({"kind": "relação sem evidência", "object": r["id"], "label": r["type"],
                        "suggestion": "vincular documento/registro que sustente a relação"})
        if len(set(r.get("source_ids", []))) == 1 and r.get("nature") not in ("fato", "observado"):
            out.append({"kind": "relação de fonte única", "object": r["id"], "label": r["type"],
                        "suggestion": "buscar corroboração independente"})
    for ev in case["events"]:
        if not ev.get("source_ids"):
            out.append({"kind": "evento sem fonte", "object": ev["id"], "label": ev["title"],
                        "suggestion": "registrar origem do evento"})
        if ev.get("date_precision") in ("desconhecida", "aproximada", "ano", "mes"):
            out.append({"kind": "data imprecisa/desconhecida", "object": ev["id"], "label": ev["title"],
                        "suggestion": f"precisão atual: {ev.get('date_precision')} — obter registro com data/hora"})
    for c in contradictions(case):
        out.append({"kind": "contradição não resolvida", "object": ",".join(c["objects"]), "label": c["kind"],
                    "suggestion": "confrontar fontes; registrar decisão e motivo"})
    for h in hypothesis_matrix(case):
        if h["flags"]:
            out.append({"kind": "hipótese", "object": h["id"], "label": h["title"], "suggestion": "; ".join(h["flags"])})
    ents_in_rel = {r["source"] for r in case["relationships"]} | {r["target"] for r in case["relationships"]}
    ents_in_ev = {p for ev in case["events"] for p in ev.get("participants", [])}
    for e in case["entities"]:
        if e["id"] not in ents_in_rel and e["id"] not in ents_in_ev:
            out.append({"kind": "entidade isolada", "object": e["id"], "label": e["label"],
                        "suggestion": "verificar vínculos ou justificar presença no caso"})
    return out


# ============================================================================
# Análise completa
# ============================================================================

def full_analysis(case: dict, **filters) -> dict:
    from case_model import Case  # validação
    return {
        "generated_at": __import__("case_model").now_iso(),
        "case_id": case["case"]["id"],
        "filters": {k: (sorted(v) if isinstance(v, set) else v) for k, v in filters.items()},
        "validation": Case(case).validate(),
        "network": network_metrics(case, **filters),
        "multi_source": multi_source(case),
        "contradictions": contradictions(case),
        "smart_match": smart_match(case),
        "temporal": temporal_analysis(case),
        "spatial": spatial_analysis(case),
        "financial": financial_analysis(case),
        "anomalies": anomalies(case),
        "hypotheses": hypothesis_matrix(case),
        "gaps": gaps(case),
        "epistemic_note": "Todos os resultados desta análise são CORRELAÇÕES ou INFERÊNCIAS computacionais "
                          "sobre os dados registrados. Nenhum resultado é convertido automaticamente em fato; "
                          "a validação é humana.",
    }
