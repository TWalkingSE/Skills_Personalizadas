"""
export.py — Exportação de dados e pacote do caso (Fase 6.8).

Dados: CSV, XLSX, JSON, GraphML, GEXF.  Pacote: ZIP com caso, análise, visualizador,
relatório, manifesto de evidências, auditoria e manifesto SHA-256 de todos os arquivos.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import zipfile

import networkx as nx

from case_model import NATURES, now_iso


def _flat(v):
    if isinstance(v, (list, tuple)):
        return "; ".join(str(x) for x in v)
    if isinstance(v, dict):
        return json.dumps(v, ensure_ascii=False)
    return "" if v is None else v


def tables(case: dict) -> dict[str, list[dict]]:
    ents = []
    for e in case["entities"]:
        row = {k: _flat(e.get(k)) for k in ("id", "type", "label", "aliases", "description", "nature", "confidence",
                                            "status", "source_ids", "evidence_ids", "tags", "start", "end", "notes")}
        for k, v in e.get("identifiers", {}).items():
            row[f"id_{k}_original"] = v.get("original")
            row[f"id_{k}_normalizado"] = v.get("normalized")
        for k, v in e.get("attributes", {}).items():
            row[f"attr_{k}"] = _flat(v)
        loc = e.get("location") or {}
        row["lat"], row["lon"] = loc.get("lat"), loc.get("lon")
        ents.append(row)
    rels = [{**{k: _flat(r.get(k)) for k in ("id", "source", "type", "target", "directed", "start", "end", "nature",
                                            "confidence", "status", "source_ids", "evidence_ids", "notes", "author",
                                            "origin", "created_at")},
             "amount": (r.get("attributes") or {}).get("amount")} for r in case["relationships"]]
    evs = [{k: _flat(e.get(k)) for k in ("id", "title", "type", "start", "end", "date_precision", "participants",
                                          "nature", "confidence", "status", "source_ids", "evidence_ids", "description")}
           for e in case["events"]]
    simple = lambda coll: [{k: _flat(v) for k, v in o.items()} for o in case.get(coll, [])]
    return {"entidades": ents, "relacoes": rels, "eventos": evs, "observacoes": simple("observations"),
            "fontes": simple("sources"), "evidencias": simple("evidence"), "hipoteses": simple("hypotheses"),
            "consultas_osint": simple("osint_queries"), "auditoria": simple("audit_log")}


def write_csv_dir(case: dict, out_dir: str) -> list[str]:
    os.makedirs(out_dir, exist_ok=True)
    paths = []
    for name, rows in tables(case).items():
        p = os.path.join(out_dir, f"{name}.csv")
        cols = list(dict.fromkeys(k for r in rows for k in r)) or ["id"]
        with open(p, "w", encoding="utf-8-sig", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=cols, delimiter=";")
            w.writeheader()
            w.writerows(rows)
        paths.append(p)
    return paths


def write_xlsx(case: dict, path: str) -> str:
    import pandas as pd
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        for name, rows in tables(case).items():
            pd.DataFrame(rows or [{"id": ""}]).to_excel(xw, sheet_name=name[:31], index=False)
    return path


def to_networkx(case: dict) -> nx.MultiDiGraph:
    G = nx.MultiDiGraph(case_id=case["case"]["id"], title=case["case"]["title"], exported_at=now_iso())
    for e in case["entities"]:
        loc = e.get("location") or {}
        G.add_node(e["id"], label=e["label"], type=e["type"], nature=e.get("nature", ""),
                   nature_label=NATURES.get(e.get("nature"), ""), status=e.get("status", ""),
                   confidence=str(e.get("confidence") or ""), sources=";".join(e.get("source_ids", [])),
                   evidence=";".join(e.get("evidence_ids", [])),
                   lat=float(loc["lat"]) if loc.get("lat") is not None else 0.0,
                   lon=float(loc["lon"]) if loc.get("lon") is not None else 0.0)
    for r in case["relationships"]:
        G.add_edge(r["source"], r["target"], key=r["id"], id=r["id"], label=r["type"], type=r["type"],
                   directed=str(r.get("directed", True)), nature=r.get("nature", ""), status=r.get("status", ""),
                   confidence=str(r.get("confidence") or ""), start=r.get("start") or "", end=r.get("end") or "",
                   sources=";".join(r.get("source_ids", [])), evidence=";".join(r.get("evidence_ids", [])),
                   amount=float((r.get("attributes") or {}).get("amount") or 0))
    return G


def write_graphml(case: dict, path: str) -> str:
    nx.write_graphml(to_networkx(case), path)
    return path


def write_gexf(case: dict, path: str) -> str:
    nx.write_gexf(to_networkx(case), path)
    return path


def evidence_manifest(case: dict) -> str:
    lines = ["# Manifesto de evidências", "", f"Caso: {case['case']['id']} — {case['case']['title']}",
             f"Gerado em: {now_iso()}", "", "| ID | Nome | Tipo | SHA-256 | Tamanho | Fonte | Arquivo |", "|---|---|---|---|---|---|---|"]
    for d in case["evidence"]:
        lines.append(f"| {d['id']} | {d['name']} | {d['type']} | `{d.get('hashes', {}).get('sha256', '—')}` | "
                     f"{d.get('size') or '—'} | {d.get('source_id') or '—'} | {d.get('storage_path') or '—'} |")
    return "\n".join(lines) + "\n"


def case_package(case: dict, out_zip: str, analysis: dict | None = None, viewer_html: str | None = None,
                 report_md: str | None = None, include_evidence_files: bool = False) -> str:
    files: dict[str, bytes] = {}
    files["caso.json"] = json.dumps(case, ensure_ascii=False, indent=2).encode()
    if analysis:
        files["analise.json"] = json.dumps(analysis, ensure_ascii=False, indent=2, default=str).encode()
    if viewer_html:
        files["visualizador.html"] = viewer_html.encode()
    if report_md:
        files["relatorio.md"] = report_md.encode()
    files["evidencias/MANIFESTO.md"] = evidence_manifest(case).encode()
    G = to_networkx(case)
    buf = io.BytesIO(); nx.write_graphml(G, buf); files["grafo.graphml"] = buf.getvalue()
    buf = io.BytesIO(); nx.write_gexf(G, buf); files["grafo.gexf"] = buf.getvalue()
    for name, rows in tables(case).items():
        s = io.StringIO()
        cols = list(dict.fromkeys(k for r in rows for k in r)) or ["id"]
        w = csv.DictWriter(s, fieldnames=cols, delimiter=";")
        w.writeheader(); w.writerows(rows)
        files[f"dados/{name}.csv"] = ("﻿" + s.getvalue()).encode()
    if include_evidence_files:
        for d in case["evidence"]:
            p = d.get("storage_path")
            if p and os.path.isfile(p):
                with open(p, "rb") as fh:
                    blob = fh.read()
                expected = d.get("hashes", {}).get("sha256")
                if expected and hashlib.sha256(blob).hexdigest() != expected:
                    raise ValueError(f"Hash divergente para {d['id']} ({p}) — pacote não gerado.")
                files[f"evidencias/{d['id']}_{os.path.basename(p)}"] = blob
    manifest = "\n".join(f"{hashlib.sha256(b).hexdigest()}  {n}" for n, b in sorted(files.items())) + "\n"
    files["SHA256SUMS.txt"] = manifest.encode()
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for n, b in files.items():
            z.writestr(n, b)
    return out_zip
