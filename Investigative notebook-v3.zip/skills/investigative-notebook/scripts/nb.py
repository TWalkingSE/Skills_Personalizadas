#!/usr/bin/env python3
"""
nb.py — CLI do Investigative Notebook.

Execute `python nb.py -h` ou `python nb.py <comando> -h`.
Todas as alterações passam por case_model.Case (auditoria automática).
Usuário registrado na auditoria: --user ou variável NB_USER.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import analyze as A  # noqa: E402
import export as X  # noqa: E402
import ingest as I  # noqa: E402
from case_model import Case, normalize  # noqa: E402


def _kv(items):
    out = {}
    for it in items or []:
        k, _, v = it.partition("=")
        out[k.strip()] = v.strip()
    return out


def _loc(a):
    loc = {}
    if getattr(a, "lat", None) is not None:
        loc["lat"], loc["lon"] = a.lat, a.lon
    if getattr(a, "address", None):
        loc["address"] = a.address
    return loc


def _print(obj):
    print(json.dumps(obj, ensure_ascii=False, indent=2, default=str))


def _filters(a) -> dict:
    f = {}
    if getattr(a, "mode", None):
        f["mode"] = a.mode
    if getattr(a, "min_confidence", None) is not None:
        f["min_confidence"] = a.min_confidence
    if getattr(a, "evidence_only", False):
        f["only_with_evidence"] = True
    if getattr(a, "rel_type", None):
        f["rel_types"] = set(a.rel_type)
    if getattr(a, "since", None) or getattr(a, "until", None):
        f["period"] = (a.since, a.until)
    return f


# ----------------------------------------------------------------------------
# Lote de operações (forma preferida para a IA registrar muitos itens)
# ----------------------------------------------------------------------------

OPS = {
    "source": "add_source", "evidence": "add_evidence", "entity": "add_entity", "rel": "add_relationship",
    "relationship": "add_relationship", "event": "add_event", "obs": "add_observation",
    "observation": "add_observation", "hypothesis": "add_hypothesis", "osint": "add_osint_query",
    "update": "update", "delete": "delete", "merge": "merge_entities",
}


def _resolve(v, refs):
    if isinstance(v, str) and v.startswith("@"):
        if v[1:] not in refs:
            raise ValueError(f"Referência não definida no lote: {v}")
        return refs[v[1:]]
    if isinstance(v, list):
        return [_resolve(x, refs) for x in v]
    if isinstance(v, dict):
        return {k: _resolve(x, refs) for k, x in v.items()}
    return v


def apply_batch(case: Case, ops: list[dict]) -> dict:
    refs, created = {}, []
    for n, op in enumerate(ops, start=1):
        op = dict(op)
        kind = op.pop("op")
        ref = op.pop("ref", None)
        op = _resolve(op, refs)
        method = getattr(case, OPS[kind])
        try:
            if kind == "update":
                res = method(op.pop("id"), op.pop("set"), op.pop("reason", ""))
                res = res["id"]
            elif kind == "delete":
                method(op["id"], op.get("reason", "")); res = op["id"]
            elif kind == "merge":
                res = method(op["keep"], op["merge"], op["reason"])["id"]
            else:
                res = method(**op)
        except Exception as exc:  # noqa: BLE001
            raise SystemExit(f"Operação {n} ({kind}) falhou: {exc}")
        if ref:
            refs[ref] = res
        created.append({"op": kind, "ref": ref, "id": res})
    return {"applied": len(created), "refs": refs, "results": created}


# ----------------------------------------------------------------------------
# Comandos
# ----------------------------------------------------------------------------

def main(argv=None):
    p = argparse.ArgumentParser(prog="nb.py", description="Investigative Notebook — CLI")
    p.add_argument("--user", help="usuário para a auditoria (padrão: NB_USER ou responsável do caso)")
    sub = p.add_subparsers(dest="cmd", required=True)

    def cmd(name, help_):
        sp = sub.add_parser(name, help=help_)
        if name not in ("normalize",):
            sp.add_argument("case", help="arquivo do caso (.json)")
        return sp

    s = cmd("init", "criar caso")
    s.add_argument("--title", required=True); s.add_argument("--lead", default="")
    s.add_argument("--team", nargs="*", default=[]); s.add_argument("--classification", default="SIGILOSO")
    s.add_argument("--objective", default=""); s.add_argument("--description", default="")
    s.add_argument("--tags", nargs="*", default=[]); s.add_argument("--id")

    s = cmd("batch", "aplicar lote de operações JSON (lista de {op, ref?, ...})")
    s.add_argument("ops_file")

    s = cmd("import-bundle", "importar bundle intel-bundle/1.0 de outra skill (com entity resolution)")
    s.add_argument("bundles", nargs="+", help="um ou mais arquivos .bundle.json")
    s.add_argument("--dry-run", action="store_true", help="simular sem salvar o caso")

    s = cmd("add-source", "registrar fonte")
    s.add_argument("--type", required=True); s.add_argument("--title", required=True)
    s.add_argument("--reference", default=""); s.add_argument("--date", default=""); s.add_argument("--url", default="")
    s.add_argument("--notes", default=""); s.add_argument("--reliability", default="", help="A–F (Admiralty)")
    s.add_argument("--credibility", default="", help="1–6"); s.add_argument("--level", default="", help="primaria|secundaria")
    s.add_argument("--accessed-at", default="", help="data/hora da consulta (fontes web)")

    s = cmd("add-evidence", "registrar evidência (calcula SHA-256 e SHA-512 se --file)")
    s.add_argument("--name", required=True); s.add_argument("--type", default="outro"); s.add_argument("--file")
    s.add_argument("--source", default=""); s.add_argument("--origin", default=""); s.add_argument("--description", default="")
    s.add_argument("--sha512", action="store_true", help="(padrão) SHA-512 já é calculado junto com o SHA-256")
    s.add_argument("--md5", action="store_true", help="também calcular MD5 (referência legada)")

    s = cmd("add-entity", "adicionar entidade")
    s.add_argument("--type", required=True); s.add_argument("--label", required=True)
    s.add_argument("--id-kv", nargs="*", help="identificadores k=v (cpf=..., telefone=...)")
    s.add_argument("--attr", nargs="*", help="atributos k=v"); s.add_argument("--alias", nargs="*", default=[])
    s.add_argument("--nature"); s.add_argument("--confidence"); s.add_argument("--status")
    s.add_argument("--source", nargs="*", default=[]); s.add_argument("--evidence", nargs="*", default=[])
    s.add_argument("--lat", type=float); s.add_argument("--lon", type=float); s.add_argument("--address")
    s.add_argument("--notes", default=""); s.add_argument("--tags", nargs="*", default=[])

    s = cmd("add-rel", "adicionar relacionamento")
    s.add_argument("source"); s.add_argument("type"); s.add_argument("target")
    s.add_argument("--undirected", action="store_true"); s.add_argument("--start", default=""); s.add_argument("--end", default="")
    s.add_argument("--nature"); s.add_argument("--confidence"); s.add_argument("--status")
    s.add_argument("--source-id", nargs="*", default=[]); s.add_argument("--evidence", nargs="*", default=[])
    s.add_argument("--amount", type=float); s.add_argument("--notes", default="")

    s = cmd("add-event", "adicionar evento")
    s.add_argument("--title", required=True); s.add_argument("--type", default="personalizado")
    s.add_argument("--start", default=""); s.add_argument("--end", default="")
    s.add_argument("--participants", nargs="*", default=[]); s.add_argument("--nature"); s.add_argument("--confidence")
    s.add_argument("--source", nargs="*", default=[]); s.add_argument("--evidence", nargs="*", default=[])
    s.add_argument("--amount", type=float); s.add_argument("--from-entity"); s.add_argument("--to-entity")
    s.add_argument("--lat", type=float); s.add_argument("--lon", type=float); s.add_argument("--address")
    s.add_argument("--description", default="")

    s = cmd("add-hyp", "adicionar hipótese")
    s.add_argument("--title", required=True); s.add_argument("--supporting", nargs="*", default=[])
    s.add_argument("--contradicting", nargs="*", default=[]); s.add_argument("--gaps", nargs="*", default=[])
    s.add_argument("--confidence"); s.add_argument("--status", default="aberta")

    s = cmd("update", "alterar campos de um objeto"); s.add_argument("id"); s.add_argument("--set", nargs="+", required=True)
    s.add_argument("--json", action="store_true", help="valores em --set são JSON"); s.add_argument("--reason", default="")
    s = cmd("delete", "excluir objeto (auditoria registra o conteúdo)"); s.add_argument("id"); s.add_argument("--reason", required=True)
    s = cmd("merge", "mesclar entidades (decisão humana, exige motivo)"); s.add_argument("keep"); s.add_argument("other")
    s.add_argument("--reason", required=True)
    s = cmd("unmerge", "desfazer mesclagem (recria a entidade e devolve relações/eventos/observações)"); s.add_argument("keep"); s.add_argument("merged"); s.add_argument("--reason", required=True)
    s = cmd("reject-match", "registrar que duas entidades NÃO são a mesma"); s.add_argument("a"); s.add_argument("b")
    s.add_argument("--reason", default="")

    cmd("validate", "validar regras epistemológicas e integridade")
    cmd("stats", "contagens do caso")

    def add_filters(sp):
        sp.add_argument("--mode", choices=["todos", "oficial", "declarado", "inferencia"], default="todos")
        sp.add_argument("--min-confidence", type=float); sp.add_argument("--evidence-only", action="store_true")
        sp.add_argument("--rel-type", nargs="*"); sp.add_argument("--since"); sp.add_argument("--until")

    s = cmd("analyze", "análise completa (rede, contradições, match, temporal, espacial, financeira, anomalias, hipóteses, lacunas)")
    add_filters(s); s.add_argument("--out")
    s = cmd("metrics", "métricas de rede e comunidades"); add_filters(s)
    s = cmd("paths", "caminhos entre duas entidades"); s.add_argument("a"); s.add_argument("b")
    s.add_argument("--all", action="store_true"); s.add_argument("--cutoff", type=int, default=5); add_filters(s)
    s = cmd("ego", "rede ego de uma entidade"); s.add_argument("entity"); s.add_argument("--radius", type=int, default=1); add_filters(s)
    s = cmd("match", "Smart Match — sugestões de duplicidade"); s.add_argument("--threshold", type=float, default=0.75)
    cmd("contradictions", "contradições entre fontes")
    cmd("gaps", "lacunas investigativas")
    s = cmd("temporal", "análise temporal"); s.add_argument("--ref"); s.add_argument("--window-hours", type=float, default=24)
    s = cmd("spatial", "análise espacial"); s.add_argument("--radius-km", type=float, default=0.5)
    s = cmd("financial", "análise financeira"); s.add_argument("--threshold", type=float, default=10000)
    cmd("anomalies", "anomalias com motivo")
    cmd("hypotheses", "matriz de hipóteses")

    s = sub.add_parser("detect", help="detectar colunas e sugerir mapeamento de arquivo tabular")
    s.add_argument("file"); s.add_argument("--sheet"); s.add_argument("--table"); s.add_argument("--source-id", default="")
    s.add_argument("--out", help="salvar mapeamento sugerido")
    s = sub.add_parser("stage-table", help="gerar prévia (staging) a partir de tabela + mapeamento")
    s.add_argument("file"); s.add_argument("--mapping", required=True); s.add_argument("--sheet"); s.add_argument("--table")
    s.add_argument("--out", required=True)
    s = sub.add_parser("stage-text", help="extrair identificadores de TXT/PDF/DOCX/EML para staging")
    s.add_argument("file"); s.add_argument("--out", required=True)
    s = cmd("commit", "importar itens aceitos do staging"); s.add_argument("staging")
    s.add_argument("--accept-all", action="store_true", help="aceitar tudo que não estiver 'rejeitado' (use após revisão)")
    s.add_argument("--evidence-id", default="", help="evidência que originou os dados")

    s = cmd("export", "exportar dados"); s.add_argument("--format", required=True, choices=["graphml", "gexf", "csv", "xlsx", "json"])
    s.add_argument("--out", required=True)
    s = cmd("viewer", "gerar visualizador HTML estilo i2"); s.add_argument("--out", required=True)
    s.add_argument("--no-tiles", action="store_true", help="mapa sem tiles externos (nenhuma requisição revela a área)")
    s.add_argument("--inline-libs", help="diretório com cytoscape.min.js, leaflet.js, leaflet.css para uso offline")
    s = cmd("report", "relatório Markdown (17 seções)"); s.add_argument("--out", required=True); add_filters(s)
    s = cmd("package", "pacote do caso (.zip com SHA256SUMS)"); s.add_argument("--out", required=True)
    s.add_argument("--with-evidence-files", action="store_true"); s.add_argument("--no-tiles", action="store_true")
    s.add_argument("--inline-libs", help="embutir bibliotecas JS locais no visualizador do pacote")
    s = cmd("snapshot", "salvar versão"); s.add_argument("--label", default="")
    cmd("snapshots", "listar versões")
    s = cmd("restore", "restaurar versão"); s.add_argument("snapshot_id"); s.add_argument("--reason", required=True)
    s = cmd("diff", "comparar caso com snapshot ou outro arquivo"); s.add_argument("other")
    s = cmd("audit", "exibir trilha de auditoria"); s.add_argument("--last", type=int, default=30)
    s = sub.add_parser("normalize", help="normalizar um valor"); s.add_argument("kind"); s.add_argument("value")

    a = p.parse_args(argv)

    if a.cmd == "normalize":
        return _print(normalize(a.kind, a.value))
    if a.cmd == "detect":
        rows = I.read_table(a.file, a.sheet, a.table)
        m = I.suggest_mapping(rows, a.source_id)
        if a.out:
            with open(a.out, "w", encoding="utf-8") as fh:
                json.dump(m, fh, ensure_ascii=False, indent=2)
        return _print({"rows": len(rows), "columns": m["detected_columns"], "suggested_mapping": a.out or m})
    if a.cmd in ("stage-table", "stage-text"):
        if a.cmd == "stage-table":
            with open(a.mapping, encoding="utf-8") as fh:
                st = I.stage_from_table(a.file, json.load(fh), a.sheet, a.table)
        else:
            st = I.stage_from_text(a.file)
        with open(a.out, "w", encoding="utf-8") as fh:
            json.dump(st, fh, ensure_ascii=False, indent=2)
        return _print({"summary": st["summary"], "problems": st.get("problems", [])[:20], "staging": a.out})

    if a.cmd == "init":
        if os.path.exists(a.case):
            raise SystemExit(f"{a.case} já existe")
        c = Case.new(a.title, a.case, a.user, lead=a.lead, team=a.team, classification=a.classification,
                     objective=a.objective, description=a.description, tags=a.tags, id=a.id)
        c.save()
        return _print({"created": a.case, "case_id": c.data["case"]["id"]})

    c = Case.load(a.case, a.user)
    d = c.data
    save = True
    if a.cmd == "import-bundle":
        from bundle_import import import_bundle
        results = {}
        for bpath in a.bundles:
            with open(bpath, encoding="utf-8") as fh:
                results[bpath] = import_bundle(c, json.load(fh))
            results[bpath].pop("refs", None)
        _print(results)
        if a.dry_run:
            save = False
            print("(simulação: caso não salvo)")
    elif a.cmd == "batch":
        with open(a.ops_file, encoding="utf-8") as fh:
            ops = json.load(fh)
        _print(apply_batch(c, ops))
    elif a.cmd == "add-source":
        print(c.add_source(a.type, a.title, a.reference, a.date, notes=a.notes, url=a.url,
                           reliability=getattr(a, "reliability", ""), credibility=getattr(a, "credibility", ""),
                           level=getattr(a, "level", ""), accessed_at=getattr(a, "accessed_at", "")))
    elif a.cmd == "add-evidence":
        algs = ["sha256", "sha512"] + (["md5"] if a.md5 else [])  # SHA-256 (identificador) + SHA-512; MD5 só legado
        print(c.add_evidence(a.name, a.type, a.file, a.source, a.origin, a.description, hash_algorithms=algs))
    elif a.cmd == "add-entity":
        print(c.add_entity(a.type, a.label, identifiers=_kv(a.id_kv), attributes=_kv(a.attr), aliases=a.alias,
                           nature=a.nature, confidence=a.confidence, status=a.status, source_ids=a.source,
                           evidence_ids=a.evidence, location=_loc(a), notes=a.notes, tags=a.tags))
    elif a.cmd == "add-rel":
        print(c.add_relationship(a.source, a.type, a.target, directed=False if a.undirected else None, start=a.start,
                                 end=a.end, nature=a.nature, confidence=a.confidence, status=a.status,
                                 source_ids=a.source_id, evidence_ids=a.evidence, notes=a.notes,
                                 attributes={"amount": a.amount} if a.amount is not None else None))
    elif a.cmd == "add-event":
        attrs = {}
        if a.amount is not None:
            attrs["amount"] = a.amount
        if a.from_entity:
            attrs["from"] = c.entity(a.from_entity)["id"]
        if a.to_entity:
            attrs["to"] = c.entity(a.to_entity)["id"]
        print(c.add_event(a.title, a.type, a.start, a.end, a.participants, _loc(a), source_ids=a.source,
                          evidence_ids=a.evidence, description=a.description, nature=a.nature,
                          confidence=a.confidence, attributes=attrs))
    elif a.cmd == "add-hyp":
        print(c.add_hypothesis(a.title, supporting=a.supporting, contradicting=a.contradicting, gaps=a.gaps,
                               confidence=a.confidence, status=a.status))
    elif a.cmd == "update":
        ch = _kv(a.set)
        if a.json:
            ch = {k: json.loads(v) for k, v in ch.items()}
        _print(c.update(a.id, ch, a.reason))
    elif a.cmd == "delete":
        c.delete(a.id, a.reason); print(f"excluído: {a.id}")
    elif a.cmd == "merge":
        _print(c.merge_entities(a.keep, a.other, a.reason))
    elif a.cmd == "unmerge":
        _print(c.unmerge_entity(a.keep, a.merged, a.reason))
    elif a.cmd == "reject-match":
        d["case"].setdefault("rejected_matches", []).append(sorted([a.a, a.b]))
        c._audit("rejeição", "smart match", f"{a.a}|{a.b}", reason=a.reason)
        print("registrado")
    elif a.cmd == "commit":
        with open(a.staging, encoding="utf-8") as fh:
            st = json.load(fh)
        _print(I.commit_staging(c, st, a.accept_all, a.evidence_id))
    elif a.cmd == "snapshot":
        print(c.snapshot(a.label))
    elif a.cmd == "restore":
        c.restore_snapshot(a.snapshot_id, a.reason); print("restaurado")
    else:
        save = False
        if a.cmd == "validate":
            v = c.validate()
            _print({"errors": sum(x["level"] == "erro" for x in v), "alerts": sum(x["level"] == "alerta" for x in v),
                    "gaps": sum(x["level"] == "lacuna" for x in v), "findings": v})
        elif a.cmd == "stats":
            _print({"case": d["case"]["title"], **c.counts()})
        elif a.cmd == "analyze":
            res = A.full_analysis(d, **_filters(a))
            c._audit("análise", "caso", d["case"]["id"], after={"filters": res["filters"]}); save = True
            if a.out:
                with open(a.out, "w", encoding="utf-8") as fh:
                    json.dump(res, fh, ensure_ascii=False, indent=2, default=str)
                _print({"saved": a.out, "summary": res["network"]["summary"],
                        "contradictions": len(res["contradictions"]), "possible_duplicates": len(res["smart_match"]),
                        "anomalies": len(res["anomalies"]), "gaps": len(res["gaps"]),
                        "validation_issues": len(res["validation"])})
            else:
                _print(res)
        elif a.cmd == "metrics":
            _print(A.network_metrics(d, **_filters(a)))
        elif a.cmd == "paths":
            ea, eb = c.entity(a.a), c.entity(a.b)
            if not ea or not eb:
                raise SystemExit("entidade não encontrada")
            _print(A.paths(d, ea["id"], eb["id"], "all" if a.all else "shortest", a.cutoff, **_filters(a)))
        elif a.cmd == "ego":
            _print(A.ego_network(d, c.entity(a.entity)["id"], a.radius, **_filters(a)))
        elif a.cmd == "match":
            _print(A.smart_match(d, a.threshold))
        elif a.cmd == "contradictions":
            _print(A.contradictions(d))
        elif a.cmd == "gaps":
            _print(A.gaps(d))
        elif a.cmd == "temporal":
            _print(A.temporal_analysis(d, a.ref, a.window_hours))
        elif a.cmd == "spatial":
            _print(A.spatial_analysis(d, a.radius_km))
        elif a.cmd == "financial":
            _print(A.financial_analysis(d, a.threshold))
        elif a.cmd == "anomalies":
            _print(A.anomalies(d))
        elif a.cmd == "hypotheses":
            _print(A.hypothesis_matrix(d))
        elif a.cmd == "export":
            if a.format == "graphml":
                X.write_graphml(d, a.out)
            elif a.format == "gexf":
                X.write_gexf(d, a.out)
            elif a.format == "csv":
                X.write_csv_dir(d, a.out)
            elif a.format == "xlsx":
                X.write_xlsx(d, a.out)
            else:
                with open(a.out, "w", encoding="utf-8") as fh:
                    json.dump(d, fh, ensure_ascii=False, indent=2)
            c._audit("exportação", "caso", d["case"]["id"], after={"format": a.format, "out": a.out}); save = True
            print(a.out)
        elif a.cmd == "viewer":
            from build_viewer import build
            html = build(d, A.full_analysis(d), no_tiles=a.no_tiles, inline_libs=a.inline_libs)
            with open(a.out, "w", encoding="utf-8") as fh:
                fh.write(html)
            c._audit("exportação", "visualizador", d["case"]["id"], after={"out": a.out}); save = True
            print(a.out)
        elif a.cmd == "report":
            from report import build_report
            md = build_report(d, A.full_analysis(d, **_filters(a)))
            with open(a.out, "w", encoding="utf-8") as fh:
                fh.write(md)
            c._audit("geração de relatório", "caso", d["case"]["id"], after={"out": a.out}); save = True
            print(a.out)
        elif a.cmd == "package":
            from build_viewer import build
            from report import build_report
            an = A.full_analysis(d)
            X.case_package(d, a.out, an, build(d, an, no_tiles=a.no_tiles, inline_libs=a.inline_libs), build_report(d, an), a.with_evidence_files)
            c._audit("exportação", "pacote do caso", d["case"]["id"], after={"out": a.out}); save = True
            print(a.out)
        elif a.cmd == "snapshots":
            _print(d["snapshots"])
        elif a.cmd == "diff":
            other = a.other
            snap = next((s for s in d["snapshots"] if s["id"] == other), None)
            with open(snap["path"] if snap else other, encoding="utf-8") as fh:
                od = json.load(fh)
            _print(diff_cases(od, d))
        elif a.cmd == "audit":
            _print(d["audit_log"][-a.last:])
    if save:
        c.save()


def diff_cases(old: dict, new: dict) -> dict:
    out = {}
    for coll in ("entities", "relationships", "events", "sources", "evidence", "hypotheses", "observations"):
        o = {x["id"]: x for x in old.get(coll, [])}
        n = {x["id"]: x for x in new.get(coll, [])}
        changed = []
        for k in set(o) & set(n):
            fields = sorted(f for f in set(o[k]) | set(n[k]) if f != "updated_at" and o[k].get(f) != n[k].get(f))
            if fields:
                changed.append({"id": k, "fields": {f: {"antes": o[k].get(f), "depois": n[k].get(f)} for f in fields}})
        out[coll] = {"added": sorted(set(n) - set(o)), "removed": sorted(set(o) - set(n)), "changed": changed}
    return out


if __name__ == "__main__":
    main()
