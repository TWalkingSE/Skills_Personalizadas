# Guia do visualizador (estilo i2 Analyst's Notebook)

Gerado por `nb.py viewer caso.json --out caso.html`. Um único arquivo HTML: abre com duplo
clique, sem servidor, sem envio de dados. Edições ficam na memória até **💾 Salvar**, que baixa o
caso atualizado (JSON) com as alterações registradas na auditoria (`origin: "visualizador"`).

## Layout

```
┌ Caso · classificação · status ········· Analista · Salvar · Importar · Analisar · Exportar · tema ┐
├ Ferramentas │ Editar │ Organizar │ Analisar │ Exibir · busca ─────────────────────────────────────┤
│ PALETA        │                  GRAFO                         │ INSPECTOR                       │
│ (arrastar)    │                                                │ Detalhes · Relações · Fontes ·  │
│ legenda       │                                                │ Evidências · Timeline · Análise │
│               │                                                │ · Hipóteses                     │
├ Timeline · Mapa · Evidências · Visão geral · Filtros · Achados · Hipóteses · Auditoria ──────────┤
└ painel redimensionável (arraste o divisor) ───────────────────────────────────────────────────────┘
```

A seleção é compartilhada: selecionar uma entidade destaca suas relações no grafo, seus eventos
na timeline (os demais esmaecem), seus pontos no mapa e filtra a aba Evidências.

## Ferramentas e atalhos (padrão — editáveis com duplo clique na dica de modo)

| Ação | Atalho |
|---|---|
| Selecionar / Pan / Retângulo | V / H / B (Shift+arrastar também seleciona em retângulo) |
| Criar ligação (arrastar de uma entidade a outra, ou clicar origem e destino) | L |
| Criar entidade (tipo da paleta + clique no grafo; ou arrastar da paleta) | N |
| Ajustar à tela | F |
| Editar seleção (ou duplo clique) | E |
| Excluir (pede motivo) | Delete |
| Desfazer / Refazer | Ctrl+Z / Ctrl+Y |
| Copiar / Colar / Duplicar | Ctrl+C / Ctrl+V / Ctrl+D (cópias entram como “não verificado”) |
| Salvar | Ctrl+S |
| Buscar (nome, alias, identificador) | Ctrl+F |
| Isolar seleção / Mostrar tudo | I / A |
| Cancelar modo, limpar destaques | Esc |

Shift/Ctrl+clique adiciona ou remove da seleção. Roda do mouse = zoom.

## Edição com regras epistemológicas

- Formulários exigem natureza; o padrão de itens novos é “não verificado / em análise”.
- Trocar inferência/correlação/hipótese por **fato** pede fundamentação (fica em `promoted_from`).
- Marcar item não factual como “confirmado” pede registro de quem confirmou (`confirmed_by`).
- Salvar um “fato” sem fonte nem evidência pede confirmação e vira lacuna.
- **Mesclar** (2 entidades) exige motivo; aliases, identificadores (conflitantes preservados com
  sufixo `__ID`), fontes, evidências e relações são transferidos. **Dividir** reverte o último merge.
- Smart Match (aba Achados): Confirmar (mescla com motivo), Rejeitar (não volta a ser sugerido),
  Manter como hipótese.

## Organizar

Force-directed · Hierárquico (raiz = seleção) · Radial (centro = seleção) · Circular · Grade ·
Por comunidades · Por grupos (tipo) · Por tempo (X = primeira data associada; sem data à
direita) · Por localização (lat/lon; sem coordenadas à esquerda). Também alinhar, distribuir,
compactar e espalhar a seleção. Agrupar cria um contêiner visual (duplo clique renomeia).

## Exibir (modos)

| Modo | Efeito |
|---|---|
| Oficial | só relações `fato` (e entidades conectadas por elas ou factuais) |
| Declarado | só relações `declarado` |
| Inferência | correlação, inferência e hipótese |
| Destaque | esmaece tudo exceto contradições, anomalias, duplicidades, pontos de articulação e itens de hipóteses |
| Visão geral | oculta identificadores-folha (telefone, e-mail, CPF… com 1 vínculo) |
| Evidências | só relações com evidência vinculada |
| Temporal | aplica layout por tempo e abre a timeline |
| Geográfico | só entidades localizadas (próprias ou via eventos) e layout geográfico |

Filtros (aba Filtros) combinam com o modo: tipo, natureza, status (rejeitados ocultos por
padrão), confiança mínima, período, comunidade, tag, tipo de relação, fonte.

## Analisar

- **📊 Analisar**: grau, grau ponderado, intermediação, proximidade e PageRank na **visão atual**;
  “Tamanho” dimensiona os nós pela métrica; “comunidades” colore por grupo.
- **Expandir** 1/2 níveis/todos, opcionalmente só de um tipo (pessoas, contas, IPs...).
- **Pivô**: a entidade selecionada vira centro (2 níveis, layout radial).
- **Caminho**: com 2 entidades selecionadas — mais curto (ponderado por confiança) ou todos (até
  6 saltos), filtrando tipo de relação e “somente com evidência”. O resultado (aba Achados)
  informa o elo mais fraco e se todas as relações têm evidência.

## Painel inferior

- **Timeline**: faixas por tipo, histograma por período, agrupamento automático ou hora/dia/
  semana/mês/ano; roda = zoom, arrastar = mover; círculo tracejado = data aproximada; anel
  laranja = eventos a ≤ 10 min. Clicar um item mostra 24 h antes/depois. Itens sem data listados
  à parte.
- **Mapa**: Leaflet (com ou sem tiles) ou esquema SVG offline; trajetórias, concentração, raio
  (clique no mapa) e distância (clique em dois pontos).
- **Achados**: contradições, Smart Match, anomalias, lacunas, financeiro e caminhos, cada um com
  botão “Destacar”. Refletem a análise do Python no momento da geração — após editar, rode
  `nb.py viewer` de novo para reanalisar.
- **Hipóteses**: matriz editável; vincule itens pelo inspector (+ favorável / + contrária).
- **Auditoria**: trilha completa, inclusive das edições feitas no navegador.

## Exportar

PNG (grafo completo, 2×), SVG (se a extensão cytoscape-svg estiver disponível), relatório do
grafo para impressão/PDF (Visão geral + grafo), JSON do caso, CSV de entidades/relações/eventos,
GraphML.

## Ciclo CLI ⇄ visualizador

1. `nb.py viewer caso.json --out caso.html` → editar no navegador → 💾 Salvar (`CASO-…_AAAAMMDDHHMM.json`).
2. `nb.py diff caso_novo.json caso.json` para revisar o que mudou (ou `validate` no novo).
3. Adotar o arquivo salvo como o caso corrente (fazer `snapshot` antes no antigo).

## Uso offline e OPSEC

- `--inline-libs DIR`: embute `cytoscape.min.js` (obrigatório), `leaflet.js`/`leaflet.css` e
  `cytoscape-svg.js` (opcionais) — nenhuma requisição externa.
- `--no-tiles`: mapa sem camada do OpenStreetMap (requisições de tiles revelam a área analisada).
- Sem Cytoscape disponível, a página explica como gerar a versão offline.
- O HTML contém o caso inteiro: trate-o com a mesma classificação do caso.
