# Métodos de análise e como interpretá-los

Sumário: 1. Regra geral · 2. Métricas de rede · 3. Comunidades · 4. Caminhos · 5. Smart Match ·
6. Fontes múltiplas e contradições · 7. Temporal · 8. Espacial · 9. Financeira · 10. Anomalias ·
11. Hipóteses (ACH simplificada) · 12. Lacunas · 13. Modelos de resposta

## 1. Regra geral

Toda saída de `analyze.py` é **correlação ou inferência sobre o que foi registrado**. Antes de
afirmar qualquer coisa, pergunte: (a) o resultado se mantém em `--mode oficial`? (b) se mantém
com `--evidence-only`? (c) quantas fontes independentes sustentam os elos? Diga a resposta no
campo LIMITAÇÕES.

Viés de coleta: um nó central pode ser só o mais investigado. Métricas descrevem o grafo, não a
organização real.

## 2. Métricas de rede (`metrics`)

Calculadas no grafo não direcionado e colapsado (peso = soma das confianças das relações).

| Métrica | Leitura investigativa | Cuidado |
|---|---|---|
| Grau / grau ponderado | exposição, volume de vínculos | identificadores compartilhados (ex.: um endereço comercial) inflam o grau |
| Intermediação (betweenness) | intermediários, “ponte” entre grupos — candidatos a contas de passagem, operadores, laranjas | sensível a vínculos ausentes |
| Proximidade (closeness) | alcance rápido ao restante da rede | só significativa no mesmo componente |
| Autovetor / PageRank | importância por conexão a nós importantes | favorece clusters densos |
| Ponto de articulação | remoção fragmenta a rede — prioridade para diligência | não indica hierarquia |
| Pontes | arestas únicas entre partes — verificar a evidência dessas relações primeiro | |
| Componentes / isolados | partes desconectadas — lacuna ou elemento estranho ao caso | |
| Densidade | quão interligada é a rede | comparar só entre versões do mesmo caso |

`ego --radius 1|2` devolve a vizinhança de uma entidade (base para “pivô”).

## 3. Comunidades

Louvain (semente fixa 42, reprodutível) no Python; propagação de rótulos determinística no
visualizador (visão atual). Comunidade = grupo mais conectado internamente que com o resto.
Use para organizar o diagrama e levantar perguntas (“por que a empresa X está no grupo das
contas de passagem?”), nunca como prova de associação.

## 4. Caminhos (`paths A B`)

- Mais curto: ponderado por 1/confiança (prefere elos mais confiáveis).
- `--all --cutoff N`: até 50 caminhos simples.
- Cada caminho informa `weakest_link_confidence`, `fully_evidenced` e `contains_inference`.
- A força de um caminho é a do **elo mais fraco**. Um caminho que só existe passando por uma
  relação `hipotese` ou `correlacao` não demonstra vínculo.
- Filtros úteis: `--rel-type transferiu` (fluxo), `--since/--until` (período), `--evidence-only`.

## 5. Smart Match (`match`)

Compara entidades do mesmo tipo. Critérios e pesos:

- nome (similaridade de sequência, tokens em comum, contenção com abreviações — “S.” casa com
  “SILVA” — e primeiro/último nome iguais);
- identificador idêntico normalizado (CPF, CNPJ, telefone, e-mail...) — critério forte;
- atributo igual (ex.: `data_nascimento`);
- identificador compartilhado via grafo (ambos ligados ao mesmo telefone/endereço/IP...).

Combinação: `1 − Π(1 − sᵢ·wᵢ)`; conflitos em atributos de valor único (CPF divergente, data de
nascimento divergente) multiplicam o escore por 0,4 e geram recomendação “não mesclar”.
Decisões: confirmar (`merge --reason`, preserva tudo em `merged_from`), rejeitar
(`reject-match`, não volta a ser sugerido) ou manter como hipótese (não fazer nada / criar `H`).

Homônimos são comuns no Brasil: nome sozinho nunca basta.

## 6. Fontes múltiplas e contradições

- `multi_source`: objetos com 0, 1 ou várias fontes; ranking de entidades por nº de fontes.
- `contradictions` detecta: (a) relação exclusiva (`reside em`) com destinos diferentes em
  períodos sobrepostos ou desconhecidos; (b) atributo de valor único com valores diferentes
  (entidades e observações); (c) itens marcados `contraditorio`.
- Mesclar entidades pode **revelar** contradições antes escondidas (cada duplicata tinha um
  endereço). Rode `contradictions` após cada merge.
- Saída ao usuário: “CONTRADIÇÃO DETECTADA” + as duas versões com fontes. Proponha como
  resolver (diligência, documento de maior força probatória), não resolva.

## 7. Temporal (`temporal [--ref EV-… --window-hours 24]`)

Retorna primeira/última ocorrência, itens sem data, entidades recorrentes em eventos, eventos
simultâneos (≤ 10 min), duração das relações e, com `--ref`, antes/depois/janela.
Cuidados: logs costumam estar em UTC e relatos em horário local (Brasília = UTC−3); datas com
precisão `dia/mes/ano/aproximada` podem inverter a ordem; sequência não é causalidade.

## 8. Espacial (`spatial [--radius-km 0.5]`)

Pares próximos (haversine), endereços compartilhados, trajetórias por entidade (eventos
localizados e datados, com velocidade implícita — acima de 900 km/h é sinalizado), pontos de
concentração (~1 km). Geolocalização por IP indica região do provedor, não a pessoa; ERB
indica área de cobertura.

## 9. Financeira (`financial [--threshold 10000]`)

Transações = relações financeiras com `attributes.amount` + eventos de transferência (sem dupla
contagem). Por conta: entradas, saídas, saldo, quantidades, primeira/última data, concentração
da principal contraparte. Achados (todos com motivo e limitação):

| Padrão | Regra padrão (configurável) |
|---|---|
| Possível conta de passagem | entradas ≈ saídas (±10%), repasse em até 72 h |
| Possível fracionamento | ≥ 3 transações entre 85% e 100% do limiar |
| Fluxo circular | ciclo no grafo de transferências (até 6 contas) |
| Intermediárias | intermediação no grafo financeiro |
| Valor fora do padrão | acima de Q3 + 1,5×IQR da amostra (≥ 5 transações) |
| Fluxos | caminhos maximais a partir das origens (contas sem entrada) |

O limiar padrão de R$ 10.000 é apenas um parâmetro de triagem; ajuste ao contexto e não o trate
como regra normativa. Saldos prévios e movimentações não importadas podem explicar qualquer
padrão — diga isso.

## 10. Anomalias (`anomalies`)

Valor fora do padrão, fracionamento, circularidade, horário incomum (00h–05h, apenas datas
exatas), frequência anormal (≥ 5 eventos em 60 min por entidade), novo IP/dispositivo após uso
anterior. Cada item traz `reason`; apresente sempre o motivo. Anomalia é gatilho de verificação,
não indício por si.

## 11. Hipóteses (`hypotheses`)

Matriz: favoráveis × contrárias × lacunas × confiança × status, com alertas:
- nenhuma evidência contrária registrada → buscar ativamente (viés de confirmação);
- confiança alta com menos de duas evidências favoráveis;
- apoio baseado em itens não factuais (inferência, correlação, não verificado).

Boas práticas (ACH): formule hipóteses concorrentes para o mesmo fato (ex.: H1 “A controla a
conta” × H1′ “a conta foi cedida/invadida”); avalie cada evidência contra todas; a hipótese
mais sustentada é a com **menos evidências inconsistentes**, não a com mais favoráveis. A
confiança é juízo do analista — não a calcule automaticamente.

## 12. Lacunas (`gaps`)

Entidades sem identificação ou sem fonte, relações sem evidência ou de fonte única, eventos sem
fonte ou com data imprecisa, contradições não resolvidas, alertas de hipótese, entidades
isoladas. Converta lacunas em **diligências** concretas (ofício a banco/provedor, oitiva,
consulta cadastral), agrupadas por prioridade (o que sustenta pontes e pontos de articulação
primeiro).

## 13. Modelos de resposta

Ilustrativos (números e IDs inspirados no caso fictício de `assets/`; use sempre os do caso real).

Entidade relevante:
```
CONCLUSÃO: A Conta A 1234-5 (E-0010) ocupa posição de intermediária no fluxo financeiro.
EVIDÊNCIAS: R-0017, R-0018, R-0019, R-0020; D-0001
FUNDAMENTAÇÃO: Recebeu R$ 28.500,00 da conta da vítima e repassou R$ 28.200,00 em três transferências em 33 minutos; maior intermediação do grafo (0,54).
TIPO: inferência (baseada em fatos documentados)
CONFIANÇA: alta
LIMITAÇÕES: O padrão é compatível com conta de passagem, mas não identifica quem a operava; extrato restrito a 30 dias.
FONTES: S-0003 (extrato bancário, ofício 45/2026)
```

Ausência de suporte:
```
CONCLUSÃO: Não há, no caso, elemento factual que vincule Pessoa A à Conta A.
EVIDÊNCIAS: caminho E-0002 → E-0010 inexistente em --mode oficial; único vínculo é R-0015 (hipótese)
TIPO: hipótese (não sustentada)
LIMITAÇÕES: Resposta do provedor sobre o IP 198.51.100.7 pendente.
```
