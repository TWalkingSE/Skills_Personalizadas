# Arquitetura da plataforma Investigative Notebook

Sumário: 1. Princípios · 2. O que já existe nesta skill · 3. Arquitetura em camadas ·
4. Estrutura de diretórios · 5. Esquema SQLite · 6. Interface Streamlit · 7. IA local ·
8. Roadmap por fase com critérios de aceite · 9. Testes

## 1. Princípios

Rastreabilidade, transparência, reprodutibilidade, explicabilidade, controle humano,
preservação da fonte, separação entre fato e inferência, segurança dos dados e modularidade.
Na prática: a camada de domínio é a única que altera dados, sempre com auditoria; a UI e a IA
**propõem**, o analista **decide**.

## 2. O que já existe nesta skill (reaproveite em vez de reescrever)

| Especificação | Implementação pronta |
|---|---|
| core/ (cases, entities, relationships, observations, evidence, events, sources, hypotheses) | `scripts/case_model.py` — classe `Case`, vocabulários, validação, merge, snapshots, auditoria, normalização, hash |
| graph/ (engine, centrality, communities, paths, matching) | `scripts/analyze.py` — `build_graph`, `network_metrics`, `ego_network`, `paths`, `smart_match` |
| timeline/, geospatial/ | `analyze.py` — `timeline`, `temporal_analysis`, `spatial_analysis` |
| ingestion/ | `scripts/ingest.py` — CSV/TSV/XLSX/JSON/SQLite, texto/PDF/DOCX/EML, staging e commit com entity resolution |
| reports/ | `scripts/report.py` (Markdown 17 seções), `scripts/export.py` (CSV/XLSX/GraphML/GEXF/pacote ZIP) |
| ui/ (graph, inspector, timeline, map, palette) | `assets/viewer_template.html` + `scripts/build_viewer.py` (Cytoscape.js + Leaflet) |
| ai/ | regras e formato explicável no `SKILL.md`; `analyze.full_analysis` como insumo |

Persistência atual: JSON único por caso (simples, versionável, fácil de auditar). Migrar para
SQLite (§5) quando houver múltiplos usuários, casos grandes (> ~50 mil elementos) ou consultas
cruzadas entre casos — mantendo `Case` como API e trocando só o repositório.

## 3. Arquitetura em camadas

```
UI (Streamlit + componente de grafo)   ← só lê o domínio e envia comandos
      │ comandos (criar, editar, mesclar, importar, analisar)
Aplicação (serviços/casos de uso)      ← orquestra; nenhuma regra de negócio na UI
      │
Domínio (case_model)                    ← regras epistemológicas, validação, auditoria
      │
Repositório (JSON | SQLite via SQLAlchemy) ← troca sem afetar o domínio
      │
Módulos plugáveis: analysis, ingestion, osint, ai, reports (registrados por entry points/dict)
```

Módulos novos implementam uma interface mínima (`name`, `run(case, **params) -> dict` com campos
`findings[]`, cada um com `reason`, `objects`, `nature`, `limitations`), sem tocar o núcleo.

## 4. Estrutura de diretórios sugerida

```
investigative_notebook/
├── app.py                      # Streamlit (entrada)
├── core/        case_model.py (desta skill), services.py
├── graph/       analyze.py (rede, caminhos, matching)
├── timeline/    (funções de analyze.py separadas se crescer)
├── geospatial/  geocode.py (geocodificação local/offline preferencial)
├── ingestion/   ingest.py, parsers específicos (CDR, extratos de bancos, logs de provedores)
├── osint/       ip.py, dns.py, domains.py, certificates.py, reputation.py (todos registram consulta)
├── ai/          extraction.py, investigator.py (prompts com formato explicável)
├── reports/     report.py, export.py, docx/pdf
├── database/    schema.py, repository.py
├── ui/          viewer_template.html, componentes Streamlit
└── tests/
```

## 5. Esquema SQLite (quando migrar)

```sql
CREATE TABLE cases(id TEXT PRIMARY KEY, title TEXT, description TEXT, objective TEXT, lead TEXT,
  classification TEXT, status TEXT, created_at TEXT, updated_at TEXT, meta JSON);
CREATE TABLE sources(id TEXT, case_id TEXT, type TEXT, title TEXT, reference TEXT, date TEXT,
  meta JSON, PRIMARY KEY(case_id,id));
CREATE TABLE evidence(id TEXT, case_id TEXT, name TEXT, type TEXT, source_id TEXT, sha256 TEXT,
  sha512 TEXT, size INTEGER, storage_path TEXT, acquired_at TEXT, custody JSON, meta JSON,
  PRIMARY KEY(case_id,id));
CREATE TABLE entities(id TEXT, case_id TEXT, type TEXT, label TEXT, label_norm TEXT,
  nature TEXT NOT NULL, confidence TEXT, status TEXT, start TEXT, "end" TEXT, lat REAL, lon REAL,
  attributes JSON, meta JSON, PRIMARY KEY(case_id,id));
CREATE TABLE identifiers(case_id TEXT, entity_id TEXT, kind TEXT, original TEXT, normalized TEXT,
  valid INTEGER);                                   -- índice p/ entity resolution
CREATE INDEX ix_ident ON identifiers(case_id, kind, normalized);
CREATE TABLE relationships(id TEXT, case_id TEXT, type TEXT, directed INTEGER, source TEXT,
  target TEXT, start TEXT, "end" TEXT, nature TEXT NOT NULL, confidence TEXT, status TEXT,
  amount REAL, attributes JSON, meta JSON, PRIMARY KEY(case_id,id));
CREATE TABLE links(case_id TEXT, object_id TEXT, kind TEXT CHECK(kind IN('source','evidence')),
  ref_id TEXT);                                     -- N:N proveniência
CREATE TABLE observations(id TEXT, case_id TEXT, statement TEXT, entity_id TEXT,
  relationship_id TEXT, attribute TEXT, value TEXT, observed_at TEXT, source_id TEXT,
  evidence_id TEXT, method TEXT, nature TEXT, confidence TEXT, PRIMARY KEY(case_id,id));
CREATE TABLE events(id TEXT, case_id TEXT, title TEXT, type TEXT, start TEXT, "end" TEXT,
  date_precision TEXT, lat REAL, lon REAL, nature TEXT, confidence TEXT, status TEXT,
  attributes JSON, PRIMARY KEY(case_id,id));
CREATE TABLE event_participants(case_id TEXT, event_id TEXT, entity_id TEXT);
CREATE TABLE hypotheses(id TEXT, case_id TEXT, title TEXT, statement TEXT, confidence REAL,
  status TEXT, gaps JSON, PRIMARY KEY(case_id,id));
CREATE TABLE hypothesis_items(case_id TEXT, hypothesis_id TEXT, object_id TEXT,
  stance TEXT CHECK(stance IN('favoravel','contraria','relacionada')));
CREATE TABLE osint_queries(id TEXT, case_id TEXT, query TEXT, tool TEXT, date TEXT,
  result_summary TEXT, limitations TEXT, legal_basis TEXT, evidence_id TEXT, PRIMARY KEY(case_id,id));
CREATE TABLE snapshots(id TEXT, case_id TEXT, label TEXT, created_at TEXT, sha256 TEXT,
  blob BLOB, PRIMARY KEY(case_id,id));
CREATE TABLE audit_log(seq INTEGER PRIMARY KEY AUTOINCREMENT, case_id TEXT, ts TEXT, user TEXT,
  action TEXT, object_type TEXT, object_id TEXT, before JSON, after JSON, reason TEXT,
  prev_hash TEXT, hash TEXT);                       -- encadeamento de hash = auditoria à prova de adulteração
```

Auditoria encadeada: `hash = sha256(prev_hash + json(registro))`; verificação periódica detecta
alteração retroativa. Considere SQLCipher ou criptografia de disco para casos sigilosos.

## 6. Interface Streamlit

Layout do i2 mapeado para Streamlit:

| Área | Implementação |
|---|---|
| Barra superior (Caso, Salvar, Importar, Analisar, IA, Exportar) | `st.columns` + botões / `st.popover` |
| Paleta | `st.sidebar` com busca de tipos e formulário de criação |
| Grafo | componente Cytoscape bidirecional (ex.: pacote `st-cytoscape` — confirmar disponibilidade/licença) ou `components.html` com `viewer_template.html` (somente leitura + exportação de JSON) |
| Inspector | coluna direita com `st.tabs` (Detalhes, Relações, Fontes, Evidências, Timeline, Análise, Hipóteses) |
| Timeline | Plotly `px.timeline`/scatter com seleção (`on_select`) |
| Mapa | `folium` + `streamlit-folium` (tiles configuráveis; offline sem tiles) |
| Filtros | `st.multiselect`, `st.slider` de confiança e período, armazenados em `st.session_state` |
| Seleção sincronizada | `st.session_state.selection` atualizado por qualquer vista e lido por todas |

Desfazer/refazer: pilha de comandos na camada de aplicação (cada comando sabe se reverter),
não cópias inteiras do estado, quando o caso crescer.

## 7. IA local

- Preferir modelos locais para dados sensíveis (ex.: servidor de inferência local); APIs
  externas só por configuração explícita, com registro na auditoria do que foi enviado.
- Extração: o modelo devolve **propostas** no formato do staging (`ingest.py`), nunca grava no caso.
- Respostas analíticas no formato: CONCLUSÃO, EVIDÊNCIAS (IDs), FUNDAMENTAÇÃO, TIPO, CONFIANÇA,
  LIMITAÇÕES, FONTES. Validar a saída: todo ID citado deve existir no caso; resposta sem
  evidência citada é rejeitada.
- Contexto para o modelo: subgrafo relevante + `full_analysis` filtrada, não o caso inteiro.

## 8. Roadmap com critérios de aceite

| Fase | Entregas | Aceite (exemplos verificáveis) |
|---|---|---|
| 1 Core | caso, entidades, relações, observações, fontes, evidências, status, confiança, persistência, auditoria básica | `validate` sem erros no caso de exemplo; toda escrita gera auditoria; promoção a fato sem motivo é recusada |
| 2 Grafo | paleta, inspector, seleção, criação, layouts, zoom/pan, expansão, pivô, filtros | criar entidade e relação pela UI e vê-las no JSON; 8 modos de exibição; desfazer/refazer |
| 3 Tempo/espaço | eventos, timeline, mapa, geocodificação, análises, sincronização | selecionar entidade destaca eventos e pontos; janela de 24 h correta; datas aproximadas sinalizadas |
| 4 Importação | CSV/XLSX/JSON/PDF/DOCX, normalização, proveniência, hash, contradições | prévia antes de importar; entidade existente reaproveitada por identificador; hash conferido |
| 5 Motor analítico | Smart Match, centralidades, comunidades, caminhos, financeiro, anomalias, hipóteses, IA explicável, lacunas | nenhum merge automático; toda anomalia com motivo; fracionamento/passagem/ciclo detectados no caso de exemplo |
| 6 OSINT/relatórios | IP, DNS, domínios, ASN/BGP, certificados, relatórios, exportação, auditoria completa, snapshots, pacote | toda consulta externa registrada; pacote com SHA256SUMS verificável; relatório com 17 seções |

## 9. Testes

- Caso de exemplo `assets/example_case_ops.json` como fixture: deve produzir 1 possível
  duplicidade (João da Silva Ferreira × JOAO S. FERREIRA), contradição de data de nascimento,
  conta de passagem + fracionamento + fluxo circular, anomalias de horário e novo IP.
- Testes de propriedade: normalização idempotente; no visualizador, mesclar seguido de “Dividir” restaura a entidade;
  `snapshot`→`restore` preserva o hash.
- Testes de UI com Playwright (o visualizador expõe `cy`, `S` e funções globais).
