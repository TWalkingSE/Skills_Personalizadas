# OSINT, infraestrutura digital e cuidados legais

Sumário: 1. Registro de consultas · 2. Padrões de pivô no grafo · 3. Armadilhas de atribuição ·
4. Cadeia de custódia · 5. Base legal (Brasil) · 6. OPSEC do analista

## 1. Registro de consultas externas

Toda consulta (RDAP/WHOIS, DNS, certificados, reputação, buscas em fontes abertas) vira um item
`osint` **e** as entidades/relações resultantes nascem com `nature: "nao_verificado"` e fonte do
tipo `consulta_osint`:

```json
{"op":"source","ref":"q1src","type":"consulta_osint","title":"RDAP 203.0.113.45","date":"2026-10-07"},
{"op":"entity","ref":"asn","type":"asn","label":"AS64500","identifiers":{"asn":"64500"},"source_ids":["@q1src"]},
{"op":"rel","source":"203.0.113.45","type":"anunciado por","target":"@asn","source_ids":["@q1src"]},
{"op":"osint","query":"RDAP 203.0.113.45","tool":"RDAP (registro regional)","result_summary":"Prefixo 203.0.113.0/24, AS64500","entity_ids":["@asn"],"limitations":"Dado do momento da consulta; titularidade do bloco ≠ usuário do IP","legal_basis":"fonte aberta"}
```

Salve a resposta bruta como evidência (arquivo + SHA-256) quando ela sustentar conclusão.
Para a análise técnica aprofundada de IPs/ASN/BGP use a skill `analise-ip`; para planejamento
OSINT com base legal, `osint-investigator-forense`; criptoativos, `crypto-investigator`.

## 2. Padrões de pivô no grafo

| Pivô | Relação sugerida | Entidade criada |
|---|---|---|
| IP → ASN | `anunciado por` | asn |
| IP → prefixo | `pertence a` | prefixo_ip |
| IP → provedor/cloud | `pertence a` | organizacao |
| IP ← domínio (A/AAAA) | `resolve para` (domínio → IP) | dominio |
| IP → PTR | `associado a` | dominio |
| Domínio → NS / MX / CNAME | `associado a` (anote o tipo do registro em `attributes.dns_type`) | dominio |
| Domínio → registrante (RDAP) | `registrado por` | pessoa/organizacao/email |
| Certificado → domínios/SAN | `emitido para` | certificado → dominio |
| Certificado → emissor | `emitido para` invertido / `associado a` | organizacao |
| E-mail/usuário → perfil social | `associado a` | perfil_social |
| Pessoa → IP (log de provedor) | `acessou` com `start` = data/hora **com fuso** | ip |

Datas em DNS/RDAP/certificados: registre `start`/`end` (validade, primeira/última observação)
para habilitar filtros por período e o layout temporal.

## 3. Armadilhas de atribuição (coloque nas LIMITAÇÕES)

- **CDN/hospedagem compartilhada**: um IP pode servir milhares de domínios. “Mesmo IP” entre
  domínios é correlação fraca; prefira certificados, NS dedicados, analytics IDs, padrões de
  registro.
- **CGNAT**: IPv4 de conexão móvel/residencial é compartilhado; a identificação exige IP +
  **porta de origem** + data/hora + fuso. Registre esses campos em `attributes`.
- **VPN/proxy/Tor/nuvem**: o IP aponta para o serviço, não para a pessoa.
- **Geolocalização por IP**: região aproximada do provedor; nunca use como local do fato.
- **RDAP/WHOIS**: dados de registrante podem ser falsos ou ocultados por privacidade.
- **Fuso horário**: logs frequentemente em UTC; relatos em horário de Brasília (UTC−3).
- **Momento da coleta**: DNS e reputação mudam; sempre datar a consulta.

## 4. Cadeia de custódia

O modelo registra: hash (SHA-256) no registro, `custody[]` com cada manuseio, `acquired_at`,
`source_id`, `storage_path`, e o pacote do caso confere os hashes antes de empacotar. No Brasil,
os arts. 158-A a 158-F do CPP (incluídos pela Lei 13.964/2019) disciplinam a cadeia de custódia
de vestígios; documente as etapas aplicáveis (coleta, acondicionamento, transporte, recebimento,
processamento, armazenamento). Capturas de páginas: salve arquivo, URL, data/hora com fuso, hash
e, se possível, ferramenta de captura com registro próprio.

## 5. Base legal (Brasil) — referência rápida, verificar a norma vigente

| Dado | Regra geral |
|---|---|
| Dados cadastrais (qualificação, filiação, endereço) | requisitáveis pela autoridade competente sem ordem judicial (Marco Civil, art. 10 §3º; Lei 12.850/2013, art. 15; Lei 9.613/1998, art. 17-B) |
| Registros de conexão e de acesso a aplicações | dependem de ordem judicial (Marco Civil, arts. 10 e 22); guarda mínima de 1 ano (conexão, art. 13) e 6 meses (aplicações, art. 15) |
| Conteúdo de comunicações / interceptação | ordem judicial (Lei 9.296/1996; Marco Civil, art. 7º, II–III) |
| Sigilo bancário | afastamento por ordem judicial (LC 105/2001), salvo hipóteses legais específicas |
| LGPD | não se aplica a tratamento para fins exclusivos de segurança pública e investigação criminal (art. 4º, III), que deve observar devido processo, princípios gerais e direitos do titular (art. 4º, §1º) |

Registre em `legal_basis` (consulta OSINT) e na fonte (ex.: “Ofício 45/2026 — decisão judicial
nos autos nº …”) a base de cada dado. Isto não é aconselhamento jurídico; confirme com a
autoridade responsável e a jurisprudência atual.

## 6. OPSEC do analista

- Prefira processamento local (esta skill não envia dados a terceiros). APIs externas só quando
  autorizado e configurado; nunca envie identificadores do caso a serviços públicos sem avaliar
  o risco de alertar o investigado ou expor a vítima.
- Visualizador: `--inline-libs` e `--no-tiles` para estações isoladas.
- Consultas a infraestrutura do investigado (acessar o domínio, resolver DNS dele) podem ser
  registradas pelo alvo; use ambiente de pesquisa adequado e registre a decisão.
- Mascare dados de vítimas ao compartilhar exemplos ou pedir ajuda externa.
