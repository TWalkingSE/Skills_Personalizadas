# Modelo de dados do caso

Sumário: 1. Estrutura geral · 2. Caso · 3. Entidade · 4. Relacionamento · 5. Observação ·
6. Evento · 7. Fonte · 8. Evidência · 9. Hipótese · 10. Consulta OSINT · 11. Snapshot e auditoria ·
12. Vocabulários · 13. Operações em lote · 14. Normalização

O caso é um único JSON (`schema_version: "1.0"`). A biblioteca `scripts/case_model.py` é a
referência executável — em caso de dúvida, ela prevalece sobre este texto.

## 1. Estrutura geral

```
CASE ─┬─ entities[]        nós do grafo
      ├─ relationships[]   arestas (direcionadas ou não)
      ├─ observations[]    afirmações contextualizadas (quem disse o quê, quando, como)
      ├─ events[]          ocorrências datadas com participantes
      ├─ sources[]         origem da informação
      ├─ evidence[]        arquivos/documentos com hash e custódia
      ├─ hypotheses[]      proposições com evidências favoráveis/contrárias
      ├─ osint_queries[]   registro de consultas externas
      ├─ snapshots[]       versões (arquivos em snapshots/ com SHA-256)
      ├─ audit_log[]       trilha de auditoria
      ├─ positions{}       posições dos nós no visualizador
      └─ groups[]          agrupamentos visuais {id, label, members[]}
```

IDs: `E-0001` entidade, `R-` relação, `O-` observação, `EV-` evento, `S-` fonte, `D-` evidência,
`H-` hipótese, `Q-` consulta OSINT, `SN-` snapshot. Gerados automaticamente; não reutilize.

## 2. Caso (`case`)

`id, title, description, objective, lead, team[], created_at, updated_at, classification
(OSTENSIVO|RESERVADO|SIGILOSO|SECRETO), status (aberto|em_analise|suspenso|concluido|arquivado),
tags[], notes, custom_entity_types{chave: rótulo}, custom_relationship_types[],
rejected_matches[[id,id]], match_decisions{"A|B": {decision, by, at}}`.

## 3. Entidade

| Campo | Observação |
|---|---|
| `type` | tipo nativo (ver §12) ou personalizado — tipos novos são registrados em `custom_entity_types` |
| `label`, `label_normalized` | rótulo exibido e forma normalizada (maiúsculas, sem acento) para matching |
| `identifiers` | `{cpf: {original, normalized, valid, note}, telefone: {...}}` — o original nunca é descartado |
| `aliases[]` | outros nomes (inclusive os absorvidos em merge) |
| `attributes{}` | atributos livres (`data_nascimento`, `nome_mae`, `banco`, `agencia`...) |
| `description`, `start`, `end` | período de existência/validade |
| `location` | `{lat, lon, address, precision_m}` |
| `source_ids[]`, `evidence_ids[]` | vínculos de proveniência |
| `nature`, `confidence`, `status` | ver §12 |
| `tags[]`, `notes` | |
| `provenance` | preenchido em importações: arquivo, SHA-256, linhas/ocorrências, método |
| `merged_from[]` | snapshots das entidades absorvidas + motivo (permite reverter) |
| `promoted_from`, `confirmed_by` | registro de promoção para fato / confirmação humana |
| `created_by`, `created_at`, `updated_at` | |

## 4. Relacionamento

`id, type, directed, source, target, start, end, source_ids[], evidence_ids[], nature,
confidence, status, notes, attributes{amount, currency, duracao_seg, ...}, origin
(manual|importação|visualizador), author, created_at, updated_at, provenance, promoted_from`.

- Tipos em `UNDIRECTED_TYPES` (conhece, relacionado a, associado a, compartilha, conectado a)
  nascem não direcionados.
- `reside em` é **exclusivo**: dois destinos simultâneos para a mesma origem geram contradição.
- Fluxo financeiro: `transferiu` (origem → destino) com `attributes.amount`; `recebeu`/`recebeu de`
  são interpretados no sentido inverso.

## 5. Observação

Representa uma afirmação **no contexto em que foi feita**:
`statement, entity_id, relationship_id, attribute, value, observed_at, source_id, evidence_id,
method, nature, confidence, author, notes`.

Use quando a mesma informação vem de várias fontes, quando há divergência de valores (a
detecção de contradições compara `attribute`/`value` de valor único — ver `SINGLE_VALUED_ATTRIBUTES`)
ou quando o “quem disse” importa (depoimentos).

## 6. Evento

`title, type, start, start_original, end, date_precision (exata|dia|mes|ano|aproximada|desconhecida),
participants[], location, relationship_ids[], source_ids[], evidence_ids[], description,
attributes{amount, from, to, ...}, nature, confidence, status`.

Transferências registradas como evento e como relação são deduplicadas na análise financeira
(mesmo par, valor e horário ±5 min, ou `relationship_ids` apontando para a relação).

## 7. Fonte

`type` (§12), `title, reference, date, url, accessed_at, reliability` (A–F, Admiralty), `credibility` (1–6), `level` (primaria/secundaria), `notes`. O tipo sugere a natureza padrão
dos itens que a citam (`SOURCE_DEFAULT_NATURE`), sempre ajustável.

## 8. Evidência

`name, type, origin, source_id, description, acquired_at, created_at, storage_path, hashes
{sha256, sha512?, md5?}, size, entity_ids[], relationship_ids[], custody[{ts, user, action, hashes?}],
registered_by, registered_at`.

SHA-256 é o padrão; SHA-512 opcional; MD5 só como referência legada (`--md5`). O pacote do caso
recalcula e confere o hash antes de incluir arquivos.

## 9. Hipótese

`title, statement, supporting[ids], contradicting[ids], gaps[], confidence (0–100, juízo do
analista), status (aberta|em_analise|sustentada|enfraquecida|confirmada|rejeitada),
related_ids[], notes`. `supporting/contradicting` aceitam IDs de relações, entidades, eventos,
observações ou evidências.

## 10. Consulta OSINT

`query, tool, date, result_summary, entity_ids[], evidence_id, limitations, legal_basis, user`.

## 11. Snapshot e auditoria

Snapshot: `{id, label, created_at, sha256, path, counts}` — o arquivo fica em `snapshots/` ao lado
do caso; `restore` confere o hash antes de restaurar e preserva a auditoria.

Auditoria: `{ts, user, action, object_type, object_id, before, after, reason, origin?}`. Ações:
criação, edição, exclusão (com conteúdo excluído em `before`), importação, merge, rejeição,
confirmação, análise, consulta externa, geração de relatório, exportação, snapshot, restauração.

## 12. Vocabulários

- **Natureza**: fato (OFFICIAL) · observado (OBSERVED) · declarado (DECLARED) · correlacao (CORRELATED) · inferencia (INFERRED) · hipotese (HYPOTHESIS) · nao_verificado (UNVERIFIED) — os termos em inglês do contrato também são aceitos na entrada
- **Confiança**: muito_baixa (0,1) · baixa (0,3) · media (0,5) · alta (0,7) · muito_alta (0,9);
  também aceita 0–1 ou 0–100.
- **Status**: confirmado · nao_confirmado · hipotese · em_analise · rejeitado · contraditorio · arquivado
- **Entidades nativas**: pessoa, empresa, organizacao, endereco, telefone, email, cpf, cnpj,
  documento, conta_bancaria, pix, cartao, veiculo, ip, dominio, url, usuario, perfil_social,
  dispositivo, imei, mac, asn, prefixo_ip, certificado, arquivo, evento, localizacao, transacao,
  processo, ocorrencia, boletim, evidencia, imagem, audio, video, outro
- **Relações sugeridas**: possui, utiliza, pertence a, reside em, trabalha em, sócio de,
  administrador de, proprietário de, transferiu, recebeu, telefonou, enviou mensagem, acessou,
  conectado a, associado a, localizado em, visitou, esteve em, controla, representa, conhece,
  relacionado a, compartilha, originou, recebeu de, encaminhou para, resolve para, anunciado por,
  hospedado em, emitido para, registrado por (novos tipos são aceitos)
- **Eventos**: ligacao, mensagem, transferencia, saque, deposito, login, acesso, viagem, encontro,
  criacao_conta, abertura_empresa, alteracao_cadastral, ocorrencia, apreensao, busca,
  evento_policial, evento_financeiro, evento_digital, personalizado
- **Fontes**: documento_oficial, boletim, depoimento, sistema_institucional, banco_de_dados,
  arquivo_fornecido, pagina_web, api, consulta_osint, log, imagem, video, audio,
  fonte_secundaria, fonte_desconhecida
- **Evidências**: pdf, documento, imagem, screenshot, audio, video, planilha, csv, json, xml, txt,
  email, exportacao_aplicativo, log, relatorio, extrato, boletim, outro

## 13. Operações em lote (`nb.py batch`)

Lista de objetos `{"op": ..., "ref"?: ..., <parâmetros>}` aplicada em ordem. `ref` nomeia o ID
gerado; `"@ref"` em qualquer valor (inclusive dentro de listas/dicionários) é substituído pelo ID.

| op | parâmetros (além dos opcionais do modelo) |
|---|---|
| `source` | `type, title` |
| `evidence` | `name, type, file_path?` (calcula hash se o arquivo existir) |
| `entity` | `type, label` |
| `rel` / `relationship` | `source, type, target` (aceita ID, rótulo ou alias) |
| `event` | `title, type, start?, participants[]` |
| `obs` / `observation` | `statement, entity_id?, attribute?, value?, source_id?` |
| `hypothesis` | `title, supporting[], contradicting[], gaps[], confidence, status` |
| `osint` | `query, tool, result_summary, entity_ids[], limitations` |
| `update` | `id, set{...}, reason?` (promoção a fato exige `reason`) |
| `delete` | `id, reason` |
| `merge` | `keep, merge, reason` |

Uma falha interrompe o lote informando o número da operação; o arquivo do caso só é salvo se
todas as operações forem aplicadas.

## 14. Normalização (`normalize(kind, value)`)

Retorna `{original, normalized, valid, note}`:
CPF/CNPJ (dígitos + dígitos verificadores) · telefone (E.164, assume +55 para 10–11 dígitos) ·
e-mail (minúsculas) · IP (forma canônica, nota privado/reservado) · prefixo IP · domínio
(minúsculas, IDNA, “refang” de `[.]`) · URL (`hxxp`→`http`) · placa (Mercosul/anterior) · nome e
endereço (maiúsculas sem acento, abreviações expandidas) · data (ISO + precisão) · valor (R$ →
float) · IMEI (Luhn) · MAC · ASN · PIX (detecta e-mail, CPF, CNPJ, telefone, aleatória).

## 13. Análises (`analyses[]`, prefixo AN-)

Registro reproduzível de cada análise feita sobre o caso (contrato ANALYSIS): `type`, `method`,
`parameters{}`, `input_entities[]`, `result`, `confidence`, `limitations`, `nature` (normalmente
`inferencia`/`correlacao`), `tool`, `tool_version`, `created_by`, `created_at`. As skills de
inteligência registram as suas via `import-bundle` (op `analysis`); aparecem no relatório (seção de
fontes) e no visualizador (Achados → Análises registradas).
