# Contrato de dados `intel-bundle/1.0`

Sumário: 1. Por que um contrato comum · 2. Estrutura · 3. Operações · 4. Proveniência (locator) ·
5. Natureza, confiança e confiabilidade da fonte · 6. Entity resolution na importação · 7. Indicadores (IOC) ·
8. Exemplo mínimo · 9. Biblioteca `intel_contract.py` · 10. Correspondência com o contrato da plataforma ·
11. Regras gerais

## 1. Por que um contrato comum

As skills especializadas são motores de coleta, extração e análise; o **Investigative Notebook** é
a camada de visualização e gestão do caso. Todas entregam o mesmo formato, de modo que o mesmo
CPF, conta, telefone, IP, domínio, hash ou perfil vindo de skills diferentes cai na mesma entidade
do caso — com todas as proveniências.

```
DOCUMENT INTELLIGENCE ─┐
FINANCIAL INTELLIGENCE ┤
SOCIAL MEDIA INTEL. ───┤
MALWARE/ARTIFACT ──────┤
OSINT INTELLIGENCE ────┼──► intel-bundle/1.0 ──► nb.py import-bundle ──► KNOWLEDGE GRAPH (caso.json)
LINK ANALYSIS ─────────┤                                                     │
TIMELINE & GEOSPATIAL ─┤                    ENTITY RESOLUTION (consistência) ─┤ (lê e decide sobre o caso)
HYPOTHESIS ENGINE ─────┤                    EVIDENCE & PROVENANCE (rastreio) ─┤
CASE CORRELATION ──────┘                    CASE CORRELATION (entre casos) ───┘
```

Entity Resolution e Evidence & Provenance trabalham **diretamente sobre o caso** (fila de revisão,
merge com histórico, custódia, verificação de hashes); as demais produzem bundles.

## 2. Estrutura

```json
{
  "contract": "intel-bundle/1.0",
  "producer": "document-intelligence", "producer_version": "1.0",
  "generated_at": "2026-10-07T16:00:00-03:00",
  "case_ref": "IPL 045/2026", "legal_basis": "Ofício 51/2026 — decisão nos autos …", "analyst": "…",
  "summary": {"entity": 43, "rel": 27, ...},
  "items": [ ... operações em ordem ... ],
  "findings": [ ... achados do produtor (contradições, anomalias, padrões) ... ],
  "validation": [ ... alertas da validação no momento da gravação ... ]
}
```

## 3. Operações (`items[]`)

Cada item tem `op`, `ref` (nome local) e parâmetros. Valores `"@ref"` apontam para itens
anteriores do mesmo bundle.

| op | campos principais |
|---|---|
| `source` | `type` (documento_oficial, boletim, depoimento, sistema_institucional, banco_de_dados, log, consulta_osint, pagina_web, api, arquivo_fornecido, fonte_secundaria…), `title`, `reference`, `date`, `url`, `accessed_at` (data/hora da consulta), `reliability` (A–F), `credibility` (1–6), `level` (primaria \| secundaria) |
| `evidence` | `name`, `type`, `sha256` (+ `sha512`, `md5`, `sha1` opcionais), `file_path?`, `source_id`, `acquired_at`, `origin` |
| `entity` | `type`, `label`, `identifiers{}`, `attributes{}`, `aliases[]`, `nature`, `confidence`, `source_ids[]`, `evidence_ids[]`, `provenance[]`, `location?`, `tags[]` |
| `indicator` | como `entity`, com `attributes.ioc_type`, `tlp`, `first_seen`, `last_seen`; recebe a tag `IOC` |
| `rel` | `source`, `type`, `target`, `start`, `end`, `attributes{amount, txid, …}`, `nature`, `confidence`, `source_ids`, `evidence_ids`, `provenance[]`, `notes` |
| `event` | `title`, `type`, `start`, `participants[]`, `attributes{amount, from, to…}`, `nature`, `provenance[]` |
| `obs` | `statement`, `entity_id`, `attribute`, `value`, `source_id`, `evidence_id`, `method`, `nature`, `provenance[]` |
| `hypothesis` | `title`, `supporting[]`, `contradicting[]`, `gaps[]`, `confidence`, `status` |
| `osint` | `query`, `tool`, `result_summary`, `entity_ids[]`, `limitations`, `legal_basis`, `url`, `snippet`, `reliability` |
| `analysis` | `type`, `method`, `result`, `input_entities[]`, `parameters{}`, `confidence`, `limitations`, `nature`, `tool`, `tool_version` — registro reproduzível de uma análise (vai para `case.analyses`, prefixo `AN-`) |

Tipos de entidade: os do Notebook (pessoa, empresa, telefone, email, cpf, cnpj, endereco,
conta_bancaria, pix, veiculo, ip, dominio, url, usuario, perfil_social, dispositivo, asn,
prefixo_ip, certificado, arquivo, evento, localizacao, transacao, processo, boletim, documento,
instituicao, hash, indicador, aplicativo, mutex, chave_registro, …). Tipos novos são aceitos.

## 4. Proveniência (locator)

```json
{"document": "extrato.pdf", "doc_sha256": "08c6…", "doc_id": "DOC-08C6C3A838",
 "page": 4, "where": "§ 12 | Aba!C12 | cabeçalho Received | seção .text | AndroidManifest.xml",
 "line": 17, "char_start": 435, "char_end": 475, "bbox": [40, 112, 178, 122], "bbox_unit": "pt",
 "snippet": "Telefone: (79) 99999-0001", "context": "…", "method": "bloco de qualificação", "confidence": 0.85}
```
`cite(locator, "O telefone X")` → «O telefone X foi extraído da página 4 do documento extrato.pdf
(SHA-256 08c6…), linha 17, posição [40, 112, 178, 122] pt: «…» [método: …].» Para fontes não
documentais (consulta web, API, análise de binário) use `document` = nome da fonte/arquivo e
`where`/`snippet` com o trecho ou campo de origem.

## 5. Natureza, confiança e confiabilidade da fonte

| Contrato | Chave interna | Quando usar |
|---|---|---|
| OFFICIAL | `fato` | registro de fonte oficial: quebra de sigilo, resposta de ofício, sistema institucional, ordem judicial |
| OBSERVED | `observado` | verificação direta pelo analista/ferramenta: hash calculado, string presente no arquivo, perfil público capturado, metadado lido |
| DECLARED | `declarado` | afirmado por alguém: BO, depoimento, termo, autodeclaração |
| CORRELATED | `correlacao` | coincidência de atributos/estrutura (mesmo telefone, match de perfil, entidade compartilhada entre casos) |
| INFERRED | `inferencia` | resultado de raciocínio/algoritmo (centralidade, padrão financeiro, perfil de malware) |
| HYPOTHESIS | `hipotese` | explicação a testar |
| UNVERIFIED | `nao_verificado` | sem verificação (fonte aberta, recebido de terceiros) |

A biblioteca e o Notebook aceitam tanto a chave interna quanto o termo do contrato. O modo
`oficial` do grafo inclui `fato` e `observado`. Ninguém marca `fato`/`observado` sem fonte ou
evidência (a validação acusa) e nenhuma ferramenta promove inferência a fato: isso exige
`update` com fundamentação (`promoted_from`). Padrões algorítmicos dizem "compatível com", nunca
afirmam crime ou autoria. `confidence`: muito_baixa … muito_alta (ou 0–1).

Confiabilidade da fonte (escala Admiralty): **A** completamente confiável · **B** geralmente ·
**C** razoavelmente · **D** geralmente não confiável · **E** não confiável · **F** não avaliável.
Credibilidade da informação: **1** confirmada por outras fontes · **2** provavelmente verdadeira ·
**3** possivelmente · **4** duvidosa · **5** improvável · **6** não avaliável. Fonte **primária** é a
origem do dado (cartório, plataforma, banco); **secundária** a reproduz (notícia, agregador, buscador).

## 6. Entity resolution na importação (`nb.py import-bundle`)

- **Unifica** quando um identificador forte normalizado coincide: cpf, cnpj, telefone, email,
  ip, prefixo_ip, dominio, url, placa, pix, imei, mac, asn, sha256/sha1/md5/sha512,
  conta_bancaria **completa** (`banco|agência|conta` sem `?`), processo, perfil
  (`plataforma:usuario`), username, e2e, chassi, renavam, certificado_sha256, pacote_android.
- Pessoa/empresa com mesmo CPF/CNPJ mas **nome incompatível** → não unifica; ambas ficam
  `contraditorio` e uma observação registra a contradição.
- **Nunca** unifica por nome — homônimos ficam para o Smart Match e a decisão humana.
- Fontes: (tipo, título, referência); evidências: SHA-256; relações: (origem, tipo, destino,
  início, valor, txid); eventos: (tipo, início ±minuto, participantes, valor).
- Atributo divergente de entidade existente vira OBSERVAÇÃO (a detecção de contradições do
  Notebook a encontra). Natureza existente nunca é promovida pelo bundle.

## 7. Indicadores (IOC)

`indicator` com `ioc_type` ∈ ip, domain, url, email, hash/sha256/sha1/md5, file, certificate,
mutex, registry, asn, user_agent, path, apk. Tipo de entidade derivado (ip → ip, domain →
dominio, hash → hash, …). Exibir sempre *defanged* em relatórios (`hxxp`, `[.]`); armazenar o
valor real normalizado.

## 8. Exemplo mínimo

```json
{"contract":"intel-bundle/1.0","producer":"exemplo","items":[
 {"op":"source","ref":"s1","type":"documento_oficial","title":"Extrato Banco X","reference":"Ofício 45/2026"},
 {"op":"evidence","ref":"d1","name":"extrato.pdf","type":"extrato","sha256":"08c6…","source_id":"@s1"},
 {"op":"entity","ref":"p","type":"pessoa","label":"João da Silva","identifiers":{"cpf":"246.813.579-28"},
  "nature":"fato","confidence":"alta","source_ids":["@s1"],"evidence_ids":["@d1"],
  "provenance":[{"document":"extrato.pdf","page":1,"line":2,"snippet":"Titular: JOÃO DA SILVA"}]},
 {"op":"entity","ref":"c","type":"conta_bancaria","label":"Conta 999/1234/12345-6",
  "identifiers":{"conta_bancaria":"banco 999 ag 1234 cc 12345-6"},"nature":"fato","source_ids":["@s1"]},
 {"op":"rel","source":"@p","type":"possui","target":"@c","nature":"fato","source_ids":["@s1"],"evidence_ids":["@d1"],
  "provenance":[{"document":"extrato.pdf","page":1,"line":2,"snippet":"Titular: JOÃO DA SILVA"}]}]}
```

## 9. Biblioteca `intel_contract.py`

```python
from intel_contract import Bundle, locator, cite
b = Bundle("minha-skill", "1.0", case_ref="IPL 045/2026", legal_basis="…")
s = b.source("documento_oficial", "Extrato", reference="Ofício 45/2026")
d = b.evidence("extrato.pdf", "extrato", file_path="extrato.pdf", source_id=s)
loc = locator("extrato.pdf", page=1, line=2, snippet="Titular: JOÃO DA SILVA", method="cabeçalho")
p = b.entity("pessoa", "JOÃO DA SILVA", {"cpf": "246.813.579-28"}, nature="fato", source_ids=[s], evidence_ids=[d], provenance=loc)
b.indicator("domain", "loja-ferreira.example", provenance=loc)
b.save("saida.bundle.json", findings=[...])   # valida antes de gravar
```
Dentro de um mesmo bundle, entidades com o mesmo identificador forte são agregadas
automaticamente (acumulando proveniência), salvo pessoas/empresas com nomes incompatíveis.

## 10. Correspondência com o contrato da plataforma

| Objeto do contrato | Onde fica no caso / bundle |
|---|---|
| ENTITY `id, type, name, aliases, attributes, source_ids, evidence_ids, confidence, status, created_at, updated_at` | `entities[]`: `name` = `label`; `identifiers{}` guarda valor original **e** normalizado |
| RELATIONSHIP `source_entity, target_entity, direction, start_time, end_time …` | `relationships[]`: `source`, `target`, `directed`, `start`, `end` |
| EVENT `start_time, end_time, location, entity_ids …` | `events[]`: `start`, `end`, `location{address, lat, lon, precision}`, `participants[]` |
| SOURCE `name, url, accessed_at, description, reliability` | `sources[]`: `title`, `url`, `accessed_at`, `notes`, `reliability` + `credibility`, `level` |
| EVIDENCE `hash, hash_algorithm, file_reference, page, excerpt, acquired_at` | `evidence[]`: `hashes{sha256, sha512, md5…}` (SHA-256 é o identificador de integridade), `storage_path`, `acquired_at`, `custody[]`; página/trecho ficam no `provenance` de cada item extraído |
| HYPOTHESIS | `hypotheses[]`: `title`, `statement`, `supporting[]`, `contradicting[]`, `gaps[]`, `confidence`, `status` |
| ANALYSIS | `analyses[]` (op `analysis`) |
| INDICATOR `type, value, source, first_seen, last_seen, confidence` | entidade com tag `IOC` e `attributes.ioc_type`, `first_seen`, `last_seen` (op `indicator`) |

## 11. Regras gerais (todas as skills)

1. Toda informação tem origem (`source_ids`/`evidence_ids` + `provenance`).
2. Inferência, hipótese e correlação são identificadas pela natureza; correlações informam fatores.
3. Análises são registradas (`analysis`) com método, parâmetros e limitações — reproduzíveis.
4. Dados originais nunca são sobrescritos: valor original e normalizado convivem; divergências
   viram observações; merge só por decisão humana registrada, preservando o histórico.
5. Coincidência não é identificação; padrão não é crime nem autoria; contradições não são ocultadas.
6. Consultas externas e ferramentas usadas são registradas (`osint`, `analysis.tool/tool_version`).
7. Toda alteração passa pela trilha de auditoria do caso e permite revisão humana.
